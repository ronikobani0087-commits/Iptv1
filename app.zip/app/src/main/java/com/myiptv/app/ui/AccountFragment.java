package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.AccountInfo;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.util.List;

/** "الحساب": the saved playlists as glass tiles, plus a "+" tile that opens the add-playlist form. */
public class AccountFragment extends Fragment {
    private LinearLayout row;
    private TextView status;
    private boolean busy;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        FrameLayout page = new FrameLayout(c);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, 20), Ui.dp(c, 24), Ui.dp(c, 20));
        page.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(c);
        title.setText("قوائم التشغيل");
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        col.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        HorizontalScrollView hs = new HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setClipToPadding(false);
        row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        hs.addView(row, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = Ui.dp(c, 16);
        col.addView(hs, hp);

        status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.muted));
        status.setTextSize(14);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = Ui.dp(c, 12);
        col.addView(status, sp);

        buildTiles(null);
        return page;
    }

    @Override
    public void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            final List<Playlist> all = AppDatabase.get(app).dao().getPlaylists();
            Async.main(() -> {
                if (isAdded()) buildTiles(all);
            });
        });
    }

    private void buildTiles(@Nullable List<Playlist> all) {
        Context c = requireContext();
        row.removeAllViews();
        row.addView(addTile(c), tileLp(c));
        if (all == null) return;
        long active = Prefs.getActive(c);
        for (Playlist p : all) row.addView(listTile(c, p, p.id == active), tileLp(c));
    }

    private static LinearLayout.LayoutParams tileLp(Context c) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(c, 230), Ui.dp(c, 170));
        lp.setMarginEnd(Ui.dp(c, 14));
        return lp;
    }

    private View addTile(Context c) {
        LinearLayout t = baseTile(c);
        t.setGravity(Gravity.CENTER);
        TextView plus = new TextView(c);
        plus.setText("+");
        plus.setGravity(Gravity.CENTER);
        plus.setIncludeFontPadding(false);
        plus.setTextSize(34);
        plus.setTextColor(ContextCompat.getColor(c, R.color.text));
        plus.setBackgroundResource(R.drawable.bg_tab);
        plus.setSelected(true);
        t.addView(plus, new LinearLayout.LayoutParams(Ui.dp(c, 60), Ui.dp(c, 60)));
        TextView tv = new TextView(c);
        tv.setText("أضف قائمة التشغيل");
        tv.setTextColor(ContextCompat.getColor(c, R.color.muted));
        tv.setTextSize(15);
        tv.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 12);
        t.addView(tv, lp);
        t.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).openAddForm();
        });
        return t;
    }

    private View listTile(final Context c, final Playlist p, boolean active) {
        LinearLayout t = baseTile(c);
        t.setPadding(Ui.dp(c, 14), Ui.dp(c, 12), Ui.dp(c, 14), Ui.dp(c, 10));

        TextView name = new TextView(c);
        name.setText((active ? "✓ " : "") + p.name);
        name.setTextColor(ContextCompat.getColor(c, R.color.text));
        name.setTextSize(17);
        name.setTypeface(Typeface.DEFAULT_BOLD);
        name.setMaxLines(1);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        name.setGravity(Gravity.START);
        t.addView(name);

        String host = p.url;
        try {
            String h = android.net.Uri.parse(p.url).getHost();
            if (h != null) host = h;
        } catch (Exception ignored) {
        }
        TextView sub = new TextView(c);
        sub.setText(("xtream".equals(p.type) ? "Xtream · " : "M3U · ") + host);
        sub.setTextColor(ContextCompat.getColor(c, R.color.muted));
        sub.setTextSize(12);
        sub.setMaxLines(1);
        sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
        sub.setTextDirection(View.TEXT_DIRECTION_LTR);
        sub.setGravity(Gravity.START);
        t.addView(sub, topMargin(c, 4));

        final TextView exp = new TextView(c);
        exp.setTextColor(ContextCompat.getColor(c, R.color.text));
        exp.setTextSize(13);
        exp.setGravity(Gravity.START);
        if ("xtream".equals(p.type)) {
            String cached = AccountInfo.cached(c, p.id);
            exp.setText("ينتهي: " + (cached.isEmpty() ? "…" : cached));
            final Context app = c.getApplicationContext();
            Async.io(() -> {
                final String d = AccountInfo.fetch(app, p.id);
                Async.main(() -> {
                    if (isAdded() && !d.isEmpty()) exp.setText("ينتهي: " + d);
                });
            });
        } else {
            exp.setText("تاريخ الانتهاء غير متوفر");
        }
        t.addView(exp, topMargin(c, 6));

        View spacer = new View(c);
        t.addView(spacer, new LinearLayout.LayoutParams(1, 0, 1f));

        LinearLayout actions = new LinearLayout(c);
        actions.setOrientation(LinearLayout.HORIZONTAL);
        TextView upd = Ui.button(c, "تحديث", false);
        upd.setTextSize(12);
        upd.setPadding(Ui.dp(c, 10), Ui.dp(c, 5), Ui.dp(c, 10), Ui.dp(c, 5));
        upd.setOnClickListener(v -> refresh(p));
        TextView del = Ui.button(c, "حذف", false);
        del.setTextSize(12);
        del.setPadding(Ui.dp(c, 10), Ui.dp(c, 5), Ui.dp(c, 10), Ui.dp(c, 5));
        del.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).confirmLogout(p.id);
        });
        actions.addView(upd);
        LinearLayout.LayoutParams dlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        dlp.setMarginStart(Ui.dp(c, 8));
        actions.addView(del, dlp);
        t.addView(actions);

        t.setOnClickListener(v -> {
            Prefs.setActive(c.getApplicationContext(), p.id);
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).goHome();
        });
        return t;
    }

    private static LinearLayout.LayoutParams topMargin(Context c, int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, dp);
        return lp;
    }

    private LinearLayout baseTile(Context c) {
        LinearLayout t = new LinearLayout(c);
        t.setOrientation(LinearLayout.VERTICAL);
        t.setBackgroundResource(R.drawable.bg_card_focus);
        t.setFocusable(true);
        t.setClickable(true);
        return t;
    }

    private void refresh(Playlist p) {
        if (busy) return;
        busy = true;
        status.setText("جارٍ التحديث…");
        SyncRepository.sync(requireContext().getApplicationContext(), p.id, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
                if (isAdded()) status.setText(message);
            }

            @Override
            public void onDone() {
                busy = false;
                if (!isAdded()) return;
                status.setText("تم تحديث القائمة");
                reload();
            }

            @Override
            public void onError(String message) {
                busy = false;
                if (isAdded()) status.setText("تعذر التحديث: " + message);
            }
        });
    }
}
