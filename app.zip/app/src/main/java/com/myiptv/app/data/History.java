package com.myiptv.app.data;

import androidx.room.Entity;
import androidx.room.Index;
import androidx.room.PrimaryKey;

/** Last watched episode of a series, with the position to resume from. */
@Entity(tableName = "history",
        indices = {@Index(value = {"playlistId", "type", "remoteId"}, unique = true)})
public class History {
    @PrimaryKey(autoGenerate = true)
    public long id;
    public long playlistId;
    public String type;
    /** Series id. */
    public String remoteId;
    /** Series name. */
    public String name;
    public String icon;
    public String episodeTitle;
    public String streamUrl;
    public long positionMs;
    /** Length of the episode when it was last watched (0 = unknown). */
    public long durationMs;
    public long updatedAt;
}
