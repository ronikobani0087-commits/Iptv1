package com.myiptv.app.util;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.util.LruCache;

import java.io.File;
import java.io.FileOutputStream;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Small picture of an episode: a frame taken from the video itself, just after its second minute
 * (past the intro, so it shows real scenes). Frames are cached in memory and on disk, so each
 * episode is only read from the network once.
 */
public final class EpisodeThumbs {
    /** Where in the episode the frame is taken: 2 min 05 s. */
    private static final long FRAME_AT_US = 125_000_000L;
    private static final int MAX_W = 480;

    public interface Callback {
        void onThumb(Bitmap bitmap);
    }

    private static final LruCache<String, Bitmap> MEM = new LruCache<String, Bitmap>(24) {
    };
    /** Two at a time: reading a frame over the network is slow and must not starve the player. */
    private static final ExecutorService POOL = Executors.newFixedThreadPool(2);
    private static final HashMap<String, Boolean> FAILED = new HashMap<>();

    private EpisodeThumbs() {}

    /** Returns the frame through {@code cb} on the main thread; does nothing when it cannot be read. */
    public static void load(Context context, final String videoUrl, final Callback cb) {
        if (videoUrl == null || !videoUrl.startsWith("http")) return;
        final Context app = context.getApplicationContext();
        final String key = md5(videoUrl);
        Bitmap hit = MEM.get(key);
        if (hit != null) {
            cb.onThumb(hit);
            return;
        }
        synchronized (FAILED) {
            if (FAILED.containsKey(key)) return;
        }
        POOL.execute(() -> {
            Bitmap bmp = fromDisk(app, key);
            if (bmp == null) {
                bmp = fromVideo(videoUrl);
                if (bmp != null) toDisk(app, key, bmp);
            }
            if (bmp == null) {
                synchronized (FAILED) {
                    FAILED.put(key, Boolean.TRUE);
                }
                return;
            }
            final Bitmap result = bmp;
            MEM.put(key, result);
            Async.main(() -> cb.onThumb(result));
        });
    }

    private static Bitmap fromVideo(String videoUrl) {
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            java.util.HashMap<String, String> headers = new java.util.HashMap<>();
            headers.put("User-Agent", "Mozilla/5.0 (Linux; Android 11) IPTVPlayer/0.1");
            mmr.setDataSource(videoUrl, headers);
            long at = FRAME_AT_US;
            String d = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (d != null) {
                try {
                    long durUs = Long.parseLong(d) * 1000L;
                    if (durUs > 0 && durUs <= at) at = durUs / 2; // very short clip: take the middle
                } catch (NumberFormatException ignored) {
                    // keep the default time
                }
            }
            Bitmap f = mmr.getFrameAtTime(at, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (f == null) f = mmr.getFrameAtTime(at);
            if (f == null) return null;
            if (f.getWidth() > MAX_W) {
                int h = Math.round(f.getHeight() * (MAX_W / (float) f.getWidth()));
                Bitmap s = Bitmap.createScaledBitmap(f, MAX_W, Math.max(1, h), true);
                if (s != f) f.recycle();
                f = s;
            }
            return f;
        } catch (Exception | OutOfMemoryError e) {
            return null;
        } finally {
            try {
                mmr.release();
            } catch (Exception ignored) {
                // nothing to release
            }
        }
    }

    private static File fileFor(Context app, String key) {
        File dir = new File(app.getCacheDir(), "ep_thumbs");
        if (!dir.exists()) dir.mkdirs();
        return new File(dir, key + ".jpg");
    }

    private static Bitmap fromDisk(Context app, String key) {
        File f = fileFor(app, key);
        if (!f.isFile() || f.length() == 0) return null;
        try {
            return BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Exception | OutOfMemoryError e) {
            return null;
        }
    }

    private static void toDisk(Context app, String key, Bitmap b) {
        File f = fileFor(app, key);
        try (FileOutputStream os = new FileOutputStream(f)) {
            b.compress(Bitmap.CompressFormat.JPEG, 85, os);
        } catch (Exception e) {
            f.delete();
        }
    }

    private static String md5(String s) {
        try {
            byte[] d = MessageDigest.getInstance("MD5").digest(s.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : d) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(s.hashCode());
        }
    }
}
