package com.myiptv.app.data;

/** Query result: the name and the real logo of a live channel. */
public class NameLogo {
    public String name;
    public String icon;
}
