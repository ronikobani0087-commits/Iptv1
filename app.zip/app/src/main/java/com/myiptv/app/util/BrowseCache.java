package com.myiptv.app.util;

import android.util.LruCache;

import com.myiptv.app.data.Item;

import java.util.List;

/**
 * Remembers the cards of the packages already opened in movies / series, so going back to a
 * package (or back to the section) shows at once instead of reading the database again.
 * Cleared whenever the library is refreshed or the order is changed.
 */
public final class BrowseCache {
    private static final LruCache<String, List<Item>> ITEMS = new LruCache<>(10);

    private BrowseCache() {}

    public static String key(long pid, String type, String cat) {
        return pid + "|" + type + "|" + cat;
    }

    public static synchronized List<Item> get(String key) {
        return ITEMS.get(key);
    }

    public static synchronized void put(String key, List<Item> items) {
        if (items != null && !items.isEmpty()) ITEMS.put(key, items);
    }

    public static synchronized void clear() {
        ITEMS.evictAll();
    }
}
