package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.text.InputType;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDao;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.PlaylistFactory;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.AccountInfo;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.util.List;

/**
 * Press and hold on a server card: one menu with connect / edit / delete.
 * Shared by the settings screen and the accounts screen.
 */
public final class ServerDialogs {
    private ServerDialogs() {}

    // ------------------------------------------------------------------ menu

    /** The menu itself: اتصال · تعديل · حذف. {@code onChanged} runs on the main thread after any change. */
    public static void showActions(final Fragment host, final Playlist p, final boolean isActive,
                                   final Runnable onChanged) {
        if (!host.isAdded()) return;
        final Context c = host.requireContext();

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(Ui.dp(c, 22), Ui.dp(c, 18), Ui.dp(c, 22), Ui.dp(c, 12));

        TextView title = new TextView(c);
        title.setText(p.name == null ? "" : p.name);
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        title.setGravity(Gravity.START);
        title.setSingleLine(true);
        title.setEllipsize(TextUtils.TruncateAt.END);
        box.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sub = new TextView(c);
        sub.setText(hostOf(p));
        sub.setTextColor(ContextCompat.getColor(c, R.color.muted));
        sub.setTextSize(13);
        sub.setTextDirection(View.TEXT_DIRECTION_LTR);
        sub.setGravity(Gravity.START);
        sub.setSingleLine(true);
        box.addView(sub, lp(c, 2));

        final TextView connect = Ui.button(c, isActive ? "✓  متصل حالياً" : "اتصال بهذا السيرفر", !isActive);
        final TextView edit = Ui.button(c, "تعديل السيرفر", false);
        final TextView del = Ui.button(c, "حذف الاتصال", false);
        final TextView cancel = Ui.button(c, "إلغاء", false);
        box.addView(connect, lp(c, 16));
        box.addView(edit, lp(c, 8));
        box.addView(del, lp(c, 8));
        box.addView(cancel, lp(c, 8));

        final AlertDialog dlg = new AlertDialog.Builder(c).setView(box).create();
        style(dlg);

        connect.setOnClickListener(v -> {
            dlg.dismiss();
            if (!isActive) connect(host, p, onChanged);
        });
        edit.setOnClickListener(v -> {
            dlg.dismiss();
            showEdit(host, p, onChanged);
        });
        del.setOnClickListener(v -> {
            dlg.dismiss();
            confirmDelete(host, p, onChanged);
        });
        cancel.setOnClickListener(v -> dlg.dismiss());
        (isActive ? edit : connect).requestFocus();
    }

    // --------------------------------------------------------------- connect

    /** Leaves the connected server and connects to this one. */
    public static void connect(Fragment host, Playlist p, Runnable onChanged) {
        if (!host.isAdded()) return;
        final Context app = host.requireContext().getApplicationContext();
        Prefs.setActive(app, p.id);
        Prefs.markHomeDirty();
        if (host.getActivity() instanceof MainActivity) ((MainActivity) host.getActivity()).refreshExpiry();
        Toast.makeText(app, "تم الاتصال بالسيرفر: " + p.name, Toast.LENGTH_SHORT).show();
        if (onChanged != null) onChanged.run();
    }

    // ------------------------------------------------------------------ edit

    private static void showEdit(final Fragment host, final Playlist p, final Runnable onChanged) {
        if (!host.isAdded()) return;
        final Context c = host.requireContext();
        final boolean xtream = "xtream".equals(p.type);

        ScrollView scroll = new ScrollView(c);
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(Ui.dp(c, 22), Ui.dp(c, 18), Ui.dp(c, 22), Ui.dp(c, 12));
        scroll.addView(box, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(c);
        title.setText("تعديل السيرفر");
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(19);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setGravity(Gravity.START);
        box.addView(title);

        final EditText etName = field(c, "الاسم", p.name, false);
        final EditText etUrl = field(c, xtream ? "رابط السيرفر" : "رابط M3U", p.url, true);
        final EditText etUser = field(c, "اسم المستخدم", p.username, true);
        final EditText etPass = field(c, "كلمة المرور", p.password, true);
        etPass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);

        addLabeled(c, box, "الاسم", etName);
        addLabeled(c, box, xtream ? "رابط السيرفر" : "رابط M3U", etUrl);
        if (xtream) {
            addLabeled(c, box, "اسم المستخدم", etUser);
            addLabeled(c, box, "كلمة المرور", etPass);
        }

        final TextView status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.live_red));
        status.setTextSize(13);
        status.setGravity(Gravity.START);
        box.addView(status, lp(c, 8));

        final TextView save = Ui.button(c, "حفظ", true);
        final TextView cancel = Ui.button(c, "إلغاء", false);
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bp.setMarginEnd(Ui.dp(c, 8));
        row.addView(save, bp);
        row.addView(cancel, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        box.addView(row, lp(c, 8));

        final AlertDialog dlg = new AlertDialog.Builder(c).setView(scroll).create();
        style(dlg);

        cancel.setOnClickListener(v -> dlg.dismiss());
        save.setOnClickListener(v -> {
            Ui.hideKeyboard(v);
            final Playlist np;
            try {
                np = PlaylistFactory.build(etName.getText().toString(), etUrl.getText().toString(),
                        xtream ? etUser.getText().toString() : "",
                        xtream ? etPass.getText().toString() : "");
            } catch (IllegalArgumentException e) {
                status.setText(e.getMessage());
                return;
            }
            dlg.dismiss();
            applyEdit(host, p.id, np, onChanged);
        });
    }

    /** Saves the new values; when the connection details changed the library is read again from the server. */
    private static void applyEdit(final Fragment host, final long id, final Playlist np, final Runnable onChanged) {
        final Context app = host.requireContext().getApplicationContext();
        Async.io(() -> {
            final AppDao dao = AppDatabase.get(app).dao();
            final Playlist cur = dao.getPlaylist(id);
            if (cur == null) return;
            final Playlist backup = copyOf(cur);
            boolean connChanged = !same(cur.url, np.url) || !same(cur.type, np.type)
                    || !same(cur.username, np.username) || !same(cur.password, np.password);
            cur.name = np.name;
            cur.type = np.type;
            cur.url = np.url;
            cur.username = np.username;
            cur.password = np.password;
            dao.updatePlaylist(cur);
            Prefs.markHomeDirty();
            if (!connChanged) {
                Async.main(() -> {
                    Toast.makeText(app, "تم حفظ التعديل", Toast.LENGTH_SHORT).show();
                    changed(host, onChanged);
                });
                return;
            }
            Async.main(() -> {
                Toast.makeText(app, "جارٍ الاتصال بالسيرفر وتحديث المكتبة…", Toast.LENGTH_LONG).show();
                SyncRepository.sync(app, id, new SyncRepository.Callback() {
                    @Override
                    public void onProgress(String message) {
                    }

                    @Override
                    public void onDone() {
                        Async.io(() -> {
                            AccountInfo.fetch(app, id);
                            Async.main(() -> {
                                Toast.makeText(app, "تم حفظ التعديل والاتصال بالسيرفر", Toast.LENGTH_SHORT).show();
                                changed(host, onChanged);
                            });
                        });
                    }

                    @Override
                    public void onError(final String message) {
                        // the new details do not work: the old ones come back, nothing is lost
                        Async.io(() -> {
                            dao.updatePlaylist(backup);
                            Prefs.markHomeDirty();
                            Async.main(() -> {
                                Toast.makeText(app, "تعذر الاتصال بالبيانات الجديدة، أُعيدت القديمة: " + message,
                                        Toast.LENGTH_LONG).show();
                                changed(host, onChanged);
                            });
                        });
                    }
                });
            });
        });
    }

    // ---------------------------------------------------------------- delete

    private static void confirmDelete(final Fragment host, final Playlist p, final Runnable onChanged) {
        if (!host.isAdded()) return;
        final Context app = host.requireContext().getApplicationContext();
        final AlertDialog dlg = new AlertDialog.Builder(host.requireContext())
                .setMessage("حذف الاتصال بالسيرفر \"" + p.name + "\" وكل بياناته من الجهاز؟")
                .setPositiveButton("حذف الاتصال", (d, w) -> Async.io(() -> {
                    AppDao dao = AppDatabase.get(app).dao();
                    dao.deleteItems(p.id);
                    dao.deleteCategories(p.id);
                    dao.deletePlaylist(p.id);
                    final List<Playlist> rest = dao.getPlaylists();
                    if (Prefs.getActive(app) == p.id) {
                        Prefs.setActive(app, rest.isEmpty() ? -1 : rest.get(0).id);
                    }
                    Prefs.markHomeDirty();
                    Async.main(() -> {
                        changed(host, onChanged);
                        // the last server was removed: the add-account screen opens
                        if (rest.isEmpty() && host.isAdded() && host.getActivity() instanceof MainActivity) {
                            ((MainActivity) host.getActivity()).openAddPlaylist();
                        }
                    });
                }))
                .setNegativeButton("إلغاء", null)
                .create();
        style(dlg);
    }

    // --------------------------------------------------------------- helpers

    private static void changed(Fragment host, Runnable onChanged) {
        if (!host.isAdded()) return;
        if (host.getActivity() instanceof MainActivity) ((MainActivity) host.getActivity()).refreshExpiry();
        if (onChanged != null) onChanged.run();
    }

    private static Playlist copyOf(Playlist s) {
        Playlist d = new Playlist();
        d.id = s.id;
        d.name = s.name;
        d.type = s.type;
        d.url = s.url;
        d.username = s.username;
        d.password = s.password;
        d.updatedAt = s.updatedAt;
        return d;
    }

    private static boolean same(String a, String b) {
        return (a == null ? "" : a).equals(b == null ? "" : b);
    }

    private static String hostOf(Playlist p) {
        String host = p.url;
        try {
            String h = android.net.Uri.parse(p.url).getHost();
            if (h != null) host = h;
        } catch (Exception ignored) {
        }
        return ("xtream".equals(p.type) ? "Xtream · " : "M3U · ") + host;
    }

    private static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, topDp);
        return lp;
    }

    private static void addLabeled(Context c, LinearLayout box, String label, EditText field) {
        TextView t = new TextView(c);
        t.setText(label);
        t.setTextColor(ContextCompat.getColor(c, R.color.muted));
        t.setTextSize(13);
        t.setGravity(Gravity.START);
        box.addView(t, lp(c, 12));
        box.addView(field, lp(c, 4));
    }

    private static EditText field(Context c, String hint, String value, boolean ltr) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value == null ? "" : value);
        e.setHintTextColor(ContextCompat.getColor(c, R.color.muted));
        e.setTextColor(ContextCompat.getColor(c, R.color.text));
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setBackgroundResource(R.drawable.bg_field);
        e.setPadding(Ui.dp(c, 12), Ui.dp(c, 9), Ui.dp(c, 12), Ui.dp(c, 9));
        e.setTextDirection(ltr ? View.TEXT_DIRECTION_LTR : View.TEXT_DIRECTION_ANY_RTL);
        e.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        e.setInputType(InputType.TYPE_CLASS_TEXT | (ltr ? InputType.TYPE_TEXT_VARIATION_URI : 0));
        return e;
    }

    /** Shows the dialog with the app's dark glass background. */
    private static void style(AlertDialog dlg) {
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
    }
}
