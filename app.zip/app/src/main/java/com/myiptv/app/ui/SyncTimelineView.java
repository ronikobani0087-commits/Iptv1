package com.myiptv.app.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;

/**
 * Timeline of the first sync: account, channels, movies, series, done. Reads right to left. The line
 * fills with a cyan glow as each stage finishes, the current stage pulses.
 */
public class SyncTimelineView extends View {
    private static final String[] LABELS = {"الحساب", "القنوات", "الأفلام", "المسلسلات", "اكتمل"};
    private static final int CYAN = 0xFF2EE6F2;

    private final Paint base = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint node = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint halo = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);

    private int stage = 0;          // target stage
    private float shown = 0f;       // animated position of the glowing line (in stages)
    private float pulse = 0f;
    private ValueAnimator move, loop;

    public SyncTimelineView(Context c) {
        super(c);
        init();
    }

    public SyncTimelineView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        base.setStyle(Paint.Style.STROKE);
        base.setStrokeCap(Paint.Cap.ROUND);
        base.setColor(0x33FFFFFF);
        fill.setStyle(Paint.Style.STROKE);
        fill.setStrokeCap(Paint.Cap.ROUND);
        halo.setStyle(Paint.Style.STROKE);
        text.setTextAlign(Paint.Align.CENTER);
        setFocusable(false);
    }

    /** 0 = account ... 3 = series, 4 = done. */
    public void setStage(int s) {
        s = Math.max(0, Math.min(LABELS.length - 1, s));
        if (s == stage && move != null) return;
        stage = s;
        if (move != null) move.cancel();
        move = ValueAnimator.ofFloat(shown, stage);
        move.setDuration(650);
        move.setInterpolator(new DecelerateInterpolator());
        move.addUpdateListener(a -> {
            shown = (float) a.getAnimatedValue();
            invalidate();
        });
        move.start();
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        loop = ValueAnimator.ofFloat(0f, 1f);
        loop.setDuration(1400);
        loop.setRepeatCount(ValueAnimator.INFINITE);
        loop.setInterpolator(new LinearInterpolator());
        loop.addUpdateListener(a -> {
            pulse = (float) a.getAnimatedValue();
            invalidate();
        });
        loop.start();
    }

    @Override
    protected void onDetachedFromWindow() {
        if (loop != null) loop.cancel();
        if (move != null) move.cancel();
        super.onDetachedFromWindow();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        float d = getResources().getDisplayMetrics().density;
        int n = LABELS.length;
        float side = 46f * d;
        float left = side, right = w - side;
        float step = (right - left) / (n - 1);
        float y = h * 0.36f;
        // right to left: stage 0 is on the right
        float[] xs = new float[n];
        for (int i = 0; i < n; i++) xs[i] = right - i * step;

        base.setStrokeWidth(3f * d);
        canvas.drawLine(xs[n - 1], y, xs[0], y, base);

        float to = xs[0] - shown * step;
        if (shown > 0.01f) {
            fill.setStrokeWidth(3.5f * d);
            fill.setShader(new LinearGradient(xs[0], y, to, y, 0xFF1BB5C4, 0xFF7FF4FA, Shader.TileMode.CLAMP));
            canvas.drawLine(xs[0], y, to, y, fill);
            // soft glow around the filled part
            fill.setStrokeWidth(9f * d);
            fill.setShader(new LinearGradient(xs[0], y, to, y, 0x331BB5C4, 0x557FF4FA, Shader.TileMode.CLAMP));
            canvas.drawLine(xs[0], y, to, y, fill);
            fill.setShader(null);
        }

        text.setTextSize(12f * d);
        for (int i = 0; i < n; i++) {
            boolean done = i < stage || (stage == n - 1 && i == n - 1);
            boolean cur = i == stage && stage < n - 1;
            float r = (cur ? 8f : 6.5f) * d;
            if (cur) {
                halo.setStrokeWidth(2f * d);
                halo.setColor(((int) (150 * (1f - pulse)) << 24) | 0x2EE6F2);
                canvas.drawCircle(xs[i], y, r + pulse * 11f * d, halo);
            }
            node.setStyle(done || cur ? Paint.Style.FILL : Paint.Style.STROKE);
            node.setStrokeWidth(2f * d);
            node.setColor(done ? CYAN : cur ? 0xFFFFFFFF : 0x66FFFFFF);
            canvas.drawCircle(xs[i], y, r, node);
            text.setColor(done || cur ? 0xFFFFFFFF : 0x80FFFFFF);
            text.setFakeBoldText(cur);
            canvas.drawText(LABELS[i], xs[i], y + 28f * d, text);
        }
    }
}
