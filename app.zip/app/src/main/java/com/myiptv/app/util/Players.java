package com.myiptv.app.util;

import android.content.Context;

import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;

/** Creates ExoPlayer instances configured for IPTV streams. */
public final class Players {
    private Players() {}

    public static ExoPlayer create(Context context) {
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Linux; Android 11) IPTVPlayer/0.2")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(30000);
        DefaultMediaSourceFactory factory =
                new DefaultMediaSourceFactory(new DefaultDataSource.Factory(context, http));
        return new ExoPlayer.Builder(context).setMediaSourceFactory(factory).build();
    }
}
