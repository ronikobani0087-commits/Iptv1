package com.myiptv.app.util;

import android.content.Context;

import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.upstream.DefaultBandwidthMeter;
import androidx.media3.exoplayer.upstream.DefaultLoadErrorHandlingPolicy;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.extractor.ts.TsExtractor;

/** Creates ExoPlayer instances configured for fast start and quick recovery on IPTV streams. */
public final class Players {
    private Players() {}

    /** Retries failed segment / connection loads quickly (about 0.5s, 1s, 1.5s) instead of waiting 1-5s. */
    private static final class FastRetryPolicy extends DefaultLoadErrorHandlingPolicy {
        FastRetryPolicy() {
            super(5);
        }

        @Override
        public long getRetryDelayMsFor(LoadErrorInfo info) {
            long d = super.getRetryDelayMsFor(info);
            if (d == C.TIME_UNSET) return d; // fatal error (404...): let the player-level retry handle it
            return Math.min(d, 1500L);
        }
    }

    public static ExoPlayer create(Context context) {
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent("Mozilla/5.0 (Linux; Android 11) IPTVPlayer/0.2")
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(6000)
                .setReadTimeoutMs(8000);

        // MPEG-TS (the usual Xtream live stream) starts faster with these flags
        DefaultExtractorsFactory extractors = new DefaultExtractorsFactory()
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS)
                .setTsExtractorTimestampSearchBytes(TsExtractor.DEFAULT_TIMESTAMP_SEARCH_BYTES / 2)
                // IPTV channels carry a single program: don't wait to discover more PMTs
                .setTsExtractorMode(TsExtractor.MODE_SINGLE_PMT);

        DefaultMediaSourceFactory factory =
                new DefaultMediaSourceFactory(new DefaultDataSource.Factory(context, http), extractors);
        factory.setLoadErrorHandlingPolicy(new FastRetryPolicy());

        // Picture starts after only 0.7s of data (fast zapping). After a stall it waits 2.5s so it
        // does not stutter again. A 30s ceiling + 40MB cap keeps memory safe on weak TV boxes (HEVC / 4K).
        DefaultLoadControl loadControl = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(10000, 30000, 700, 2500)
                .setTargetBufferBytes(40 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .setBackBuffer(0, false)
                .build();

        // async MediaCodec queueing = smoother frames, no jank on heavy HEVC; joining time 0 = first
        // frame is shown the moment it is decoded instead of waiting for the video renderer to sync.
        DefaultRenderersFactory renderers = new DefaultRenderersFactory(context)
                .setEnableDecoderFallback(true)
                .forceEnableMediaCodecAsynchronousQueueing()
                .setAllowedVideoJoiningTimeMs(0);

        return new ExoPlayer.Builder(context, renderers)
                .setMediaSourceFactory(factory)
                .setLoadControl(loadControl)
                // adaptive (HLS) streams start on a good quality right away instead of the lowest one
                .setBandwidthMeter(new DefaultBandwidthMeter.Builder(context)
                        .setInitialBitrateEstimate(8_000_000L).build())
                .build();
    }

    /** A live channel: stays close to the live edge and catches up slightly after a stall. */
    public static MediaItem liveItem(String url) {
        return new MediaItem.Builder()
                .setUri(url)
                .setLiveConfiguration(new MediaItem.LiveConfiguration.Builder()
                        .setTargetOffsetMs(5000)
                        .setMinOffsetMs(2000)
                        .setMaxPlaybackSpeed(1.05f)
                        .build())
                .build();
    }
}
