package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.myiptv.app.R;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

/** "الكبار +18": a grid of site cards; each opens inside the app through the ad-blocking browser. */
public class AdultFragment extends Fragment {

    /** name, start url, extra allowed domains (comma separated, mirrors of the same site). */
    private static final String[][] SITES = {
            {"SxyPrn", "https://sxyprn.com", ""},
            {"SpankBang", "https://spankbang.com", ""},
            {"PornOne", "https://pornone.com", ""},
    };

    private TextView status;
    private RecyclerView grid;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(c, 24), Ui.dp(c, 18), Ui.dp(c, 24), Ui.dp(c, 12));

        TextView title = new TextView(c);
        title.setText("الكبار +18");
        title.setTextColor(0xFFD7E6EA);
        title.setTextSize(24);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        status = new TextView(c);
        status.setTextColor(0xFF8FB0B8);
        status.setTextSize(14);
        status.setPadding(0, Ui.dp(c, 4), 0, Ui.dp(c, 10));
        root.addView(status);

        grid = new RecyclerView(c);
        grid.setLayoutManager(new GridLayoutManager(c, 3));
        grid.setClipToPadding(false);
        grid.setAdapter(new CardAdapter());
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle b) {
        super.onViewCreated(v, b);
        refreshStatus();
        if (Prefs.getBool(requireContext(), "parental_lock", false)) {
            grid.setVisibility(View.INVISIBLE);
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).goHome();
            return;
        }
        if (!Prefs.getBool(requireContext(), "adult_ok", false)) {
            grid.setVisibility(View.INVISIBLE);
            askAge();
        }
    }

    private void askAge() {
        new AlertDialog.Builder(requireContext())
                .setMessage("هذا القسم مخصص للبالغين فقط (+18).\nهل عمرك 18 سنة أو أكثر؟")
                .setCancelable(false)
                .setPositiveButton("نعم، أنا بالغ", (d, w) -> {
                    Prefs.putBool(requireContext(), "adult_ok", true);
                    grid.setVisibility(View.VISIBLE);
                    focusFirst();
                })
                .setNegativeButton("لا", (d, w) -> {
                    if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).goHome();
                })
                .show();
    }

    private void focusFirst() {
        grid.post(() -> {
            View first = grid.getChildAt(0);
            if (first != null) first.requestFocus();
        });
    }

    private boolean cfOn() {
        return Prefs.getBool(requireContext(), "adult_cf", false);
    }

    private void refreshStatus() {
        if (cfOn()) {
            status.setText("Cloudflare مفعّل: تشفير DNS عبر 1.1.1.1 داخل هذا القسم فقط");
            status.setTextColor(0xFF2ECC71);
        } else {
            status.setText("Cloudflare متوقف: الاتصال مباشر (قد تكون بعض المواقع محجوبة). فعّله من آخر بطاقة.");
            status.setTextColor(0xFFE0A030);
        }
    }

    private void open(String[] site) {
        AdultBrowserActivity.start(requireContext(), site[1], site[2]);
    }

    private final class CardAdapter extends RecyclerView.Adapter<CardAdapter.VH> {
        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            FrameLayout wrap = new FrameLayout(c);
            wrap.setLayoutParams(new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 140)));
            wrap.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setBackgroundResource(R.drawable.bg_card_focus);
            card.setFocusable(true);
            card.setClickable(true);
            TextView name = new TextView(c);
            name.setTextColor(Color.WHITE);
            name.setTextSize(22);
            name.setTypeface(null, android.graphics.Typeface.BOLD);
            name.setGravity(Gravity.CENTER);
            TextView sub = new TextView(c);
            sub.setTextColor(0xFF8FB0B8);
            sub.setTextSize(13);
            sub.setGravity(Gravity.CENTER);
            card.addView(name);
            card.addView(sub);
            wrap.addView(card, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return new VH(wrap, card, name, sub);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final int pos = position;
            if (pos < SITES.length) {
                final String[] s = SITES[pos];
                h.name.setText(s[0]);
                h.sub.setText(android.net.Uri.parse(s[1]).getHost());
                h.card.setOnClickListener(v -> open(s));
            } else {
                h.name.setText("Cloudflare VPN");
                h.sub.setText(cfOn() ? "مفعّل ✓ (اضغط للإيقاف)" : "متوقف (اضغط للتشغيل)");
                h.card.setOnClickListener(v -> {
                    Prefs.putBool(requireContext(), "adult_cf", !cfOn());
                    refreshStatus();
                    notifyItemChanged(pos);
                });
            }
        }

        @Override
        public int getItemCount() {
            return SITES.length + 1;
        }

        final class VH extends RecyclerView.ViewHolder {
            final View card;
            final TextView name, sub;

            VH(View root, View card, TextView name, TextView sub) {
                super(root);
                this.card = card;
                this.name = name;
                this.sub = sub;
            }
        }
    }
}
