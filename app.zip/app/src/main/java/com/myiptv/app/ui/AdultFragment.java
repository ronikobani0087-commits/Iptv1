package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.myiptv.app.R;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

/** "الكبار +18": a grid of site cards; each opens inside the app through the ad-blocking browser. */
public class AdultFragment extends Fragment {

    /** name, start url, extra allowed domains (comma separated, mirrors of the same site). */
    private static final String[][] SITES = {
            {"XVideos", "https://www.xvideos.com", ""},
            {"XHamster", "https://xhamster.com", ""},
    };

    private TextView status;
    private RecyclerView grid;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(c, 24), Ui.dp(c, 18), Ui.dp(c, 24), Ui.dp(c, 12));

        TextView title = new TextView(c);
        title.setText("الكبار +18");
        title.setTextColor(0xFFD7E6EA);
        title.setTextSize(24);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        root.addView(title);

        status = new TextView(c);
        status.setTextColor(0xFF8FB0B8);
        status.setTextSize(14);
        status.setPadding(0, Ui.dp(c, 4), 0, Ui.dp(c, 10));
        root.addView(status);

        grid = new RecyclerView(c);
        grid.setLayoutManager(new GridLayoutManager(c, 3));
        grid.setClipToPadding(false);
        grid.setAdapter(new CardAdapter());
        root.addView(grid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle b) {
        super.onViewCreated(v, b);
        refreshStatus();
        if (!Prefs.getBool(requireContext(), "adult_ok", false)) {
            grid.setVisibility(View.INVISIBLE);
            askAge();
        }
    }

    private void askAge() {
        new AlertDialog.Builder(requireContext())
                .setMessage("هذا القسم مخصص للبالغين فقط (+18).\nهل عمرك 18 سنة أو أكثر؟")
                .setCancelable(false)
                .setPositiveButton("نعم، أنا بالغ", (d, w) -> {
                    Prefs.putBool(requireContext(), "adult_ok", true);
                    grid.setVisibility(View.VISIBLE);
                    focusFirst();
                })
                .setNegativeButton("لا", (d, w) -> {
                    if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).goHome();
                })
                .show();
    }

    private void focusFirst() {
        grid.post(() -> {
            View first = grid.getChildAt(0);
            if (first != null) first.requestFocus();
        });
    }

    private void refreshStatus() {
        String p = Prefs.getString(requireContext(), "adult_proxy").trim();
        if (p.isEmpty()) {
            status.setText("بدون بروكسي: الاتصال مباشر (قد تكون بعض المواقع محجوبة). اضبط البروكسي من آخر بطاقة.");
            status.setTextColor(0xFFE0A030);
        } else {
            status.setText("التصفح يمر عبر البروكسي: " + p);
            status.setTextColor(0xFF2ECC71);
        }
    }

    private void open(String[] site) {
        AdultBrowserActivity.start(requireContext(), site[1], site[2]);
    }

    private void proxyDialog() {
        final Context c = requireContext();
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(Ui.dp(c, 20), Ui.dp(c, 10), Ui.dp(c, 20), 0);
        final EditText host = field(c, "host:port   مثال: de1.example.com:8080", Prefs.getString(c, "adult_proxy"));
        final EditText user = field(c, "اسم المستخدم (اختياري)", Prefs.getString(c, "adult_proxy_user"));
        final EditText pass = field(c, "كلمة المرور (اختياري)", Prefs.getString(c, "adult_proxy_pass"));
        pass.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        box.addView(host);
        box.addView(user);
        box.addView(pass);
        TextView hint = new TextView(c);
        hint.setText("أدخل بروكسي HTTP في ألمانيا أو أمريكا. اتركه فارغاً للاتصال المباشر.");
        hint.setTextColor(0xFF8FB0B8);
        hint.setTextSize(13);
        hint.setPadding(0, Ui.dp(c, 8), 0, 0);
        box.addView(hint);
        AlertDialog dlg = new AlertDialog.Builder(c)
                .setTitle("بروكسي ألماني / أمريكي")
                .setView(box)
                .setPositiveButton("حفظ", (d, w) -> {
                    Prefs.putString(c, "adult_proxy", host.getText().toString().trim());
                    Prefs.putString(c, "adult_proxy_user", user.getText().toString().trim());
                    Prefs.putString(c, "adult_proxy_pass", pass.getText().toString());
                    refreshStatus();
                })
                .setNegativeButton("إلغاء", null)
                .create();
        dlg.show();
        if (dlg.getWindow() != null) dlg.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
    }

    private static EditText field(Context c, String hint, String value) {
        EditText e = new EditText(c);
        e.setHint(hint);
        e.setText(value);
        e.setSingleLine(true);
        e.setTextColor(0xFFD7E6EA);
        e.setHintTextColor(0xFF8FB0B8);
        e.setTextSize(15);
        e.setBackgroundResource(R.drawable.bg_field);
        e.setPadding(Ui.dp(c, 12), Ui.dp(c, 10), Ui.dp(c, 12), Ui.dp(c, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 8);
        e.setLayoutParams(lp);
        return e;
    }

    private final class CardAdapter extends RecyclerView.Adapter<CardAdapter.VH> {
        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            FrameLayout wrap = new FrameLayout(c);
            wrap.setLayoutParams(new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 140)));
            wrap.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setGravity(Gravity.CENTER);
            card.setBackgroundResource(R.drawable.bg_card_focus);
            card.setFocusable(true);
            card.setClickable(true);
            TextView name = new TextView(c);
            name.setTextColor(Color.WHITE);
            name.setTextSize(22);
            name.setTypeface(null, android.graphics.Typeface.BOLD);
            name.setGravity(Gravity.CENTER);
            TextView sub = new TextView(c);
            sub.setTextColor(0xFF8FB0B8);
            sub.setTextSize(13);
            sub.setGravity(Gravity.CENTER);
            card.addView(name);
            card.addView(sub);
            wrap.addView(card, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            return new VH(wrap, card, name, sub);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int pos) {
            if (pos < SITES.length) {
                final String[] s = SITES[pos];
                h.name.setText(s[0]);
                h.sub.setText(android.net.Uri.parse(s[1]).getHost());
                h.card.setOnClickListener(v -> open(s));
            } else {
                h.name.setText("إعدادات البروكسي");
                h.sub.setText("ألماني / أمريكي");
                h.card.setOnClickListener(v -> proxyDialog());
            }
        }

        @Override
        public int getItemCount() {
            return SITES.length + 1;
        }

        final class VH extends RecyclerView.ViewHolder {
            final View card;
            final TextView name, sub;

            VH(View root, View card, TextView name, TextView sub) {
                super(root);
                this.card = card;
                this.name = name;
                this.sub = sub;
            }
        }
    }
}
