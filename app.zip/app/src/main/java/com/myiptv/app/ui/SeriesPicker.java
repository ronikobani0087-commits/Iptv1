package com.myiptv.app.ui;

import android.app.Activity;

/** Opens the series details screen (seasons and episodes). */
public final class SeriesPicker {
    private SeriesPicker() {}

    public static void show(Activity activity, long playlistId, String seriesName,
                            String seriesId, String icon) {
        if (seriesId == null || seriesId.isEmpty()) return;
        SeriesActivity.start(activity, playlistId, seriesName, seriesId, icon);
    }
}
