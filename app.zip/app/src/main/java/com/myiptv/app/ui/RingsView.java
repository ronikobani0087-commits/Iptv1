package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

/**
 * First login screen background: the app background image with, around the logo, a soft shadow
 * and a ring made of the background's own smoke (the same picture, lit up and cut out in a ring
 * with feathered edges), so the ring looks like a piece of the background and not a drawing.
 */
public class RingsView extends View {
    private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mask = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Drawable bg;      // the plain background
    private Drawable bgLit;   // the same picture, brightened: the smoke of the ring
    private View anchor;      // the logo: the rings are centred on it

    public RingsView(Context c) {
        super(c);
        init();
    }

    public RingsView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        setFocusable(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnScrollChangedListener(this::invalidate);
        getViewTreeObserver().addOnGlobalLayoutListener(this::invalidate);
    }

    private void cropTo(Drawable d, int w, int h) {
        float sc = Math.max(w / (float) d.getIntrinsicWidth(), h / (float) d.getIntrinsicHeight());
        int bw = Math.round(d.getIntrinsicWidth() * sc), bh = Math.round(d.getIntrinsicHeight() * sc);
        int l = (w - bw) / 2, t = (h - bh) / 2;
        d.setBounds(l, t, l + bw, t + bh);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        float d = getResources().getDisplayMetrics().density;

        if (bg == null) {
            bg = ContextCompat.getDrawable(getContext(), R.drawable.bg_main);
            Drawable lit = ContextCompat.getDrawable(getContext(), R.drawable.bg_main);
            if (lit != null) {
                bgLit = lit.mutate();
                ColorMatrix cm = new ColorMatrix(new float[]{
                        1.6f, 0, 0, 0, 4,
                        0, 2.3f, 0, 0, 10,
                        0, 0, 2.3f, 0, 12,
                        0, 0, 0, 1, 0});
                bgLit.setColorFilter(new ColorMatrixColorFilter(cm));
            }
        }
        if (bg == null || bg.getIntrinsicWidth() <= 0) {
            canvas.drawColor(0xFF0F1625);
            return;
        }
        cropTo(bg, w, h);
        bg.draw(canvas);

        // centre of the rings = centre of the logo
        float cx = w / 2f, cy = h * 0.2f, unit = 70f * d;
        if (anchor == null) anchor = getRootView().findViewById(R.id.ft_logo);
        if (anchor != null && anchor.getWidth() > 0) {
            int[] a = new int[2], me = new int[2];
            anchor.getLocationInWindow(a);
            getLocationInWindow(me);
            cx = a[0] - me[0] + anchor.getWidth() / 2f;
            cy = a[1] - me[1] + anchor.getHeight() / 2f;
            unit = anchor.getHeight();
        }

        // 1) gradual shadow around the logo so it stands out
        float shadeR = unit * 2.6f;
        shade.setShader(new RadialGradient(cx, cy, shadeR,
                new int[]{0xB3000A12, 0x66000A12, 0x00000A12}, new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, shadeR, shade);

        // 2) the smoke ring: the lit background kept only where a feathered ring-shaped mask says so.
        //    One layer for the whole view (no inner layer edges that could show as thin lines) and one
        //    mask holding both rings, so the smoke melts into the smoke of the screen.
        if (bgLit != null) {
            float r0 = unit * 0.95f, b0 = unit * 0.5f;     // inner ring: centre line and half width
            float r1 = unit * 2.2f, b1 = unit * 0.7f;     // outer, fainter ring
            float outer = r1 + b1;
            int sc = canvas.saveLayer(0, 0, w, h, null);
            cropTo(bgLit, w, h);
            bgLit.draw(canvas);
            mask.setShader(new RadialGradient(cx, cy, outer,
                    new int[]{0x00000000, 0x00000000, 0xB0000000, 0x00000000, 0x00000000, 0x70000000, 0x00000000},
                    new float[]{0f, (r0 - b0) / outer, r0 / outer, (r0 + b0) / outer,
                            (r1 - b1) / outer, r1 / outer, 1f},
                    Shader.TileMode.CLAMP));
            canvas.drawRect(0, 0, w, h, mask);
            canvas.restoreToCount(sc);
        }
    }
}
