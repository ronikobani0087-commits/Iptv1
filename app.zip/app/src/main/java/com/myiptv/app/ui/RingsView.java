package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.drawable.Drawable;
import androidx.core.content.ContextCompat;
import com.myiptv.app.R;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/** The app background image with soft concentric rings around the logo (first login screen). */
public class RingsView extends View {
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint dash = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Drawable bg;

    public RingsView(Context c) {
        super(c);
        init();
    }

    public RingsView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(2f);
        dash.setStyle(Paint.Style.STROKE);
        dash.setStrokeWidth(10f);
        dash.setPathEffect(new DashPathEffect(new float[]{3f, 9f}, 0f));
        glow.setStyle(Paint.Style.FILL);
        setFocusable(false);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        float cx = w / 2f;
        float cy = h * 0.22f; // the rings are centred on the logo
        float maxR = (float) Math.hypot(Math.max(cx, w - cx), Math.max(cy, h - cy));
        if (bg == null) bg = ContextCompat.getDrawable(getContext(), R.drawable.bg_main);
        if (bg != null && bg.getIntrinsicWidth() > 0) { // centre-crop, like everywhere else in the app
            float sc = Math.max(w / (float) bg.getIntrinsicWidth(), h / (float) bg.getIntrinsicHeight());
            int bw = Math.round(bg.getIntrinsicWidth() * sc), bh = Math.round(bg.getIntrinsicHeight() * sc);
            int l = (w - bw) / 2, t = (h - bh) / 2;
            bg.setBounds(l, t, l + bw, t + bh);
            bg.draw(canvas);
        } else {
            canvas.drawColor(0xFF0F1625);
        }

        float d = getResources().getDisplayMetrics().density;
        float step = 46f * d;
        for (int i = 1; i * step < maxR; i++) {
            float r = i * step;
            int alpha = Math.max(10, 70 - i * 9);
            ring.setColor((alpha << 24) | 0x2CD9E0);
            canvas.drawCircle(cx, cy, r, ring);
            if (i == 2 || i == 4) {
                dash.setColor(((alpha / 2 + 8) << 24) | 0x7FE8F0);
                canvas.drawCircle(cx, cy, r + 14f * d, dash);
            }
        }
        glow.setShader(new RadialGradient(cx, cy, 110f * d,
                new int[]{0x552CD9E0, 0x00000000}, null, Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, 110f * d, glow);
    }
}
