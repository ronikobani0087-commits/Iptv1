package com.myiptv.app.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Reads the channel that carries a match from https://kooralive.la/ (one light page, cached 5 minutes).
 * In the page every match block lists: team, team, channel (e.g. "beIN SPORTS HD 1"), commentator, league.
 */
public final class KooraLive {
    private static final String URL = "https://kooralive.la/";
    private static final long TTL_MS = 5L * 60L * 1000L;
    private static List<String> cacheLines;
    private static long cacheTime;
    /** Last outcome, for diagnostics. */
    public static volatile String lastStatus = "";

    private KooraLive() {}

    /** Channel name as the site writes it ("beIN SPORTS HD 1"), or "" when not found. Blocking (network). */
    public static String channelFor(SportsRepository.Match m) {
        try {
            List<String> lines = lines();
            int prev = -1;
            for (int i = 0; i < lines.size(); i++) {
                String l = lines.get(i);
                if (!isChannel(l)) continue;
                StringBuilder sb = new StringBuilder();
                for (int j = Math.max(prev + 1, i - 14); j < i; j++) sb.append(' ').append(lines.get(j));
                String t = MatchBroadcast.norm(sb.toString());
                if (MatchBroadcast.hasTeam(t, m.homeNames, m.home) && MatchBroadcast.hasTeam(t, m.awayNames, m.away)) {
                    lastStatus = "ok";
                    return l.trim();
                }
                prev = i;
            }
            lastStatus = "match not in list";
        } catch (Exception e) {
            lastStatus = String.valueOf(e.getMessage());
        }
        return "";
    }

    private static boolean isChannel(String l) {
        String k = l.toLowerCase(Locale.ROOT);
        return l.length() < 40 && (k.contains("bein") || k.contains("ssc ") || k.contains("alkass")
                || k.contains("thmanyah"));
    }

    private static List<String> lines() throws Exception {
        synchronized (KooraLive.class) {
            if (cacheLines != null && System.currentTimeMillis() - cacheTime < TTL_MS) return cacheLines;
        }
        String html = Http.readStringBrowser(URL);
        html = html.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", " ");
        html = html.replaceAll("(?s)<[^>]+>", "\n");
        html = html.replace("&amp;", "&").replace("&nbsp;", " ").replace("&#8217;", "'");
        List<String> out = new ArrayList<>();
        for (String s : html.split("\n")) {
            String t = s.trim();
            if (!t.isEmpty()) out.add(t);
        }
        synchronized (KooraLive.class) {
            cacheLines = out;
            cacheTime = System.currentTimeMillis();
        }
        return out;
    }
}
