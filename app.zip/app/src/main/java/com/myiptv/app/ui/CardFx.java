package com.myiptv.app.ui;

import android.graphics.Typeface;
import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

/**
 * Focus look for poster cards (remote / keyboard only, never on touch):
 * the card grows a little and rises above its neighbours, a thick cyan frame is drawn
 * (see bg_poster) and the title turns bold cyan.
 */
public final class CardFx {
    public static final float SCALE = 1.05f;
    public static final float LIFT = 20f;
    private static final Typeface MEDIUM = Typeface.create("sans-serif-medium", Typeface.NORMAL);

    private CardFx() {
    }

    /** @param cell the whole tile (frame + title); @param frame the focusable frame; @param name the title. */
    public static void attach(final View cell, final View frame, final TextView name) {
        frame.setOnFocusChangeListener((v, has) -> apply(cell, frame, name, has && !v.isInTouchMode(), true));
    }

    /** Puts a (re)bound tile into the right state without animating. */
    public static void sync(View cell, View frame, TextView name) {
        apply(cell, frame, name, frame.hasFocus() && !frame.isInTouchMode(), false);
    }

    private static void apply(View cell, View frame, TextView name, boolean on, boolean animate) {
        cell.setTranslationZ(on ? LIFT : 0f);
        float s = on ? SCALE : 1f;
        if (animate) {
            cell.animate().cancel();
            cell.animate().scaleX(s).scaleY(s).setDuration(120).start();
        } else {
            cell.animate().cancel();
            cell.setScaleX(s);
            cell.setScaleY(s);
        }
        if (name != null) {
            name.setTextColor(ContextCompat.getColor(name.getContext(), on ? R.color.eye : R.color.text));
            name.setTypeface(on ? Typeface.DEFAULT_BOLD : MEDIUM);
        }
    }
}
