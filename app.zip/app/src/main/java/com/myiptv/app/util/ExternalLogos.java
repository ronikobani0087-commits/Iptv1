package com.myiptv.app.util;

import android.content.Context;
import android.util.JsonReader;
import android.util.JsonToken;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.Writer;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * Channel logos from an external open database (iptv-org), used for channels whose provider gives
 * no logo. The database is downloaded once in the background, reduced to a small "name -> logo url"
 * file in the app cache and refreshed every 30 days. Lookups never touch the network.
 */
public final class ExternalLogos {
    private ExternalLogos() {}

    private static final String LOGOS_URL = "https://iptv-org.github.io/api/logos.json";
    private static final String CHANNELS_URL = "https://iptv-org.github.io/api/channels.json";
    private static final long MAX_AGE_MS = 30L * 24L * 3600L * 1000L;
    private static final long RETRY_AFTER_FAIL_MS = 6L * 3600L * 1000L;

    private static volatile Map<String, String> map = null;
    private static volatile boolean running = false;
    private static volatile long lastFail = 0L;

    private static final Pattern BRACKETS = Pattern.compile("\\([^)]*\\)|\\[[^\\]]*\\]");
    private static final Pattern SPLIT = Pattern.compile("[^a-z0-9\\u0600-\\u06FF]+");

    public interface Ready {
        void onReady();
    }

    /** Logo url for a channel name, or null when unknown (or the database is not ready yet). */
    public static String lookup(String name) {
        Map<String, String> m = map;
        if (m == null || name == null) return null;
        String k = key(name);
        return k == null ? null : m.get(k);
    }

    /**
     * Loads the cached database (downloading / refreshing it first when needed) on a background
     * thread. {@code ready} runs on the main thread once logos become available.
     */
    public static void ensure(Context context, final Ready ready) {
        if (map != null || running) return;
        if (System.currentTimeMillis() - lastFail < RETRY_AFTER_FAIL_MS) return;
        running = true;
        final Context app = context.getApplicationContext();
        Async.io(() -> {
            try {
                File f = new File(app.getCacheDir(), "ext_logos.tsv");
                boolean stale = !f.exists() || System.currentTimeMillis() - f.lastModified() > MAX_AGE_MS;
                if (stale) {
                    try {
                        download(f);
                    } catch (Exception e) {
                        lastFail = System.currentTimeMillis();
                        // keep an old copy if there is one
                    }
                }
                if (f.exists()) {
                    Map<String, String> m = read(f);
                    if (!m.isEmpty()) {
                        map = m;
                        if (ready != null) Async.main(ready::onReady);
                    }
                }
            } catch (Throwable ignored) {
                lastFail = System.currentTimeMillis();
            } finally {
                running = false;
            }
        });
    }

    private static Map<String, String> read(File f) throws Exception {
        Map<String, String> m = new HashMap<>(32768);
        try (BufferedReader r = new BufferedReader(
                new InputStreamReader(new FileInputStream(f), "UTF-8"), 65536)) {
            String line;
            while ((line = r.readLine()) != null) {
                int t = line.indexOf('\t');
                if (t > 0 && t < line.length() - 1) m.put(line.substring(0, t), line.substring(t + 1));
            }
        }
        return m;
    }

    private static void download(File out) throws Exception {
        // 1) channel id -> best logo url
        Map<String, String> logoById = new HashMap<>(32768);
        try (InputStream in = Http.open(LOGOS_URL);
             JsonReader r = new JsonReader(new InputStreamReader(in, "UTF-8"))) {
            r.beginArray();
            while (r.hasNext()) {
                String channel = null;
                String url = null;
                String format = "";
                int width = 0;
                r.beginObject();
                while (r.hasNext()) {
                    String n = r.nextName();
                    if (r.peek() == JsonToken.NULL) {
                        r.skipValue();
                    } else if ("channel".equals(n)) {
                        channel = r.nextString();
                    } else if ("url".equals(n)) {
                        url = r.nextString();
                    } else if ("format".equals(n)) {
                        format = r.nextString();
                    } else if ("width".equals(n)) {
                        width = r.nextInt();
                    } else {
                        r.skipValue();
                    }
                }
                r.endObject();
                if (channel == null || url == null || !url.startsWith("http")) continue;
                String fmt = format.toUpperCase(Locale.US);
                if (fmt.equals("SVG") || fmt.equals("GIF")) continue; // Glide shows PNG / JPG / WEBP
                String old = logoById.get(channel);
                if (old == null || width >= 100) logoById.put(channel, url);
            }
            r.endArray();
        }

        // 2) every name / alternative name of a channel -> its logo url
        File tmp = new File(out.getParentFile(), "ext_logos.tmp");
        try (InputStream in = Http.open(CHANNELS_URL);
             JsonReader r = new JsonReader(new InputStreamReader(in, "UTF-8"));
             Writer w = new OutputStreamWriter(new FileOutputStream(tmp), "UTF-8")) {
            Map<String, Boolean> written = new HashMap<>(32768);
            r.beginArray();
            while (r.hasNext()) {
                String id = null;
                java.util.List<String> names = new java.util.ArrayList<>();
                r.beginObject();
                while (r.hasNext()) {
                    String n = r.nextName();
                    if (r.peek() == JsonToken.NULL) {
                        r.skipValue();
                    } else if ("id".equals(n)) {
                        id = r.nextString();
                    } else if ("name".equals(n)) {
                        names.add(r.nextString());
                    } else if ("alt_names".equals(n) && r.peek() == JsonToken.BEGIN_ARRAY) {
                        r.beginArray();
                        while (r.hasNext()) names.add(r.nextString());
                        r.endArray();
                    } else {
                        r.skipValue();
                    }
                }
                r.endObject();
                String url = id == null ? null : logoById.get(id);
                if (url == null) continue;
                for (String nm : names) {
                    String k = key(nm);
                    if (k == null || written.containsKey(k)) continue;
                    written.put(k, Boolean.TRUE);
                    w.write(k);
                    w.write('\t');
                    w.write(url);
                    w.write('\n');
                }
            }
            r.endArray();
        }
        if (!tmp.renameTo(out)) {
            out.delete();
            if (!tmp.renameTo(out)) throw new java.io.IOException("rename failed");
        }
    }

    private static boolean tag(String t) {
        return t.equals("fhd") || t.equals("uhd") || t.equals("hevc") || t.equals("raw")
                || t.equals("backup") || t.equals("live") || t.equals("sd") || t.equals("hd")
                || t.equals("4k") || t.equals("8k") || t.equals("h265") || t.equals("h264");
    }

    /** Name without brackets and quality tags, letters + digits joined; digits are kept (beIN 1 != beIN 2). */
    static String key(String name) {
        if (name == null || name.isEmpty()) return null;
        String n = BRACKETS.matcher(name.toLowerCase(Locale.US)).replaceAll(" ")
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ة', 'ه').replace('ى', 'ي');
        StringBuilder sb = new StringBuilder();
        for (String t : SPLIT.split(n)) {
            if (t.isEmpty() || tag(t)) continue;
            sb.append(t);
        }
        return sb.length() < 3 ? null : sb.toString();
    }
}
