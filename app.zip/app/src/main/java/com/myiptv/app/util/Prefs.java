package com.myiptv.app.util;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("app", Context.MODE_PRIVATE);
    }

    public static long getActive(Context c) {
        return sp(c).getLong("active_playlist", -1L);
    }

    public static void setActive(Context c, long id) {
        sp(c).edit().putLong("active_playlist", id).apply();
    }

    /** Series ids the user marked as finished (hidden from "series I follow"). */
    public static Set<String> getCompleted(Context c, long playlistId) {
        Set<String> s = sp(c).getStringSet("done_" + playlistId, null);
        if (s == null) return new HashSet<String>();
        return new HashSet<String>(s);
    }

    public static void setCompleted(Context c, long playlistId, String seriesId, boolean done) {
        if (seriesId == null) return;
        Set<String> s = getCompleted(c, playlistId);
        if (done) s.add(seriesId);
        else s.remove(seriesId);
        sp(c).edit().putStringSet("done_" + playlistId, s).apply();
    }

    private static String seenKey(long playlistId, String seriesId) {
        return "seen_" + playlistId + "_" + seriesId;
    }

    /** True if any of the keys (episode url / label) was marked as watched for this series. */
    public static boolean isSeen(Context c, long playlistId, String seriesId, String... keys) {
        if (seriesId == null) return false;
        Set<String> s = sp(c).getStringSet(seenKey(playlistId, seriesId), null);
        if (s == null) return false;
        for (String k : keys) {
            if (k != null && !k.isEmpty() && s.contains(k)) return true;
        }
        return false;
    }

    /** Marks an episode as watched (stored under every key given: its url and its label). */
    public static void markSeen(Context c, long playlistId, String seriesId, String... keys) {
        if (seriesId == null) return;
        Set<String> s = new HashSet<String>();
        Set<String> old = sp(c).getStringSet(seenKey(playlistId, seriesId), null);
        if (old != null) s.addAll(old);
        boolean changed = false;
        for (String k : keys) {
            if (k != null && !k.isEmpty() && s.add(k)) changed = true;
        }
        if (changed) sp(c).edit().putStringSet(seenKey(playlistId, seriesId), s).apply();
    }

    public static String getString(Context c, String key) {
        String v = sp(c).getString(key, "");
        return v == null ? "" : v;
    }

    public static void putString(Context c, String key, String value) {
        sp(c).edit().putString(key, value).apply();
    }

    public static boolean getBool(Context c, String key, boolean def) {
        return sp(c).getBoolean(key, def);
    }

    public static void putBool(Context c, String key, boolean value) {
        sp(c).edit().putBoolean(key, value).apply();
    }
}
