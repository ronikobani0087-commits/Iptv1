package com.myiptv.app.util;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.HashSet;
import java.util.Set;

public final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp(Context c) {
        return c.getApplicationContext().getSharedPreferences("app", Context.MODE_PRIVATE);
    }

    public static long getActive(Context c) {
        return sp(c).getLong("active_playlist", -1L);
    }

    public static void setActive(Context c, long id) {
        sp(c).edit().putLong("active_playlist", id).apply();
    }

    /** Series ids the user marked as finished (hidden from "series I follow"). */
    public static Set<String> getCompleted(Context c, long playlistId) {
        Set<String> s = sp(c).getStringSet("done_" + playlistId, null);
        if (s == null) return new HashSet<String>();
        return new HashSet<String>(s);
    }

    public static void setCompleted(Context c, long playlistId, String seriesId, boolean done) {
        if (seriesId == null) return;
        Set<String> s = getCompleted(c, playlistId);
        if (done) s.add(seriesId);
        else s.remove(seriesId);
        sp(c).edit().putStringSet("done_" + playlistId, s).apply();
    }

    public static String getString(Context c, String key) {
        String v = sp(c).getString(key, "");
        return v == null ? "" : v;
    }

    public static void putString(Context c, String key, String value) {
        sp(c).edit().putString(key, value).apply();
    }
}
