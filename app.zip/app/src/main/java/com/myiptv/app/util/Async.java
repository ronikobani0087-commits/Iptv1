package com.myiptv.app.util;

import android.os.Handler;
import android.os.Looper;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class Async {
    private static final ExecutorService IO = Executors.newFixedThreadPool(4);
    /** Slow network work (series details, scores, frames): kept apart so it cannot hold up the quick loads. */
    private static final ExecutorService NET = Executors.newFixedThreadPool(4);
    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    private Async() {}

    public static void io(Runnable r) {
        IO.execute(r);
    }

    public static void net(Runnable r) {
        NET.execute(r);
    }

    public static void main(Runnable r) {
        MAIN.post(r);
    }
}
