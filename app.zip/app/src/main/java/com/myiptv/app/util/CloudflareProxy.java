package com.myiptv.app.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tiny local proxy (127.0.0.1) used only by the 18+ browser. Every host name is resolved through
 * Cloudflare DNS-over-HTTPS (1.1.1.1) instead of the provider's DNS, so sites that are blocked at
 * DNS level open normally. It is NOT a full VPN: the real IP address does not change.
 */
public final class CloudflareProxy {
    private CloudflareProxy() {}

    private static final Pattern A_REC = Pattern.compile(
            "\"type\"\\s*:\\s*1\\s*,\\s*\"TTL\"\\s*:\\s*(\\d+)\\s*,\\s*\"data\"\\s*:\\s*\"([0-9.]+)\"");
    private static final Pattern IPV4 = Pattern.compile("^\\d{1,3}(\\.\\d{1,3}){3}$");

    private static final class Entry {
        final InetAddress[] addrs;
        final long expires;

        Entry(InetAddress[] a, long e) {
            addrs = a;
            expires = e;
        }
    }

    private static final ConcurrentHashMap<String, Entry> CACHE = new ConcurrentHashMap<String, Entry>();
    private static ServerSocket server;
    private static ExecutorService pool;

    /** Starts the proxy (if not running) and returns its local port. */
    public static synchronized int start() throws IOException {
        if (server != null && !server.isClosed()) return server.getLocalPort();
        final ServerSocket ss = new ServerSocket(0, 64, InetAddress.getByName("127.0.0.1"));
        final ExecutorService ex = Executors.newCachedThreadPool();
        server = ss;
        pool = ex;
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                while (!ss.isClosed()) {
                    try {
                        final Socket c = ss.accept();
                        ex.execute(new Runnable() {
                            @Override
                            public void run() {
                                handle(c);
                            }
                        });
                    } catch (Throwable e) {
                        break;
                    }
                }
            }
        }, "cf-proxy");
        t.setDaemon(true);
        t.start();
        return ss.getLocalPort();
    }

    public static synchronized void stop() {
        try {
            if (server != null) server.close();
        } catch (Throwable ignored) {
        }
        if (pool != null) pool.shutdownNow();
        server = null;
        pool = null;
    }

    // ------------------------------------------------------------------ connection handling

    private static void handle(Socket client) {
        Socket up = null;
        try {
            client.setTcpNoDelay(true);
            InputStream in = client.getInputStream();
            OutputStream out = client.getOutputStream();
            byte[] head = readHead(in);
            if (head == null) return;
            String text = new String(head, "ISO-8859-1");
            int eol = text.indexOf("\r\n");
            String first = eol < 0 ? text : text.substring(0, eol);
            String[] p = first.split(" ");
            if (p.length < 3) return;

            if (p[0].equalsIgnoreCase("CONNECT")) {
                String hp = p[1];
                int c = hp.lastIndexOf(':');
                String host = c > 0 ? hp.substring(0, c) : hp;
                int port = c > 0 ? Integer.parseInt(hp.substring(c + 1)) : 443;
                up = open(host, port);
                out.write("HTTP/1.1 200 Connection Established\r\n\r\n".getBytes("ISO-8859-1"));
                out.flush();
            } else {
                URL u = new URL(p[1]);
                int port = u.getPort() > 0 ? u.getPort() : 80;
                up = open(u.getHost(), port);
                String path = u.getFile().isEmpty() ? "/" : u.getFile();
                StringBuilder sb = new StringBuilder();
                sb.append(p[0]).append(' ').append(path).append(' ').append(p[2]).append("\r\n");
                String rest = eol < 0 ? "" : text.substring(eol + 2);
                for (String line : rest.split("\r\n")) {
                    String l = line.toLowerCase(Locale.US);
                    if (line.isEmpty() || l.startsWith("proxy-connection:") || l.startsWith("connection:")) continue;
                    sb.append(line).append("\r\n");
                }
                sb.append("Connection: close\r\n\r\n");
                up.getOutputStream().write(sb.toString().getBytes("ISO-8859-1"));
                up.getOutputStream().flush();
            }
            pipe(client, up);
        } catch (Throwable e) {
            try {
                client.getOutputStream().write("HTTP/1.1 502 Bad Gateway\r\n\r\n".getBytes("ISO-8859-1"));
            } catch (Throwable ignored) {
            }
        } finally {
            close(up);
            close(client);
        }
    }

    /** Reads the request head up to the blank line, one byte at a time so no body byte is consumed. */
    private static byte[] readHead(InputStream in) throws IOException {
        ByteArrayOutputStream b = new ByteArrayOutputStream();
        int state = 0, ch;
        while ((ch = in.read()) >= 0) {
            b.write(ch);
            if (b.size() > 32768) return null;
            if (ch == '\r' && (state == 0 || state == 2)) state++;
            else if (ch == '\n' && (state == 1 || state == 3)) state++;
            else state = 0;
            if (state == 4) return b.toByteArray();
        }
        return null;
    }

    private static Socket open(String host, int port) throws IOException {
        IOException last = null;
        for (InetAddress a : resolve(host)) {
            Socket s = new Socket();
            try {
                s.setTcpNoDelay(true);
                s.connect(new InetSocketAddress(a, port), 10000);
                return s;
            } catch (IOException e) {
                last = e;
                close(s);
            }
        }
        throw last != null ? last : new IOException("no address for " + host);
    }

    private static void pipe(final Socket a, final Socket b) throws IOException {
        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {
                copy(b, a);
            }
        }, "cf-pipe");
        t.setDaemon(true);
        t.start();
        copy(a, b);
        close(a);
        close(b);
    }

    private static void copy(Socket from, Socket to) {
        byte[] buf = new byte[16384];
        try {
            InputStream i = from.getInputStream();
            OutputStream o = to.getOutputStream();
            int n;
            while ((n = i.read(buf)) >= 0) {
                o.write(buf, 0, n);
                o.flush();
            }
        } catch (Throwable ignored) {
        }
        close(from);
        close(to);
    }

    private static void close(Socket s) {
        if (s == null) return;
        try {
            s.close();
        } catch (Throwable ignored) {
        }
    }

    // ------------------------------------------------------------------ Cloudflare DNS over HTTPS

    private static InetAddress[] resolve(String host) throws IOException {
        if (IPV4.matcher(host).matches() || host.indexOf(':') >= 0) return InetAddress.getAllByName(host);
        String key = host.toLowerCase(Locale.US);
        Entry e = CACHE.get(key);
        long now = System.currentTimeMillis();
        if (e != null && e.expires > now) return e.addrs;
        try {
            Entry fresh = doh(key, now);
            if (fresh != null) {
                CACHE.put(key, fresh);
                return fresh.addrs;
            }
        } catch (Throwable ignored) {
        }
        return InetAddress.getAllByName(host);   // DoH unreachable: fall back to the system resolver
    }

    private static Entry doh(String host, long now) throws IOException {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL("https://1.1.1.1/dns-query?type=A&name="
                    + URLEncoder.encode(host, "UTF-8")).openConnection();
            con.setConnectTimeout(8000);
            con.setReadTimeout(8000);
            con.setRequestProperty("accept", "application/dns-json");
            if (con.getResponseCode() != 200) return null;
            ByteArrayOutputStream b = new ByteArrayOutputStream();
            InputStream in = con.getInputStream();
            byte[] buf = new byte[4096];
            int n;
            while ((n = in.read(buf)) >= 0) b.write(buf, 0, n);
            Matcher m = A_REC.matcher(b.toString("UTF-8"));
            List<InetAddress> list = new ArrayList<InetAddress>();
            long ttl = 300;
            while (m.find()) {
                ttl = Math.min(ttl, Math.max(30, Long.parseLong(m.group(1))));
                list.add(InetAddress.getByName(m.group(2)));   // literal IP: no lookup
            }
            if (list.isEmpty()) return null;
            return new Entry(list.toArray(new InetAddress[0]), now + ttl * 1000L);
        } finally {
            if (con != null) con.disconnect();
        }
    }
}
