package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.PlaylistFactory;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;

/**
 * Shown after the intro only while no provider / account has been added: the logo and three boxes
 * (server link, user name, password). The keyboard stays compact so the typing remains visible.
 */
public class FirstLaunchFragment extends Fragment {
    private EditText etUrl, etUser, etPass;
    private TextView status;
    private boolean busy;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_first_launch, container, false);
        etUrl = v.findViewById(R.id.ft_url);
        etUser = v.findViewById(R.id.ft_user);
        etPass = v.findViewById(R.id.ft_pass);
        status = v.findViewById(R.id.ft_status);
        etPass.setOnEditorActionListener((tv, action, ev) -> {
            if (action == EditorInfo.IME_ACTION_DONE) {
                submit();
                return true;
            }
            return false;
        });
        v.findViewById(R.id.ft_login).setOnClickListener(x -> submit());
        final android.widget.ImageView eye = v.findViewById(R.id.ft_eye);
        eye.setOnClickListener(x -> {
            boolean hidden = (etPass.getInputType() & android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD) != 0;
            int sel = etPass.getSelectionStart();
            etPass.setInputType(android.text.InputType.TYPE_CLASS_TEXT | (hidden
                    ? android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    : android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD));
            eye.setImageResource(hidden ? R.drawable.ic_pw_hide : R.drawable.ic_pw_show);
            etPass.setSelection(Math.max(0, Math.min(sel, etPass.length())));
        });
        etUrl.requestFocus();
        return v;
    }

    private void submit() {
        if (busy) return;
        String server = etUrl.getText().toString().trim();
        if (server.isEmpty()) {
            status.setText("أدخل رابط مزود الخدمة");
            etUrl.requestFocus();
            return;
        }
        final Playlist p;
        try {
            p = PlaylistFactory.build("", server,
                    etUser.getText().toString(), etPass.getText().toString());
        } catch (IllegalArgumentException e) {
            status.setText(e.getMessage());
            return;
        }
        busy = true;
        status.setText("جارٍ الحفظ…");
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            final long id = db.dao().insertPlaylist(p);
            Prefs.setActive(app, id);
            Async.main(() -> SyncRepository.sync(app, id, new SyncRepository.Callback() {
                @Override
                public void onProgress(String message) {
                    if (isAdded()) status.setText(message);
                }

                @Override
                public void onDone() {
                    if (isAdded()) ((MainActivity) requireActivity()).goHome();
                }

                @Override
                public void onError(String message) {
                    // Don't keep a playlist that failed to load.
                    Async.io(() -> {
                        db.dao().deletePlaylist(id);
                        if (Prefs.getActive(app) == id) Prefs.setActive(app, -1);
                    });
                    if (!isAdded()) return;
                    busy = false;
                    status.setText("تعذر إضافة القائمة: " + message);
                }
            }));
        });
    }
}
