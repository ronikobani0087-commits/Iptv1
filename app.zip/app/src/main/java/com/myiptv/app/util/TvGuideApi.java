package com.myiptv.app.util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;

/**
 * Reads the broadcaster of a match from https://tvguideapi.com/data/events.
 * One light request (cached 5 minutes) replaces the heavy program-guide (EPG) download.
 * The parser does not depend on exact field names: it looks for the event object that names both
 * teams and takes the channel names found inside it.
 */
public final class TvGuideApi {
    private static final String URL = "https://tvguideapi.com/data/events";
    private static final long TTL_MS = 5L * 60L * 1000L;
    private static String cache;
    private static long cacheTime;
    /** Last outcome, for diagnostics: "ok, N channel", "HTTP 403", "match not in list"... */
    public static volatile String lastStatus = "";

    private TvGuideApi() {}

    /** Channel names (e.g. "beIN SPORTS 3") for the match, empty when not found. Blocking (network). */
    public static List<String> channelsFor(SportsRepository.Match m) {
        List<String> out = new ArrayList<>();
        try {
            Object root = new org.json.JSONTokener(load()).nextValue();
            visit(root, m, out, 0);
            lastStatus = out.isEmpty() ? "match not in list" : "ok";
        } catch (Exception e) {
            lastStatus = String.valueOf(e.getMessage());
        }
        return out;
    }

    private static String load() throws Exception {
        synchronized (TvGuideApi.class) {
            if (cache != null && System.currentTimeMillis() - cacheTime < TTL_MS) return cache;
        }
        String s = Http.readStringBrowser(URL);
        synchronized (TvGuideApi.class) {
            cache = s;
            cacheTime = System.currentTimeMillis();
        }
        return s;
    }

    private static void visit(Object node, SportsRepository.Match m, List<String> out, int depth) {
        if (node == null || depth > 8 || !out.isEmpty()) return;
        if (node instanceof JSONArray) {
            JSONArray a = (JSONArray) node;
            for (int i = 0; i < a.length() && out.isEmpty(); i++) visit(a.opt(i), m, out, depth + 1);
        } else if (node instanceof JSONObject) {
            JSONObject o = (JSONObject) node;
            StringBuilder text = new StringBuilder();
            flatten(o, text, 0);
            String t = MatchBroadcast.norm(text.toString());
            if (MatchBroadcast.hasTeam(t, m.homeNames, m.home) && MatchBroadcast.hasTeam(t, m.awayNames, m.away)
                    && text.length() < 4000) {
                collectChannels(o, out, 0);
                if (!out.isEmpty()) return;
            }
            Iterator<String> keys = o.keys();
            while (keys.hasNext() && out.isEmpty()) visit(o.opt(keys.next()), m, out, depth + 1);
        }
    }

    private static void flatten(Object n, StringBuilder sb, int depth) {
        if (n == null || depth > 5 || sb.length() > 4000) return;
        if (n instanceof String) {
            sb.append(' ').append((String) n);
        } else if (n instanceof JSONObject) {
            JSONObject o = (JSONObject) n;
            Iterator<String> k = o.keys();
            while (k.hasNext()) flatten(o.opt(k.next()), sb, depth + 1);
        } else if (n instanceof JSONArray) {
            JSONArray a = (JSONArray) n;
            for (int i = 0; i < a.length(); i++) flatten(a.opt(i), sb, depth + 1);
        }
    }

    private static void collectChannels(Object n, List<String> out, int depth) {
        if (n == null || depth > 5) return;
        if (n instanceof JSONObject) {
            JSONObject o = (JSONObject) n;
            Iterator<String> k = o.keys();
            while (k.hasNext()) {
                String key = k.next();
                String lk = key.toLowerCase(Locale.ROOT);
                Object v = o.opt(key);
                boolean channelKey = lk.contains("channel") || lk.contains("network")
                        || lk.contains("broadcast") || lk.contains("station");
                if (channelKey) addNames(v, out, 0);
                else if (v instanceof JSONObject || v instanceof JSONArray) collectChannels(v, out, depth + 1);
            }
        } else if (n instanceof JSONArray) {
            JSONArray a = (JSONArray) n;
            for (int i = 0; i < a.length(); i++) collectChannels(a.opt(i), out, depth + 1);
        }
    }

    private static void addNames(Object v, List<String> out, int depth) {
        if (v == null || depth > 3) return;
        if (v instanceof String) {
            String s = ((String) v).trim();
            if (!s.isEmpty() && !out.contains(s)) out.add(s);
        } else if (v instanceof JSONArray) {
            JSONArray a = (JSONArray) v;
            for (int i = 0; i < a.length(); i++) addNames(a.opt(i), out, depth + 1);
        } else if (v instanceof JSONObject) {
            JSONObject o = (JSONObject) v;
            for (String f : new String[]{"name", "title", "channel", "label"}) {
                if (o.opt(f) instanceof String) {
                    addNames(o.opt(f), out, depth + 1);
                    return;
                }
            }
        }
    }
}
