package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.SportsRepository;
import com.myiptv.app.util.Ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** "عرض الكل" of today's matches: every match on one board (3 cards per row); a card opens its details. */
public class MatchesActivity extends BaseActivity {
    private static final int COLUMNS = 3;
    private LinearLayout grid;
    private TextView subtitle;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        load();
    }

    private View buildUi() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackgroundColor(ContextCompat.getColor(c, R.color.bg));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, 16), Ui.dp(c, 24), Ui.dp(c, 12));
        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        TextView title = new TextView(c);
        title.setText("مباريات اليوم");
        title.setTextColor(Color.WHITE);
        title.setTextSize(22);
        title.setTypeface(title.getTypeface(), android.graphics.Typeface.BOLD);
        col.addView(title);

        subtitle = new TextView(c);
        subtitle.setText("جارٍ تحميل المباريات…");
        subtitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
        subtitle.setTextSize(14);
        subtitle.setPadding(0, Ui.dp(c, 2), 0, Ui.dp(c, 10));
        col.addView(subtitle);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipChildren(false);
        grid = new LinearLayout(c);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.addView(grid, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void load() {
        Async.io(() -> {
            List<SportsRepository.Match> ms;
            try {
                ms = SportsRepository.today();
            } catch (Exception e) {
                ms = new ArrayList<>();
            }
            final List<SportsRepository.Match> list = ms;
            Async.main(() -> {
                if (isFinishing() || isDestroyed()) return;
                show(list);
            });
        });
    }

    private void show(List<SportsRepository.Match> list) {
        grid.removeAllViews();
        if (list.isEmpty()) {
            subtitle.setText("لا توجد مباريات مهمة حالياً");
            return;
        }
        subtitle.setText(String.format(Locale.US, "%d مباراة \u2022 اليوم", list.size()));
        View first = null;
        LinearLayout row = null;
        for (int i = 0; i < list.size(); i++) {
            if (i % COLUMNS == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                grid.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            View card = card(list.get(i));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 150), 1f);
            lp.setMargins(Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5));
            row.addView(card, lp);
            if (first == null) first = card;
        }
        // fill the last row so the cards keep the same width
        int rest = list.size() % COLUMNS;
        if (rest != 0 && row != null) {
            for (int k = rest; k < COLUMNS; k++) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            }
        }
        if (first != null) first.requestFocus();
    }

    private View card(final SportsRepository.Match m) {
        final Context c = this;
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
        card.setBackground(rounded(0x33202B40, 16));
        card.setFocusable(true);
        card.setClickable(true);
        card.setOnFocusChangeListener((v, has) -> v.setBackground(rounded(has ? 0x773A4C70 : 0x33202B40, 16)));
        card.setOnClickListener(v -> MatchDetailsActivity.start(c, m.id));

        TextView league = new TextView(c);
        league.setText(m.league);
        league.setTextColor(ContextCompat.getColor(c, R.color.muted));
        league.setTextSize(12);
        league.setMaxLines(1);
        league.setGravity(Gravity.CENTER);
        card.addView(league);

        LinearLayout teams = new LinearLayout(c);
        teams.setOrientation(LinearLayout.HORIZONTAL);
        teams.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        teams.setGravity(Gravity.CENTER);
        card.addView(teams, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        teams.addView(team(c, m.home, m.homeLogo), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        boolean started = !"pre".equals(m.state);
        TextView big = new TextView(c);
        big.setTextColor(Color.WHITE);
        big.setTypeface(big.getTypeface(), android.graphics.Typeface.BOLD);
        big.setTextSize(started ? 18 : 15);
        big.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        big.setText(started ? m.awayScore + " - " + m.homeScore
                : new SimpleDateFormat("HH:mm", Locale.US).format(new Date(m.start)));
        mid.addView(big);
        TextView badge = new TextView(c);
        badge.setTextSize(11);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(Ui.dp(c, 8), Ui.dp(c, 2), Ui.dp(c, 8), Ui.dp(c, 2));
        if ("in".equals(m.state)) {
            badge.setText("مباشر " + m.clock);
            badge.setTextColor(ContextCompat.getColor(c, R.color.live_red));
            badge.setBackground(rounded(ContextCompat.getColor(c, R.color.live_bg), 10));
        } else if ("post".equals(m.state)) {
            badge.setText("انتهت");
            badge.setTextColor(ContextCompat.getColor(c, R.color.muted));
        } else {
            badge.setText("اليوم");
            badge.setTextColor(ContextCompat.getColor(c, R.color.muted));
        }
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = Ui.dp(c, 4);
        mid.addView(badge, bp);
        teams.addView(mid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        teams.addView(team(c, m.away, m.awayLogo), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return card;
    }

    private LinearLayout team(Context c, String name, String logo) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackground(rounded(0x22FFFFFF, 40));
        iv.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6));
        if (Ui.validLogo(logo)) Glide.with(this).load(logo).into(iv);
        else iv.setImageResource(R.drawable.ic_live);
        box.addView(iv, new LinearLayout.LayoutParams(Ui.dp(c, 52), Ui.dp(c, 52)));
        TextView t = new TextView(c);
        t.setText(name);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setMaxLines(1);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 4);
        box.addView(t, lp);
        return box;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(Ui.dp(this, radiusDp));
        return g;
    }
}
