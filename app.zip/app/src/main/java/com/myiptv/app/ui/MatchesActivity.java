package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.SportsRepository;
import com.myiptv.app.util.Ui;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/**
 * "عرض الكل" of the matches: three tabs on top (yesterday = results, today = the default one that opens with
 * the page, tomorrow = kick-off times) and under them every match of the chosen day on one board
 * (3 cards per row); a card opens its details. Works with touch and with the remote (D-pad + OK).
 */
public class MatchesActivity extends BaseActivity {
    private static final int COLUMNS = 3;
    /** Day offsets of the tabs, in the order they are added (the first one sits on the right in RTL). */
    private static final int[] OFFSETS = {-1, 0, 1};
    private static final String[] TAB_NAMES = {"مباريات الأمس", "مباريات اليوم", "مباريات الغد"};
    private static final String[] DAY_WORD = {"الأمس", "اليوم", "غداً"};
    private static final String[] EMPTY_TEXT = {
            "لا توجد مباريات مهمة أمس", "لا توجد مباريات مهمة حالياً", "لا توجد مباريات مهمة غداً"};

    private LinearLayout grid;
    private TextView subtitle;
    private final TextView[] tabs = new TextView[3];
    private int current = 1; // today
    private int requestSeq;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(buildUi());
        load(current, true);
    }

    private View buildUi() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackgroundColor(ContextCompat.getColor(c, R.color.bg));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView appBg = new ImageView(c);
        appBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        appBg.setImageResource(R.drawable.bg_main);
        root.addView(appBg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, 16), Ui.dp(c, 24), Ui.dp(c, 12));
        root.addView(col, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout tabRow = new LinearLayout(c);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        tabRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        tabRow.setGravity(Gravity.CENTER);
        for (int i = 0; i < tabs.length; i++) {
            final int idx = i;
            final TextView t = new TextView(c);
            t.setId(View.generateViewId());
            t.setText(TAB_NAMES[i]);
            t.setTextSize(16);
            t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.dp(c, 24), Ui.dp(c, 8), Ui.dp(c, 24), Ui.dp(c, 8));
            t.setFocusable(true);
            t.setClickable(true);
            t.setOnFocusChangeListener((v, has) -> styleTab(idx, has));
            t.setOnClickListener(v -> selectTab(idx));
            tabs[i] = t;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(Ui.dp(c, 8), 0, Ui.dp(c, 8), 0);
            tabRow.addView(t, lp);
        }
        col.addView(tabRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        styleTabs();

        subtitle = new TextView(c);
        subtitle.setText("جارٍ تحميل المباريات…");
        subtitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
        subtitle.setTextSize(14);
        subtitle.setPadding(Ui.dp(c, 4), Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 8));
        col.addView(subtitle);

        ScrollView sv = new ScrollView(c);
        sv.setVerticalScrollBarEnabled(false);
        sv.setClipChildren(false);
        sv.setFocusable(false); // only the cards and the tabs take the remote's focus
        grid = new LinearLayout(c);
        grid.setOrientation(LinearLayout.VERTICAL);
        grid.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        sv.addView(grid, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(sv, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        return root;
    }

    private void styleTabs() {
        for (int i = 0; i < tabs.length; i++) styleTab(i, tabs[i] != null && tabs[i].hasFocus());
    }

    private void styleTab(int i, boolean focused) {
        TextView t = tabs[i];
        if (t == null) return;
        boolean selected = i == current;
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(Ui.dp(this, 22));
        if (selected) g.setColor(ContextCompat.getColor(this, R.color.accent));
        else g.setColor(focused ? 0x773A4C70 : 0x33202B40);
        if (focused) g.setStroke(Ui.dp(this, 2), ContextCompat.getColor(this, R.color.glass_focus_edge));
        else if (!selected) g.setStroke(Ui.dp(this, 1), ContextCompat.getColor(this, R.color.stroke));
        t.setBackground(g);
        t.setTextColor(selected ? ContextCompat.getColor(this, R.color.on_accent) : Color.WHITE);
    }

    private void selectTab(int i) {
        if (i == current && grid.getChildCount() > 0) return;
        current = i;
        styleTabs();
        load(i, false);
    }

    /** Loads the day of tab {@code tab}; an answer that arrives after another tab was chosen is dropped. */
    private void load(final int tab, final boolean focusFirst) {
        final int seq = ++requestSeq;
        final int offset = OFFSETS[tab];
        grid.removeAllViews();
        subtitle.setText("جارٍ تحميل المباريات…");
        Async.io(() -> {
            List<SportsRepository.Match> ms;
            try {
                ms = SportsRepository.day(offset);
            } catch (Exception e) {
                ms = new ArrayList<>();
            }
            final List<SportsRepository.Match> list = ms;
            Async.main(() -> {
                if (isFinishing() || isDestroyed() || seq != requestSeq) return;
                show(tab, list, focusFirst);
            });
        });
    }

    private void show(int tab, List<SportsRepository.Match> list, boolean focusFirst) {
        grid.removeAllViews();
        for (TextView t : tabs) t.setNextFocusDownId(View.NO_ID);
        if (list.isEmpty()) {
            subtitle.setText(EMPTY_TEXT[tab]);
            if (focusFirst) tabs[tab].requestFocus();
            return;
        }
        subtitle.setText(String.format(Locale.US, "%d مباراة \u2022 %s", list.size(), DAY_WORD[tab]));
        View first = null;
        LinearLayout row = null;
        for (int i = 0; i < list.size(); i++) {
            if (i % COLUMNS == 0) {
                row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
                grid.addView(row, new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            }
            View card = card(list.get(i), tab);
            if (i < COLUMNS) card.setNextFocusUpId(tabs[tab].getId()); // first row: Up goes to the chosen tab
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 150), 1f);
            lp.setMargins(Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5), Ui.dp(this, 5));
            row.addView(card, lp);
            if (first == null) {
                first = card;
                first.setId(View.generateViewId());
            }
        }
        // fill the last row so the cards keep the same width
        int rest = list.size() % COLUMNS;
        if (rest != 0 && row != null) {
            for (int k = rest; k < COLUMNS; k++) {
                row.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1f));
            }
        }
        for (TextView t : tabs) t.setNextFocusDownId(first.getId()); // Down from any tab: the first card
        if (focusFirst) first.requestFocus();
    }

    private View card(final SportsRepository.Match m, int tab) {
        final Context c = this;
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
        card.setBackground(rounded(0x33202B40, 16));
        card.setFocusable(true);
        card.setClickable(true);
        card.setOnFocusChangeListener((v, has) -> v.setBackground(rounded(has ? 0x773A4C70 : 0x33202B40, 16)));
        card.setOnClickListener(v -> MatchDetailsActivity.start(c, m.id));

        TextView league = new TextView(c);
        league.setText(m.league);
        league.setTextColor(ContextCompat.getColor(c, R.color.muted));
        league.setTextSize(12);
        league.setMaxLines(1);
        league.setGravity(Gravity.CENTER);
        card.addView(league);

        LinearLayout teams = new LinearLayout(c);
        teams.setOrientation(LinearLayout.HORIZONTAL);
        teams.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        teams.setGravity(Gravity.CENTER);
        card.addView(teams, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        teams.addView(team(c, m.home, m.homeLogo), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        boolean started = !"pre".equals(m.state);
        TextView big = new TextView(c);
        big.setTextColor(Color.WHITE);
        big.setTypeface(big.getTypeface(), android.graphics.Typeface.BOLD);
        big.setTextSize(started ? 18 : 15);
        big.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        big.setText(started ? m.awayScore + " - " + m.homeScore
                : new SimpleDateFormat("HH:mm", Locale.US).format(new Date(m.start)));
        mid.addView(big);
        TextView badge = new TextView(c);
        badge.setTextSize(11);
        badge.setGravity(Gravity.CENTER);
        badge.setPadding(Ui.dp(c, 8), Ui.dp(c, 2), Ui.dp(c, 8), Ui.dp(c, 2));
        if ("in".equals(m.state)) {
            badge.setText("مباشر " + m.clock);
            badge.setTextColor(ContextCompat.getColor(c, R.color.live_red));
            badge.setBackground(rounded(ContextCompat.getColor(c, R.color.live_bg), 10));
        } else if ("post".equals(m.state)) {
            badge.setText("انتهت");
            badge.setTextColor(ContextCompat.getColor(c, R.color.muted));
        } else {
            badge.setText(tab == 0 ? "أمس" : tab == 2 ? "غداً" : "اليوم");
            badge.setTextColor(ContextCompat.getColor(c, R.color.muted));
        }
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = Ui.dp(c, 4);
        mid.addView(badge, bp);
        teams.addView(mid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        teams.addView(team(c, m.away, m.awayLogo), new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return card;
    }

    private LinearLayout team(Context c, String name, String logo) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackground(rounded(0x22FFFFFF, 40));
        iv.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6));
        Ui.loadLogo(iv, logo, R.drawable.ic_live, 0, 0);
        box.addView(iv, new LinearLayout.LayoutParams(Ui.dp(c, 52), Ui.dp(c, 52)));
        TextView t = new TextView(c);
        t.setText(name);
        t.setTextColor(Color.WHITE);
        t.setTextSize(13);
        t.setMaxLines(1);
        t.setEllipsize(android.text.TextUtils.TruncateAt.END);
        t.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 4);
        box.addView(t, lp);
        return box;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(Ui.dp(this, radiusDp));
        return g;
    }
}
