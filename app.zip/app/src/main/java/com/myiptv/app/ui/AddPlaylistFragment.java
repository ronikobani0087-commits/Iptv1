package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.PlaylistFactory;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;

/** "أضف قائمة التشغيل": a glass card with an Xtream tab (server, user, password) and an M3U tab (link). */
public class AddPlaylistFragment extends Fragment {
    /** first = true on the very first launch (no account yet): no back button. */
    public static AddPlaylistFragment newInstance(boolean first) {
        AddPlaylistFragment f = new AddPlaylistFragment();
        Bundle b = new Bundle();
        b.putBoolean(ARG_FIRST, first);
        f.setArguments(b);
        return f;
    }

    private static final String ARG_FIRST = "first";
    private EditText etName, etUrl, etUser, etPass;
    private TextView btnSave, status, tabXtream, tabM3u, lblUrl;
    private View rowCred;
    private boolean xtream = true;
    private boolean passShown;
    private boolean busy;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_add_playlist, container, false);
        etName = v.findViewById(R.id.et_name);
        etUrl = v.findViewById(R.id.et_url);
        etUser = v.findViewById(R.id.et_user);
        etPass = v.findViewById(R.id.et_pass);
        btnSave = v.findViewById(R.id.btn_save);
        status = v.findViewById(R.id.status);
        tabXtream = v.findViewById(R.id.tab_xtream);
        tabM3u = v.findViewById(R.id.tab_m3u);
        lblUrl = v.findViewById(R.id.lbl_url);
        rowCred = v.findViewById(R.id.row_cred);

        tabXtream.setOnClickListener(x -> setMode(true));
        tabM3u.setOnClickListener(x -> setMode(false));
        setMode(true);

        btnSave.setOnClickListener(x -> {
            com.myiptv.app.util.Ui.hideKeyboard(x); // the remote's OK on the button closes the keyboard
            submit();
        });
        btnSave.setOnFocusChangeListener((x, has) -> {
            if (has) com.myiptv.app.util.Ui.hideKeyboard(x);
        });
        v.findViewById(R.id.btn_eye).setOnClickListener(x -> {
            passShown = !passShown;
            etPass.setInputType(android.text.InputType.TYPE_CLASS_TEXT | (passShown
                    ? android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    : android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD));
            etPass.setSelection(etPass.length());
        });
        View back = v.findViewById(R.id.btn_back);
        Bundle args = getArguments();
        if (args != null && args.getBoolean(ARG_FIRST, false)) back.setVisibility(View.GONE);
        back.setOnClickListener(x -> {
            if (!busy) requireActivity().getSupportFragmentManager().popBackStack();
        });
        etPass.setOnEditorActionListener((tv, action, ev) -> {
            if (action == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                submit();
                return true;
            }
            return false;
        });
        return v;
    }

    private void setMode(boolean x) {
        xtream = x;
        Context c = requireContext();
        tabXtream.setSelected(x);
        tabM3u.setSelected(!x);
        tabXtream.setTextColor(ContextCompat.getColor(c, x ? R.color.text : R.color.muted));
        tabM3u.setTextColor(ContextCompat.getColor(c, x ? R.color.muted : R.color.text));
        rowCred.setVisibility(x ? View.VISIBLE : View.GONE);
        lblUrl.setText(x ? "رابط السيرفر" : "أدخل رابط M3U");
        etUrl.setHint(x ? "http://server_domain:8080" : "http://server_domain/playlist.m3u");
        status.setText("");
    }

    private void submit() {
        if (busy) return;
        com.myiptv.app.util.Ui.hideKeyboard(etUrl);
        String server = etUrl.getText().toString().trim();
        if (server.isEmpty()) {
            status.setText("أدخل رابط مزود الخدمة");
            return;
        }
        final Playlist p;
        try {
            p = PlaylistFactory.build(etName.getText().toString(), server,
                    xtream ? etUser.getText().toString() : "",
                    xtream ? etPass.getText().toString() : "");
        } catch (IllegalArgumentException e) {
            status.setText(e.getMessage());
            return;
        }

        busy = true;
        btnSave.setAlpha(0.5f);
        status.setText("جارٍ الحفظ…");
        final Context app = requireContext().getApplicationContext();

        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            // the server that is connected now: kept as a fallback in case the new one cannot be loaded
            final long previous = Prefs.getActive(app);
            final long id = db.dao().insertPlaylist(p);
            // the new server becomes the connected one at once; the old one is left automatically
            Prefs.setActive(app, id);
            Async.main(() -> SyncRepository.sync(app, id, new SyncRepository.Callback() {
                @Override
                public void onProgress(String message) {
                    if (isAdded()) status.setText(message);
                }

                @Override
                public void onDone() {
                    com.myiptv.app.util.Prefs.markHomeDirty();
                    if (!isAdded()) return;
                    android.widget.Toast.makeText(app, "تم الاتصال بالسيرفر الجديد", android.widget.Toast.LENGTH_SHORT).show();
                    ((MainActivity) requireActivity()).goHome();
                }

                @Override
                public void onError(String message) {
                    // Don't keep a playlist that failed to load; go back to the server that was connected.
                    Async.io(() -> {
                        db.dao().deletePlaylist(id);
                        if (Prefs.getActive(app) == id) {
                            boolean prevAlive = previous >= 0 && db.dao().getPlaylist(previous) != null;
                            Prefs.setActive(app, prevAlive ? previous : -1);
                        }
                    });
                    if (!isAdded()) return;
                    busy = false;
                    btnSave.setAlpha(1f);
                    status.setText("تعذر إضافة القائمة: " + message);
                }
            }));
        });
    }
}
