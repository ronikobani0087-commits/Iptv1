package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.PlaylistFactory;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.AccountInfo;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;

public class AddPlaylistFragment extends Fragment {
    /** first = true on the very first launch (no account yet): no cancel button. */
    public static AddPlaylistFragment newInstance(boolean first) {
        AddPlaylistFragment f = new AddPlaylistFragment();
        Bundle b = new Bundle();
        b.putBoolean(ARG_FIRST, first);
        f.setArguments(b);
        return f;
    }
    private static final String ARG_FIRST = "first";
    private EditText etName, etUrl, etUser, etPass;
    private TextView btnSave, status, infoName, infoServer, infoUser, infoExp;
    private View listsBox;
    private android.widget.LinearLayout listsRow;
    private boolean passShown;
    private boolean busy;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_add_playlist, container, false);
        etName = v.findViewById(R.id.et_name);
        etUrl = v.findViewById(R.id.et_url);
        etUser = v.findViewById(R.id.et_user);
        etPass = v.findViewById(R.id.et_pass);
        btnSave = v.findViewById(R.id.btn_save);
        status = v.findViewById(R.id.status);
        listsBox = v.findViewById(R.id.lists_box);
        listsRow = v.findViewById(R.id.lists_row);
        infoName = v.findViewById(R.id.info_name);
        infoServer = v.findViewById(R.id.info_server);
        infoUser = v.findViewById(R.id.info_user);
        infoExp = v.findViewById(R.id.info_exp);
        btnSave.setOnClickListener(x -> submit());
        v.findViewById(R.id.btn_eye).setOnClickListener(x -> {
            passShown = !passShown;
            etPass.setInputType(android.text.InputType.TYPE_CLASS_TEXT | (passShown
                    ? android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD
                    : android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD));
            etPass.setSelection(etPass.length());
        });
        v.findViewById(R.id.btn_update).setOnClickListener(x -> updateActive());
        v.findViewById(R.id.btn_logout).setOnClickListener(x -> {
            long pid = Prefs.getActive(requireContext());
            if (pid >= 0) ((MainActivity) requireActivity()).confirmLogout(pid);
        });
        View cancel = v.findViewById(R.id.btn_cancel);
        Bundle args = getArguments();
        if (args != null && args.getBoolean(ARG_FIRST, false)) cancel.setVisibility(View.GONE);
        etPass.setOnEditorActionListener((tv, action, ev) -> {
            if (action == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                submit();
                return true;
            }
            return false;
        });
        cancel.setOnClickListener(x -> {
            if (!busy) requireActivity().getSupportFragmentManager().popBackStack();
        });
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadLists();
    }

    /** "قوائمي": one chip per saved list; the selected one shows the server info + expiry date. */
    private void loadLists() {
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            final java.util.List<Playlist> all = AppDatabase.get(app).dao().getPlaylists();
            final long active = Prefs.getActive(app);
            Async.main(() -> {
                if (!isAdded()) return;
                listsBox.setVisibility(all.isEmpty() ? View.GONE : View.VISIBLE);
                listsRow.removeAllViews();
                Playlist shown = null;
                for (Playlist p : all) {
                    boolean sel = p.id == active;
                    if (sel) shown = p;
                    TextView chip = com.myiptv.app.util.Ui.button(requireContext(),
                            (sel ? "✓ " : "") + p.name, sel);
                    chip.setOnClickListener(x -> {
                        Prefs.setActive(app, p.id);
                        loadLists();
                    });
                    android.widget.LinearLayout.LayoutParams lp = new android.widget.LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                    lp.setMarginEnd(com.myiptv.app.util.Ui.dp(requireContext(), 8));
                    listsRow.addView(chip, lp);
                }
                if (shown == null && !all.isEmpty()) shown = all.get(0);
                if (shown != null) showInfo(app, shown);
            });
        });
    }

    private void showInfo(final Context app, final Playlist p) {
        infoName.setText(p.name);
        String host = p.url;
        try {
            String h = android.net.Uri.parse(p.url).getHost();
            if (h != null) host = h;
        } catch (Exception ignored) {
        }
        infoServer.setText("xtream".equals(p.type) ? "Xtream · " + host : "M3U · " + host);
        boolean x = "xtream".equals(p.type);
        infoUser.setText(x ? "👤 " + p.username : "");
        infoUser.setVisibility(x ? View.VISIBLE : View.GONE);
        if (!x) {
            infoExp.setText("تاريخ الانتهاء: غير متوفر لقوائم M3U");
            return;
        }
        String cached = AccountInfo.cached(app, p.id);
        infoExp.setText("تاريخ الانتهاء: " + (cached.isEmpty() ? "…" : cached));
        Async.io(() -> {
            final String t = AccountInfo.fetch(app, p.id);
            Async.main(() -> {
                if (isAdded() && !t.isEmpty()) infoExp.setText("تاريخ الانتهاء: " + t);
            });
        });
    }

    /** "تحديث القوائم": reloads the active list from the server. */
    private void updateActive() {
        if (busy) return;
        final Context app = requireContext().getApplicationContext();
        final long pid = Prefs.getActive(app);
        if (pid < 0) {
            status.setText("لا توجد قائمة لتحديثها");
            return;
        }
        busy = true;
        status.setText("جارٍ التحديث…");
        SyncRepository.sync(app, pid, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
                if (isAdded()) status.setText(message);
            }

            @Override
            public void onDone() {
                busy = false;
                if (!isAdded()) return;
                status.setText("تم تحديث القائمة");
                loadLists();
            }

            @Override
            public void onError(String message) {
                busy = false;
                if (isAdded()) status.setText("تعذر التحديث: " + message);
            }
        });
    }

    private void submit() {
        if (busy) return;
        String server = etUrl.getText().toString().trim();
        if (server.isEmpty()) {
            status.setText("أدخل رابط مزود الخدمة");
            return;
        }
        final Playlist p;
        try {
            p = PlaylistFactory.build(etName.getText().toString(), server,
                    etUser.getText().toString(), etPass.getText().toString());
        } catch (IllegalArgumentException e) {
            status.setText(e.getMessage());
            return;
        }

        busy = true;
        btnSave.setAlpha(0.5f);
        status.setText("جارٍ الحفظ…");
        final Context app = requireContext().getApplicationContext();

        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            final long id = db.dao().insertPlaylist(p);
            Prefs.setActive(app, id);
            Async.main(() -> SyncRepository.sync(app, id, new SyncRepository.Callback() {
                @Override
                public void onProgress(String message) {
                    if (isAdded()) status.setText(message);
                }

                @Override
                public void onDone() {
                    if (isAdded()) ((MainActivity) requireActivity()).goHome();
                }

                @Override
                public void onError(String message) {
                    // Don't keep a playlist that failed to load.
                    Async.io(() -> {
                        db.dao().deletePlaylist(id);
                        if (Prefs.getActive(app) == id) Prefs.setActive(app, -1);
                    });
                    if (!isAdded()) return;
                    busy = false;
                    btnSave.setAlpha(1f);
                    status.setText("تعذر إضافة القائمة: " + message);
                }
            }));
        });
    }
}
