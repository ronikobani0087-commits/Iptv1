package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.PlaylistFactory;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;

public class AddPlaylistFragment extends Fragment {
    /** first = true on the very first launch (no account yet): no cancel button. */
    public static AddPlaylistFragment newInstance(boolean first) {
        AddPlaylistFragment f = new AddPlaylistFragment();
        Bundle b = new Bundle();
        b.putBoolean(ARG_FIRST, first);
        f.setArguments(b);
        return f;
    }
    private static final String ARG_FIRST = "first";
    private EditText etUrl, etUser, etPass;
    private TextView btnSave, status;
    private boolean busy;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_add_playlist, container, false);
        etUrl = v.findViewById(R.id.et_url);
        etUser = v.findViewById(R.id.et_user);
        etPass = v.findViewById(R.id.et_pass);
        btnSave = v.findViewById(R.id.btn_save);
        status = v.findViewById(R.id.status);
        btnSave.setOnClickListener(x -> submit());
        View cancel = v.findViewById(R.id.btn_cancel);
        Bundle args = getArguments();
        if (args != null && args.getBoolean(ARG_FIRST, false)) cancel.setVisibility(View.GONE);
        etPass.setOnEditorActionListener((tv, action, ev) -> {
            if (action == android.view.inputmethod.EditorInfo.IME_ACTION_DONE) {
                submit();
                return true;
            }
            return false;
        });
        cancel.setOnClickListener(x -> {
            if (!busy) requireActivity().getSupportFragmentManager().popBackStack();
        });
        return v;
    }

    private void submit() {
        if (busy) return;
        String server = etUrl.getText().toString().trim();
        if (server.isEmpty()) {
            status.setText("أدخل رابط مزود الخدمة");
            return;
        }
        final Playlist p;
        try {
            p = PlaylistFactory.build("", server,
                    etUser.getText().toString(), etPass.getText().toString());
        } catch (IllegalArgumentException e) {
            status.setText(e.getMessage());
            return;
        }

        busy = true;
        btnSave.setAlpha(0.5f);
        status.setText("جارٍ الحفظ…");
        final Context app = requireContext().getApplicationContext();

        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            final long id = db.dao().insertPlaylist(p);
            Prefs.setActive(app, id);
            Async.main(() -> SyncRepository.sync(app, id, new SyncRepository.Callback() {
                @Override
                public void onProgress(String message) {
                    if (isAdded()) status.setText(message);
                }

                @Override
                public void onDone() {
                    if (isAdded()) ((MainActivity) requireActivity()).goHome();
                }

                @Override
                public void onError(String message) {
                    // Don't keep a playlist that failed to load.
                    Async.io(() -> {
                        db.dao().deletePlaylist(id);
                        if (Prefs.getActive(app) == id) Prefs.setActive(app, -1);
                    });
                    if (!isAdded()) return;
                    busy = false;
                    btnSave.setAlpha(1f);
                    status.setText("تعذر إضافة القائمة: " + message);
                }
            }));
        });
    }
}
