package com.myiptv.app.util;

import android.content.Context;

import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;

import org.json.JSONObject;

import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Subscription expiry date of an Xtream account (cached in Prefs, refreshed from the server). */
public final class AccountInfo {
    private AccountInfo() {}

    private static String key(long pid) {
        return "exp_" + pid;
    }

    /** Text to show under the menu, or "" when unknown (M3U lists have no expiry). */
    public static String cached(Context c, long pid) {
        return Prefs.getString(c, key(pid));
    }

    /** Blocking: asks the server and stores the result. Call from a background thread. */
    public static String fetch(Context c, long pid) {
        try {
            Playlist p = AppDatabase.get(c.getApplicationContext()).dao().getPlaylist(pid);
            if (p == null || !"xtream".equals(p.type)) return "";
            String api = p.url + "/player_api.php?username=" + URLEncoder.encode(p.username, "UTF-8")
                    + "&password=" + URLEncoder.encode(p.password, "UTF-8");
            JSONObject o = new JSONObject(Http.readString(api));
            JSONObject ui = o.optJSONObject("user_info");
            if (ui == null) return cached(c, pid);
            String raw = ui.optString("exp_date", "");
            String text;
            if (raw.isEmpty() || "null".equals(raw)) {
                text = "غير محدود";
            } else {
                long sec = Long.parseLong(raw.trim());
                text = new SimpleDateFormat("yyyy/MM/dd", Locale.US).format(new Date(sec * 1000L));
            }
            Prefs.putString(c, key(pid), text);
            return text;
        } catch (Exception e) {
            return cached(c, pid);
        }
    }
}
