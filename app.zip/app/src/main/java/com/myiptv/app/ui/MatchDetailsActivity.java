package com.myiptv.app.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.LiveQueue;
import com.myiptv.app.util.MatchBroadcast;
import com.myiptv.app.util.SportsRepository;
import com.myiptv.app.util.Ui;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

/**
 * Match details (landscape, remote friendly). The first item is "شاهد المباراة": it opens the channel
 * that carries the match, or says that the broadcast details are not available.
 */
public class MatchDetailsActivity extends BaseActivity {
    private static final String EXTRA_ID = "match_id";

    public static void start(Context context, String matchId) {
        Intent i = new Intent(context, MatchDetailsActivity.class);
        i.putExtra(EXTRA_ID, matchId);
        context.startActivity(i);
    }

    private SportsRepository.Match match;
    private MatchBroadcast.Result broadcast;
    private TextView watchBtn;
    private TextView channelValue;
    private TextView countdown;
    private TextView roundValue, firstLegValue, refereeValue;
    private final Handler ticker = new Handler(Looper.getMainLooper());
    private boolean tickerOn;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        match = SportsRepository.find(getIntent().getStringExtra(EXTRA_ID));
        if (match == null) {
            finish();
            return;
        }
        setContentView(buildUi());
        resolveChannel();
    }

    @Override
    protected void onResume() {
        super.onResume();
        startTicker();
    }

    @Override
    protected void onPause() {
        tickerOn = false;
        ticker.removeCallbacksAndMessages(null);
        super.onPause();
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackgroundColor(ContextCompat.getColor(c, R.color.bg));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setPadding(Ui.dp(c, 24), Ui.dp(c, 18), Ui.dp(c, 24), Ui.dp(c, 18));
        root.addView(row, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // first child sits on the right: the teams card
        LinearLayout teams = buildTeamsCard(c);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.MATCH_PARENT, 1f);
        tp.setMarginStart(0);
        tp.setMarginEnd(Ui.dp(c, 18));
        row.addView(teams, tp);

        // second child, on the left: watch button first, then the information rows
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(false);
        scroll.setVerticalScrollBarEnabled(false);
        scroll.setClipChildren(false);
        scroll.setClipToPadding(false);
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        col.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6));
        scroll.addView(col, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row.addView(scroll, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1.5f));

        // 1) شاهد المباراة (always the first option; the text changes once the channel is known)
        watchBtn = Ui.button(c, "جارٍ البحث عن القناة…", false);
        watchBtn.setTextSize(18);
        watchBtn.setTypeface(watchBtn.getTypeface(), android.graphics.Typeface.BOLD);
        watchBtn.setNextFocusUpId(View.NO_ID);
        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 54));
        wp.bottomMargin = Ui.dp(c, 14);
        col.addView(watchBtn, wp);
        watchBtn.setOnClickListener(v -> onWatch());

        TextView head = new TextView(c);
        head.setText("معلومات اللقاء");
        head.setTextColor(ContextCompat.getColor(c, R.color.muted));
        head.setTextSize(15);
        head.setPadding(Ui.dp(c, 4), 0, Ui.dp(c, 4), Ui.dp(c, 8));
        col.addView(head);

        addRow(col, "البطولة", match.league);
        roundValue = addRow(col, "الجولة", match.round);
        firstLegValue = addRow(col, "نتيجة الذهاب", match.firstLeg);
        if (!match.venue.isEmpty()) addRow(col, "ملعب المباراة", match.venue);
        channelValue = addRow(col, "القناة الناقلة", "جارٍ البحث…");
        refereeValue = addRow(col, "حكم المباراة", match.referee);
        showOptional();
        addRow(col, "وقت المباراة", timeText());
        addRow(col, "تاريخ المباراة", dateText());

        watchBtn.post(() -> watchBtn.requestFocus());
        return root;
    }

    private LinearLayout buildTeamsCard(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setPadding(Ui.dp(c, 14), Ui.dp(c, 14), Ui.dp(c, 14), Ui.dp(c, 14));
        card.setBackground(rounded(0x33202B40, 18));

        TextView league = new TextView(c);
        league.setText(match.league);
        league.setTextColor(Color.WHITE);
        league.setTextSize(14);
        league.setGravity(Gravity.CENTER);
        league.setPadding(Ui.dp(c, 14), Ui.dp(c, 6), Ui.dp(c, 14), Ui.dp(c, 6));
        league.setBackground(rounded(0xFF1A2438, 16));
        card.addView(league, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout teamsRow = new LinearLayout(c);
        teamsRow.setOrientation(LinearLayout.HORIZONTAL);
        teamsRow.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        teamsRow.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        rp.topMargin = Ui.dp(c, 8);
        card.addView(teamsRow, rp);

        // home on the right (first in RTL), away on the left
        teamsRow.addView(teamBox(c, match.home, match.homeLogo),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        LinearLayout mid = new LinearLayout(c);
        mid.setOrientation(LinearLayout.VERTICAL);
        mid.setGravity(Gravity.CENTER);
        boolean started = !"pre".equals(match.state);
        TextView big = new TextView(c);
        big.setTextColor(Color.WHITE);
        big.setTypeface(big.getTypeface(), android.graphics.Typeface.BOLD);
        big.setTextSize(started ? 30 : 22);
        big.setGravity(Gravity.CENTER);
        big.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        big.setText(started ? match.awayScore + " - " + match.homeScore : timeText());
        mid.addView(big);

        countdown = new TextView(c);
        countdown.setTextSize(15);
        countdown.setGravity(Gravity.CENTER);
        countdown.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        countdown.setPadding(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 4));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.topMargin = Ui.dp(c, 6);
        mid.addView(countdown, cp);
        teamsRow.addView(mid, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        teamsRow.addView(teamBox(c, match.away, match.awayLogo),
                new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        updateCountdown();
        return card;
    }

    private LinearLayout teamBox(Context c, String name, String logo) {
        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setGravity(Gravity.CENTER_HORIZONTAL);
        ImageView iv = new ImageView(c);
        iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
        iv.setBackground(rounded(0x22FFFFFF, 60));
        iv.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
        if (Ui.validLogo(logo)) {
            Glide.with(this).load(logo).into(iv);
        } else {
            iv.setImageResource(R.drawable.ic_live);
        }
        box.addView(iv, new LinearLayout.LayoutParams(Ui.dp(c, 76), Ui.dp(c, 76)));
        TextView t = new TextView(c);
        t.setText(name);
        t.setTextColor(Color.WHITE);
        t.setTextSize(16);
        t.setGravity(Gravity.CENTER);
        t.setMaxLines(2);
        t.setTypeface(t.getTypeface(), android.graphics.Typeface.BOLD);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 8);
        box.addView(t, lp);
        return box;
    }

    /** One information row: label on the right, value next to it (like the phone app). Returns the value view. */
    private TextView addRow(LinearLayout col, String label, String value) {
        Context c = this;
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setBackground(rounded(0x33202B40, 14));
        r.setPadding(Ui.dp(c, 16), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 12));
        // focusable so the remote can walk down the list and scroll it; the button stays first
        r.setFocusable(true);
        r.setOnFocusChangeListener((v, has) ->
                v.setBackground(rounded(has ? 0x663A4C70 : 0x33202B40, 14)));

        TextView l = new TextView(c);
        l.setText(label);
        l.setTextColor(ContextCompat.getColor(c, R.color.muted));
        l.setTextSize(15);
        r.addView(l, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView v = new TextView(c);
        v.setText(value);
        v.setTextColor(Color.WHITE);
        v.setTextSize(16);
        v.setTypeface(v.getTypeface(), android.graphics.Typeface.BOLD);
        r.addView(v, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1.4f));

        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = Ui.dp(c, 8);
        col.addView(r, lp);
        return v;
    }

    private GradientDrawable rounded(int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(Ui.dp(this, radiusDp));
        return g;
    }

    // ------------------------------------------------------------------ channel

    /** Rows without data (round, first leg, referee) stay hidden, like on the phone. */
    private void showOptional() {
        setRowVisible(roundValue, match.round);
        setRowVisible(firstLegValue, match.firstLeg);
        setRowVisible(refereeValue, match.referee);
    }

    private void setRowVisible(TextView v, String text) {
        if (v == null) return;
        boolean has = text != null && !text.isEmpty();
        v.setText(has ? text : "");
        ((View) v.getParent()).setVisibility(has ? View.VISIBLE : View.GONE);
    }

    private void resolveChannel() {
        final Context app = getApplicationContext();
        final SportsRepository.Match m = match;
        Async.io(() -> {
            final MatchBroadcast.Result r = MatchBroadcast.resolve(app, m);
            Async.main(() -> {
                if (isFinishing() || isDestroyed()) return;
                broadcast = r;
                showChannel();
            });
            // referee / round: a second, slower lookup that must never delay the watch button
            SportsRepository.loadExtras(m);
            Async.main(() -> {
                if (isFinishing() || isDestroyed()) return;
                showOptional();
            });
        });
    }

    private void showChannel() {
        if (broadcast != null && broadcast.playable()) {
            watchBtn.setText("شاهد المباراة  •  " + broadcast.label);
            watchBtn.setBackgroundResource(R.drawable.bg_button);
            watchBtn.setTextColor(ContextCompat.getColor(this, R.color.on_accent));
            channelValue.setText(broadcast.label);
        } else {
            // not found automatically: the button lets the person pick the channel by hand
            boolean canPick = broadcast != null && !broadcast.queue.isEmpty();
            watchBtn.setText(canPick ? "اختر القناة لمشاهدة المباراة" : "تفاصيل البث غير موجودة");
            watchBtn.setBackgroundResource(R.drawable.bg_button_secondary);
            watchBtn.setTextColor(ContextCompat.getColor(this, R.color.text));
            boolean named = broadcast != null && !broadcast.label.isEmpty();
            channelValue.setText(named ? broadcast.label : "غير متوفرة");
        }
        // keep the remote focus on the button whatever the text change did
        watchBtn.requestFocus();
    }

    private void onWatch() {
        if (broadcast == null) { // still searching
            Toast.makeText(this, "جارٍ البحث عن القناة…", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!broadcast.playable()) {
            pickChannel(broadcast.queue);
            return;
        }
        if (broadcast.variants.size() > 1) {
            pickChannel(broadcast.variants); // HD / FHD / 4K / SD versions of the carrying channel
            return;
        }
        play(broadcast.channel, broadcast.number);
    }

    private void play(com.myiptv.app.data.Item ch, int number) {
        LiveQueue.set(broadcast.queue, null);
        PlayerActivity.startLive(this, ch.streamUrl, ch.name, ch.icon, number, "بث مباشر");
    }

    /** The match's channel is unknown: let the person choose one of the sports channels of the subscription. */
    private void pickChannel(final java.util.List<com.myiptv.app.data.Item> list) {
        if (list == null || list.isEmpty()) {
            Toast.makeText(this, "لا توجد قنوات رياضية في القائمة الحالية", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) {
            String n = list.get(i).name == null ? "" : list.get(i).name;
            names[i] = n.replaceAll("^[\\s|\\[\\(]*[A-Za-z]{2,3}[\\s|\\]\\):\\-]+", "").trim();
        }
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("اختر القناة الناقلة")
                .setItems(names, (d, which) -> {
                    com.myiptv.app.data.Item it = list.get(which);
                    int pos = broadcast.queue.indexOf(it);
                    play(it, pos < 0 ? which + 1 : pos + 1);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    // ------------------------------------------------------------------ time

    private Locale latin() {
        return Locale.forLanguageTag("ar-u-nu-latn");
    }

    private String timeText() {
        return new SimpleDateFormat("hh:mm a", latin()).format(new Date(match.start));
    }

    private String dateText() {
        return new SimpleDateFormat("EEEE ( dd-MM-yyyy )", latin()).format(new Date(match.start));
    }

    private void startTicker() {
        tickerOn = true;
        ticker.removeCallbacksAndMessages(null);
        ticker.post(new Runnable() {
            @Override
            public void run() {
                if (!tickerOn) return;
                updateCountdown();
                ticker.postDelayed(this, 1000L);
            }
        });
    }

    private void updateCountdown() {
        if (countdown == null || match == null) return;
        if ("in".equals(match.state)) {
            countdown.setText("مباشر " + match.clock);
            countdown.setTextColor(ContextCompat.getColor(this, R.color.live_red));
            countdown.setBackground(rounded(ContextCompat.getColor(this, R.color.live_bg), 14));
        } else if ("post".equals(match.state)) {
            countdown.setText("انتهت المباراة");
            countdown.setTextColor(ContextCompat.getColor(this, R.color.muted));
            countdown.setBackground(rounded(0xFF1A2438, 14));
        } else {
            long left = Math.max(0L, (match.start - System.currentTimeMillis()) / 1000L);
            countdown.setText(left == 0L ? "على وشك البدء"
                    : String.format(Locale.US, "%02d : %02d : %02d",
                            left / 3600L, (left % 3600L) / 60L, left % 60L));
            countdown.setTextColor(Color.WHITE);
            countdown.setBackground(rounded(0xFF1A2438, 14));
        }
    }
}
