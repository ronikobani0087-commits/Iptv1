package com.myiptv.app.ui;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.myiptv.app.R;
import com.myiptv.app.util.Ui;

/** Internet speed test: runs Fast.com (Netflix) inside the app. */
public class SpeedTestActivity extends AppCompatActivity {

    @Override
    protected void attachBaseContext(android.content.Context base) {
        super.attachBaseContext(com.myiptv.app.util.Ui.scaled(base));
    }

    private static final String URL = "https://fast.com";

    private WebView web;
    private TextView message;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(ContextCompat.getColor(this, R.color.bg));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(Ui.dp(this, 16), Ui.dp(this, 8), Ui.dp(this, 16), Ui.dp(this, 8));
        bar.setBackgroundColor(ContextCompat.getColor(this, R.color.sidebar));

        TextView title = new TextView(this);
        title.setText("اختبار السرعة · Fast.com");
        title.setTextColor(ContextCompat.getColor(this, R.color.text));
        title.setTextSize(15);
        bar.addView(title, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView reload = Ui.button(this, "إعادة الاختبار", false);
        reload.setOnClickListener(v -> web.loadUrl(URL));
        bar.addView(reload);

        TextView close = Ui.button(this, "إغلاق", true);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        cp.setMarginStart(Ui.dp(this, 8));
        close.setOnClickListener(v -> finish());
        bar.addView(close, cp);
        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        message = new TextView(this);
        message.setTextColor(ContextCompat.getColor(this, R.color.muted));
        message.setTextSize(13);
        message.setPadding(Ui.dp(this, 16), Ui.dp(this, 6), Ui.dp(this, 16), Ui.dp(this, 6));
        message.setText("جارٍ تحميل الاختبار…");
        root.addView(message, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        web.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        web.setBackgroundColor(0xFF000000);
        WebSettings st = web.getSettings();
        st.setJavaScriptEnabled(true);
        st.setDomStorageEnabled(true);
        st.setMediaPlaybackRequiresUserGesture(false);
        web.setFocusable(true);
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                message.setVisibility(View.VISIBLE);
                message.setText("جارٍ تحميل الاختبار…");
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                message.setVisibility(View.GONE);
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    message.setVisibility(View.VISIBLE);
                    message.setText("تعذر فتح الاختبار. تحقق من الاتصال بالإنترنت.");
                }
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        getWindow().getDecorView().setKeepScreenOn(true);
        web.loadUrl(URL);
        web.requestFocus();
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK && web != null && web.canGoBack()) {
            web.goBack();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            ((ViewGroup) web.getParent()).removeView(web);
            web.destroy();
            web = null;
        }
        super.onDestroy();
    }

    /** Fallback used by the settings screen when the device has no usable WebView. */
    public static void openInBrowser(android.content.Context c) {
        Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(URL));
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        c.startActivity(i);
    }
}
