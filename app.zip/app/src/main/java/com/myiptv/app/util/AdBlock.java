package com.myiptv.app.util;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Ad / popup blocking for the adult browser: host blocklist + url patterns + page-side script. */
public final class AdBlock {
    private AdBlock() {}

    /** Plain host list (ads and trackers only), refreshed weekly. */
    private static final String LIST_URL =
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext";

    private static final String[] BUILTIN = {
            "exoclick.com", "exosrv.com", "exdynsrv.com", "magsrv.com", "realsrv.com", "juicyads.com",
            "trafficjunky.net", "trafficjunky.com", "adsco.re", "popads.net", "popcash.net",
            "propellerads.com", "propeller-tracking.com", "onclkds.com", "clickadu.com", "hilltopads.net",
            "a-ads.com", "adsterra.com", "highperformanceformat.com", "profitablegatecpm.com",
            "effectivegatecpm.com", "trafficstars.com", "tsyndicate.com", "adtng.com", "adcash.com",
            "clksite.com", "adspyglass.com", "ero-advertising.com", "trackwilltrk.com", "voluumtrk.com",
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adnxs.com",
            "adsrvr.org", "taboola.com", "outbrain.com", "mgid.com", "revcontent.com",
            "google-analytics.com", "googletagmanager.com", "mc.yandex.ru", "counter.yadro.ru",
            "bngpt.com", "bngprm.com", "awempire.com", "stripchat.com", "adxpansion.com", "ad-maven.com",
            "admaven.com", "monetag.com", "richpush.co", "pushance.com", "tsyndicate.com", "ads.exosrv.com"
    };

    private static volatile Set<String> hosts;

    public static synchronized void init(Context c) {
        if (hosts != null) return;
        final Context app = c.getApplicationContext();
        Set<String> s = new HashSet<String>(Arrays.asList(BUILTIN));
        final File f = new File(app.getFilesDir(), "adhosts.txt");
        if (f.exists()) readInto(f, s);
        hosts = s;
        if (!f.exists() || System.currentTimeMillis() - f.lastModified() > 7L * 24 * 3600 * 1000) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    download(f);
                }
            }).start();
        }
    }

    private static void readInto(File f, Set<String> out) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) addLine(line, out);
        } catch (Throwable ignored) {
        }
    }

    private static void addLine(String line, Set<String> out) {
        String t = line.trim().toLowerCase(Locale.US);
        if (t.isEmpty() || t.startsWith("#") || t.indexOf(' ') >= 0 || t.indexOf('.') < 0) return;
        out.add(t);
    }

    private static void download(File f) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(LIST_URL).openConnection();
            con.setConnectTimeout(15000);
            con.setReadTimeout(20000);
            if (con.getResponseCode() != 200) return;
            Set<String> s = new HashSet<String>(Arrays.asList(BUILTIN));
            StringBuilder raw = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) {
                    addLine(line, s);
                    raw.append(line).append('\n');
                }
            }
            if (s.size() < 200) return;   // a broken answer: keep what we have
            try (FileOutputStream o = new FileOutputStream(f)) {
                o.write(raw.toString().getBytes("UTF-8"));
            }
            hosts = s;
        } catch (Throwable ignored) {
        } finally {
            if (con != null) con.disconnect();
        }
    }

    public static boolean isBlockedHost(String host) {
        Set<String> s = hosts;
        if (s == null || host == null) return false;
        String h = host.toLowerCase(Locale.US);
        while (h != null) {
            if (s.contains(h)) return true;
            int i = h.indexOf('.');
            if (i < 0) break;
            h = h.substring(i + 1);
        }
        return false;
    }

    public static boolean isAd(String url, String host) {
        if (isBlockedHost(host)) return true;
        String u = url.toLowerCase(Locale.US);
        return u.contains("/popunder") || u.contains("popunder.") || u.contains("/pagead/")
                || u.contains("/adserver") || u.contains("/pop.js");
    }

    private static final String CSS =
            "iframe[src*='exoclick'],iframe[src*='juicyads'],iframe[src*='trafficjunky'],"
                    + "iframe[src*='adsterra'],iframe[src*='magsrv'],ins.adsbygoogle,"
                    + "[id^='ad-'],[id^='ad_'],[class^='ad-'],[class*=' ad-'],[class*='advert'],"
                    + "[class*='banner-ad'],[id*='popunder'],.exo-native-widget,.exo_wrapper"
                    + "{display:none!important}";

    /** Runs inside every page: kills window.open popups, off-site _blank links, hides ad boxes. */
    public static String js() {
        return "(function(){if(window.__rb)return;window.__rb=1;"
                + "function reg(h){var p=h.split('.');return p.slice(-2).join('.');}"
                + "var me=reg(location.hostname);"
                + "window.open=function(u){try{var x=new URL(u,location.href);"
                + "if(reg(x.hostname)===me)location.href=x.href;}catch(e){}return null;};"
                + "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?"
                + "e.target.closest('a'):null;if(a&&a.target==='_blank'){try{var x=new URL(a.href,location.href);"
                + "if(reg(x.hostname)!==me){e.preventDefault();e.stopPropagation();}else{a.target='_self';}}"
                + "catch(_){}}},true);"
                + "var st=document.createElement('style');st.textContent=" + org.json.JSONObject.quote(CSS) + ";"
                + "(document.head||document.documentElement).appendChild(st);})();"
                + OVERLAY_JS;
    }

    /**
     * Second page script: removes ad layers that sit on top of the page or of the video (fixed /
     * absolute, high z-index, covering the screen or holding an off-site iframe / link). Real
     * players (anything holding a video or a player-like iframe) and fullscreen are never touched.
     */
    private static final String OVERLAY_JS =
            "(function(){if(window.__rbo)return;window.__rbo=1;"
                    + "function reg(h){var p=h.split('.');return p.slice(-2).join('.');}"
                    + "var me=reg(location.hostname);"
                    + "function ext(u){try{return reg(new URL(u,location.href).hostname)!==me;}catch(e){return false;}}"
                    + "function hasVideo(e){return e.tagName==='VIDEO'||!!(e.querySelector&&e.querySelector('video'));}"
                    + "function playerFrame(e){var l=e.tagName==='IFRAME'?[e]:(e.querySelectorAll?e.querySelectorAll('iframe'):[]);"
                    + "for(var i=0;i<l.length;i++){var s=l[i].src||'';if(!ext(s)||/player|embed|video|stream|cdn|vid/i.test(s))return true;}return false;}"
                    + "function extFrame(e){var l=e.tagName==='IFRAME'?[e]:(e.querySelectorAll?e.querySelectorAll('iframe'):[]);"
                    + "for(var i=0;i<l.length;i++){if(ext(l[i].src||''))return true;}return false;}"
                    + "function extLink(e){if(e.tagName==='A')return ext(e.href);var l=e.querySelectorAll?e.querySelectorAll('a[href]'):[];"
                    + "for(var i=0;i<l.length;i++){if(ext(l[i].href))return true;}return false;}"
                    + "function layer(e){var cs=getComputedStyle(e);if(cs.position!=='fixed'&&cs.position!=='absolute')return false;"
                    + "var z=parseInt(cs.zIndex,10);return !isNaN(z)&&z>=999;}"
                    + "function kill(e){try{e.remove();}catch(x){e.style.setProperty('display','none','important');}}"
                    + "function check(e){if(!e||e.nodeType!==1||document.fullscreenElement)return;"
                    + "var t=e.tagName;if(t==='BODY'||t==='HTML'||t==='SCRIPT'||t==='STYLE'||t==='VIDEO')return;"
                    + "if(!layer(e)||hasVideo(e)||playerFrame(e))return;"
                    + "var r=e.getBoundingClientRect();var big=r.width*r.height>=innerWidth*innerHeight*0.3;"
                    + "if(big||extFrame(e))kill(e);}"
                    + "function overVideo(){var v=document.getElementsByTagName('video');"
                    + "for(var i=0;i<v.length;i++){var r=v[i].getBoundingClientRect();if(r.width<50||r.height<50)continue;"
                    + "var pts=[[.5,.5],[.25,.25],[.75,.25],[.25,.75],[.75,.75]];"
                    + "for(var k=0;k<pts.length;k++){var l=document.elementsFromPoint(r.left+r.width*pts[k][0],r.top+r.height*pts[k][1]);"
                    + "for(var j=0;j<l.length;j++){var e=l[j];if(e===v[i]||e.contains(v[i]))break;"
                    + "if(v[i].contains(e))continue;if(extFrame(e)||extLink(e))kill(e);}}}}"
                    + "function scan(){try{var b=document.body;if(b){for(var i=0;i<b.children.length;i++)check(b.children[i]);}"
                    + "overVideo();}catch(e){}}"
                    + "var tm=0;function later(){if(tm)return;tm=setTimeout(function(){tm=0;scan();},250);}"
                    + "try{new MutationObserver(later).observe(document.documentElement,{childList:true,subtree:true});}catch(e){}"
                    + "setInterval(scan,1500);scan();})();";
}
