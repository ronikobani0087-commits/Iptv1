package com.myiptv.app.util;

import android.content.Context;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

/** Ad / popup blocking for the adult browser: host blocklist + url patterns + page-side script. */
public final class AdBlock {
    private AdBlock() {}

    /** Plain host list (ads and trackers only), refreshed weekly. */
    private static final String LIST_URL =
            "https://pgl.yoyo.org/adservers/serverlist.php?hostformat=nohtml&showintro=0&mimetype=plaintext";

    private static final String[] BUILTIN = {
            "exoclick.com", "exosrv.com", "exdynsrv.com", "magsrv.com", "realsrv.com", "juicyads.com",
            "trafficjunky.net", "trafficjunky.com", "adsco.re", "popads.net", "popcash.net",
            "propellerads.com", "propeller-tracking.com", "onclkds.com", "clickadu.com", "hilltopads.net",
            "a-ads.com", "adsterra.com", "highperformanceformat.com", "profitablegatecpm.com",
            "effectivegatecpm.com", "trafficstars.com", "tsyndicate.com", "adtng.com", "adcash.com",
            "clksite.com", "adspyglass.com", "ero-advertising.com", "trackwilltrk.com", "voluumtrk.com",
            "doubleclick.net", "googlesyndication.com", "googleadservices.com", "adnxs.com",
            "adsrvr.org", "taboola.com", "outbrain.com", "mgid.com", "revcontent.com",
            "google-analytics.com", "googletagmanager.com", "mc.yandex.ru", "counter.yadro.ru"
    };

    private static volatile Set<String> hosts;

    public static synchronized void init(Context c) {
        if (hosts != null) return;
        final Context app = c.getApplicationContext();
        Set<String> s = new HashSet<String>(Arrays.asList(BUILTIN));
        final File f = new File(app.getFilesDir(), "adhosts.txt");
        if (f.exists()) readInto(f, s);
        hosts = s;
        if (!f.exists() || System.currentTimeMillis() - f.lastModified() > 7L * 24 * 3600 * 1000) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    download(f);
                }
            }).start();
        }
    }

    private static void readInto(File f, Set<String> out) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(new FileInputStream(f), "UTF-8"))) {
            String line;
            while ((line = r.readLine()) != null) addLine(line, out);
        } catch (Throwable ignored) {
        }
    }

    private static void addLine(String line, Set<String> out) {
        String t = line.trim().toLowerCase(Locale.US);
        if (t.isEmpty() || t.startsWith("#") || t.indexOf(' ') >= 0 || t.indexOf('.') < 0) return;
        out.add(t);
    }

    private static void download(File f) {
        HttpURLConnection con = null;
        try {
            con = (HttpURLConnection) new URL(LIST_URL).openConnection();
            con.setConnectTimeout(15000);
            con.setReadTimeout(20000);
            if (con.getResponseCode() != 200) return;
            Set<String> s = new HashSet<String>(Arrays.asList(BUILTIN));
            StringBuilder raw = new StringBuilder();
            try (BufferedReader r = new BufferedReader(new InputStreamReader(con.getInputStream(), "UTF-8"))) {
                String line;
                while ((line = r.readLine()) != null) {
                    addLine(line, s);
                    raw.append(line).append('\n');
                }
            }
            if (s.size() < 200) return;   // a broken answer: keep what we have
            try (FileOutputStream o = new FileOutputStream(f)) {
                o.write(raw.toString().getBytes("UTF-8"));
            }
            hosts = s;
        } catch (Throwable ignored) {
        } finally {
            if (con != null) con.disconnect();
        }
    }

    public static boolean isBlockedHost(String host) {
        Set<String> s = hosts;
        if (s == null || host == null) return false;
        String h = host.toLowerCase(Locale.US);
        while (h != null) {
            if (s.contains(h)) return true;
            int i = h.indexOf('.');
            if (i < 0) break;
            h = h.substring(i + 1);
        }
        return false;
    }

    public static boolean isAd(String url, String host) {
        if (isBlockedHost(host)) return true;
        String u = url.toLowerCase(Locale.US);
        return u.contains("/popunder") || u.contains("popunder.") || u.contains("/pagead/")
                || u.contains("/adserver") || u.contains("/pop.js");
    }

    private static final String CSS =
            "iframe[src*='exoclick'],iframe[src*='juicyads'],iframe[src*='trafficjunky'],"
                    + "iframe[src*='adsterra'],iframe[src*='magsrv'],ins.adsbygoogle,"
                    + "[id^='ad-'],[id^='ad_'],[class^='ad-'],[class*=' ad-'],[class*='advert'],"
                    + "[class*='banner-ad'],[id*='popunder'],.exo-native-widget,.exo_wrapper"
                    + "{display:none!important}";

    /** Runs inside every page: kills window.open popups, off-site _blank links, hides ad boxes. */
    public static String js() {
        return "(function(){if(window.__rb)return;window.__rb=1;"
                + "function reg(h){var p=h.split('.');return p.slice(-2).join('.');}"
                + "var me=reg(location.hostname);"
                + "window.open=function(u){try{var x=new URL(u,location.href);"
                + "if(reg(x.hostname)===me)location.href=x.href;}catch(e){}return null;};"
                + "document.addEventListener('click',function(e){var a=e.target&&e.target.closest?"
                + "e.target.closest('a'):null;if(a&&a.target==='_blank'){try{var x=new URL(a.href,location.href);"
                + "if(reg(x.hostname)!==me){e.preventDefault();e.stopPropagation();}else{a.target='_self';}}"
                + "catch(_){}}},true);"
                + "var st=document.createElement('style');st.textContent=" + org.json.JSONObject.quote(CSS) + ";"
                + "(document.head||document.documentElement).appendChild(st);})();";
    }
}
