package com.myiptv.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface AppDao {
    @Insert
    long insertPlaylist(Playlist p);

    @Update
    void updatePlaylist(Playlist p);

    @Query("SELECT * FROM playlists ORDER BY id")
    List<Playlist> getPlaylists();

    @Query("SELECT * FROM playlists WHERE id = :id")
    Playlist getPlaylist(long id);

    @Query("DELETE FROM playlists WHERE id = :id")
    void deletePlaylist(long id);

    @Insert
    void insertCategories(List<Category> list);

    @Insert
    void insertItems(List<Item> list);

    @Query("DELETE FROM categories WHERE playlistId = :id")
    void deleteCategories(long id);

    @Query("DELETE FROM items WHERE playlistId = :id")
    void deleteItems(long id);

    @Query("SELECT COUNT(*) FROM items WHERE playlistId = :id AND type = :type")
    int countItems(long id, String type);

    @Query("SELECT * FROM categories WHERE playlistId = :id AND type = :type ORDER BY position")
    List<Category> getCategories(long id, String type);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND categoryRemoteId = :cat ORDER BY position LIMIT :limit OFFSET :offset")
    List<Item> getItems(long id, String type, String cat, int limit, int offset);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND categoryRemoteId = :cat ORDER BY position")
    List<Item> itemsInCategory(long id, String type, String cat);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type ORDER BY position LIMIT :limit")
    List<Item> itemsAll(long id, String type, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND name LIKE '%' || :q || '%' ORDER BY position LIMIT :limit")
    List<Item> searchItems(long id, String type, String q, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'series' AND added > 0 ORDER BY added DESC LIMIT :limit")
    List<Item> recentSeries(long id, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'series' AND categoryRemoteId IN (SELECT remoteId FROM categories WHERE playlistId = :id AND type = 'series' AND (name LIKE '%عرب%' OR name LIKE '%مصر%' OR name LIKE '%سوري%' OR name LIKE '%خليج%' OR name LIKE '%رمضان%' OR name LIKE '%برامج%' OR name LIKE '%برنامج%' OR name LIKE '%كويت%' OR name LIKE '%سعود%' OR name LIKE '%لبنان%' OR name LIKE '%عراق%' OR name LIKE '%اردن%' OR name LIKE '%أردن%' OR name LIKE '%مغرب%' OR name LIKE '%جزائر%' OR name LIKE '%تونس%' OR LOWER(name) LIKE '%arab%')) ORDER BY added DESC, position LIMIT :limit")
    List<Item> recentArabicSeries(long id, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'movie' AND categoryRemoteId IN (SELECT remoteId FROM categories WHERE playlistId = :id AND type = 'movie' AND (name LIKE '%عرب%' OR name LIKE '%مصر%' OR name LIKE '%سوري%' OR name LIKE '%خليج%' OR name LIKE '%كويت%' OR name LIKE '%سعود%' OR name LIKE '%لبنان%' OR name LIKE '%عراق%' OR name LIKE '%اردن%' OR name LIKE '%أردن%' OR name LIKE '%مغرب%' OR name LIKE '%جزائر%' OR name LIKE '%تونس%' OR LOWER(name) LIKE '%arab%')) ORDER BY added DESC, position LIMIT :limit")
    List<Item> recentArabicMovies(long id, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'series' AND categoryRemoteId IN (SELECT remoteId FROM categories WHERE playlistId = :id AND type = 'series' AND (name LIKE '%برامج%' OR name LIKE '%برنامج%')) ORDER BY added DESC, position LIMIT :limit")
    List<Item> recentPrograms(long id, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'live' AND (LOWER(name) LIKE '%bein%' OR name LIKE '%بي ان%' OR name LIKE '%بي إن%' OR name LIKE '%بين سبورت%') ORDER BY position LIMIT :limit")
    List<Item> beinChannels(long id, int limit);

    /** beIN and the other common sports channels (SSC, Alkass, Arryadia, ESPN, DAZN...), to look for a match in their guide. */
    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'live' AND (LOWER(name) LIKE '%bein%' OR LOWER(name) LIKE '%sport%' OR LOWER(name) LIKE '%ssc%' OR LOWER(name) LIKE '%espn%' OR LOWER(name) LIKE '%dazn%' OR LOWER(name) LIKE '%alkass%' OR LOWER(name) LIKE '%arryadia%' OR LOWER(name) LIKE '%thmanyah%' OR name LIKE '%بي ان%' OR name LIKE '%بي إن%' OR name LIKE '%بين سبورت%' OR name LIKE '%سبورت%' OR name LIKE '%رياض%' OR name LIKE '%الكاس%' OR name LIKE '%ثمانية%') ORDER BY position LIMIT :limit")
    List<Item> sportsChannels(long id, int limit);

    /** Every live channel that has a real logo (used to lend logos to channels without one). */
    @Query("SELECT name AS name, icon AS icon FROM items WHERE playlistId = :id AND type = 'live' AND icon LIKE 'http%' AND LOWER(icon) NOT LIKE '%nologo%' AND LOWER(icon) NOT LIKE '%no_logo%' ORDER BY position")
    List<NameLogo> logoNames(long id);

    /** A real logo (not a "no logo" picture) of any beIN Sports channel, to use for the ones without. */
    @Query("SELECT icon FROM items WHERE playlistId = :id AND type = 'live' AND icon LIKE 'http%' AND LOWER(icon) NOT LIKE '%nologo%' AND LOWER(icon) NOT LIKE '%no_logo%' AND (LOWER(name) LIKE '%bein%' OR name LIKE '%بي ان%' OR name LIKE '%بي إن%' OR name LIKE '%بين سبورت%') ORDER BY position LIMIT 1")
    String beinLogo(long id);

    /** A real logo of any MBC channel, to use for the ones without. */
    @Query("SELECT icon FROM items WHERE playlistId = :id AND type = 'live' AND icon LIKE 'http%' AND LOWER(icon) NOT LIKE '%nologo%' AND LOWER(icon) NOT LIKE '%no_logo%' AND (LOWER(name) LIKE '%mbc%' OR name LIKE '%ام بي سي%' OR name LIKE '%إم بي سي%' OR name LIKE '%أم بي سي%') ORDER BY position LIMIT 1")
    String mbcLogo(long id);

    /** Package (category) of a live channel, to borrow the package logo for favorites. */
    @Query("SELECT categoryRemoteId FROM items WHERE playlistId = :id AND type = 'live' AND remoteId = :rid LIMIT 1")
    String liveCategoryOf(long id, String rid);

    /** One logo per live package: the icon of its first channel that has one. */
    @Query("SELECT categoryRemoteId AS catId, icon AS icon FROM items WHERE id IN (SELECT MIN(id) FROM items WHERE playlistId = :id AND type = 'live' AND icon LIKE 'http%' AND LOWER(icon) NOT LIKE '%nologo%' AND LOWER(icon) NOT LIKE '%no_logo%' GROUP BY categoryRemoteId)")
    List<CatLogo> catLogos(long id);
}
