package com.myiptv.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface AppDao {
    @Insert
    long insertPlaylist(Playlist p);

    @Update
    void updatePlaylist(Playlist p);

    @Query("SELECT * FROM playlists ORDER BY id")
    List<Playlist> getPlaylists();

    @Query("SELECT * FROM playlists WHERE id = :id")
    Playlist getPlaylist(long id);

    @Query("DELETE FROM playlists WHERE id = :id")
    void deletePlaylist(long id);

    @Insert
    void insertCategories(List<Category> list);

    @Insert
    void insertItems(List<Item> list);

    @Query("DELETE FROM categories WHERE playlistId = :id")
    void deleteCategories(long id);

    @Query("DELETE FROM items WHERE playlistId = :id")
    void deleteItems(long id);

    @Query("SELECT COUNT(*) FROM items WHERE playlistId = :id AND type = :type")
    int countItems(long id, String type);

    @Query("SELECT * FROM categories WHERE playlistId = :id AND type = :type ORDER BY position")
    List<Category> getCategories(long id, String type);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND categoryRemoteId = :cat ORDER BY position LIMIT :limit OFFSET :offset")
    List<Item> getItems(long id, String type, String cat, int limit, int offset);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND categoryRemoteId = :cat ORDER BY position")
    List<Item> itemsInCategory(long id, String type, String cat);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type ORDER BY position LIMIT :limit")
    List<Item> itemsAll(long id, String type, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND name LIKE '%' || :q || '%' ORDER BY position LIMIT :limit")
    List<Item> searchItems(long id, String type, String q, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'series' AND added > 0 ORDER BY added DESC LIMIT :limit")
    List<Item> recentSeries(long id, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'series' AND categoryRemoteId IN (SELECT remoteId FROM categories WHERE playlistId = :id AND type = 'series' AND (name LIKE '%عرب%' OR name LIKE '%مصر%' OR name LIKE '%سوري%' OR name LIKE '%خليج%' OR name LIKE '%رمضان%' OR name LIKE '%برامج%' OR name LIKE '%برنامج%' OR name LIKE '%كويت%' OR name LIKE '%سعود%' OR name LIKE '%لبنان%' OR name LIKE '%عراق%' OR name LIKE '%اردن%' OR name LIKE '%أردن%' OR name LIKE '%مغرب%' OR name LIKE '%جزائر%' OR name LIKE '%تونس%' OR LOWER(name) LIKE '%arab%')) ORDER BY added DESC, position LIMIT :limit")
    List<Item> recentArabicSeries(long id, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'live' AND (LOWER(name) LIKE '%bein%' OR name LIKE '%بي ان%' OR name LIKE '%بي إن%' OR name LIKE '%بين سبورت%') ORDER BY position LIMIT :limit")
    List<Item> beinChannels(long id, int limit);

    /** One logo per live package: the icon of its first channel that has one. */
    @Query("SELECT categoryRemoteId AS catId, icon AS icon FROM items WHERE id IN (SELECT MIN(id) FROM items WHERE playlistId = :id AND type = 'live' AND icon LIKE 'http%' GROUP BY categoryRemoteId)")
    List<CatLogo> catLogos(long id);
}
