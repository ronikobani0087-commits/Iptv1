package com.myiptv.app.data;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import java.util.List;

@Dao
public interface AppDao {
    @Insert
    long insertPlaylist(Playlist p);

    @Update
    void updatePlaylist(Playlist p);

    @Query("SELECT * FROM playlists ORDER BY id")
    List<Playlist> getPlaylists();

    @Query("SELECT * FROM playlists WHERE id = :id")
    Playlist getPlaylist(long id);

    @Query("DELETE FROM playlists WHERE id = :id")
    void deletePlaylist(long id);

    @Insert
    void insertCategories(List<Category> list);

    @Insert
    void insertItems(List<Item> list);

    @Query("DELETE FROM categories WHERE playlistId = :id")
    void deleteCategories(long id);

    @Query("DELETE FROM items WHERE playlistId = :id")
    void deleteItems(long id);

    @Query("SELECT COUNT(*) FROM items WHERE playlistId = :id AND type = :type")
    int countItems(long id, String type);

    @Query("SELECT * FROM categories WHERE playlistId = :id AND type = :type ORDER BY position")
    List<Category> getCategories(long id, String type);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND categoryRemoteId = :cat ORDER BY position LIMIT :limit OFFSET :offset")
    List<Item> getItems(long id, String type, String cat, int limit, int offset);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type AND categoryRemoteId = :cat ORDER BY position")
    List<Item> itemsInCategory(long id, String type, String cat);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = :type ORDER BY position LIMIT :limit")
    List<Item> itemsAll(long id, String type, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'series' AND added > 0 ORDER BY added DESC LIMIT :limit")
    List<Item> recentSeries(long id, int limit);

    @Query("SELECT * FROM items WHERE playlistId = :id AND type = 'live' AND (LOWER(name) LIKE '%bein%' OR name LIKE '%بي ان%' OR name LIKE '%بي إن%' OR name LIKE '%بين سبورت%') ORDER BY position LIMIT :limit")
    List<Item> beinChannels(long id, int limit);
}
