package com.myiptv.app.ui;

import android.annotation.SuppressLint;
import android.app.UiModeManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.net.Uri;
import android.os.Bundle;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.HttpAuthHandler;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.webkit.ProxyConfig;
import androidx.webkit.ProxyController;
import androidx.webkit.WebViewFeature;

import com.myiptv.app.util.AdBlock;
import com.myiptv.app.util.CloudflareProxy;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.io.ByteArrayInputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Opens a site inside the app: ad / popup blocking, optional Cloudflare DNS tunnel for the
 * whole browser, remote-control cursor on TV, fullscreen video.
 */
public class AdultBrowserActivity extends AppCompatActivity {

    private static final String X_URL = "url";
    private static final String X_ALLOW = "allow";
    private static final String DESKTOP_UA = "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    public static void start(Context c, String url, String extraAllowedCsv) {
        Intent i = new Intent(c, AdultBrowserActivity.class);
        i.putExtra(X_URL, url);
        i.putExtra(X_ALLOW, extraAllowedCsv == null ? "" : extraAllowedCsv);
        c.startActivity(i);
    }

    private WebView web;
    private FrameLayout root;
    private CursorView cursor;
    private ProgressBar bar;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private boolean cursorMode;
    private boolean proxyApplied;
    private int authTries;
    private long lastToast;
    private final List<String> allowed = new ArrayList<String>();

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(Ui.scaled(base));
    }

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        AdBlock.init(this);
        final String url = getIntent().getStringExtra(X_URL);
        if (url == null || Uri.parse(url).getHost() == null) {
            finish();
            return;
        }
        allowed.add(reg(Uri.parse(url).getHost()));
        String extra = getIntent().getStringExtra(X_ALLOW);
        if (extra != null) {
            for (String s : extra.split(",")) {
                if (!s.trim().isEmpty()) allowed.add(reg(s.trim()));
            }
        }

        boolean tv = (getResources().getConfiguration().uiMode & Configuration.UI_MODE_TYPE_MASK)
                == Configuration.UI_MODE_TYPE_TELEVISION;
        boolean touch = getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
        cursorMode = tv || !touch;

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        web = new WebView(this);
        root.addView(web, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        bar.setMax(100);
        root.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 3), Gravity.TOP));
        cursor = new CursorView(this);
        cursor.setVisibility(cursorMode ? View.VISIBLE : View.GONE);
        root.addView(cursor, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        setContentView(root);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setUserAgentString(cursorMode ? DESKTOP_UA : s.getUserAgentString().replace("; wv", ""));
        CookieManager cm = CookieManager.getInstance();
        cm.setAcceptCookie(true);
        cm.setAcceptThirdPartyCookies(web, false);
        web.setBackgroundColor(Color.BLACK);
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (customView != null) hideCustom();
                else if (web.canGoBack()) web.goBack();
                else finish();
            }
        });

        if (cursorMode) {
            Toast.makeText(this, "زر القائمة (Menu) يبدّل بين المؤشر والتنقل العادي", Toast.LENGTH_LONG).show();
        }
        applyProxy(new Runnable() {
            @Override
            public void run() {
                web.loadUrl(url);
            }
        });
    }

    // ---------------------------------------------------------------- proxy

    /** Cloudflare switch on: all browser traffic goes through the local DNS-over-HTTPS proxy, never direct. */
    private void applyProxy(final Runnable then) {
        if (!Prefs.getBool(this, "adult_cf", false)) {
            then.run();
            return;
        }
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
            showMessage("إصدار WebView في الجهاز لا يدعم Cloudflare.\nحدّث Android System WebView من المتجر.\n"
                    + "لم يتم الاتصال حفاظاً على حمايتك.");
            return;
        }
        try {
            int port = CloudflareProxy.start();
            ProxyConfig cfg = new ProxyConfig.Builder().addProxyRule("127.0.0.1:" + port).build();
            proxyApplied = true;
            ProxyController.getInstance().setProxyOverride(cfg, ContextCompat.getMainExecutor(this), then);
        } catch (Throwable t) {
            showMessage("تعذر تشغيل Cloudflare.\nأوقفه من زر Cloudflare VPN ثم أعد المحاولة.");
        }
    }

    private void clearProxy() {
        if (!proxyApplied) return;
        try {
            if (WebViewFeature.isFeatureSupported(WebViewFeature.PROXY_OVERRIDE)) {
                ProxyController.getInstance().clearProxyOverride(
                        ContextCompat.getMainExecutor(this), new Runnable() {
                            @Override
                            public void run() {
                            }
                        });
            }
        } catch (Throwable ignored) {
        }
        proxyApplied = false;
        CloudflareProxy.stop();
    }

    // ---------------------------------------------------------------- navigation rules

    private static String reg(String host) {
        String h = host.toLowerCase(Locale.US);
        String[] p = h.split("\\.");
        if (p.length <= 2) return h;
        return p[p.length - 2] + "." + p[p.length - 1];
    }

    private boolean allowNav(Uri u) {
        String sc = u.getScheme();
        String host = u.getHost();
        if (host == null || sc == null) return false;
        if (!sc.equals("http") && !sc.equals("https")) return false;
        if (AdBlock.isBlockedHost(host)) return false;
        return allowed.contains(reg(host));
    }

    private void blockedToast() {
        long n = SystemClock.uptimeMillis();
        if (n - lastToast > 3000) {
            lastToast = n;
            Toast.makeText(this, "تم حظر إعلان / تحويل خارجي", Toast.LENGTH_SHORT).show();
        }
    }

    private void showMessage(String msg) {
        String html = "<html><body style='background:#0B4A5A;color:#D7E6EA;font-family:sans-serif;"
                + "text-align:center;padding-top:20vh;font-size:20px' dir='rtl'>"
                + msg.replace("\n", "<br>") + "</body></html>";
        web.loadDataWithBaseURL(null, html, "text/html", "utf-8", null);
    }

    private final class Client extends WebViewClient {
        @Override
        public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
            boolean ok = allowNav(r.getUrl());
            if (!ok) blockedToast();
            return !ok;
        }

        @Override
        public boolean shouldOverrideUrlLoading(WebView v, String url) {
            boolean ok = allowNav(Uri.parse(url));
            if (!ok) blockedToast();
            return !ok;
        }

        @Override
        public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
            Uri u = r.getUrl();
            String host = u.getHost();
            if (host != null && AdBlock.isAd(u.toString(), host)) {
                return new WebResourceResponse("text/plain", "UTF-8", new ByteArrayInputStream(new byte[0]));
            }
            return null;
        }

        @Override
        public void onPageStarted(WebView v, String url, Bitmap icon) {
            bar.setVisibility(View.VISIBLE);
            v.evaluateJavascript(AdBlock.js(), null);
        }

        @Override
        public void onPageFinished(WebView v, String url) {
            bar.setVisibility(View.GONE);
            v.evaluateJavascript(AdBlock.js(), null);
        }

        @Override
        public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
            if (r.isForMainFrame()) {
                showMessage("تعذر تحميل الصفحة.\nتحقق من الإنترنت أو جرّب زر Cloudflare VPN.");
            }
        }

        @Override
        public void onReceivedHttpAuthRequest(WebView v, HttpAuthHandler h, String host, String realm) {
            h.cancel();
        }
    }

    private final class Chrome extends WebChromeClient {
        private boolean injected;

        @Override
        public void onProgressChanged(WebView v, int p) {
            bar.setProgress(p);
            if (p < 15) injected = false;
            if (p >= 25 && !injected) {
                injected = true;
                v.evaluateJavascript(AdBlock.js(), null);
            }
        }

        @Override
        public boolean onCreateWindow(WebView v, boolean dialog, boolean gesture, android.os.Message m) {
            return false;
        }

        @Override
        public boolean onJsAlert(WebView v, String url, String msg, JsResult r) {
            r.cancel();
            return true;
        }

        @Override
        public boolean onJsConfirm(WebView v, String url, String msg, JsResult r) {
            r.cancel();
            return true;
        }

        @Override
        public void onPermissionRequest(PermissionRequest r) {
            r.deny();
        }

        @Override
        public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
            cb.invoke(origin, false, false);
        }

        @Override
        public Bitmap getDefaultVideoPoster() {
            return Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) {
                cb.onCustomViewHidden();
                return;
            }
            customView = view;
            customCb = cb;
            root.addView(view, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            web.setVisibility(View.INVISIBLE);
            cursor.setVisibility(View.GONE);
            bar.setVisibility(View.GONE);
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        if (customCb != null) customCb.onCustomViewHidden();
        customCb = null;
        web.setVisibility(View.VISIBLE);
        cursor.setVisibility(cursorMode ? View.VISIBLE : View.GONE);
        web.requestFocus();
    }

    // ---------------------------------------------------------------- remote control

    private static final String JS_TOGGLE =
            "var v=document.querySelector('video');if(v){if(v.paused){v.play();}else{v.pause();}}";

    private void seek(int sec) {
        web.evaluateJavascript("var v=document.querySelector('video');if(v){v.currentTime+=(" + sec + ");}", null);
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int k = e.getKeyCode();
        boolean down = e.getAction() == KeyEvent.ACTION_DOWN;

        if (k == KeyEvent.KEYCODE_MENU) {
            if (!down && customView == null) {
                cursorMode = !cursorMode;
                cursor.setVisibility(cursorMode ? View.VISIBLE : View.GONE);
                Toast.makeText(this, cursorMode ? "وضع المؤشر" : "وضع التنقل العادي", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        // fullscreen video: OK = play / pause, left / right = seek 10 s
        if (customView != null) {
            switch (k) {
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                    if (down && e.getRepeatCount() == 0) web.evaluateJavascript(JS_TOGGLE, null);
                    return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                case KeyEvent.KEYCODE_MEDIA_REWIND:
                    if (down) seek(-10);
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                    if (down) seek(10);
                    return true;
                default:
                    return super.dispatchKeyEvent(e);
            }
        }

        if (cursorMode) {
            switch (k) {
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    if (down) cursor.move(-1, 0, e.getRepeatCount());
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    if (down) cursor.move(1, 0, e.getRepeatCount());
                    return true;
                case KeyEvent.KEYCODE_DPAD_UP:
                    if (down) cursor.move(0, -1, e.getRepeatCount());
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                    if (down) cursor.move(0, 1, e.getRepeatCount());
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                    if (down && e.getRepeatCount() == 0) cursor.click();
                    return true;
                default:
                    break;
            }
        }
        return super.dispatchKeyEvent(e);
    }

    /** A round pointer drawn over the page; it moves with the arrows and taps with OK. */
    private final class CursorView extends View {
        private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
        private float cx = -1, cy = -1;
        private final float r;

        CursorView(Context c) {
            super(c);
            r = Ui.dp(c, 9);
            fill.setColor(0xCCFFFFFF);
            line.setColor(0xFF000000);
            line.setStyle(Paint.Style.STROKE);
            line.setStrokeWidth(Ui.dp(c, 2));
            setFocusable(false);
            setClickable(false);
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            if (cx < 0) {
                cx = w / 2f;
                cy = h / 2f;
            }
            cx = Math.min(cx, w);
            cy = Math.min(cy, h);
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            return false;   // never steals touches from the page
        }

        @Override
        protected void onDraw(Canvas c) {
            if (cx < 0) return;
            c.drawCircle(cx, cy, r, fill);
            c.drawCircle(cx, cy, r, line);
        }

        void move(int dx, int dy, int repeat) {
            float step = Ui.dp(getContext(), 10) * (1f + Math.min(repeat, 12) / 3f);
            float edge = Ui.dp(getContext(), 40);
            float nx = Math.max(0, Math.min(getWidth(), cx + dx * step));
            float ny = Math.max(0, Math.min(getHeight(), cy + dy * step));
            // pushing against the top / bottom edge scrolls the page
            if (dy != 0 && ((dy < 0 && cy <= edge) || (dy > 0 && cy >= getHeight() - edge))) {
                web.scrollBy(0, Math.round(dy * step * 2.2f));
            }
            cx = nx;
            cy = ny;
            invalidate();
        }

        void click() {
            final float x = cx, y = cy;
            long t = SystemClock.uptimeMillis();
            MotionEvent d = MotionEvent.obtain(t, t, MotionEvent.ACTION_DOWN, x, y, 0);
            d.setSource(InputDevice.SOURCE_TOUCHSCREEN);
            web.dispatchTouchEvent(d);
            d.recycle();
            web.postDelayed(new Runnable() {
                @Override
                public void run() {
                    long n = SystemClock.uptimeMillis();
                    MotionEvent u = MotionEvent.obtain(n, n, MotionEvent.ACTION_UP, x, y, 0);
                    u.setSource(InputDevice.SOURCE_TOUCHSCREEN);
                    web.dispatchTouchEvent(u);
                    u.recycle();
                }
            }, 60);
        }
    }

    // ---------------------------------------------------------------- lifecycle

    private void hideBars() {
        WindowInsetsControllerCompat c = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        c.hide(WindowInsetsCompat.Type.systemBars());
        c.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
        hideBars();
    }

    @Override
    protected void onPause() {
        if (web != null) web.onPause();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            root.removeAllViews();
            web.stopLoading();
            web.clearHistory();
            web.clearCache(true);
            web.destroy();
            web = null;
        }
        clearProxy();
        super.onDestroy();
    }
}
