package com.myiptv.app.ui;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDao;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;

import java.net.URI;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class PlaylistsFragment extends Fragment {
    private final Adapter adapter = new Adapter();
    private TextView status, empty;
    private long activeId = -1;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate(R.layout.fragment_playlists, container, false);
        status = v.findViewById(R.id.status);
        empty = v.findViewById(R.id.empty);
        RecyclerView list = v.findViewById(R.id.list);
        list.setLayoutManager(new LinearLayoutManager(requireContext()));
        list.setAdapter(adapter);
        v.findViewById(R.id.btn_speed).setOnClickListener(x -> {
            try {
                startActivity(new android.content.Intent(requireContext(), SpeedTestActivity.class));
            } catch (Exception e) {
                SpeedTestActivity.openInBrowser(requireContext());
            }
        });
        v.findViewById(R.id.btn_add).setOnClickListener(
                x -> ((MainActivity) requireActivity()).openAddPlaylist());
        return v;
    }

    @Override
    public void onResume() {
        super.onResume();
        reload();
    }

    private void reload() {
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            List<Playlist> l = AppDatabase.get(app).dao().getPlaylists();
            long a = Prefs.getActive(app);
            Async.main(() -> {
                if (!isAdded()) return;
                activeId = a;
                adapter.set(l);
                empty.setVisibility(l.isEmpty() ? View.VISIBLE : View.GONE);
            });
        });
    }

    private void refreshPlaylist(Playlist p) {
        final Context app = requireContext().getApplicationContext();
        status.setText("جارٍ التحديث…");
        SyncRepository.sync(app, p.id, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
                if (isAdded()) status.setText(message);
            }

            @Override
            public void onDone() {
                if (!isAdded()) return;
                status.setText("تم تحديث القائمة");
                reload();
            }

            @Override
            public void onError(String message) {
                if (isAdded()) status.setText("تعذر التحديث: " + message);
            }
        });
    }

    private void confirmDelete(Playlist p) {
        new AlertDialog.Builder(requireContext())
                .setMessage("حذف القائمة \"" + p.name + "\" وكل بياناتها؟")
                .setPositiveButton("حذف", (d, w) -> {
                    final Context app = requireContext().getApplicationContext();
                    Async.io(() -> {
                        AppDao dao = AppDatabase.get(app).dao();
                        dao.deleteItems(p.id);
                        dao.deleteCategories(p.id);
                        dao.deletePlaylist(p.id);
                        if (Prefs.getActive(app) == p.id) {
                            List<Playlist> rest = dao.getPlaylists();
                            Prefs.setActive(app, rest.isEmpty() ? -1 : rest.get(0).id);
                        }
                        Async.main(() -> {
                            if (isAdded()) reload();
                        });
                    });
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private static String hostOf(String url) {
        try {
            String h = new URI(url).getHost();
            return h == null ? url : h;
        } catch (Exception e) {
            return url;
        }
    }

    private class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        private List<Playlist> data = new ArrayList<>();

        void set(List<Playlist> l) {
            data = l;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return new VH(LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_playlist, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Playlist p = data.get(position);
            h.name.setText((p.id == activeId ? "✓ " : "") + p.name);
            String kind = "xtream".equals(p.type) ? "Xtream" : "M3U";
            String when = p.updatedAt > 0
                    ? " · " + DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
                    .format(new Date(p.updatedAt)) : "";
            h.detail.setText(kind + " · " + hostOf(p.url) + when);
            h.itemView.setOnClickListener(v -> {
                Prefs.setActive(v.getContext(), p.id);
                activeId = p.id;
                notifyDataSetChanged();
            });
            h.refresh.setOnClickListener(v -> refreshPlaylist(p));
            h.delete.setOnClickListener(v -> confirmDelete(p));
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        class VH extends RecyclerView.ViewHolder {
            final TextView name, detail, refresh, delete;

            VH(@NonNull View v) {
                super(v);
                name = v.findViewById(R.id.name);
                detail = v.findViewById(R.id.detail);
                refresh = v.findViewById(R.id.refresh);
                delete = v.findViewById(R.id.delete);
            }
        }
    }
}
