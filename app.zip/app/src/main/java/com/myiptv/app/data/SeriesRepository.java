package com.myiptv.app.data;

import com.myiptv.app.util.Http;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

/** Loads the details and the episodes of an Xtream series. */
public final class SeriesRepository {
    private SeriesRepository() {}

    public static final class Episode {
        public int season;
        public int number;
        public String id = "";
        public String title = "";
        public String ext = "mp4";
        public String url = "";
        public String image = "";

        /** Compact label, e.g. "م1 ح12". */
        public String shortLabel() {
            return "م" + season + " ح" + number;
        }

        /** Label kept in the watch history, e.g. "الموسم 1 · الحلقة 12". */
        public String longLabel() {
            return "الموسم " + season + " · الحلقة " + number;
        }
    }

    public static final class Info {
        public String name = "";
        public String cover = "";
        public String backdrop = "";
        public String plot = "";
        public String cast = "";
        public String genre = "";
        public String director = "";
        public String year = "";
        public String rating = "";
        public final List<Episode> episodes = new ArrayList<Episode>();

        public List<Integer> seasons() {
            TreeSet<Integer> set = new TreeSet<Integer>();
            for (Episode e : episodes) set.add(e.season);
            return new ArrayList<Integer>(set);
        }
    }

    // ---- cache: series details are read from the server once, then reused (series page, player,
    // home rows) for a few minutes, so opening a series is instant the second time
    private static final long CACHE_MS = 15L * 60L * 1000L;
    private static final java.util.HashMap<String, Object[]> CACHE = new java.util.HashMap<>();
    private static final java.util.HashSet<String> LOADING = new java.util.HashSet<>();

    private static String cacheKey(Playlist p, String seriesId) {
        return p.id + "|" + seriesId;
    }

    public static synchronized Info cached(Playlist p, String seriesId) {
        if (p == null) return null;
        Object[] e = CACHE.get(cacheKey(p, seriesId));
        if (e == null || System.currentTimeMillis() - (Long) e[0] > CACHE_MS) return null;
        return (Info) e[1];
    }

    public static synchronized void clearCache() {
        CACHE.clear();
    }

    /** Warms the cache in the background (called when a series card rests under the remote's focus). */
    public static void prefetch(final android.content.Context context, final long playlistId,
                                final String seriesId) {
        final android.content.Context app = context.getApplicationContext();
        final String k = playlistId + "|" + seriesId;
        synchronized (SeriesRepository.class) {
            if (LOADING.contains(k)) return;
            Object[] e = CACHE.get(k);
            if (e != null && System.currentTimeMillis() - (Long) e[0] <= CACHE_MS) return;
            LOADING.add(k);
        }
        com.myiptv.app.util.Async.net(() -> {
            try {
                Playlist p = AppDatabase.get(app).dao().getPlaylist(playlistId);
                if (p != null) load(p, seriesId);
            } catch (Throwable ignored) {
                // the page will simply load normally
            } finally {
                synchronized (SeriesRepository.class) {
                    LOADING.remove(k);
                }
            }
        });
    }

    public static Info load(Playlist p, String seriesId) throws Exception {
        if (p == null || !"xtream".equals(p.type)) {
            throw new Exception("الحلقات غير متاحة لهذه القائمة");
        }
        Info hit = cached(p, seriesId);
        if (hit != null) return hit;
        Info fresh = loadFromServer(p, seriesId);
        synchronized (SeriesRepository.class) {
            CACHE.put(cacheKey(p, seriesId), new Object[]{System.currentTimeMillis(), fresh});
        }
        return fresh;
    }

    private static Info loadFromServer(Playlist p, String seriesId) throws Exception {
        String uenc = URLEncoder.encode(p.username, "UTF-8");
        String penc = URLEncoder.encode(p.password, "UTF-8");
        String api = p.url + "/player_api.php?username=" + uenc + "&password=" + penc
                + "&action=get_series_info&series_id=" + URLEncoder.encode(seriesId, "UTF-8");
        JSONObject o = new JSONObject(Http.readString(api));

        Info info = new Info();
        JSONObject inf = o.optJSONObject("info");
        if (inf != null) {
            info.name = inf.optString("name", "");
            info.cover = inf.optString("cover", "");
            info.plot = inf.optString("plot", "");
            info.cast = inf.optString("cast", "");
            info.genre = inf.optString("genre", "");
            info.director = inf.optString("director", "");
            info.rating = inf.optString("rating", "");
            String date = inf.optString("releaseDate", "");
            if (date.isEmpty()) date = inf.optString("release_date", "");
            info.year = date.length() >= 4 ? date.substring(0, 4) : date;
            JSONArray back = inf.optJSONArray("backdrop_path");
            if (back != null && back.length() > 0) info.backdrop = back.optString(0, "");
        }

        Object epsObj = o.opt("episodes");
        if (epsObj instanceof JSONObject) {
            JSONObject eps = (JSONObject) epsObj;
            Iterator<String> keys = eps.keys();
            while (keys.hasNext()) {
                String key = keys.next();
                addSeason(info, p, uenc, penc, toInt(key), eps.optJSONArray(key));
            }
        } else if (epsObj instanceof JSONArray) {
            JSONArray all = (JSONArray) epsObj;
            for (int i = 0; i < all.length(); i++) {
                Object el = all.opt(i);
                if (el instanceof JSONArray) addSeason(info, p, uenc, penc, i + 1, (JSONArray) el);
            }
        }

        Collections.sort(info.episodes, new Comparator<Episode>() {
            @Override
            public int compare(Episode a, Episode b) {
                if (a.season != b.season) return Integer.compare(a.season, b.season);
                return Integer.compare(a.number, b.number);
            }
        });
        return info;
    }

    private static void addSeason(Info info, Playlist p, String uenc, String penc,
                                  int seasonNumber, JSONArray arr) {
        if (arr == null) return;
        for (int i = 0; i < arr.length(); i++) {
            JSONObject ep = arr.optJSONObject(i);
            if (ep == null) continue;
            String id = ep.optString("id", "");
            if (id.isEmpty()) continue;
            Episode e = new Episode();
            e.id = id;
            e.season = ep.optInt("season", seasonNumber);
            e.number = ep.optInt("episode_num", i + 1);
            e.title = ep.optString("title", "");
            String ext = ep.optString("container_extension", "mp4");
            e.ext = ext.isEmpty() ? "mp4" : ext;
            e.url = p.url + "/series/" + uenc + "/" + penc + "/" + id + "." + e.ext;
            JSONObject einfo = ep.optJSONObject("info");
            if (einfo != null) e.image = einfo.optString("movie_image", "");
            info.episodes.add(e);
        }
    }

    private static int toInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }
}
