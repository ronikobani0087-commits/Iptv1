package com.myiptv.app.data;

import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.annotation.NonNull;
import androidx.room.RoomDatabase;
import androidx.room.migration.Migration;
import androidx.sqlite.db.SupportSQLiteDatabase;

/** Separate database for things the user creates (favorites, history, custom order). */
@Database(entities = {Favorite.class, History.class, OrderPref.class}, version = 2, exportSchema = false)
public abstract class UserDatabase extends RoomDatabase {
    public abstract UserDao dao();

    private static volatile UserDatabase instance;

    private static final Migration MIGRATION_1_2 = new Migration(1, 2) {
        @Override
        public void migrate(@NonNull SupportSQLiteDatabase db) {
            db.execSQL("ALTER TABLE history ADD COLUMN durationMs INTEGER NOT NULL DEFAULT 0");
        }
    };

    public static UserDatabase get(Context context) {
        if (instance == null) {
            synchronized (UserDatabase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context.getApplicationContext(),
                            UserDatabase.class, "user.db")
                            .addMigrations(MIGRATION_1_2).build();
                }
            }
        }
        return instance;
    }
}
