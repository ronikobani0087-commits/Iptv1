package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.View;

import com.myiptv.app.util.Ui;

/**
 * Pill shaped on / off switch: green when on, transparent with a glowing outline when off.
 * It only draws the state; the row that contains it handles clicks and focus.
 */
public final class PillToggle extends View {
    private static final int GREEN_FILL = 0x802ECC71;   // translucent green
    private static final int GREEN_EDGE = 0xFF2ECC71;
    private static final int WHITE = 0xFFFFFFFF;

    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint edge = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint knob = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF rect = new RectF();
    private boolean checked;

    public PillToggle(Context c) {
        super(c);
        fill.setStyle(Paint.Style.FILL);
        edge.setStyle(Paint.Style.STROKE);
        edge.setStrokeWidth(Ui.dp(c, 2));
        knob.setStyle(Paint.Style.FILL);
        setFocusable(false);
        setClickable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    public boolean isChecked() {
        return checked;
    }

    public void setChecked(boolean on) {
        if (checked == on) return;
        checked = on;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float inset = Ui.dp(getContext(), 3);
        rect.set(inset, inset, w - inset, h - inset);
        float r = rect.height() / 2f;

        if (checked) {
            // on: translucent green
            fill.setColor(GREEN_FILL);
            canvas.drawRoundRect(rect, r, r, fill);
            edge.setColor(GREEN_EDGE);
            canvas.drawRoundRect(rect, r, r, edge);
            knob.setColor(WHITE);
        } else {
            // off: transparent inside, everything else white
            edge.setColor(WHITE);
            canvas.drawRoundRect(rect, r, r, edge);
            knob.setColor(WHITE);
        }

        float kr = r - Ui.dp(getContext(), 4);
        if (kr < 2) kr = 2;
        // RTL aware: "on" is on the side the text starts from
        boolean rtl = getLayoutDirection() == LAYOUT_DIRECTION_RTL;
        boolean right = checked != rtl;
        float cx = right ? rect.right - r : rect.left + r;
        canvas.drawCircle(cx, rect.centerY(), kr, knob);
    }
}
