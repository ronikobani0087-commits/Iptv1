package com.myiptv.app.ui;

import android.content.Context;
import android.content.res.Configuration;

import androidx.appcompat.app.AppCompatActivity;

import com.myiptv.app.util.Ui;

/**
 * Base of every screen: on phones all sizes (cards, lists, text, buttons) are scaled down
 * together so the same TV layout fits the small screen. TVs and tablets are left untouched.
 */
public abstract class BaseActivity extends AppCompatActivity {
    private float phoneScale = 1f;
    private int realDensityDpi;
    private int realWidthDp;
    private int realHeightDp;
    private int realSmallestDp;

    @Override
    protected void attachBaseContext(Context base) {
        Configuration c = base.getResources().getConfiguration();
        phoneScale = Ui.phoneScale(base);
        realDensityDpi = c.densityDpi;
        realWidthDp = c.screenWidthDp;
        realHeightDp = c.screenHeightDp;
        realSmallestDp = c.smallestScreenWidthDp;
        super.attachBaseContext(phoneScale < 0.999f ? Ui.scaledContext(base) : base);
    }

    @Override
    public void applyOverrideConfiguration(Configuration override) {
        // AppCompat re-applies its own override configuration; keep the phone scale in it
        if (override != null && phoneScale < 0.999f && realDensityDpi > 0) {
            Configuration real = new Configuration();
            real.densityDpi = realDensityDpi;
            real.screenWidthDp = realWidthDp;
            real.screenHeightDp = realHeightDp;
            real.smallestScreenWidthDp = realSmallestDp;
            Configuration s = Ui.scaledConfig(real, phoneScale);
            override.densityDpi = s.densityDpi;
            override.screenWidthDp = s.screenWidthDp;
            override.screenHeightDp = s.screenHeightDp;
            override.smallestScreenWidthDp = s.smallestScreenWidthDp;
        }
        super.applyOverrideConfiguration(override);
    }
}
