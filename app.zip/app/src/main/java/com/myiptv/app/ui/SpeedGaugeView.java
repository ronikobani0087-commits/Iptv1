package com.myiptv.app.ui;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.DecelerateInterpolator;

import java.util.Locale;

/** Half-circle speedometer: animated arc + glowing tip, big number and unit in the middle. */
public class SpeedGaugeView extends View {
    private static final float START = 180f;   // left end of the half circle
    private static final float SWEEP = 180f;
    private static final double[] SCALES = {50, 100, 250, 500, 1000};

    private final Paint track = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arc = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tick = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tip = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint number = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint unit = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint label = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF box = new RectF();

    private double scale = SCALES[0];
    private float shown;          // animated 0..1 fraction
    private double value;         // last real value
    private String placeholder = "—";
    private boolean hasValue;
    private ValueAnimator anim;

    public SpeedGaugeView(Context c) {
        super(c);
        setLayoutDirection(LAYOUT_DIRECTION_LTR);
        track.setStyle(Paint.Style.STROKE);
        track.setStrokeCap(Paint.Cap.ROUND);
        track.setColor(0x26FFFFFF);
        arc.setStyle(Paint.Style.STROKE);
        arc.setStrokeCap(Paint.Cap.ROUND);
        tick.setStyle(Paint.Style.STROKE);
        tick.setColor(0x66FFFFFF);
        glow.setStyle(Paint.Style.FILL);
        tip.setStyle(Paint.Style.FILL);
        tip.setColor(Color.WHITE);
        number.setColor(Color.WHITE);
        number.setTextAlign(Paint.Align.CENTER);
        number.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        unit.setColor(0xB3FFFFFF);
        unit.setTextAlign(Paint.Align.CENTER);
        label.setColor(0x99FFFFFF);
        label.setTextAlign(Paint.Align.CENTER);
    }

    /** Numeric text moves the gauge; anything else ("—", "…") is shown as a placeholder. */
    public void setText(CharSequence t) {
        try {
            setSpeed(Double.parseDouble(String.valueOf(t)));
        } catch (NumberFormatException e) {
            placeholder = String.valueOf(t);
            hasValue = false;
            value = 0;
            scale = SCALES[0];
            animateTo(0f);
        }
    }

    public void setSpeed(double mbps) {
        hasValue = true;
        value = mbps;
        for (double s : SCALES) {          // the scale only grows during a test
            if (s > scale && mbps > scale * 0.9) scale = s;
            if (mbps <= scale) break;
        }
        animateTo((float) Math.min(1.0, mbps / scale));
    }

    private void animateTo(float f) {
        if (anim != null) anim.cancel();
        anim = ValueAnimator.ofFloat(shown, f);
        anim.setDuration(350);
        anim.setInterpolator(new DecelerateInterpolator());
        anim.addUpdateListener(a -> {
            shown = (float) a.getAnimatedValue();
            invalidate();
        });
        anim.start();
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        int w = MeasureSpec.getSize(wSpec);
        setMeasuredDimension(w, Math.round(w * 0.62f));
    }

    @Override
    protected void onDraw(Canvas cv) {
        float w = getWidth();
        float stroke = w * 0.075f;
        float pad = stroke * 1.2f;
        float r = w / 2f - pad;
        float cx = w / 2f, cy = r + pad;
        box.set(cx - r, cy - r, cx + r, cy + r);

        track.setStrokeWidth(stroke);
        cv.drawArc(box, START, SWEEP, false, track);

        // scale ticks and end labels
        tick.setStrokeWidth(Math.max(2f, stroke * 0.12f));
        for (int i = 0; i <= 10; i++) {
            double a = Math.toRadians(START + SWEEP * i / 10f);
            float r1 = r - stroke * 0.95f, r2 = r1 - stroke * (i % 5 == 0 ? 0.7f : 0.4f);
            cv.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1,
                    cx + (float) Math.cos(a) * r2, cy + (float) Math.sin(a) * r2, tick);
        }
        label.setTextSize(w * 0.05f);
        cv.drawText("0", cx - r, cy + stroke * 1.5f, label);
        cv.drawText(String.format(Locale.US, "%d", (long) scale), cx + r, cy + stroke * 1.5f, label);

        // progress arc
        float sweep = SWEEP * shown;
        if (sweep > 0.5f) {
            arc.setStrokeWidth(stroke);
            arc.setShader(new SweepGradient(cx, cy,
                    new int[]{0xFF1FD38A, 0xFF00D2D8, 0xFF4DA3FF, 0xFF1FD38A},
                    new float[]{0.5f, 0.62f, 0.8f, 1f}));
            cv.drawArc(box, START, sweep, false, arc);

            double a = Math.toRadians(START + sweep);
            float tx = cx + (float) Math.cos(a) * r, ty = cy + (float) Math.sin(a) * r;
            glow.setColor(0x4000D2D8);
            cv.drawCircle(tx, ty, stroke * 1.25f, glow);
            cv.drawCircle(tx, ty, stroke * 0.55f, tip);
        }

        // number + unit
        String text = hasValue ? (value >= 100 ? String.format(Locale.US, "%.0f", value)
                : String.format(Locale.US, "%.1f", value)) : placeholder;
        number.setTextSize(w * 0.2f);
        cv.drawText(text, cx, cy - r * 0.12f, number);
        unit.setTextSize(w * 0.055f);
        cv.drawText("Mbps", cx, cy + r * 0.12f, unit);
    }

    @Override
    protected void onDetachedFromWindow() {
        if (anim != null) anim.cancel();
        super.onDetachedFromWindow();
    }
}
