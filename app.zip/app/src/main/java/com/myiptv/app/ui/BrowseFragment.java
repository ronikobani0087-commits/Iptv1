package com.myiptv.app.ui;

import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.data.AppDao;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Category;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.OrderPref;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.LiveQueue;
import com.myiptv.app.util.Players;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Categories | items | (live preview) screen, used for live channels and movies.
 * Categories and items keep the exact order of the provider.
 */
public class BrowseFragment extends Fragment {
    private static final String ARG_TYPE = "type";
    private static final int ALL_LIMIT = 20000;
    /** Leading special entries in the packages list: favorites, then "All". */
    private static final int SPECIAL = 2;
    private static final String FAV_ID = "\u0000fav";

    private static boolean isSpecial(Category c) {
        return c.remoteId == null || FAV_ID.equals(c.remoteId);
    }

    public static BrowseFragment newInstance(String type) {
        BrowseFragment f = new BrowseFragment();
        Bundle a = new Bundle();
        a.putString(ARG_TYPE, type);
        f.setArguments(a);
        return f;
    }

    /** Live TV on a wide screen: the video fills the screen and the lists float over it. */
    public static boolean fullscreenLive(Context c) {
        return c.getResources().getConfiguration().screenWidthDp >= 700;
    }

    private String type = "live";
    private long playlistId = -1;
    private boolean showPreview;
    private boolean overlayMode;

    private RecyclerView catsView;
    private EditText searchBox;
    private boolean suppressSearch;
    private String searchQuery = "";
    private final Handler searchHandler = new Handler(Looper.getMainLooper());
    private final Runnable searchRunnable = new Runnable() {
        @Override
        public void run() {
            applySearch();
        }
    };

    private final CatAdapter catAdapter = new CatAdapter();
    private final ItemAdapter itemAdapter = new ItemAdapter();
    private RecyclerView itemsView;
    private TextView emptyView;

    private PlayerView playerView;
    private TextView previewTitle;
    private TextView previewMessage;
    private ExoPlayer player;
    private Item current;

    private int selectedCat = -1;
    private int loadToken;
    private final Set<String> favIds = new HashSet<>();
    private boolean itemsReorderable;

    private boolean grid;
    private int gridCardH;
    private boolean hasTouch = true;
    private int currentNumber;
    private final Map<String, String> catNames = new HashMap<>();

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (previewMessage == null) return;
            if (state == Player.STATE_BUFFERING) {
                previewMessage.setText("جارٍ التحميل…");
                previewMessage.setVisibility(View.VISIBLE);
            } else if (state == Player.STATE_READY) {
                previewMessage.setVisibility(View.GONE);
            }
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            if (previewMessage == null) return;
            previewMessage.setText("تعذر تشغيل القناة (" + error.getErrorCodeName() + ")");
            previewMessage.setVisibility(View.VISIBLE);
        }
    };

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        Bundle args = getArguments();
        type = args == null ? "live" : args.getString(ARG_TYPE, "live");
        int screenW = getResources().getConfiguration().screenWidthDp;
        boolean isLive = "live".equals(type);
        showPreview = isLive && fullscreenLive(c);
        overlayMode = showPreview;
        boolean narrow = screenW < 500;
        grid = !isLive;
        hasTouch = c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN);
        float density = getResources().getDisplayMetrics().density;
        int sidebarDp = 0; // the main menu is hidden on this screen
        int catDp = overlayMode ? 170 : (narrow ? 120 : 190);
        // Poster grid: about 96dp cards, as many columns as fit next to the categories.
        int availDp = Math.max(160, screenW - sidebarDp - catDp - 12 - 16);
        // five cards per row (fewer only on very small screens)
        int span = availDp / 5 >= 80 ? 5 : Math.max(3, availDp / 80);
        int cellDp = availDp / span;
        gridCardH = Ui.dp(c, Math.round((cellDp - 10) * 1.38f));

        FrameLayout frame = new FrameLayout(c);
        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.HORIZONTAL);
        if (overlayMode) {
            // video behind, both lists (packages + channels) float over it on the right
            frame.setBackgroundColor(0xFF000000);
            frame.addView(buildBackdrop(c), new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            root.setBackgroundResource(R.drawable.bg_live_scrim);
            frame.addView(root, new FrameLayout.LayoutParams(
                    Ui.dp(c, catDp + 300 + 40), ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START));
        } else {
            frame.addView(root, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        }

        LinearLayout catColumn = new LinearLayout(c);
        catColumn.setOrientation(LinearLayout.VERTICAL);
        if (!overlayMode) catColumn.setBackgroundResource(R.drawable.bg_panel);

        if (!isLive) {
            catColumn.addView(buildSearchBox(c), buttonLp(c));
        }

        catsView = new RecyclerView(c);
        catsView.setLayoutManager(new LinearLayoutManager(c));
        catsView.setAdapter(catAdapter);
        catsView.setClipToPadding(false);
        catsView.setPadding(Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8));
        catColumn.addView(catsView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        LinearLayout.LayoutParams catLp = new LinearLayout.LayoutParams(
                Ui.dp(c, catDp), ViewGroup.LayoutParams.MATCH_PARENT);
        catLp.setMargins(Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8));
        root.addView(catColumn, catLp);
        // packages are re-ordered from the long-press menu (see showMoveDialog)

        itemsView = new RecyclerView(c);
        itemsView.setLayoutManager(grid ? new GridLayoutManager(c, span) : new LinearLayoutManager(c));
        itemsView.setAdapter(itemAdapter);
        itemsView.setClipToPadding(false);
        itemsView.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
        if (overlayMode) {
            root.addView(itemsView, new LinearLayout.LayoutParams(
                    Ui.dp(c, 300), ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            root.addView(itemsView, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));
        }
        new ItemTouchHelper(itemDragCallback).attachToRecyclerView(itemsView);

        emptyView = new TextView(c);
        emptyView.setTextColor(ContextCompat.getColor(c, R.color.muted));
        emptyView.setTextSize(15);
        emptyView.setGravity(Gravity.CENTER);
        emptyView.setVisibility(View.GONE);
        frame.addView(emptyView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        loadCategories();
        return frame;
    }

    @Override
    public void onDestroyView() {
        searchHandler.removeCallbacks(searchRunnable);
        super.onDestroyView();
    }

    private TextView smallButton(Context c, String text) {
        TextView t = new TextView(c);
        t.setText(text);
        t.setTextColor(ContextCompat.getColor(c, overlayMode ? R.color.text : R.color.muted));
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundResource(R.drawable.bg_nav);
        t.setFocusable(true);
        t.setClickable(true);
        t.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
        return t;
    }

    private LinearLayout.LayoutParams buttonLp(Context c) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMargins(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), 0);
        return lp;
    }

    /** Search field shown at the top of the packages column in the movies and series sections. */
    private View buildSearchBox(Context c) {
        searchBox = new EditText(c);
        searchBox.setHint("movie".equals(type) ? "ابحث عن فيلم…" : "ابحث عن مسلسل…");
        searchBox.setHintTextColor(ContextCompat.getColor(c, R.color.muted));
        searchBox.setTextColor(ContextCompat.getColor(c, R.color.text));
        searchBox.setTextSize(13);
        searchBox.setSingleLine(true);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setBackgroundResource(R.drawable.bg_field);
        searchBox.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
        searchBox.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        searchBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (suppressSearch) return;
                searchQuery = s.toString().trim();
                searchHandler.removeCallbacks(searchRunnable);
                searchHandler.postDelayed(searchRunnable, 350);
            }
        });
        searchBox.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == EditorInfo.IME_ACTION_SEARCH) {
                searchHandler.removeCallbacks(searchRunnable);
                applySearch();
            }
            return false;
        });
        return searchBox;
    }

    /** Full screen video behind the lists, with the channel name and a hint at the bottom. */
    private View buildBackdrop(Context c) {
        FrameLayout box = new FrameLayout(c);
        box.setBackgroundColor(0xFF000000);
        playerView = new PlayerView(c);
        playerView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        playerView.setUseController(false);
        playerView.setOnClickListener(v -> {
            if (current != null) openLive(current, currentNumber);
        });
        box.addView(playerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        previewMessage = new TextView(c);
        previewMessage.setTextColor(0xFFFFFFFF);
        previewMessage.setTextSize(14);
        previewMessage.setGravity(Gravity.CENTER);
        previewMessage.setText("اختر قناة للمشاهدة");
        box.addView(previewMessage, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        LinearLayout info = new LinearLayout(c);
        info.setOrientation(LinearLayout.VERTICAL);
        previewTitle = new TextView(c);
        previewTitle.setTextColor(0xFFFFFFFF);
        previewTitle.setTextSize(16);
        previewTitle.setTypeface(Typeface.DEFAULT_BOLD);
        previewTitle.setMaxLines(1);
        previewTitle.setEllipsize(TextUtils.TruncateAt.END);
        previewTitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        previewTitle.setShadowLayer(6f, 0f, 1f, 0xFF000000);
        info.addView(previewTitle);
        TextView hint = new TextView(c);
        hint.setTextColor(0xFFD7E6EA);
        hint.setTextSize(12);
        hint.setText("اضغط على القناة مرة ثانية أو على الشاشة لعرضها بملء الشاشة");
        hint.setShadowLayer(6f, 0f, 1f, 0xFF000000);
        info.addView(hint);
        FrameLayout.LayoutParams ip = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.END);
        ip.setMargins(Ui.dp(c, 20), 0, Ui.dp(c, 20), Ui.dp(c, 16));
        box.addView(info, ip);
        return box;
    }

    // ------------------------------------------------------------ search

    private void applySearch() {
        if (!isAdded() || playlistId < 0 || itemsView == null) return;
        final String q = searchQuery;
        if (q.isEmpty()) {
            if (selectedCat >= 0) selectCategory(selectedCat);
            return;
        }
        final int token = ++loadToken;
        final long pid = playlistId;
        final Context app = requireContext().getApplicationContext();
        itemsReorderable = false;
        Async.io(() -> {
            final List<Item> found = AppDatabase.get(app).dao().searchItems(pid, type, q, 500);
            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                itemAdapter.set(found);
                itemsView.scrollToPosition(0);
                if (found.isEmpty()) {
                    Toast.makeText(requireContext(), "لا توجد نتائج", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    // ---------------------------------------------------------------- data

    private void loadCategories() {
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            UserDao ud = UserDatabase.get(app).dao();
            long pid = Prefs.getActive(app);
            Playlist p = pid < 0 ? null : dao.getPlaylist(pid);
            final List<Category> list = new ArrayList<>();
            final List<String> favs = new ArrayList<>();
            if (p != null) {
                Category fav = new Category();
                fav.name = "★ المفضلة";
                fav.remoteId = FAV_ID;
                list.add(fav);
                Category all = new Category();
                all.name = "الكل";
                all.remoteId = null;
                list.add(all);
                List<Category> real = dao.getCategories(p.id, type);
                real = applyOrder(real, ud.getOrder(p.id, "cat:" + type), new KeyFn<Category>() {
                    @Override
                    public String key(Category c) {
                        return c.remoteId == null ? "" : c.remoteId;
                    }
                });
                list.addAll(real);
                catNames.clear();
                for (Category rc : real) {
                    if (rc.remoteId != null) catNames.put(rc.remoteId, rc.name == null ? "" : rc.name);
                }
                favs.addAll(ud.favoriteIds(p.id, type));
            }
            final long finalId = p == null ? -1 : p.id;
            Async.main(() -> {
                if (!isAdded()) return;
                playlistId = finalId;
                favIds.clear();
                favIds.addAll(favs);
                if (finalId < 0) {
                    showEmpty("لا توجد قائمة مضافة.\nأضف قائمة من الرئيسية.");
                    return;
                }
                if (list.size() <= SPECIAL) {
                    showEmpty("لا يوجد محتوى في هذه القائمة.");
                    return;
                }
                emptyView.setVisibility(View.GONE);
                catAdapter.set(list);
                selectCategory(SPECIAL);
            });
        });
    }

    private void showEmpty(String text) {
        emptyView.setText(text);
        emptyView.setVisibility(View.VISIBLE);
    }

    private void selectCategory(int pos) {
        if (pos < 0 || pos >= catAdapter.data.size()) return;
        // picking a package leaves the search results
        searchHandler.removeCallbacks(searchRunnable);
        searchQuery = "";
        if (searchBox != null && searchBox.getText().length() > 0) {
            suppressSearch = true;
            searchBox.setText("");
            suppressSearch = false;
        }
        int old = selectedCat;
        selectedCat = pos;
        if (old >= 0) catAdapter.notifyItemChanged(old);
        catAdapter.notifyItemChanged(pos);

        final Category cat = catAdapter.data.get(pos);
        final int token = ++loadToken;
        final long pid = playlistId;
        final Context app = requireContext().getApplicationContext();
        itemsReorderable = !isSpecial(cat);
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            List<Item> list;
            if (FAV_ID.equals(cat.remoteId)) {
                list = new ArrayList<>();
                for (Favorite f : UserDatabase.get(app).dao().favoritesOfType(pid, type, 2000)) {
                    Item it = new Item();
                    it.id = 2000000000L + f.id;
                    it.playlistId = pid;
                    it.type = type;
                    it.remoteId = f.remoteId;
                    it.name = f.name;
                    it.icon = f.icon;
                    it.streamUrl = f.streamUrl;
                    it.rating = "";
                    it.year = "";
                    list.add(it);
                }
            } else if (cat.remoteId == null) {
                list = dao.itemsAll(pid, type, ALL_LIMIT);
            } else {
                list = dao.itemsInCategory(pid, type, cat.remoteId);
                list = applyOrder(list, UserDatabase.get(app).dao().getOrder(pid, itemScope(cat)),
                        new KeyFn<Item>() {
                            @Override
                            public String key(Item i) {
                                return itemKey(i);
                            }
                        });
            }
            final List<Item> result = list;
            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                itemAdapter.set(result);
                itemsView.scrollToPosition(0);
            });
        });
    }

    // ----------------------------------------------- custom order (drag and drop)

    private interface KeyFn<T> {
        String key(T t);
    }

    private static String itemKey(Item i) {
        return (i.streamUrl != null && !i.streamUrl.isEmpty()) ? i.streamUrl : String.valueOf(i.remoteId);
    }

    private String itemScope(Category cat) {
        return "items:" + type + ":" + cat.remoteId;
    }

    /** Sorts by the saved order; anything not in it keeps the provider order after the saved ones. */
    private static <T> List<T> applyOrder(List<T> list, String json, final KeyFn<T> fn) {
        if (json == null || json.isEmpty() || list.size() < 2) return list;
        final Map<String, Integer> rank = new HashMap<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                String k = arr.optString(i);
                if (!rank.containsKey(k)) rank.put(k, i);
            }
        } catch (Exception e) {
            return list;
        }
        List<T> copy = new ArrayList<>(list);
        Collections.sort(copy, new Comparator<T>() {
            @Override
            public int compare(T a, T b) {
                Integer ra = rank.get(fn.key(a));
                Integer rb = rank.get(fn.key(b));
                return Integer.compare(ra == null ? Integer.MAX_VALUE : ra,
                        rb == null ? Integer.MAX_VALUE : rb);
            }
        });
        return copy;
    }

    private void saveOrder(final String scope, List<String> keys) {
        final JSONArray arr = new JSONArray();
        for (String k : keys) arr.put(k);
        final long pid = playlistId;
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            OrderPref o = new OrderPref();
            o.playlistId = pid;
            o.scope = scope;
            o.json = arr.toString();
            UserDatabase.get(app).dao().putOrder(o);
        });
    }

    private void saveCategoryOrder() {
        List<String> keys = new ArrayList<>();
        for (Category c : catAdapter.data) {
            if (!isSpecial(c)) keys.add(c.remoteId);
        }
        saveOrder("cat:" + type, keys);
    }

    private void saveItemOrder() {
        if (selectedCat < 0 || selectedCat >= catAdapter.data.size()) return;
        Category cat = catAdapter.data.get(selectedCat);
        if (isSpecial(cat)) return;
        List<String> keys = new ArrayList<>();
        for (Item i : itemAdapter.data) keys.add(itemKey(i));
        saveOrder(itemScope(cat), keys);
    }

    /** Long press on a package: a small menu to move it up or down (works with a remote too). */
    private void showMoveDialog(int startPos) {
        if (!isAdded() || startPos < SPECIAL || startPos >= catAdapter.data.size()) return;
        final Context c = requireContext();
        final int[] pos = {startPos};

        LinearLayout box = new LinearLayout(c);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(Ui.dp(c, 22), Ui.dp(c, 18), Ui.dp(c, 22), Ui.dp(c, 10));

        TextView title = new TextView(c);
        String n = catAdapter.data.get(startPos).name;
        title.setText(n == null ? "" : n);
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        title.setGravity(Gravity.START);
        box.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView up = Ui.button(c, "▲  نقل للأعلى", true);
        TextView down = Ui.button(c, "▼  نقل للأسفل", true);
        TextView close = Ui.button(c, "تم", false);
        up.setOnClickListener(v -> {
            if (moveCategory(pos[0], pos[0] - 1)) pos[0]--;
        });
        down.setOnClickListener(v -> {
            if (moveCategory(pos[0], pos[0] + 1)) pos[0]++;
        });
        box.addView(up, dialogButtonLp(c, 14));
        box.addView(down, dialogButtonLp(c, 8));
        box.addView(close, dialogButtonLp(c, 8));

        final AlertDialog dlg = new AlertDialog.Builder(c).setView(box).create();
        close.setOnClickListener(v -> dlg.dismiss());
        dlg.show();
        up.requestFocus();
    }

    private static LinearLayout.LayoutParams dialogButtonLp(Context c, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, topDp);
        return lp;
    }

    /** Moves a package one place; the "All" entry (position 0) always stays first. */
    private boolean moveCategory(int from, int to) {
        int n = catAdapter.data.size();
        if (from < SPECIAL || to < SPECIAL || from >= n || to >= n || from == to) return false;
        Collections.swap(catAdapter.data, from, to);
        if (selectedCat == from) selectedCat = to;
        else if (selectedCat == to) selectedCat = from;
        catAdapter.notifyItemMoved(from, to);
        catAdapter.notifyItemChanged(from);
        catAdapter.notifyItemChanged(to);
        if (catsView != null) catsView.smoothScrollToPosition(to);
        saveCategoryOrder();
        return true;
    }

    private void resetOrder() {
        final long pid = playlistId;
        if (pid < 0) return;
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            ud.clearOrders(pid, "cat:" + type);
            ud.clearOrders(pid, "items:" + type + ":%");
            Async.main(() -> {
                if (!isAdded()) return;
                Toast.makeText(requireContext(), "تمت إعادة الترتيب الأصلي", Toast.LENGTH_SHORT).show();
                loadCategories();
            });
        });
    }

    private final ItemTouchHelper.SimpleCallback catDragCallback =
            new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
                private boolean moved;

                @Override
                public boolean onMove(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder from,
                                      @NonNull RecyclerView.ViewHolder to) {
                    int a = from.getBindingAdapterPosition();
                    int b = to.getBindingAdapterPosition();
                    if (a == RecyclerView.NO_POSITION || b == RecyclerView.NO_POSITION) return false;
                    if (a == 0 || b == 0) return false; // "All" stays first
                    Collections.swap(catAdapter.data, a, b);
                    if (selectedCat == a) selectedCat = b;
                    else if (selectedCat == b) selectedCat = a;
                    catAdapter.notifyItemMoved(a, b);
                    moved = true;
                    return true;
                }

                @Override
                public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int direction) {
                }

                @Override
                public int getMovementFlags(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh) {
                    if (vh.getBindingAdapterPosition() == 0) return 0;
                    return super.getMovementFlags(rv, vh);
                }

                @Override
                public void clearView(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh) {
                    super.clearView(rv, vh);
                    vh.itemView.setAlpha(1f);
                    if (moved) {
                        moved = false;
                        saveCategoryOrder();
                    }
                }

                @Override
                public void onSelectedChanged(RecyclerView.ViewHolder vh, int actionState) {
                    super.onSelectedChanged(vh, actionState);
                    if (vh != null && actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                        vh.itemView.setAlpha(0.7f);
                    }
                }
            };

    private final ItemTouchHelper.SimpleCallback itemDragCallback =
            new ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP | ItemTouchHelper.DOWN, 0) {
                private boolean moved;

                @Override
                public int getDragDirs(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh) {
                    return grid
                            ? (ItemTouchHelper.UP | ItemTouchHelper.DOWN
                            | ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT)
                            : (ItemTouchHelper.UP | ItemTouchHelper.DOWN);
                }

                @Override
                public boolean isLongPressDragEnabled() {
                    return itemsReorderable && hasTouch;
                }

                @Override
                public boolean onMove(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder from,
                                      @NonNull RecyclerView.ViewHolder to) {
                    int a = from.getBindingAdapterPosition();
                    int b = to.getBindingAdapterPosition();
                    if (a == RecyclerView.NO_POSITION || b == RecyclerView.NO_POSITION) return false;
                    Collections.swap(itemAdapter.data, a, b);
                    itemAdapter.notifyItemMoved(a, b);
                    moved = true;
                    return true;
                }

                @Override
                public void onSwiped(@NonNull RecyclerView.ViewHolder vh, int direction) {
                }

                @Override
                public void clearView(@NonNull RecyclerView rv, @NonNull RecyclerView.ViewHolder vh) {
                    super.clearView(rv, vh);
                    vh.itemView.setAlpha(1f);
                    if (moved) {
                        moved = false;
                        saveItemOrder();
                    }
                }

                @Override
                public void onSelectedChanged(RecyclerView.ViewHolder vh, int actionState) {
                    super.onSelectedChanged(vh, actionState);
                    if (vh != null && actionState == ItemTouchHelper.ACTION_STATE_DRAG) {
                        vh.itemView.setAlpha(0.7f);
                    }
                }
            };

    // ------------------------------------------------------------- favorites

    private void toggleFavorite(final Item it, final int position) {
        final long pid = playlistId;
        if (pid < 0 || it.remoteId == null) return;
        final boolean wasFav = favIds.contains(it.remoteId);
        if (wasFav) favIds.remove(it.remoteId);
        else favIds.add(it.remoteId);
        if (wasFav && selectedCat >= 0 && selectedCat < catAdapter.data.size()
                && FAV_ID.equals(catAdapter.data.get(selectedCat).remoteId)
                && position >= 0 && position < itemAdapter.data.size()) {
            itemAdapter.data.remove(position);
            itemAdapter.notifyItemRemoved(position);
        } else {
            itemAdapter.notifyItemChanged(position);
        }
        final Context app = requireContext().getApplicationContext();
        Toast.makeText(app, wasFav ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (wasFav) {
                ud.removeFavorite(pid, type, it.remoteId);
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = type;
                f.remoteId = it.remoteId;
                f.name = it.name == null ? "" : it.name;
                f.icon = it.icon == null ? "" : it.icon;
                f.streamUrl = it.streamUrl == null ? "" : it.streamUrl;
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
            }
        });
    }

    // ------------------------------------------------------------- playback

    @Override
    public void onStart() {
        super.onStart();
        if (showPreview && playerView != null) {
            player = Players.create(requireContext());
            player.addListener(listener);
            playerView.setPlayer(player);
            if (current != null) playPreview(current);
        }
    }

    @Override
    public void onStop() {
        super.onStop();
        if (player != null) {
            player.removeListener(listener);
            if (playerView != null) playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }

    private void openLive(Item it, int number) {
        // the remote flips channels inside this list; numbers match the list positions
        LiveQueue.set(itemAdapter.data, catNames);
        String sub = it.categoryRemoteId == null ? "" : catNames.get(it.categoryRemoteId);
        PlayerActivity.startLive(requireContext(), it.streamUrl, it.name, it.icon,
                number, sub == null ? "" : sub);
    }

    private void playPreview(Item it) {
        current = it;
        previewTitle.setText(it.name == null ? "" : it.name);
        if (player == null) return;
        previewMessage.setText("جارٍ التحميل…");
        previewMessage.setVisibility(View.VISIBLE);
        player.setMediaItem(MediaItem.fromUri(it.streamUrl));
        player.prepare();
        player.play();
        if (overlayMode) itemAdapter.notifyDataSetChanged();
    }

    private void onItemClick(Item it, int number) {
        if (it.streamUrl == null || it.streamUrl.isEmpty()) {
            if ("series".equals(type)) {
                SeriesPicker.show(requireActivity(), playlistId, it.name, it.remoteId, it.icon);
            } else {
                Toast.makeText(requireContext(), "لا يوجد رابط تشغيل لهذا العنصر", Toast.LENGTH_SHORT).show();
            }
            return;
        }
        currentNumber = number;
        if (showPreview && (current == null || current.id != it.id)) {
            playPreview(it);
        } else if ("live".equals(type)) {
            openLive(it, number);
        } else {
            PlayerActivity.start(requireContext(), it.streamUrl, it.name);
        }
    }

    // ------------------------------------------------------------ adapters

    private class CatAdapter extends RecyclerView.Adapter<CatAdapter.VH> {
        List<Category> data = new ArrayList<>();

        void set(List<Category> l) {
            data = l;
            selectedCat = -1;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            TextView tv = new TextView(c);
            tv.setTextColor(overlayMode ? 0xFFFFFFFF : ContextCompat.getColor(c, R.color.text));
            tv.setTextSize(overlayMode ? 15 : 12);
            if (overlayMode) {
                tv.setTypeface(Typeface.DEFAULT_BOLD);
                tv.setShadowLayer(4f, 0f, 1f, 0xFF000000);
            }
            tv.setMaxLines(2);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            tv.setGravity(Gravity.CENTER_VERTICAL);
            tv.setMinHeight(Ui.dp(c, 44));
            tv.setPadding(Ui.dp(c, 10), Ui.dp(c, 6), Ui.dp(c, 10), Ui.dp(c, 6));
            tv.setBackgroundResource(R.drawable.bg_nav);
            tv.setFocusable(true);
            tv.setClickable(true);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(c, 2);
            tv.setLayoutParams(lp);
            return new VH(tv);
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            Category cat = data.get(position);
            TextView tv = (TextView) h.itemView;
            tv.setText(cat.name == null ? "" : cat.name);
            tv.setSelected(position == selectedCat);
            tv.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) selectCategory(p);
            });
            tv.setOnLongClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p == RecyclerView.NO_POSITION || p < SPECIAL) return false; // favorites and "All" stay first
                showMoveDialog(p);
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        class VH extends RecyclerView.ViewHolder {
            VH(@NonNull View v) {
                super(v);
            }
        }
    }

    private class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.VH> {
        List<Item> data = new ArrayList<>();

        void set(List<Item> l) {
            data = l;
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return grid ? createPoster(parent.getContext()) : createRow(parent.getContext());
        }

        /** Poster card with the title underneath, used for movies and series. */
        private VH createPoster(Context c) {
            LinearLayout cell = new LinearLayout(c);
            cell.setOrientation(LinearLayout.VERTICAL);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMargins(Ui.dp(c, 5), Ui.dp(c, 4), Ui.dp(c, 5), Ui.dp(c, 8));
            cell.setLayoutParams(lp);

            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setPadding(Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2), Ui.dp(c, 2));
            cell.addView(frame, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, gridCardH));

            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            img.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
            CardStrip.round(img, Ui.dp(c, 10));
            frame.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView inTitle = new TextView(c);
            inTitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
            inTitle.setTextSize(12);
            inTitle.setMaxLines(4);
            inTitle.setEllipsize(TextUtils.TruncateAt.END);
            inTitle.setGravity(Gravity.CENTER);
            inTitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            inTitle.setPadding(Ui.dp(c, 6), 0, Ui.dp(c, 6), 0);
            frame.addView(inTitle, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView rating = new TextView(c);
            rating.setTextColor(ContextCompat.getColor(c, R.color.text));
            rating.setTextSize(10);
            rating.setBackgroundResource(R.drawable.bg_badge_dark);
            rating.setPadding(Ui.dp(c, 5), Ui.dp(c, 1), Ui.dp(c, 5), Ui.dp(c, 1));
            FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.START);
            rp.setMargins(Ui.dp(c, 6), 0, Ui.dp(c, 6), Ui.dp(c, 6));
            frame.addView(rating, rp);

            // Favorite star: tap on a touch screen. On a remote, long-press OK instead,
            // so the star never becomes an extra stop when moving with the arrow keys.
            TextView star = new TextView(c);
            star.setTextSize(15);
            star.setGravity(Gravity.CENTER);
            star.setBackgroundResource(R.drawable.bg_badge_dark);
            star.setClickable(true);
            star.setFocusable(false);
            FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 28), Ui.dp(c, 28), Gravity.TOP | Gravity.END);
            sp.setMargins(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), 0);
            frame.addView(star, sp);

            TextView name = new TextView(c);
            name.setTextColor(ContextCompat.getColor(c, R.color.text));
            name.setTextSize(12);
            name.setMaxLines(1);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            name.setGravity(Gravity.START);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            np.topMargin = Ui.dp(c, 6);
            cell.addView(name, np);

            VH h = new VH(cell, img, name, rating, star);
            h.inTitle = inTitle;
            h.click = frame;
            return h;
        }

        /** List row with a logo, used for live channels. */
        private VH createRow(Context c) {
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8), Ui.dp(c, 8));
            row.setBackgroundResource(overlayMode ? R.drawable.bg_nav : R.drawable.bg_card_focus);
            row.setFocusable(true);
            row.setClickable(true);
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = Ui.dp(c, 6);
            row.setLayoutParams(lp);

            ImageView logo = new ImageView(c);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            row.addView(logo, new LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44)));

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            cp.setMarginStart(Ui.dp(c, 10));
            row.addView(col, cp);

            TextView name = new TextView(c);
            name.setTextColor(overlayMode ? 0xFFFFFFFF : ContextCompat.getColor(c, R.color.text));
            name.setTextSize(overlayMode ? 16 : 13);
            if (overlayMode) {
                name.setTypeface(Typeface.DEFAULT_BOLD);
                name.setShadowLayer(4f, 0f, 1f, 0xFF000000);
            }
            name.setMaxLines(1);
            name.setEllipsize(TextUtils.TruncateAt.END);
            name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            col.addView(name);

            TextView sub = new TextView(c);
            sub.setTextColor(overlayMode ? 0xFFC3D8DE : ContextCompat.getColor(c, R.color.muted));
            sub.setTextSize(11);
            sub.setMaxLines(1);
            col.addView(sub);

            TextView star = new TextView(c);
            star.setTextSize(22);
            star.setGravity(Gravity.CENTER);
            star.setFocusable(true);
            star.setClickable(true);
            star.setBackgroundResource(R.drawable.bg_nav);
            LinearLayout.LayoutParams sp2 = new LinearLayout.LayoutParams(Ui.dp(c, 44), Ui.dp(c, 44));
            sp2.setMarginStart(Ui.dp(c, 6));
            row.addView(star, sp2);

            VH h = new VH(row, logo, name, sub, star);
            h.click = row;
            return h;
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Item it = data.get(position);
            Context c = h.itemView.getContext();
            final boolean fav = favIds.contains(it.remoteId);
            h.name.setText(it.name == null ? "" : it.name);

            if (grid) {
                boolean hasImg = it.icon != null && it.icon.startsWith("http");
                h.inTitle.setText(it.name == null ? "" : it.name);
                h.inTitle.setVisibility(hasImg ? View.GONE : View.VISIBLE);
                if (hasImg) {
                    CardStrip.load(h.logo, it.icon, android.R.color.transparent, 300, 420);
                } else {
                    Glide.with(c).clear(h.logo);
                    h.logo.setImageDrawable(null);
                }
                boolean hasRating = it.rating != null && !it.rating.isEmpty()
                        && !"0".equals(it.rating) && !"0.0".equals(it.rating);
                h.sub.setVisibility(hasRating ? View.VISIBLE : View.GONE);
                h.sub.setText(hasRating ? it.rating + " ★" : "");
                h.star.setText(fav ? "★" : "☆");
                h.star.setTextColor(fav ? 0xFFFFC107 : ContextCompat.getColor(c, R.color.text));
                h.click.setOnLongClickListener(v -> {
                    if (hasTouch) return false;
                    int p = h.getBindingAdapterPosition();
                    if (p == RecyclerView.NO_POSITION) return false;
                    toggleFavorite(it, p);
                    return true;
                });
            } else {
                String sub = "";
                if (it.year != null && !it.year.isEmpty()) sub = it.year;
                if (it.rating != null && !it.rating.isEmpty() && !"0".equals(it.rating)) {
                    sub = sub.isEmpty() ? "★ " + it.rating : sub + "  ★ " + it.rating;
                }
                h.sub.setText(sub);
                h.sub.setVisibility(sub.isEmpty() ? View.GONE : View.VISIBLE);
                CardStrip.load(h.logo, it.icon, R.drawable.ic_app_mark, 120, 120);
                h.itemView.setSelected(overlayMode && current != null && current.id == it.id);
                h.star.setText(fav ? "★" : "☆");
                h.star.setTextColor(fav ? 0xFFFFC107 : ContextCompat.getColor(c, R.color.muted));
            }

            h.star.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) toggleFavorite(it, p);
            });
            h.click.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                onItemClick(it, p == RecyclerView.NO_POSITION ? 0 : p + 1);
            });
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        class VH extends RecyclerView.ViewHolder {
            final ImageView logo;
            final TextView name, sub, star;
            TextView inTitle;
            View click;

            VH(@NonNull View v, ImageView logo, TextView name, TextView sub, TextView star) {
                super(v);
                this.logo = logo;
                this.name = name;
                this.sub = sub;
                this.star = star;
            }
        }
    }
}
