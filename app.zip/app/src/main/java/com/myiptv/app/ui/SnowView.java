package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

import java.util.Random;

/**
 * Background decoration for the home screen: small, very transparent snow flakes and dots in the
 * color of the app logo. It is drawn behind the cards, so it never covers posters or channel logos.
 */
public final class SnowView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int rgb;
    private final float density;

    private float[] xs = new float[0];
    private float[] ys = new float[0];
    private float[] rs = new float[0];
    private int[] alphas = new int[0];
    private boolean[] flake = new boolean[0];

    public SnowView(Context c) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        rgb = ContextCompat.getColor(c, R.color.eye) & 0x00FFFFFF;
        paint.setStrokeCap(Paint.Cap.ROUND);
        setFocusable(false);
        setClickable(false);
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        if (w <= 0 || h <= 0) return;
        // same pattern every time (fixed seed): about one flake per 70 x 70 dp
        int n = (int) ((w / density) * (h / density) / 4900f);
        n = Math.max(24, Math.min(n, 110));
        Random rnd = new Random(20260101L);
        xs = new float[n];
        ys = new float[n];
        rs = new float[n];
        alphas = new int[n];
        flake = new boolean[n];
        for (int i = 0; i < n; i++) {
            xs[i] = rnd.nextFloat() * w;
            ys[i] = rnd.nextFloat() * h;
            flake[i] = rnd.nextFloat() < 0.45f;
            rs[i] = (flake[i] ? 3.5f + rnd.nextFloat() * 4.5f : 1.2f + rnd.nextFloat() * 2.2f) * density;
            alphas[i] = 16 + rnd.nextInt(34); // 6% - 20% opaque
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        for (int i = 0; i < xs.length; i++) {
            paint.setColor((alphas[i] << 24) | rgb);
            if (flake[i]) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(Math.max(1f, rs[i] * 0.2f));
                float r = rs[i];
                for (int k = 0; k < 3; k++) {
                    double a = Math.toRadians(k * 60);
                    float dx = (float) (Math.cos(a) * r);
                    float dy = (float) (Math.sin(a) * r);
                    canvas.drawLine(xs[i] - dx, ys[i] - dy, xs[i] + dx, ys[i] + dy, paint);
                }
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(xs[i], ys[i], r * 0.18f, paint);
            } else {
                paint.setStyle(Paint.Style.FILL);
                canvas.drawCircle(xs[i], ys[i], rs[i], paint);
            }
        }
    }
}
