package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

import java.util.Random;

/**
 * Small, still, translucent snowballs tinted with the logo's cyan.
 * Nothing moves, so it costs nothing after the first draw. It never takes focus or touches
 * and is meant to sit underneath other views.
 */
public final class SnowView extends View {
    private final float[] xs, ys, rs, as;
    private final int count;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd;
    private final float density;
    private final int base;
    private final int light;

    public SnowView(Context c, int count, long seed) {
        super(c);
        this.count = count;
        density = c.getResources().getDisplayMetrics().density;
        rnd = new Random(seed);
        xs = new float[count];
        ys = new float[count];
        rs = new float[count];
        as = new float[count];
        base = ContextCompat.getColor(c, R.color.snow);
        light = ContextCompat.getColor(c, R.color.snow_hi);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Math.max(1f, density * 0.8f));
        setFocusable(false);
        setClickable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        for (int i = 0; i < count; i++) {
            xs[i] = rnd.nextFloat() * w;
            ys[i] = rnd.nextFloat() * h;
            rs[i] = (1.5f + rnd.nextFloat() * 3.5f) * density;
            as[i] = 0.10f + rnd.nextFloat() * 0.20f;
        }
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (getWidth() <= 0) return;
        for (int i = 0; i < count; i++) {
            fill.setColor(base);
            fill.setAlpha((int) (255 * as[i] * 0.6f));
            canvas.drawCircle(xs[i], ys[i], rs[i], fill);
            ring.setColor(base);
            ring.setAlpha((int) (255 * Math.min(1f, as[i] * 1.5f)));
            canvas.drawCircle(xs[i], ys[i], rs[i], ring);
            glint.setColor(light);
            glint.setAlpha((int) (255 * Math.min(1f, as[i] * 2f)));
            canvas.drawCircle(xs[i] - rs[i] * 0.3f, ys[i] - rs[i] * 0.3f, Math.max(0.8f, rs[i] * 0.22f), glint);
        }
    }
}
