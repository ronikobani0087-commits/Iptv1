package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.View;

import com.myiptv.app.R;

import java.util.Random;

/**
 * Slowly drifting translucent snowballs tinted with the logo's cyan.
 * Draws only; it never takes focus or touches, so it is meant to sit underneath other views.
 */
public final class SnowView extends View {
    private static final class Ball {
        float x, y, r, speed, drift, phase, alpha;
    }

    private final Ball[] balls;
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint glint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rnd;
    private final float density;
    private final int base;
    private final int light;
    private long last;
    private boolean placed;

    public SnowView(Context c, int count, long seed) {
        super(c);
        density = c.getResources().getDisplayMetrics().density;
        rnd = new Random(seed);
        balls = new Ball[count];
        for (int i = 0; i < count; i++) balls[i] = new Ball();
        base = androidx.core.content.ContextCompat.getColor(c, R.color.snow);
        light = androidx.core.content.ContextCompat.getColor(c, R.color.snow_hi);
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(Math.max(1f, density));
        setFocusable(false);
        setClickable(false);
        setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
    }

    private void respawn(Ball b, boolean anywhere) {
        int w = Math.max(1, getWidth());
        int h = Math.max(1, getHeight());
        b.r = (3f + rnd.nextFloat() * 8f) * density;
        b.x = rnd.nextFloat() * w;
        b.y = anywhere ? rnd.nextFloat() * h : -b.r * 2;
        // bigger balls are a little faster, like they are closer to the screen
        b.speed = (10f + rnd.nextFloat() * 16f + b.r / density * 1.5f) * density;
        b.drift = (6f + rnd.nextFloat() * 14f) * density;
        b.phase = rnd.nextFloat() * 6.2831f;
        b.alpha = 0.10f + rnd.nextFloat() * 0.22f;
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (w <= 0 || h <= 0) return;
        for (Ball b : balls) respawn(b, true);
        placed = true;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        last = 0;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        if (!placed) return;
        long now = System.nanoTime();
        float dt = last == 0 ? 0f : Math.min(0.05f, (now - last) / 1e9f);
        last = now;
        float t = now / 1e9f;
        int h = getHeight();
        int w = getWidth();
        for (Ball b : balls) {
            b.y += b.speed * dt;
            if (b.y - b.r > h) respawn(b, false);
            float x = b.x + (float) Math.sin(t * 0.6f + b.phase) * b.drift;
            if (x < -b.r) x += w + 2 * b.r;
            if (x > w + b.r) x -= w + 2 * b.r;
            fill.setColor(base);
            fill.setAlpha((int) (255 * b.alpha * 0.55f));
            canvas.drawCircle(x, b.y, b.r, fill);
            ring.setColor(base);
            ring.setAlpha((int) (255 * Math.min(1f, b.alpha * 1.6f)));
            canvas.drawCircle(x, b.y, b.r, ring);
            glint.setColor(light);
            glint.setAlpha((int) (255 * Math.min(1f, b.alpha * 2.2f)));
            canvas.drawCircle(x - b.r * 0.35f, b.y - b.r * 0.35f, Math.max(1f, b.r * 0.22f), glint);
        }
        postInvalidateOnAnimation();
    }
}
