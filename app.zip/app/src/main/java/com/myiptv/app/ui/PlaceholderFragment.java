package com.myiptv.app.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/** Temporary screen for sections that are built in later phases. */
public class PlaceholderFragment extends Fragment {
    public static PlaceholderFragment newInstance(String title) {
        PlaceholderFragment f = new PlaceholderFragment();
        Bundle a = new Bundle();
        a.putString("title", title);
        f.setArguments(a);
        return f;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        TextView tv = new TextView(requireContext());
        tv.setGravity(Gravity.CENTER);
        tv.setTextColor(0xFFD7E6EA);
        tv.setTextSize(18);
        String title = getArguments() == null ? "" : getArguments().getString("title", "");
        tv.setText(title + "\nقريباً في المرحلة التالية");
        return tv;
    }
}
