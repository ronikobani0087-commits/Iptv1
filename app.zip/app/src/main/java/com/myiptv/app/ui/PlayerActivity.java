package com.myiptv.app.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.data.AppDao;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Category;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.LiveQueue;
import com.myiptv.app.util.Players;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Full screen video player.
 * Remote control: on live channels UP / DOWN (or CH+ / CH-) flip channels, LEFT / RIGHT change the
 * volume and the number keys jump to a channel number. On movies and episodes LEFT / RIGHT seek
 * and OK pauses / resumes.
 */
public class PlayerActivity extends AppCompatActivity {
    private static final String EXTRA_URL = "url";
    private static final String EXTRA_TITLE = "title";
    private static final String EXTRA_PLAYLIST = "playlist";
    private static final String EXTRA_TYPE = "type";
    private static final String EXTRA_REMOTE = "remote";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_ICON = "icon";
    private static final String EXTRA_EPISODE = "episode";
    private static final String EXTRA_POS = "pos";
    private static final String EXTRA_LIVE = "live";
    private static final String EXTRA_LOGO = "logo";
    private static final String EXTRA_NUM = "num";
    private static final String EXTRA_SUB = "sub";
    private static final String EXTRA_BROWSE = "browse";
    private static final String FAV_ID = "\u0000fav";
    private static final int SPECIAL = 2;

    private static final long SEEK_STEP_MS = 10000L;

    public static void start(Context context, String url, String title) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        context.startActivity(i);
    }

    /** Opens live TV straight in the player: last (or first) channel plays and the channel list is shown. */
    public static void startBrowse(Context context) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_LIVE, true);
        i.putExtra(EXTRA_BROWSE, true);
        context.startActivity(i);
    }

    /** Plays a live channel and shows the channel banner (logo, number, name, group). */
    public static void startLive(Context context, String url, String title, String logo,
                                 int number, String subtitle) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_LIVE, true);
        i.putExtra(EXTRA_LOGO, logo);
        i.putExtra(EXTRA_NUM, number);
        i.putExtra(EXTRA_SUB, subtitle);
        context.startActivity(i);
    }

    /** Plays a series episode and remembers where the user stopped (for "series I follow"). */
    public static void startTracked(Context context, String url, String title, long playlistId,
                                    String type, String remoteId, String name, String icon,
                                    String episode, long positionMs) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_PLAYLIST, playlistId);
        i.putExtra(EXTRA_TYPE, type);
        i.putExtra(EXTRA_REMOTE, remoteId);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_ICON, icon);
        i.putExtra(EXTRA_EPISODE, episode);
        i.putExtra(EXTRA_POS, positionMs);
        context.startActivity(i);
    }

    private long trackPlaylist = -1;
    private String trackType, trackRemote, trackName, trackIcon, trackEpisode;
    private long startPos;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PlayerView playerView;
    private TextView message;
    private TextView titleView;
    private View infoBar;
    private View controlsRow;
    private TextView btnPlay;
    private boolean live;
    private ExoPlayer player;
    private String url;

    // live banner views, updated when the channel changes
    private TextView liveTitle;
    private TextView liveSub;
    private ImageView liveIcon;
    private ImageView liveMark;
    private TextView numberEntry;
    private int queueIndex = -1;
    private boolean browse;
    private final StringBuilder typed = new StringBuilder();

    private final Runnable hideTitle = new Runnable() {
        @Override
        public void run() {
            if (titleView != null) titleView.setVisibility(View.GONE);
            if (infoBar != null) infoBar.setVisibility(View.GONE);
            if (controlsRow != null) controlsRow.setVisibility(View.GONE);
        }
    };

    private final Runnable commitNumber = new Runnable() {
        @Override
        public void run() {
            commitTypedNumber();
        }
    };

    private void showInfo() {
        if (panelVisible()) return;
        handler.removeCallbacks(hideTitle);
        if (live) {
            if (infoBar != null) infoBar.setVisibility(View.VISIBLE);
        } else {
            if (titleView != null) titleView.setVisibility(View.VISIBLE);
            if (controlsRow != null) controlsRow.setVisibility(View.VISIBLE);
            if (playerView != null) playerView.showController();
        }
        handler.postDelayed(hideTitle, 5000);
    }

    /** Tap on the screen: on movies the player's own controller toggles, so the buttons follow it. */
    private void onScreenTap() {
        if (live) {
            showPanel();
            return;
        }
        boolean willShow = !playerView.isControllerFullyVisible();
        handler.removeCallbacks(hideTitle);
        int vis = willShow ? View.VISIBLE : View.GONE;
        if (titleView != null) titleView.setVisibility(vis);
        if (controlsRow != null) controlsRow.setVisibility(vis);
        if (willShow) handler.postDelayed(hideTitle, 5000);
    }

    // ------------------------------------------------------------- remote keys

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && handleRemoteKey(event)) {
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private boolean handleRemoteKey(KeyEvent e) {
        if (player == null) return false;
        int k = e.getKeyCode();
        boolean first = e.getRepeatCount() == 0;
        if (panelVisible()) return false; // the channel list handles its own keys

        if (live) {
            int digit = digitOf(k);
            if (digit >= 0) {
                if (first) onDigit(digit);
                return true;
            }
            switch (k) {
                case KeyEvent.KEYCODE_DPAD_UP:
                case KeyEvent.KEYCODE_CHANNEL_UP:
                case KeyEvent.KEYCODE_MEDIA_NEXT:
                    if (first) zap(1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                case KeyEvent.KEYCODE_CHANNEL_DOWN:
                case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                    if (first) zap(-1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    changeVolume(true);
                    showInfo();
                    return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    changeVolume(false);
                    showInfo();
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_NUMPAD_ENTER:
                    if (typed.length() > 0) {
                        handler.removeCallbacks(commitNumber);
                        commitTypedNumber();
                    } else if (first) {
                        showPanel();
                    }
                    return true;
                default:
                    return false;
            }
        }

        switch (k) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                seekBy(-SEEK_STEP_MS);
                showInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                seekBy(SEEK_STEP_MS);
                showInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (first) {
                    togglePlay();
                    showInfo();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                player.play();
                showInfo();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                player.pause();
                showInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
                showInfo();
                return true;
            default:
                return false;
        }
    }

    private static int digitOf(int keyCode) {
        if (keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9) {
            return keyCode - KeyEvent.KEYCODE_0;
        }
        if (keyCode >= KeyEvent.KEYCODE_NUMPAD_0 && keyCode <= KeyEvent.KEYCODE_NUMPAD_9) {
            return keyCode - KeyEvent.KEYCODE_NUMPAD_0;
        }
        return -1;
    }

    private void seekBy(long deltaMs) {
        if (player == null) return;
        long pos = player.getCurrentPosition() + deltaMs;
        long dur = player.getDuration();
        if (dur > 0 && pos > dur - 1000) pos = dur - 1000;
        if (pos < 0) pos = 0;
        player.seekTo(pos);
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.getPlaybackState() == Player.STATE_ENDED) {
            player.seekTo(0);
            player.play();
        } else if (player.isPlaying()) {
            player.pause();
        } else {
            player.play();
        }
    }

    private void changeVolume(boolean up) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI);
    }

    // --------------------------------------------------------- channel flipping

    private int findQueueIndex(String channelUrl, int number) {
        List<Item> list = LiveQueue.items;
        if (channelUrl == null || list.isEmpty()) return -1;
        if (number >= 1 && number <= list.size()
                && channelUrl.equals(list.get(number - 1).streamUrl)) {
            return number - 1;
        }
        for (int i = 0; i < list.size(); i++) {
            if (channelUrl.equals(list.get(i).streamUrl)) return i;
        }
        return -1;
    }

    private void zap(int delta) {
        List<Item> list = LiveQueue.items;
        int n = list.size();
        if (queueIndex < 0 || n == 0 || queueIndex >= n) {
            showInfo();
            return;
        }
        int idx = queueIndex;
        for (int step = 0; step < n; step++) {
            idx = ((idx + delta) % n + n) % n;
            Item it = list.get(idx);
            if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                playChannel(idx);
                return;
            }
        }
    }

    private void playChannel(int idx) {
        List<Item> list = LiveQueue.items;
        if (idx < 0 || idx >= list.size() || player == null) return;
        Item it = list.get(idx);
        queueIndex = idx;
        url = it.streamUrl;
        Prefs.putString(this, "last_live_url", url == null ? "" : url);
        if (it.categoryRemoteId != null) Prefs.putString(this, "last_live_cat", it.categoryRemoteId);
        String sub = it.categoryRemoteId == null ? "" : LiveQueue.catNames.get(it.categoryRemoteId);
        updateLiveBanner(it.name, it.icon, idx + 1, sub);
        message.setText("جارٍ التحميل…");
        message.setVisibility(View.VISIBLE);
        player.setMediaItem(MediaItem.fromUri(url));
        player.prepare();
        player.play();
        showInfo();
        if (chAdapter != null) chAdapter.notifyDataSetChanged();
    }

    private void onDigit(int d) {
        if (queueIndex < 0 && LiveQueue.items.isEmpty()) return;
        if (typed.length() >= 4) typed.setLength(0);
        typed.append(d);
        numberEntry.setText(typed.toString());
        numberEntry.setVisibility(View.VISIBLE);
        handler.removeCallbacks(commitNumber);
        handler.postDelayed(commitNumber, 1600);
    }

    private void commitTypedNumber() {
        String s = typed.toString();
        typed.setLength(0);
        numberEntry.setVisibility(View.GONE);
        if (s.isEmpty()) return;
        try {
            int n = Integer.parseInt(s);
            List<Item> list = LiveQueue.items;
            if (n >= 1 && n <= list.size()) {
                Item it = list.get(n - 1);
                if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                    playChannel(n - 1);
                    return;
                }
            }
            Toast.makeText(this, "لا توجد قناة بالرقم " + n, Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException ignored) {
            // ignore
        }
    }

    private void updateLiveBanner(String name, String logo, int number, String sub) {
        if (liveTitle == null) return;
        liveTitle.setText((number > 0 ? number + "   " : "") + (name == null ? "" : name));
        boolean hasSub = sub != null && !sub.isEmpty();
        liveSub.setText(hasSub ? sub : "");
        liveSub.setVisibility(hasSub ? View.VISIBLE : View.GONE);
        loadLogo(liveIcon, logo, true);
        loadLogo(liveMark, logo, false);
    }

    private void loadLogo(ImageView target, String logo, boolean placeholder) {
        if (target == null) return;
        if (logo != null && logo.startsWith("http")) {
            target.setVisibility(View.VISIBLE);
            if (placeholder) {
                Glide.with(this).load(logo).placeholder(R.drawable.ic_live)
                        .error(R.drawable.ic_live).into(target);
            } else {
                Glide.with(this).load(logo).into(target);
            }
        } else if (placeholder) {
            Glide.with(this).clear(target);
            target.setImageResource(R.drawable.ic_live);
        } else {
            Glide.with(this).clear(target);
            target.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_MENU:
                showInfo();
                break;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (state == Player.STATE_BUFFERING) {
                message.setText("جارٍ التحميل…");
                message.setVisibility(View.VISIBLE);
            } else if (state == Player.STATE_READY) {
                message.setVisibility(View.GONE);
            }
        }

        @Override
        public void onIsPlayingChanged(boolean isPlaying) {
            if (btnPlay != null) btnPlay.setText(isPlaying ? "❚❚" : "▶");
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            message.setText("تعذر تشغيل هذا المحتوى (" + error.getErrorCodeName() + ")");
            message.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        url = getIntent().getStringExtra(EXTRA_URL);
        String name = getIntent().getStringExtra(EXTRA_TITLE);
        trackPlaylist = getIntent().getLongExtra(EXTRA_PLAYLIST, -1L);
        trackType = getIntent().getStringExtra(EXTRA_TYPE);
        trackRemote = getIntent().getStringExtra(EXTRA_REMOTE);
        trackName = getIntent().getStringExtra(EXTRA_NAME);
        trackIcon = getIntent().getStringExtra(EXTRA_ICON);
        trackEpisode = getIntent().getStringExtra(EXTRA_EPISODE);
        startPos = getIntent().getLongExtra(EXTRA_POS, 0L);
        live = getIntent().getBooleanExtra(EXTRA_LIVE, false);
        browse = getIntent().getBooleanExtra(EXTRA_BROWSE, false);
        if ((url == null || url.isEmpty()) && !browse) {
            finish();
            return;
        }
        if (Build.VERSION.SDK_INT >= 28) {
            // draw under the camera notch too, so the picture really fills the whole screen
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (live) {
            queueIndex = findQueueIndex(url, getIntent().getIntExtra(EXTRA_NUM, 0));
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        playerView = new PlayerView(this);
        playerView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        playerView.setKeepScreenOn(true);
        playerView.setUseController(!live);
        // fill the whole screen with the complete picture (nothing cropped, no black bars)
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        playerView.setFocusable(true);
        playerView.setOnClickListener(v -> onScreenTap());
        root.addView(playerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        message = new TextView(this);
        message.setTextColor(0xFFFFFFFF);
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setPadding(Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12));
        root.addView(message, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        titleView = new TextView(this);
        titleView.setText(name == null ? "" : name);
        titleView.setTextColor(0xFFFFFFFF);
        titleView.setTextSize(16);
        titleView.setBackgroundColor(0x88000000);
        titleView.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        if (live) {
            titleView.setVisibility(View.GONE);
        }
        root.addView(titleView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
        if (live) {
            buildLiveOverlay(root, name);
            buildChannelPanel(root);
        } else {
            buildVodControls(root);
        }

        setContentView(root);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), root);
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);

        handler.postDelayed(hideTitle, 5000);
        playerView.requestFocus();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (panelVisible() && !(browse && url == null)) {
                    hidePanel();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
        if (browse) {
            numberEntry.setVisibility(View.GONE);
            showPanel();
        }
    }

    /** Back / pause / forward buttons for movies and episodes (touch); the remote uses the arrow keys. */
    private void buildVodControls(FrameLayout root) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.setGravity(Gravity.CENTER);

        TextView back = vodButton("« 10");
        btnPlay = vodButton("❚❚");
        TextView fwd = vodButton("10 »");
        back.setOnClickListener(v -> {
            seekBy(-SEEK_STEP_MS);
            showInfo();
        });
        btnPlay.setOnClickListener(v -> {
            togglePlay();
            showInfo();
        });
        fwd.setOnClickListener(v -> {
            seekBy(SEEK_STEP_MS);
            showInfo();
        });
        row.addView(back, vodButtonParams());
        row.addView(btnPlay, vodButtonParams());
        row.addView(fwd, vodButtonParams());

        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        rp.bottomMargin = Ui.dp(this, 8);
        root.addView(row, rp);
        controlsRow = row;
    }

    private TextView vodButton(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(16);
        t.setTextColor(0xFFFFFFFF);
        t.setGravity(Gravity.CENTER);
        t.setBackgroundResource(R.drawable.bg_button_secondary);
        t.setClickable(true);
        t.setFocusable(false);
        return t;
    }

    private LinearLayout.LayoutParams vodButtonParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 72), Ui.dp(this, 44));
        lp.setMargins(Ui.dp(this, 6), 0, Ui.dp(this, 6), 0);
        return lp;
    }

    /** Clock (top left), channel logo (top right) and the bottom banner with number, name and group. */
    private void buildLiveOverlay(FrameLayout root, String name) {
        String logo = getIntent().getStringExtra(EXTRA_LOGO);
        int num = getIntent().getIntExtra(EXTRA_NUM, 0);
        String sub = getIntent().getStringExtra(EXTRA_SUB);

        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(0xFFE6E6E6);
        clock.setTextSize(15);
        clock.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        clock.setShadowLayer(4f, 0f, 1f, 0xFF000000);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.LEFT);
        cp.setMargins(Ui.dp(this, 28), Ui.dp(this, 14), 0, 0);
        root.addView(clock, cp);

        LinearLayout bar = new LinearLayout(this);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundResource(R.drawable.bg_player_bar);
        bar.setPadding(Ui.dp(this, 22), Ui.dp(this, 12), Ui.dp(this, 22), Ui.dp(this, 12));

        liveIcon = new ImageView(this);
        liveIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        bar.addView(liveIcon, new LinearLayout.LayoutParams(Ui.dp(this, 76), Ui.dp(this, 52)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colp.setMarginStart(Ui.dp(this, 14));
        bar.addView(col, colp);

        liveTitle = new TextView(this);
        liveTitle.setTextColor(0xFFE9EEF0);
        liveTitle.setTextSize(20);
        liveTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        liveTitle.setMaxLines(1);
        liveTitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        liveTitle.setGravity(Gravity.START);
        col.addView(liveTitle);

        liveSub = new TextView(this);
        liveSub.setTextColor(0xFF9FB4BB);
        liveSub.setTextSize(13);
        liveSub.setMaxLines(1);
        liveSub.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        liveSub.setGravity(Gravity.START);
        col.addView(liveSub);

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        bp.setMargins(Ui.dp(this, 28), 0, Ui.dp(this, 28), Ui.dp(this, 16));
        root.addView(bar, bp);
        infoBar = bar;

        // number typed on the remote, shown big at the top while it is being entered
        numberEntry = new TextView(this);
        numberEntry.setTextColor(0xFFFFFFFF);
        numberEntry.setTextSize(46);
        numberEntry.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        numberEntry.setShadowLayer(8f, 0f, 2f, 0xFF000000);
        numberEntry.setVisibility(View.GONE);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        np.topMargin = Ui.dp(this, 40);
        root.addView(numberEntry, np);

        updateLiveBanner(name, logo, num, sub);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (playerView == null) return;
        player = Players.create(this);
        player.addListener(listener);
        playerView.setPlayer(player);
        if (url == null || url.isEmpty()) {
            message.setText(browse ? "اختر قناة للمشاهدة" : "");
            message.setVisibility(browse ? View.VISIBLE : View.GONE);
            return;
        }
        message.setText("جارٍ التحميل…");
        message.setVisibility(View.VISIBLE);
        player.setMediaItem(MediaItem.fromUri(url));
        if (startPos > 0) player.seekTo(startPos);
        player.prepare();
        player.play();
    }

    @Override
    protected void onStop() {
        super.onStop();
        saveHistory();
        releasePlayer();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(hideTitle);
        handler.removeCallbacks(commitNumber);
        handler.removeCallbacks(catFocusRunnable);
        super.onDestroy();
    }

    private void saveHistory() {
        if (player == null || trackPlaylist < 0 || trackType == null || trackRemote == null) return;
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        if (pos < 5000) return;
        if (dur > 0 && pos > dur * 95 / 100) pos = 0;
        startPos = pos;
        final History h = new History();
        h.playlistId = trackPlaylist;
        h.type = trackType;
        h.remoteId = trackRemote;
        h.name = trackName == null ? "" : trackName;
        h.icon = trackIcon == null ? "" : trackIcon;
        h.episodeTitle = trackEpisode == null ? "" : trackEpisode;
        h.streamUrl = url;
        h.positionMs = pos;
        h.updatedAt = System.currentTimeMillis();
        final Context app = getApplicationContext();
        Async.io(() -> {
            UserDatabase.get(app).dao().putHistory(h);
            // watching a series again brings it back to "series I follow"
            if ("series".equals(h.type)
                    && Prefs.getCompleted(app, h.playlistId).contains(h.remoteId)) {
                Prefs.setCompleted(app, h.playlistId, h.remoteId, false);
            }
        });
    }

    private void releasePlayer() {
        if (player != null && playerView != null) {
            player.removeListener(listener);
            playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }

    // ------------------------------------------------- channel list (OK on the remote / tap)

    private FrameLayout panel;
    private RecyclerView catView;
    private RecyclerView chView;
    private final List<Category> cats = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private final Map<String, String> catNames = new HashMap<>();
    private final CatAdapter catAdapter = new CatAdapter();
    private final ChAdapter chAdapter = new ChAdapter();
    private int selCat = -1;
    private int panelToken;
    private long panelPid = -1;
    private boolean catsLoaded;
    private boolean loadingCats;
    private boolean focusAfter;
    private int pendingFocusCat = -1;

    private final Runnable catFocusRunnable = new Runnable() {
        @Override
        public void run() {
            if (pendingFocusCat >= 0 && pendingFocusCat != selCat) selectCat(pendingFocusCat, false);
        }
    };

    private boolean panelVisible() {
        return panel != null && panel.getVisibility() == View.VISIBLE;
    }

    /** Categories on the left, numbered channels next to them; the video stays visible on the right. */
    private void buildChannelPanel(FrameLayout root) {
        panel = new FrameLayout(this);
        panel.setVisibility(View.GONE);
        panel.setClickable(true);
        panel.setOnClickListener(v -> hidePanel());

        int screenW = getResources().getDisplayMetrics().widthPixels;
        LinearLayout lists = new LinearLayout(this);
        lists.setOrientation(LinearLayout.HORIZONTAL);
        lists.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);

        catView = new RecyclerView(this);
        catView.setLayoutManager(new LinearLayoutManager(this));
        catView.setAdapter(catAdapter);
        catView.setItemAnimator(null);
        catView.setBackgroundColor(0xCC0B141B);
        lists.addView(catView, new LinearLayout.LayoutParams((int) (screenW * 0.34f),
                ViewGroup.LayoutParams.MATCH_PARENT));

        View line = new View(this);
        line.setBackgroundColor(0x44FFFFFF);
        lists.addView(line, new LinearLayout.LayoutParams(Ui.dp(this, 1), ViewGroup.LayoutParams.MATCH_PARENT));

        chView = new RecyclerView(this);
        chView.setLayoutManager(new LinearLayoutManager(this));
        chView.setAdapter(chAdapter);
        chView.setItemAnimator(null);
        chView.setBackgroundColor(0xCC0B141B);
        lists.addView(chView, new LinearLayout.LayoutParams((int) (screenW * 0.30f),
                ViewGroup.LayoutParams.MATCH_PARENT));

        panel.addView(lists, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.START));
        root.addView(panel, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void showPanel() {
        if (panel == null) return;
        handler.removeCallbacks(hideTitle);
        if (infoBar != null) infoBar.setVisibility(View.GONE);
        panel.setVisibility(View.VISIBLE);
        if (!catsLoaded) {
            loadCats();
        } else {
            focusCurrent();
        }
    }

    private void hidePanel() {
        if (panel == null) return;
        handler.removeCallbacks(catFocusRunnable);
        panel.setVisibility(View.GONE);
        if (playerView != null) playerView.requestFocus();
        showInfo();
    }

    private int currentShownIndex() {
        if (url == null) return -1;
        for (int i = 0; i < shown.size(); i++) {
            if (url.equals(shown.get(i).streamUrl)) return i;
        }
        return -1;
    }

    private void focusCurrent() {
        if (chView == null || shown.isEmpty()) return;
        int idx = currentShownIndex();
        final int target = idx >= 0 ? idx : 0;
        chView.scrollToPosition(target);
        chView.post(() -> {
            RecyclerView.ViewHolder vh = chView.findViewHolderForAdapterPosition(target);
            if (vh != null) vh.itemView.requestFocus();
            else chView.requestFocus();
        });
    }

    private void loadCats() {
        if (loadingCats) return;
        loadingCats = true;
        final Context app = getApplicationContext();
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            UserDao ud = UserDatabase.get(app).dao();
            long pid = Prefs.getActive(app);
            Playlist p = pid < 0 ? null : dao.getPlaylist(pid);
            final List<Category> list = new ArrayList<>();
            final Map<String, String> names = new HashMap<>();
            if (p != null) {
                Category fav = new Category();
                fav.name = "★ المفضلة";
                fav.remoteId = FAV_ID;
                list.add(fav);
                Category all = new Category();
                all.name = "الكل";
                all.remoteId = null;
                list.add(all);
                List<Category> real = dao.getCategories(p.id, "live");
                real = applyOrder(real, ud.getOrder(p.id, "cat:live"), new KeyFn<Category>() {
                    @Override
                    public String key(Category c) {
                        return c.remoteId == null ? "" : c.remoteId;
                    }
                });
                list.addAll(real);
                for (Category rc : real) {
                    if (rc.remoteId != null) names.put(rc.remoteId, rc.name == null ? "" : rc.name);
                }
            }
            final long fid = p == null ? -1 : p.id;
            Async.main(() -> {
                loadingCats = false;
                if (isFinishing() || isDestroyed()) return;
                if (fid < 0 || list.size() <= SPECIAL) {
                    Toast.makeText(PlayerActivity.this,
                            "لا توجد قنوات. أضف حساباً من القائمة الرئيسية", Toast.LENGTH_LONG).show();
                    if (browse && (url == null || url.isEmpty())) finish();
                    return;
                }
                panelPid = fid;
                cats.clear();
                cats.addAll(list);
                catNames.clear();
                catNames.putAll(names);
                catsLoaded = true;
                selCat = -1;
                catAdapter.notifyDataSetChanged();

                // open on the group of the channel being watched (or the last one watched)
                String want = "";
                List<Item> q = LiveQueue.items;
                if (queueIndex >= 0 && queueIndex < q.size() && q.get(queueIndex).categoryRemoteId != null) {
                    want = q.get(queueIndex).categoryRemoteId;
                } else if (browse) {
                    want = Prefs.getString(PlayerActivity.this, "last_live_cat");
                }
                int start = SPECIAL;
                if (!want.isEmpty()) {
                    for (int i = SPECIAL; i < cats.size(); i++) {
                        if (want.equals(cats.get(i).remoteId)) {
                            start = i;
                            break;
                        }
                    }
                }
                focusAfter = true;
                selectCat(start, true);
            });
        });
    }

    private void selectCat(int pos, final boolean initial) {
        if (pos < 0 || pos >= cats.size()) return;
        int old = selCat;
        selCat = pos;
        if (old >= 0) catAdapter.notifyItemChanged(old);
        catAdapter.notifyItemChanged(pos);
        final Category cat = cats.get(pos);
        final int token = ++panelToken;
        final long pid = panelPid;
        final Context app = getApplicationContext();
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            UserDao ud = UserDatabase.get(app).dao();
            List<Item> list;
            if (FAV_ID.equals(cat.remoteId)) {
                list = new ArrayList<>();
                for (Favorite f : ud.favoritesOfType(pid, "live", 2000)) {
                    Item it = new Item();
                    it.id = 2000000000L + f.id;
                    it.playlistId = pid;
                    it.type = "live";
                    it.remoteId = f.remoteId;
                    it.name = f.name;
                    it.icon = f.icon;
                    it.streamUrl = f.streamUrl;
                    it.rating = "";
                    it.year = "";
                    list.add(it);
                }
            } else if (cat.remoteId == null) {
                list = dao.itemsAll(pid, "live", 20000);
            } else {
                list = dao.itemsInCategory(pid, "live", cat.remoteId);
                list = applyOrder(list, ud.getOrder(pid, "items:live:" + cat.remoteId),
                        new KeyFn<Item>() {
                            @Override
                            public String key(Item i) {
                                return (i.streamUrl != null && !i.streamUrl.isEmpty())
                                        ? i.streamUrl : String.valueOf(i.remoteId);
                            }
                        });
            }
            final List<Item> result = list;
            Async.main(() -> {
                if (isFinishing() || isDestroyed() || token != panelToken) return;
                shown.clear();
                shown.addAll(result);
                chAdapter.notifyDataSetChanged();
                chView.scrollToPosition(0);
                if (initial && browse && (url == null || url.isEmpty()) && player != null) {
                    // opened from "القنوات": start with the last channel watched, else the first one
                    String last = Prefs.getString(PlayerActivity.this, "last_live_url");
                    int idx = -1;
                    for (int i = 0; i < shown.size(); i++) {
                        String u = shown.get(i).streamUrl;
                        if (u == null || u.isEmpty()) continue;
                        if (idx < 0) idx = i;
                        if (u.equals(last)) {
                            idx = i;
                            break;
                        }
                    }
                    if (idx >= 0) {
                        LiveQueue.set(shown, catNames);
                        queueIndex = idx;
                        playChannel(idx);
                    }
                }
                if (focusAfter && panelVisible()) {
                    focusAfter = false;
                    focusCurrent();
                }
            });
        });
    }

    private void pickChannel(int pos) {
        if (pos < 0 || pos >= shown.size()) return;
        Item it = shown.get(pos);
        if (it.streamUrl == null || it.streamUrl.isEmpty()) {
            Toast.makeText(this, "لا يوجد رابط تشغيل لهذه القناة", Toast.LENGTH_SHORT).show();
            return;
        }
        LiveQueue.set(shown, catNames);
        queueIndex = pos;
        playChannel(pos);
        hidePanel();
    }

    private interface KeyFn<T> {
        String key(T t);
    }

    /** Sorts by the saved order; anything not in it keeps the provider order after the saved ones. */
    private static <T> List<T> applyOrder(List<T> list, String json, final KeyFn<T> fn) {
        if (json == null || json.isEmpty() || list.size() < 2) return list;
        final Map<String, Integer> rank = new HashMap<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                String k = arr.optString(i);
                if (!rank.containsKey(k)) rank.put(k, i);
            }
        } catch (Exception e) {
            return list;
        }
        List<T> copy = new ArrayList<>(list);
        Collections.sort(copy, new Comparator<T>() {
            @Override
            public int compare(T a, T b) {
                Integer ra = rank.get(fn.key(a));
                Integer rb = rank.get(fn.key(b));
                return Integer.compare(ra == null ? Integer.MAX_VALUE : ra,
                        rb == null ? Integer.MAX_VALUE : rb);
            }
        });
        return copy;
    }

    private static class RowVH extends RecyclerView.ViewHolder {
        final TextView num;
        final TextView name;
        final ImageView logo;

        RowVH(@NonNull View v, TextView num, TextView name, ImageView logo) {
            super(v);
            this.num = num;
            this.name = name;
            this.logo = logo;
        }
    }

    private RowVH createRow(boolean withLogo) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 8), 0, Ui.dp(this, 8), 0);
        row.setBackgroundResource(R.drawable.bg_row);
        row.setFocusable(true);
        row.setClickable(true);
        row.setLayoutParams(new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, withLogo ? 34 : 32)));

        TextView num = new TextView(this);
        num.setTextColor(0xFFE3E9EC);
        num.setTextSize(13);
        row.addView(num, new LinearLayout.LayoutParams(Ui.dp(this, withLogo ? 34 : 26),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        ImageView logo = null;
        if (withLogo) {
            logo = new ImageView(this);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 26));
            lp.setMarginEnd(Ui.dp(this, 6));
            row.addView(logo, lp);
        }

        TextView name = new TextView(this);
        name.setTextColor(0xFFFFFFFF);
        name.setTextSize(13);
        name.setMaxLines(1);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        // channels read from the left (next to the logo), categories hug the right edge
        name.setGravity((withLogo ? Gravity.START : Gravity.END) | Gravity.CENTER_VERTICAL);
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        return new RowVH(row, num, name, logo);
    }

    private class CatAdapter extends RecyclerView.Adapter<RowVH> {
        @NonNull
        @Override
        public RowVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return createRow(false);
        }

        @Override
        public void onBindViewHolder(@NonNull RowVH h, int position) {
            Category c = cats.get(position);
            h.num.setText(String.format(java.util.Locale.US, "%02d", position + 1));
            h.name.setText(c.name == null ? "" : c.name);
            h.itemView.setSelected(position == selCat);
            h.itemView.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p == RecyclerView.NO_POSITION) return;
                handler.removeCallbacks(catFocusRunnable);
                focusAfter = true;
                selectCat(p, false);
            });
            h.itemView.setOnFocusChangeListener((v, has) -> {
                if (!has) return;
                int p = h.getBindingAdapterPosition();
                if (p == RecyclerView.NO_POSITION) return;
                pendingFocusCat = p;
                handler.removeCallbacks(catFocusRunnable);
                handler.postDelayed(catFocusRunnable, 250);
            });
        }

        @Override
        public int getItemCount() {
            return cats.size();
        }
    }

    private class ChAdapter extends RecyclerView.Adapter<RowVH> {
        @NonNull
        @Override
        public RowVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return createRow(true);
        }

        @Override
        public void onBindViewHolder(@NonNull RowVH h, int position) {
            final Item it = shown.get(position);
            h.num.setText(String.format(java.util.Locale.US, "%03d", position + 1));
            h.name.setText(it.name == null ? "" : it.name);
            loadLogo(h.logo, it.icon, true);
            h.itemView.setSelected(url != null && url.equals(it.streamUrl));
            h.itemView.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) pickChannel(p);
            });
        }

        @Override
        public int getItemCount() {
            return shown.size();
        }
    }
}
