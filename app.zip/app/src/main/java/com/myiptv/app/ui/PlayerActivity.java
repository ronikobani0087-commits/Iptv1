package com.myiptv.app.ui;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.data.AppDao;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Category;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.LiveQueue;
import com.myiptv.app.util.Players;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import org.json.JSONArray;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Full screen video player.
 * Remote control: on live channels UP / DOWN (or CH+ / CH-) flip channels, LEFT / RIGHT change the
 * volume and the number keys jump to a channel number. On movies and episodes LEFT / RIGHT seek
 * and OK pauses / resumes.
 */
public class PlayerActivity extends AppCompatActivity {
    private static final String EXTRA_URL = "url";
    private static final String EXTRA_TITLE = "title";
    private static final String EXTRA_PLAYLIST = "playlist";
    private static final String EXTRA_TYPE = "type";
    private static final String EXTRA_REMOTE = "remote";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_ICON = "icon";
    private static final String EXTRA_EPISODE = "episode";
    private static final String EXTRA_POS = "pos";
    private static final String EXTRA_LIVE = "live";
    private static final String EXTRA_LOGO = "logo";
    private static final String EXTRA_NUM = "num";
    private static final String EXTRA_SUB = "sub";
    private static final String EXTRA_BROWSE = "browse";
    private static final String FAV_ID = "\u0000fav";
    private static final int SPECIAL = 2;

    private static final long SEEK_STEP_MS = 15000L;

    public static void start(Context context, String url, String title) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        context.startActivity(i);
    }

    /** Opens live TV straight in the player: last (or first) channel plays and the channel list is shown. */
    public static void startBrowse(Context context) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_LIVE, true);
        i.putExtra(EXTRA_BROWSE, true);
        context.startActivity(i);
    }

    /** Plays a live channel and shows the channel banner (logo, number, name, group). */
    public static void startLive(Context context, String url, String title, String logo,
                                 int number, String subtitle) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_LIVE, true);
        i.putExtra(EXTRA_LOGO, logo);
        i.putExtra(EXTRA_NUM, number);
        i.putExtra(EXTRA_SUB, subtitle);
        context.startActivity(i);
    }

    /** Plays a series episode and remembers where the user stopped (for "series I follow"). */
    public static void startTracked(Context context, String url, String title, long playlistId,
                                    String type, String remoteId, String name, String icon,
                                    String episode, long positionMs) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_PLAYLIST, playlistId);
        i.putExtra(EXTRA_TYPE, type);
        i.putExtra(EXTRA_REMOTE, remoteId);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_ICON, icon);
        i.putExtra(EXTRA_EPISODE, episode);
        i.putExtra(EXTRA_POS, positionMs);
        context.startActivity(i);
    }

    private long trackPlaylist = -1;
    private String trackType, trackRemote, trackName, trackIcon, trackEpisode;
    private long startPos;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PlayerView playerView;
    private TextView message;
    private TextView titleView;
    private View infoBar;
    private View controlsRow;
    private ImageView btnPlay, btnRew, btnFwd;
    private View btnResize, btnTracks;
    private SeekBar seekBar;
    private TextView timeNow, timeTotal;
    private boolean seeking;
    private int resizeIdx = 1; // 0 = original ratio, 1 = fill the screen, 2 = zoom
    private static final int[] RESIZE_MODES = {
            AspectRatioFrameLayout.RESIZE_MODE_FIT,
            AspectRatioFrameLayout.RESIZE_MODE_FILL,
            AspectRatioFrameLayout.RESIZE_MODE_ZOOM};
    private static final String[] RESIZE_NAMES = {"الحجم الأصلي", "ملء الشاشة", "تكبير"};
    private boolean live;
    private ExoPlayer player;
    private String url;

    // live banner views, updated when the channel changes
    private TextView liveTitle;
    private TextView liveSub;
    private ImageView liveIcon;
    private ImageView liveMark;
    private TextView numberEntry;
    private int queueIndex = -1;
    private boolean browse;
    private final StringBuilder typed = new StringBuilder();

    private final Runnable hideTitle = new Runnable() {
        @Override
        public void run() {
            if (titleView != null) titleView.setVisibility(View.GONE);
            if (infoBar != null) infoBar.setVisibility(View.GONE);
            if (controlsRow != null) controlsRow.setVisibility(View.GONE);
            if (!live && playerView != null) playerView.requestFocus();
        }
    };

    /** Movie / episode bar stays 10 seconds; the live banner 5. */
    private long hideDelay() {
        return live ? 5000 : 10000;
    }

    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            updateProgress();
            if (controlsRow != null && controlsRow.getVisibility() == View.VISIBLE) {
                handler.postDelayed(this, 500);
            }
        }
    };

    private static String fmt(long ms) {
        long t = Math.max(0, ms) / 1000;
        long h = t / 3600, m = (t % 3600) / 60, sec = t % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
                : String.format(java.util.Locale.US, "%02d:%02d", m, sec);
    }

    private void updateProgress() {
        if (player == null || seekBar == null || seeking) return;
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        timeNow.setText(fmt(pos));
        if (dur > 0) {
            timeTotal.setText(fmt(dur));
            seekBar.setProgress((int) (pos * 1000 / dur));
            seekBar.setSecondaryProgress(player.getBufferedPercentage() * 10);
        } else {
            timeTotal.setText("--:--");
        }
    }

    private final Runnable commitNumber = new Runnable() {
        @Override
        public void run() {
            commitTypedNumber();
        }
    };

    private void showInfo() {
        if (panelVisible()) return;
        handler.removeCallbacks(hideTitle);
        if (live) {
            if (infoBar != null) infoBar.setVisibility(View.VISIBLE);
        } else {
            if (controlsRow != null) controlsRow.setVisibility(View.VISIBLE);
            handler.removeCallbacks(tick);
            handler.post(tick);
        }
        handler.postDelayed(hideTitle, hideDelay());
    }

    /** Tap on the screen: on movies the player's own controller toggles, so the buttons follow it. */
    private void onScreenTap() {
        if (live) {
            showPanel();
            return;
        }
        boolean willShow = controlsRow != null && controlsRow.getVisibility() != View.VISIBLE;
        handler.removeCallbacks(hideTitle);
        int vis = willShow ? View.VISIBLE : View.GONE;
        if (controlsRow != null) controlsRow.setVisibility(vis);
        if (willShow) {
            handler.removeCallbacks(tick);
            handler.post(tick);
            handler.postDelayed(hideTitle, hideDelay());
        } else {
            playerView.requestFocus();
        }
    }

    // ------------------------------------------------------------- remote keys

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && handleRemoteKey(event)) {
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    private boolean handleRemoteKey(KeyEvent e) {
        if (player == null) return false;
        int k = e.getKeyCode();
        boolean first = e.getRepeatCount() == 0;
        if (panelVisible()) return false; // the channel list handles its own keys

        if (live) {
            int digit = digitOf(k);
            if (digit >= 0) {
                if (first) onDigit(digit);
                return true;
            }
            switch (k) {
                case KeyEvent.KEYCODE_DPAD_UP:
                case KeyEvent.KEYCODE_CHANNEL_UP:
                case KeyEvent.KEYCODE_MEDIA_NEXT:
                    if (first) zap(1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_DOWN:
                case KeyEvent.KEYCODE_CHANNEL_DOWN:
                case KeyEvent.KEYCODE_MEDIA_PREVIOUS:
                    if (first) zap(-1);
                    return true;
                case KeyEvent.KEYCODE_DPAD_RIGHT:
                    changeVolume(true);
                    showInfo();
                    return true;
                case KeyEvent.KEYCODE_DPAD_LEFT:
                    changeVolume(false);
                    showInfo();
                    return true;
                case KeyEvent.KEYCODE_DPAD_CENTER:
                case KeyEvent.KEYCODE_ENTER:
                case KeyEvent.KEYCODE_NUMPAD_ENTER:
                    if (typed.length() > 0) {
                        handler.removeCallbacks(commitNumber);
                        commitTypedNumber();
                    } else if (first) {
                        showPanel();
                    }
                    return true;
                default:
                    return false;
            }
        }

        // focus on back / pause / forward: arrows move between them, OK presses, UP leaves, DOWN to the tools
        View focus = getCurrentFocus();
        if (focus != null && (focus == btnRew || focus == btnPlay || focus == btnFwd)) {
            if (k == KeyEvent.KEYCODE_DPAD_UP) {
                playerView.requestFocus();
                showInfo();
                return true;
            }
            if (k == KeyEvent.KEYCODE_DPAD_DOWN) {
                if (btnResize != null) btnResize.requestFocus();
                showInfo();
                return true;
            }
            if (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT
                    || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER
                    || k == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                showInfo();
                return false;
            }
        }
        // focus is on the resize / subtitle buttons: arrows move between them, OK presses, UP leaves
        if (focus != null && (focus == btnResize || focus == btnTracks)) {
            if (k == KeyEvent.KEYCODE_DPAD_UP) {
                playerView.requestFocus();
                showInfo();
                return true;
            }
            if (k == KeyEvent.KEYCODE_DPAD_DOWN) return true;
            if (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT
                    || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER
                    || k == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                showInfo();
                return false;
            }
        }

        switch (k) {
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_MEDIA_REWIND:
                seekBy(-SEEK_STEP_MS);
                showInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_MEDIA_FAST_FORWARD:
                seekBy(SEEK_STEP_MS);
                showInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER:
            case KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE:
                if (first) {
                    togglePlay();
                    showInfo();
                }
                return true;
            case KeyEvent.KEYCODE_MEDIA_PLAY:
                player.play();
                showInfo();
                return true;
            case KeyEvent.KEYCODE_MEDIA_PAUSE:
                player.pause();
                showInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_DOWN:
                // bar already on screen: DOWN moves to the back / pause / forward buttons
                if (controlsRow != null && controlsRow.getVisibility() == View.VISIBLE
                        && btnPlay != null) {
                    btnPlay.requestFocus();
                }
                showInfo();
                return true;
            case KeyEvent.KEYCODE_DPAD_UP:
                showInfo();
                return true;
            default:
                return false;
        }
    }

    private static int digitOf(int keyCode) {
        if (keyCode >= KeyEvent.KEYCODE_0 && keyCode <= KeyEvent.KEYCODE_9) {
            return keyCode - KeyEvent.KEYCODE_0;
        }
        if (keyCode >= KeyEvent.KEYCODE_NUMPAD_0 && keyCode <= KeyEvent.KEYCODE_NUMPAD_9) {
            return keyCode - KeyEvent.KEYCODE_NUMPAD_0;
        }
        return -1;
    }

    private void seekBy(long deltaMs) {
        if (player == null) return;
        long pos = player.getCurrentPosition() + deltaMs;
        long dur = player.getDuration();
        if (dur > 0 && pos > dur - 1000) pos = dur - 1000;
        if (pos < 0) pos = 0;
        player.seekTo(pos);
    }

    /** Pause icon while playing; a RED play icon while the user has paused. */
    private void updatePlayIcon() {
        if (btnPlay == null || player == null) return;
        if (!player.getPlayWhenReady()) btnPlay.setImageResource(R.drawable.ic_vod_play_red);
        else btnPlay.setImageResource(R.drawable.ic_vod_pause);
    }

    private void togglePlay() {
        if (player == null) return;
        if (player.getPlaybackState() == Player.STATE_ENDED) {
            player.seekTo(0);
            player.play();
        } else if (player.isPlaying()) {
            player.pause();
        } else {
            player.play();
        }
    }

    private void changeVolume(boolean up) {
        AudioManager am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        if (am == null) return;
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC,
                up ? AudioManager.ADJUST_RAISE : AudioManager.ADJUST_LOWER,
                AudioManager.FLAG_SHOW_UI);
    }

    // --------------------------------------------------------- channel flipping

    private int findQueueIndex(String channelUrl, int number) {
        List<Item> list = LiveQueue.items;
        if (channelUrl == null || list.isEmpty()) return -1;
        if (number >= 1 && number <= list.size()
                && channelUrl.equals(list.get(number - 1).streamUrl)) {
            return number - 1;
        }
        for (int i = 0; i < list.size(); i++) {
            if (channelUrl.equals(list.get(i).streamUrl)) return i;
        }
        return -1;
    }

    private void zap(int delta) {
        List<Item> list = LiveQueue.items;
        int n = list.size();
        if (queueIndex < 0 || n == 0 || queueIndex >= n) {
            showInfo();
            return;
        }
        int idx = queueIndex;
        for (int step = 0; step < n; step++) {
            idx = ((idx + delta) % n + n) % n;
            Item it = list.get(idx);
            if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                playChannel(idx);
                return;
            }
        }
    }

    private String zapUrl;
    private final Runnable zapLoad = new Runnable() {
        @Override
        public void run() {
            if (player == null || zapUrl == null) return;
            player.setMediaItem(Players.liveItem(zapUrl), true);
            player.prepare();
            player.play();
        }
    };

    private void playChannel(int idx) {
        List<Item> list = LiveQueue.items;
        if (idx < 0 || idx >= list.size() || player == null) return;
        Item it = list.get(idx);
        queueIndex = idx;
        url = it.streamUrl;
        Prefs.putString(this, "last_live_url", url == null ? "" : url);
        if (it.categoryRemoteId != null) Prefs.putString(this, "last_live_cat", it.categoryRemoteId);
        String sub = it.categoryRemoteId == null ? "" : LiveQueue.catNames.get(it.categoryRemoteId);
        Prefs.putString(this, "last_live_name", it.name == null ? "" : it.name);
        Prefs.putString(this, "last_live_icon", it.icon == null ? "" : it.icon);
        Prefs.putString(this, "last_live_sub", sub == null ? "" : sub);
        Prefs.putString(this, "last_live_num", String.valueOf(idx + 1));
        updateLiveBanner(it.name, it.icon, idx + 1, sub);
        message.setVisibility(View.GONE);   // no "loading" text: the last picture / black screen stays
        retryCount = 0;
        everPlayed = false;
        handler.removeCallbacks(reconnectRun);
        handler.removeCallbacks(stallRun);
        // banner updates at once; the stream itself starts after a tiny pause so that holding / tapping
        // CH+/CH- quickly never opens (and wastes a provider connection on) every channel in between
        handler.removeCallbacks(zapLoad);
        zapUrl = url;
        handler.postDelayed(zapLoad, 100);
        showInfo();
        if (chAdapter != null && panelVisible()) chAdapter.notifyDataSetChanged();
    }

    private void onDigit(int d) {
        if (queueIndex < 0 && LiveQueue.items.isEmpty()) return;
        if (typed.length() >= 4) typed.setLength(0);
        typed.append(d);
        numberEntry.setText(typed.toString());
        numberEntry.setVisibility(View.VISIBLE);
        handler.removeCallbacks(commitNumber);
        handler.postDelayed(commitNumber, 1600);
    }

    private void commitTypedNumber() {
        String s = typed.toString();
        typed.setLength(0);
        numberEntry.setVisibility(View.GONE);
        if (s.isEmpty()) return;
        try {
            int n = Integer.parseInt(s);
            List<Item> list = LiveQueue.items;
            if (n >= 1 && n <= list.size()) {
                Item it = list.get(n - 1);
                if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                    playChannel(n - 1);
                    return;
                }
            }
            Toast.makeText(this, "لا توجد قناة بالرقم " + n, Toast.LENGTH_SHORT).show();
        } catch (NumberFormatException ignored) {
            // ignore
        }
    }

    private void updateLiveBanner(String name, String logo, int number, String sub) {
        if (liveTitle == null) return;
        liveTitle.setText((number > 0 ? number + "   " : "") + (name == null ? "" : name));
        boolean hasSub = sub != null && !sub.isEmpty();
        liveSub.setText(hasSub ? sub : "");
        liveSub.setVisibility(hasSub ? View.VISIBLE : View.GONE);
        String shown = logo;
        if (!Ui.validLogo(shown)) {
            String ext = com.myiptv.app.util.ExternalLogos.lookup(name);
            if (ext != null) shown = ext;
        }
        loadLogo(liveIcon, shown, true);
        loadLogo(liveMark, shown, false);
    }

    /** Channel logo; when the provider gives none (or it fails) the package logo is shown instead. */
    private void loadLogoWithFallback(ImageView target, String logo, String pkgLogo) {
        if (target == null) return;
        boolean hasLogo = logo != null && logo.startsWith("http");
        boolean hasPkg = pkgLogo != null && pkgLogo.startsWith("http");
        if (!hasLogo) {
            loadLogo(target, hasPkg ? pkgLogo : null, true);
            return;
        }
        target.setVisibility(View.VISIBLE);
        if (hasPkg) {
            Glide.with(this).load(logo).placeholder(android.R.color.transparent)
                    .error(Glide.with(this).load(pkgLogo).error(android.R.color.transparent)).into(target);
        } else {
            loadLogo(target, logo, true);
        }
    }

    /**
     * Logo of a list row: the channel logo, else the package logo. When there is none the slot stays
     * empty (invisible, so the columns keep their place) instead of showing a placeholder icon.
     */
    private void loadListLogo(ImageView target, String logo, String pkgLogo, boolean keep) {
        if (target == null) return;
        // MBC / beIN keep the generic icon when they have no logo of their own
        final int blank = android.R.color.transparent;   // never the TV icon
        String first = Ui.validLogo(logo) ? logo : (Ui.validLogo(pkgLogo) ? pkgLogo : null);
        if (first == null) {
            Glide.with(this).clear(target);
            target.setImageDrawable(null);
            target.setVisibility(View.INVISIBLE);
            return;
        }
        target.setVisibility(View.VISIBLE);
        if (first.equals(logo) && Ui.validLogo(pkgLogo) && !pkgLogo.equals(logo)) {
            Glide.with(this).load(logo).placeholder(blank)
                    .error(Glide.with(this).load(pkgLogo).error(blank)).into(target);
        } else {
            Glide.with(this).load(first).placeholder(blank).error(blank).into(target);
        }
    }

    private void loadLogo(ImageView target, String logo, boolean placeholder) {
        if (target == null) return;
        if (logo != null && logo.startsWith("http")) {
            target.setVisibility(View.VISIBLE);
            if (placeholder) {
                Glide.with(this).load(logo).placeholder(android.R.color.transparent)
                        .error(android.R.color.transparent).into(target);
            } else {
                Glide.with(this).load(logo).into(target);
            }
        } else if (placeholder) {
            Glide.with(this).clear(target);
            target.setImageDrawable(null);
        } else {
            Glide.with(this).clear(target);
            target.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_MENU:
                showInfo();
                break;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    // ------------------------------------------------- auto reconnect (weak net / provider drops)

    private int retryCount;
    private boolean everPlayed;
    private android.net.ConnectivityManager.NetworkCallback netCallback;

    /** Live channels retry forever; a movie / episode keeps its position and retries a few times. */
    private boolean isLiveMode() {
        return live || browse || queueIndex >= 0;
    }

    private final Runnable reconnectRun = new Runnable() {
        @Override
        public void run() {
            reconnect();
        }
    };

    /** Nothing but buffering for too long: the stream is dead even if no error was reported. */
    private final Runnable stallRun = new Runnable() {
        @Override
        public void run() {
            if (player == null || player.getPlaybackState() != Player.STATE_BUFFERING) return;
            retryCount++;
            message.setText("الشبكة ضعيفة… إعادة الاتصال (" + retryCount + ")");
            message.setVisibility(View.VISIBLE);
            reconnect();
        }
    };

    private void reconnect() {
        if (player == null || url == null || url.isEmpty()) return;
        handler.removeCallbacks(reconnectRun);
        handler.removeCallbacks(stallRun);
        boolean liveNow = isLiveMode();
        long pos = liveNow ? 0L : Math.max(player.getCurrentPosition(), startPos);
        player.setMediaItem(liveNow ? Players.liveItem(url) : MediaItem.fromUri(url));
        if (pos > 0) player.seekTo(pos);
        player.prepare();
        player.play();
    }

    /** Retries as soon as possible: 0.3s, then 1s, 2s, 3s, then every 4s. */
    private void scheduleReconnect(boolean immediate) {
        handler.removeCallbacks(reconnectRun);
        long delay = immediate || retryCount <= 1 ? 300L : Math.min(4000L, 1000L * (retryCount - 1));
        handler.postDelayed(reconnectRun, delay);
    }

    private void registerNetworkWatcher() {
        if (netCallback != null) return;
        try {
            final android.net.ConnectivityManager cm = (android.net.ConnectivityManager)
                    getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return;
            netCallback = new android.net.ConnectivityManager.NetworkCallback() {
                @Override
                public void onAvailable(android.net.Network network) {
                    // internet came back: don't wait for the next timed retry
                    handler.post(() -> {
                        if (player == null) return;
                        int st = player.getPlaybackState();
                        if (st == Player.STATE_BUFFERING || st == Player.STATE_IDLE) {
                            retryCount = Math.max(retryCount, 1);
                            scheduleReconnect(true);
                        }
                    });
                }
            };
            cm.registerNetworkCallback(new android.net.NetworkRequest.Builder()
                    .addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET).build(), netCallback);
        } catch (Exception ignored) {
            netCallback = null;
        }
    }

    private void unregisterNetworkWatcher() {
        if (netCallback == null) return;
        try {
            android.net.ConnectivityManager cm = (android.net.ConnectivityManager)
                    getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm != null) cm.unregisterNetworkCallback(netCallback);
        } catch (Exception ignored) {
            // already unregistered
        }
        netCallback = null;
    }

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            handler.removeCallbacks(stallRun);
            if (state == Player.STATE_BUFFERING) {
                message.setVisibility(retryCount == 0 ? View.GONE : View.VISIBLE);
                // first load: 9s, a stall while watching: 7s (movies get longer: seeking is slow)
                handler.postDelayed(stallRun, isLiveMode() ? (everPlayed ? 6000L : 8000L) : 25000L);
            } else if (state == Player.STATE_READY) {
                everPlayed = true;
                retryCount = 0;
                message.setVisibility(View.GONE);
            } else if (state == Player.STATE_ENDED && isLiveMode()) {
                // a live stream never really ends: the provider dropped it
                retryCount++;
                message.setText("انقطع البث… إعادة الاتصال");
                message.setVisibility(View.VISIBLE);
                scheduleReconnect(false);
            }
        }

        @Override
        public void onIsPlayingChanged(boolean isPlaying) {
            updatePlayIcon();
        }

        @Override
        public void onPlayWhenReadyChanged(boolean playWhenReady, int reason) {
            updatePlayIcon();
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            retryCount++;
            if (!isLiveMode() && retryCount > 4) {
                message.setText("تعذر تشغيل هذا المحتوى (" + error.getErrorCodeName() + ")");
                message.setVisibility(View.VISIBLE);
                return;
            }
            message.setText("انقطع البث… إعادة الاتصال تلقائياً (" + retryCount + ")");
            message.setVisibility(View.VISIBLE);
            scheduleReconnect(error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        url = getIntent().getStringExtra(EXTRA_URL);
        String name = getIntent().getStringExtra(EXTRA_TITLE);
        trackPlaylist = getIntent().getLongExtra(EXTRA_PLAYLIST, -1L);
        trackType = getIntent().getStringExtra(EXTRA_TYPE);
        trackRemote = getIntent().getStringExtra(EXTRA_REMOTE);
        trackName = getIntent().getStringExtra(EXTRA_NAME);
        trackIcon = getIntent().getStringExtra(EXTRA_ICON);
        trackEpisode = getIntent().getStringExtra(EXTRA_EPISODE);
        startPos = getIntent().getLongExtra(EXTRA_POS, 0L);
        live = getIntent().getBooleanExtra(EXTRA_LIVE, false);
        browse = getIntent().getBooleanExtra(EXTRA_BROWSE, false);
        if (browse && (url == null || url.isEmpty())) {
            // opened from "القنوات": the last channel plays at once, the list loads in the background
            String lastUrl = Prefs.getString(this, "last_live_url");
            if (!lastUrl.isEmpty()) {
                url = lastUrl;
                name = Prefs.getString(this, "last_live_name");
            }
        }
        if ((url == null || url.isEmpty()) && !browse) {
            finish();
            return;
        }
        if (Build.VERSION.SDK_INT >= 28) {
            // draw under the camera notch too, so the picture really fills the whole screen
            getWindow().getAttributes().layoutInDisplayCutoutMode =
                    android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        if (live) {
            queueIndex = findQueueIndex(url, getIntent().getIntExtra(EXTRA_NUM, 0));
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        playerView = new PlayerView(this);
        playerView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        playerView.setKeepScreenOn(true);
        playerView.setUseController(false); // movies use our own bar (buildVodControls)
        playerView.setKeepContentOnPlayerReset(true); // last frame stays until the new channel's first frame
        // fill the whole screen with the complete picture (nothing cropped, no black bars)
        playerView.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FILL);
        playerView.setFocusable(true);
        playerView.setOnClickListener(v -> onScreenTap());
        root.addView(playerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        message = new TextView(this);
        message.setTextColor(0xFFFFFFFF);
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setPadding(Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12));
        root.addView(message, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        titleView = new TextView(this);
        titleView.setText(name == null ? "" : name);
        titleView.setTextColor(0xFFFFFFFF);
        titleView.setTextSize(16);
        titleView.setBackgroundColor(0x88000000);
        titleView.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        if (live) {
            titleView.setVisibility(View.GONE);
        }
        root.addView(titleView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
        if (live) {
            buildLiveOverlay(root, name);
            buildChannelPanel(root);
        } else {
            root.removeView(titleView); // the title lives inside the bar
            titleView = null;
            buildVodControls(root, name);
        }

        setContentView(root);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), root);
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);

        handler.postDelayed(hideTitle, hideDelay());
        if (!live) {
            handler.post(tick);
        }
        playerView.requestFocus();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (panelVisible() && chOpen) {
                    closeChannels();
                } else if (panelVisible() && !(browse && (url == null || url.isEmpty()))) {
                    hidePanel();
                } else {
                    setEnabled(false);
                    getOnBackPressedDispatcher().onBackPressed();
                }
            }
        });
        if (browse) {
            numberEntry.setVisibility(View.GONE);
            loadCats();   // OK on the remote then opens a list that is already filled
        }
    }

    /**
     * Movie / episode bar: poster (if any) at the bottom left, title, seek bar with times, back /
     * pause / forward in the middle, and the resize + subtitle buttons at the bottom right.
     * It shows for 10 seconds when playback starts or on any key / tap.
     */
    private void buildVodControls(FrameLayout root, String name) {
        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        bar.setGravity(Gravity.BOTTOM);
        int pad = Ui.dp(this, 12);
        bar.setPadding(pad, Ui.dp(this, 28), pad, Ui.dp(this, 8));
        bar.setBackground(new android.graphics.drawable.GradientDrawable(
                android.graphics.drawable.GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00000000, 0xE6000000}));

        // poster of the movie / series, when there is one
        ImageView poster = new ImageView(this);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(this, 84), Ui.dp(this, 118));
        pp.setMarginEnd(Ui.dp(this, 12));
        if (trackIcon != null && !trackIcon.isEmpty()) {
            Glide.with(this).load(trackIcon).into(poster);
            bar.addView(poster, pp);
        }

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        bar.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView title = new TextView(this);
        title.setText(name == null ? "" : name);
        title.setTextColor(0xFFFFFFFF);
        title.setTextSize(15);
        title.setSingleLine(true);
        title.setGravity(Gravity.RIGHT);
        title.setShadowLayer(4f, 0f, 1f, 0xFF000000);
        col.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // current time - seek bar - total time
        LinearLayout seekRow = new LinearLayout(this);
        seekRow.setOrientation(LinearLayout.HORIZONTAL);
        seekRow.setGravity(Gravity.CENTER_VERTICAL);
        timeNow = timeLabel("00:00");
        timeTotal = timeLabel("--:--");
        seekBar = new SeekBar(this);
        seekBar.setMax(1000);
        seekBar.setFocusable(false);
        seekBar.setPadding(Ui.dp(this, 10), 0, Ui.dp(this, 10), 0);
        seekBar.setProgressTintList(android.content.res.ColorStateList.valueOf(0xFFFFFFFF));
        seekBar.setSecondaryProgressTintList(android.content.res.ColorStateList.valueOf(0x66FFFFFF));
        seekBar.setProgressBackgroundTintList(android.content.res.ColorStateList.valueOf(0x44FFFFFF));
        seekBar.setThumbTintList(android.content.res.ColorStateList.valueOf(0xFFFFFFFF));
        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar sb, int progress, boolean fromUser) {
                if (!fromUser || player == null) return;
                long dur = player.getDuration();
                if (dur > 0) timeNow.setText(fmt(dur * progress / 1000));
            }

            @Override
            public void onStartTrackingTouch(SeekBar sb) {
                seeking = true;
                handler.removeCallbacks(hideTitle);
            }

            @Override
            public void onStopTrackingTouch(SeekBar sb) {
                seeking = false;
                if (player != null && player.getDuration() > 0) {
                    player.seekTo(player.getDuration() * sb.getProgress() / 1000);
                }
                showInfo();
            }
        });
        seekRow.addView(timeNow);
        seekRow.addView(seekBar, new LinearLayout.LayoutParams(0, Ui.dp(this, 32), 1f));
        seekRow.addView(timeTotal);
        col.addView(seekRow, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // middle: back / pause / forward   right: resize + subtitles
        FrameLayout controls = new FrameLayout(this);
        LinearLayout mid = new LinearLayout(this);
        mid.setOrientation(LinearLayout.HORIZONTAL);
        ImageView back = iconButton(R.drawable.ic_vod_rew, true);
        btnPlay = iconButton(R.drawable.ic_vod_pause, true);
        ImageView fwd = iconButton(R.drawable.ic_vod_ff, true);
        btnRew = back;
        btnFwd = fwd;
        back.setOnClickListener(v -> {
            seekBy(-SEEK_STEP_MS);
            showInfo();
        });
        btnPlay.setOnClickListener(v -> {
            togglePlay();
            showInfo();
        });
        fwd.setOnClickListener(v -> {
            seekBy(SEEK_STEP_MS);
            showInfo();
        });
        mid.addView(back, iconParams());
        mid.addView(btnPlay, iconParams());
        mid.addView(fwd, iconParams());
        controls.addView(mid, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        ImageView resize = iconButton(R.drawable.ic_vod_resize, true);
        ImageView subs = iconButton(R.drawable.ic_vod_subs, true);
        btnResize = resize;
        btnTracks = subs;
        resize.setOnClickListener(v -> {
            resizeIdx = (resizeIdx + 1) % RESIZE_MODES.length;
            playerView.setResizeMode(RESIZE_MODES[resizeIdx]);
            Toast.makeText(this, RESIZE_NAMES[resizeIdx], Toast.LENGTH_SHORT).show();
            showInfo();
        });
        subs.setOnClickListener(v -> {
            showInfo();
            showTracksDialog();
        });
        tools.addView(resize, iconParams());
        tools.addView(subs, iconParams());
        controls.addView(tools, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.RIGHT | Gravity.CENTER_VERTICAL));
        col.addView(controls, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 48)));

        root.addView(bar, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM));
        controlsRow = bar;
    }

    private TextView timeLabel(String text) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextColor(0xFFE6E6E6);
        t.setTextSize(12);
        t.setGravity(Gravity.CENTER);
        t.setMinWidth(Ui.dp(this, 48));
        return t;
    }

    private ImageView iconButton(int res, boolean focusable) {
        ImageView v = new ImageView(this);
        v.setImageResource(res);
        v.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int p = Ui.dp(this, 9);
        v.setPadding(p, p, p, p);
        v.setClickable(true);
        v.setFocusable(focusable);
        if (focusable) {
            v.setBackgroundResource(R.drawable.bg_vod_btn);
            // the key the remote is on turns red
            v.setOnFocusChangeListener((view, has) -> {
                if (has) ((ImageView) view).setColorFilter(0xFFFF2D2D, android.graphics.PorterDuff.Mode.SRC_IN);
                else ((ImageView) view).clearColorFilter();
            });
        }
        return v;
    }

    private LinearLayout.LayoutParams iconParams() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 46), Ui.dp(this, 44));
        lp.setMargins(Ui.dp(this, 5), 0, Ui.dp(this, 5), 0);
        return lp;
    }

    /** Subtitle (and audio, when there is a choice) track picker. */
    private void showTracksDialog() {
        if (player == null) return;
        final List<String> labels = new ArrayList<>();
        final List<Runnable> actions = new ArrayList<>();
        Tracks tracks = player.getCurrentTracks();
        int audioCount = 0, textCount = 0;
        boolean textOn = false;
        for (Tracks.Group g : tracks.getGroups()) {
            if (g.getType() == C.TRACK_TYPE_AUDIO) audioCount += g.length;
            if (g.getType() == C.TRACK_TYPE_TEXT) {
                textCount += g.length;
                if (g.isSelected()) textOn = true;
            }
        }
        if (textCount == 0 && audioCount <= 1) {
            Toast.makeText(this, "لا توجد ترجمة لهذا المحتوى", Toast.LENGTH_SHORT).show();
            return;
        }
        if (textCount > 0) {
            labels.add((textOn ? "" : "✓ ") + "ترجمة: بدون ترجمة");
            actions.add(() -> player.setTrackSelectionParameters(
                    player.getTrackSelectionParameters().buildUpon()
                            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true).build()));
        }
        int n = 0;
        for (Tracks.Group g : tracks.getGroups()) {
            final int type = g.getType();
            boolean text = type == C.TRACK_TYPE_TEXT;
            if (!text && !(type == C.TRACK_TYPE_AUDIO && audioCount > 1)) continue;
            final TrackGroup tg = g.getMediaTrackGroup();
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                final int ti = i;
                n++;
                Format f = g.getTrackFormat(i);
                String nm = f.label;
                if ((nm == null || nm.isEmpty()) && f.language != null && !"und".equals(f.language)) {
                    nm = new java.util.Locale(f.language).getDisplayLanguage(new java.util.Locale("ar"));
                }
                if (nm == null || nm.isEmpty()) nm = "مسار " + n;
                labels.add((g.isTrackSelected(i) ? "✓ " : "") + (text ? "ترجمة: " : "صوت: ") + nm);
                actions.add(() -> player.setTrackSelectionParameters(
                        player.getTrackSelectionParameters().buildUpon()
                                .setTrackTypeDisabled(type, false)
                                .setOverrideForType(new TrackSelectionOverride(tg, ti)).build()));
            }
        }
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setTitle("الترجمة والصوت")
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    actions.get(which).run();
                    showInfo();
                })
                .setOnDismissListener(d -> showInfo())
                .show();
    }

    /** Clock (top left), channel logo (top right) and the bottom banner with number, name and group. */
    private void buildLiveOverlay(FrameLayout root, String name) {
        String logo = getIntent().getStringExtra(EXTRA_LOGO);
        int num = getIntent().getIntExtra(EXTRA_NUM, 0);
        String sub = getIntent().getStringExtra(EXTRA_SUB);
        if (browse && url != null && !url.isEmpty() && num == 0) {
            // the banner of the last watched channel, shown while the list is still loading
            logo = Prefs.getString(this, "last_live_icon");
            sub = Prefs.getString(this, "last_live_sub");
            try {
                num = Integer.parseInt(Prefs.getString(this, "last_live_num"));
            } catch (NumberFormatException ignored) {
                num = 0;
            }
        }

        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(0xFFE6E6E6);
        clock.setTextSize(15);
        clock.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        clock.setShadowLayer(4f, 0f, 1f, 0xFF000000);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.LEFT);
        cp.setMargins(Ui.dp(this, 28), Ui.dp(this, 14), 0, 0);
        root.addView(clock, cp);

        LinearLayout bar = new LinearLayout(this);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundResource(R.drawable.bg_player_bar);
        bar.setPadding(Ui.dp(this, 22), Ui.dp(this, 12), Ui.dp(this, 22), Ui.dp(this, 12));

        liveIcon = new ImageView(this);
        liveIcon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        bar.addView(liveIcon, new LinearLayout.LayoutParams(Ui.dp(this, 76), Ui.dp(this, 52)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colp.setMarginStart(Ui.dp(this, 14));
        bar.addView(col, colp);

        liveTitle = new TextView(this);
        liveTitle.setTextColor(0xFFE9EEF0);
        liveTitle.setTextSize(20);
        liveTitle.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        liveTitle.setMaxLines(1);
        liveTitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        liveTitle.setGravity(Gravity.START);
        col.addView(liveTitle);

        liveSub = new TextView(this);
        liveSub.setTextColor(0xFF9FB4BB);
        liveSub.setTextSize(13);
        liveSub.setMaxLines(1);
        liveSub.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        liveSub.setGravity(Gravity.START);
        col.addView(liveSub);

        // banner: 75% of the screen width, centred
        int bannerW = Math.min(getResources().getDisplayMetrics().widthPixels - Ui.dp(this, 56),
                (int) (getResources().getDisplayMetrics().widthPixels * 0.75f));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                bannerW, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
        bp.setMargins(0, 0, 0, Ui.dp(this, 16));
        root.addView(bar, bp);
        infoBar = bar;

        // number typed on the remote, shown big at the top while it is being entered
        numberEntry = new TextView(this);
        numberEntry.setTextColor(0xFFFFFFFF);
        numberEntry.setTextSize(46);
        numberEntry.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        numberEntry.setShadowLayer(8f, 0f, 2f, 0xFF000000);
        numberEntry.setVisibility(View.GONE);
        FrameLayout.LayoutParams np = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        np.topMargin = Ui.dp(this, 40);
        root.addView(numberEntry, np);

        updateLiveBanner(name, logo, num, sub);
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (playerView == null) return;
        player = Players.create(this);
        player.addListener(listener);
        playerView.setPlayer(player);
        if (url == null || url.isEmpty()) {
            message.setVisibility(View.GONE);
            return;
        }
        message.setVisibility(View.GONE);
        retryCount = 0;
        player.setMediaItem(isLiveMode() ? Players.liveItem(url) : MediaItem.fromUri(url));
        if (startPos > 0) player.seekTo(startPos);
        player.prepare();
        player.play();
        registerNetworkWatcher();
    }

    @Override
    protected void onStop() {
        super.onStop();
        saveHistory();
        releasePlayer();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(reconnectRun);
        handler.removeCallbacks(stallRun);
        handler.removeCallbacks(hideTitle);
        handler.removeCallbacks(tick);
        handler.removeCallbacks(commitNumber);
        handler.removeCallbacks(searchRunnable);
        super.onDestroy();
    }

    private void saveHistory() {
        if (player == null || trackPlaylist < 0 || trackType == null || trackRemote == null) return;
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        if (pos < 5000) return;
        if (dur > 0 && pos > dur * 95 / 100) pos = 0;
        startPos = pos;
        final History h = new History();
        h.playlistId = trackPlaylist;
        h.type = trackType;
        h.remoteId = trackRemote;
        h.name = trackName == null ? "" : trackName;
        h.icon = trackIcon == null ? "" : trackIcon;
        h.episodeTitle = trackEpisode == null ? "" : trackEpisode;
        h.streamUrl = url;
        h.positionMs = pos;
        h.updatedAt = System.currentTimeMillis();
        final Context app = getApplicationContext();
        Async.io(() -> {
            UserDatabase.get(app).dao().putHistory(h);
            com.myiptv.app.util.Prefs.markHomeDirty();
            if ("series".equals(h.type)) {
                Prefs.markSeen(app, h.playlistId, h.remoteId, h.streamUrl, h.episodeTitle);
            }
            // watching a series again brings it back to "series I follow"
            if ("series".equals(h.type)
                    && Prefs.getCompleted(app, h.playlistId).contains(h.remoteId)) {
                Prefs.setCompleted(app, h.playlistId, h.remoteId, false);
            }
        });
    }

    private void releasePlayer() {
        handler.removeCallbacks(reconnectRun);
        handler.removeCallbacks(stallRun);
        handler.removeCallbacks(zapLoad);
        unregisterNetworkWatcher();
        if (player != null && playerView != null) {
            player.removeListener(listener);
            playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }

    // ------------------------------------------------- channel list (OK on the remote / tap)
    // Step 1: only the packages list (with a search bar) opens. Step 2: choosing a package
    // (OK / tap) shows its channels next to it.

    private FrameLayout panel;
    private RecyclerView catView;
    private RecyclerView chView;
    private View chLine;
    private android.widget.EditText searchBox;
    private final List<Category> cats = new ArrayList<>();
    private final List<Category> catsShown = new ArrayList<>();
    private final List<Item> shown = new ArrayList<>();
    private final Map<String, String> catNames = new HashMap<>();
    private final Map<String, String> catLogos = new HashMap<>();
    /** Logos lent between sibling channels, loaded with the categories. */
    private volatile com.myiptv.app.util.LogoBook logoBook;
    /** remoteIds of the favorite live channels (the star next to each channel). */
    private final java.util.Set<String> favIds = new java.util.HashSet<>();
    private final CatAdapter catAdapter = new CatAdapter();
    private final ChAdapter chAdapter = new ChAdapter();
    private int selCat = -1;
    private int panelToken;
    private long panelPid = -1;
    private boolean catsLoaded;
    private boolean loadingCats;
    private boolean focusAfter;
    private boolean chOpen;
    private String query = "";
    private boolean suppressSearch;

    private final Runnable searchRunnable = new Runnable() {
        @Override
        public void run() {
            applySearch();
        }
    };

    private boolean panelVisible() {
        return panel != null && panel.getVisibility() == View.VISIBLE;
    }

    private static boolean isSpecial(Category c) {
        return c.remoteId == null || FAV_ID.equals(c.remoteId);
    }

    /** Packages on the left (search bar on top); the channels column opens next to it on demand. */
    private void buildChannelPanel(FrameLayout root) {
        panel = new FrameLayout(this);
        panel.setVisibility(View.GONE);
        panel.setClickable(true);
        panel.setOnClickListener(v -> hidePanel());

        int screenW = getResources().getDisplayMetrics().widthPixels;
        LinearLayout lists = new LinearLayout(this);
        lists.setOrientation(LinearLayout.HORIZONTAL);
        lists.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        lists.setPadding(Ui.dp(this, 8), Ui.dp(this, 8), Ui.dp(this, 10), Ui.dp(this, 8));

        LinearLayout catCol = new LinearLayout(this);
        catCol.setOrientation(LinearLayout.VERTICAL);
        catCol.setBackgroundResource(R.drawable.bg_list_card);
        catCol.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6));

        searchBox = new android.widget.EditText(this);
        searchBox.setHint("ابحث عن قناة أو باقة…");
        searchBox.setHintTextColor(0xFF8FB0B8);
        searchBox.setTextColor(0xFFFFFFFF);
        searchBox.setTextSize(15);
        searchBox.setSingleLine(true);
        searchBox.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        searchBox.setBackgroundResource(R.drawable.bg_search_slim);
        searchBox.setPadding(Ui.dp(this, 10), Ui.dp(this, 2), Ui.dp(this, 10), Ui.dp(this, 2));
        searchBox.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        searchBox.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        searchBox.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {
                if (suppressSearch) return;
                query = s.toString().trim();
                handler.removeCallbacks(searchRunnable);
                handler.postDelayed(searchRunnable, 350);
            }
        });
        searchBox.setOnEditorActionListener((v, actionId, event) -> {
            if (actionId == android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH) {
                handler.removeCallbacks(searchRunnable);
                applySearch();
                hideKeyboard();
            }
            return true;
        });
        LinearLayout.LayoutParams sbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(this, 38));
        sbp.setMargins(Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4));
        catCol.addView(searchBox, sbp);

        catView = new RecyclerView(this);
        catView.setLayoutManager(new LinearLayoutManager(this));
        catView.setAdapter(catAdapter);
        catView.setItemAnimator(null);
        catView.setHasFixedSize(true);
        catView.addItemDecoration(new RowDivider());
        catCol.addView(catView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        // The packages column is added last so it stays pinned to the right edge;
        // the channels column opens on its left when a package is chosen.
        chView = new RecyclerView(this);
        chView.setLayoutManager(new LinearLayoutManager(this));
        chView.setAdapter(chAdapter);
        chView.setItemAnimator(null);
        chView.setHasFixedSize(true);
        chView.addItemDecoration(new RowDivider());
        chView.setItemViewCacheSize(16);
        chView.setBackgroundResource(R.drawable.bg_list_card);
        chView.setPadding(Ui.dp(this, 4), Ui.dp(this, 6), Ui.dp(this, 4), Ui.dp(this, 6));
        chView.setClipToPadding(false);
        chView.setVisibility(View.GONE);
        lists.addView(chView, new LinearLayout.LayoutParams((int) (screenW * 0.36f),
                ViewGroup.LayoutParams.MATCH_PARENT));

        chLine = new View(this);
        chLine.setBackgroundColor(0x00000000);   // just the gap between the two rounded lists
        chLine.setVisibility(View.GONE);
        lists.addView(chLine, new LinearLayout.LayoutParams(Ui.dp(this, 8), ViewGroup.LayoutParams.MATCH_PARENT));

        lists.addView(catCol, new LinearLayout.LayoutParams((int) (screenW * 0.34f),
                ViewGroup.LayoutParams.MATCH_PARENT));

        panel.addView(lists, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.RIGHT));
        root.addView(panel, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void hideKeyboard() {
        try {
            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null && searchBox != null) imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
        } catch (Exception ignored) {
            // ignore
        }
    }

    private void showPanel() {
        if (panel == null) return;
        handler.removeCallbacks(hideTitle);
        if (infoBar != null) infoBar.setVisibility(View.GONE);
        panel.setVisibility(View.VISIBLE);
        // always starts with the packages list only
        chOpen = false;
        chView.setVisibility(View.GONE);
        chLine.setVisibility(View.GONE);
        if (!catsLoaded) {
            loadCats();
        } else {
            focusSelectedCat();
        }
    }

    private void hidePanel() {
        if (panel == null) return;
        handler.removeCallbacks(searchRunnable);
        hideKeyboard();
        if (searchBox != null) searchBox.clearFocus();
        panel.setVisibility(View.GONE);
        if (playerView != null) playerView.requestFocus();
        showInfo();
    }

    private void openChannelsColumn() {
        chOpen = true;
        chView.setVisibility(View.VISIBLE);
        chLine.setVisibility(View.VISIBLE);
    }

    private void closeChannels() {
        chOpen = false;
        chView.setVisibility(View.GONE);
        chLine.setVisibility(View.GONE);
        focusSelectedCat();
    }

    private int currentShownIndex() {
        if (url == null) return -1;
        for (int i = 0; i < shown.size(); i++) {
            if (url.equals(shown.get(i).streamUrl)) return i;
        }
        return -1;
    }

    private void focusCurrent() {
        if (chView == null || shown.isEmpty()) return;
        int idx = currentShownIndex();
        final int target = idx >= 0 ? idx : 0;
        chView.scrollToPosition(target);
        chView.post(() -> {
            RecyclerView.ViewHolder vh = chView.findViewHolderForAdapterPosition(target);
            if (vh != null) vh.itemView.requestFocus();
            else chView.requestFocus();
        });
    }

    private void focusSelectedCat() {
        if (catView == null || catsShown.isEmpty()) return;
        Category sel = selCat >= 0 && selCat < cats.size() ? cats.get(selCat) : null;
        final int i = sel == null ? 0 : Math.max(0, catsShown.indexOf(sel));
        catView.scrollToPosition(i);
        catView.post(() -> {
            RecyclerView.ViewHolder vh = catView.findViewHolderForAdapterPosition(i);
            if (vh != null) vh.itemView.requestFocus();
            else catView.requestFocus();
        });
    }

    private void notifyCat(int master) {
        if (master < 0 || master >= cats.size()) return;
        int i = catsShown.indexOf(cats.get(master));
        if (i >= 0) catAdapter.notifyItemChanged(i);
    }

    // ------------------------------------------------------------ search

    private void applySearch() {
        if (!catsLoaded || panelPid < 0) return;
        final String q = query;
        catsShown.clear();
        if (q.isEmpty()) {
            catsShown.addAll(cats);
        } else {
            String lq = q.toLowerCase();
            for (Category c : cats) {
                if (c.name != null && c.name.toLowerCase().contains(lq)) catsShown.add(c);
            }
        }
        catAdapter.notifyDataSetChanged();
        if (q.isEmpty()) {
            closeChannelsKeepFocus();
            return;
        }
        // channels matching the text are listed next to the matching packages
        openChannelsColumn();
        final int token = ++panelToken;
        final long pid = panelPid;
        final Context app = getApplicationContext();
        Async.io(() -> {
            final List<Item> found = AppDatabase.get(app).dao().searchItems(pid, "live", q, 500);
            Async.main(() -> {
                if (isFinishing() || isDestroyed() || token != panelToken) return;
                shown.clear();
                shown.addAll(found);
                chAdapter.notifyDataSetChanged();
                chView.scrollToPosition(0);
                if (found.isEmpty() && catsShown.isEmpty()) {
                    Toast.makeText(this, "لا توجد نتائج", Toast.LENGTH_SHORT).show();
                }
            });
        });
    }

    private void closeChannelsKeepFocus() {
        chOpen = false;
        chView.setVisibility(View.GONE);
        chLine.setVisibility(View.GONE);
    }

    // -------------------------------------------------------------- data

    private void loadCats() {
        if (loadingCats) return;
        loadingCats = true;
        final Context app = getApplicationContext();
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            UserDao ud = UserDatabase.get(app).dao();
            long pid = Prefs.getActive(app);
            Playlist p = pid < 0 ? null : dao.getPlaylist(pid);
            final List<Category> list = new ArrayList<>();
            final Map<String, String> names = new HashMap<>();
            final Map<String, String> logos = new HashMap<>();
            final List<String> favList = new ArrayList<>();
            if (p != null) {
                favList.addAll(ud.favoriteIds(p.id, "live"));
                try {
                    for (com.myiptv.app.data.CatLogo cl : dao.catLogos(p.id)) {
                        if (cl.catId != null && cl.icon != null) logos.put(cl.catId, cl.icon);
                    }
                    logoBook = com.myiptv.app.util.LogoBook.load(dao, p.id);
                    com.myiptv.app.util.ExternalLogos.ensure(PlayerActivity.this, () -> {
                        if (isFinishing() || isDestroyed()) return;
                        catAdapter.notifyDataSetChanged();
                        chAdapter.notifyDataSetChanged();
                    });
                } catch (Exception ignored) {
                    // packages simply show the default icon
                }
                Category fav = new Category();
                fav.name = "★ المفضلة";
                fav.remoteId = FAV_ID;
                list.add(fav);
                Category all = new Category();
                all.name = "الكل";
                all.remoteId = null;
                list.add(all);
                List<Category> real = dao.getCategories(p.id, "live");
                real = applyOrder(real, ud.getOrder(p.id, "cat:live"), new KeyFn<Category>() {
                    @Override
                    public String key(Category c) {
                        return c.remoteId == null ? "" : c.remoteId;
                    }
                });
                list.addAll(real);
                for (Category rc : real) {
                    if (rc.remoteId != null) names.put(rc.remoteId, rc.name == null ? "" : rc.name);
                }
            }
            final long fid = p == null ? -1 : p.id;
            Async.main(() -> {
                loadingCats = false;
                if (isFinishing() || isDestroyed()) return;
                if (fid < 0 || list.size() <= SPECIAL) {
                    Toast.makeText(PlayerActivity.this,
                            "لا توجد قنوات. أضف حساباً من القائمة الرئيسية", Toast.LENGTH_LONG).show();
                    if (browse && (url == null || url.isEmpty())) finish();
                    return;
                }
                panelPid = fid;
                cats.clear();
                cats.addAll(list);
                catsShown.clear();
                catsShown.addAll(cats);
                catNames.clear();
                catNames.putAll(names);
                catLogos.clear();
                catLogos.putAll(logos);
                favIds.clear();
                favIds.addAll(favList);
                catsLoaded = true;
                selCat = -1;
                catAdapter.notifyDataSetChanged();

                // select the group of the channel being watched (or the last one watched)
                String want = "";
                List<Item> q = LiveQueue.items;
                if (queueIndex >= 0 && queueIndex < q.size() && q.get(queueIndex).categoryRemoteId != null) {
                    want = q.get(queueIndex).categoryRemoteId;
                } else if (browse) {
                    want = Prefs.getString(PlayerActivity.this, "last_live_cat");
                }
                int start = SPECIAL;
                if (!want.isEmpty()) {
                    for (int i = SPECIAL; i < cats.size(); i++) {
                        if (want.equals(cats.get(i).remoteId)) {
                            start = i;
                            break;
                        }
                    }
                }
                selectCat(start, true);
                if (panelVisible()) focusSelectedCat();
            });
        });
    }

    private void openCategoryAt(int posInShown) {
        if (posInShown < 0 || posInShown >= catsShown.size()) return;
        int master = cats.indexOf(catsShown.get(posInShown));
        if (master < 0) return;
        handler.removeCallbacks(searchRunnable);
        if (!query.isEmpty()) {
            suppressSearch = true;
            searchBox.setText("");
            suppressSearch = false;
            query = "";
            catsShown.clear();
            catsShown.addAll(cats);
            catAdapter.notifyDataSetChanged();
        }
        hideKeyboard();
        openChannelsColumn();
        shown.clear();
        chAdapter.notifyDataSetChanged();
        focusAfter = true;
        selectCat(master, false);
    }

    private void selectCat(int pos, final boolean initial) {
        if (pos < 0 || pos >= cats.size()) return;
        int old = selCat;
        selCat = pos;
        notifyCat(old);
        notifyCat(pos);
        final Category cat = cats.get(pos);
        final int token = ++panelToken;
        final long pid = panelPid;
        final Context app = getApplicationContext();
        Async.io(() -> {
            AppDao dao = AppDatabase.get(app).dao();
            UserDao ud = UserDatabase.get(app).dao();
            List<Item> list;
            if (FAV_ID.equals(cat.remoteId)) {
                list = new ArrayList<>();
                for (Favorite f : ud.favoritesOfType(pid, "live", 2000)) {
                    Item it = new Item();
                    it.id = 2000000000L + f.id;
                    it.playlistId = pid;
                    it.type = "live";
                    it.remoteId = f.remoteId;
                    it.name = f.name;
                    it.icon = f.icon;
                    it.streamUrl = f.streamUrl;
                    it.rating = "";
                    it.year = "";
                    list.add(it);
                }
            } else if (cat.remoteId == null) {
                list = dao.itemsAll(pid, "live", 20000);
            } else {
                list = dao.itemsInCategory(pid, "live", cat.remoteId);
                list = applyOrder(list, ud.getOrder(pid, "items:live:" + cat.remoteId),
                        new KeyFn<Item>() {
                            @Override
                            public String key(Item i) {
                                return (i.streamUrl != null && !i.streamUrl.isEmpty())
                                        ? i.streamUrl : String.valueOf(i.remoteId);
                            }
                        });
            }
            final List<Item> result = list;
            Async.main(() -> {
                if (isFinishing() || isDestroyed() || token != panelToken) return;
                shown.clear();
                shown.addAll(result);
                chAdapter.notifyDataSetChanged();
                chView.scrollToPosition(0);
                if (initial && browse && player != null) {
                    boolean nothingPlaying = url == null || url.isEmpty();
                    int idx = -1;
                    for (int i = 0; i < shown.size(); i++) {
                        String u = shown.get(i).streamUrl;
                        if (u == null || u.isEmpty()) continue;
                        if (idx < 0 && nothingPlaying) idx = i;
                        if (!nothingPlaying && u.equals(url)) {
                            idx = i;
                            break;
                        }
                    }
                    if (idx >= 0) {
                        LiveQueue.set(shown, catNames);
                        queueIndex = idx;
                        if (nothingPlaying) {
                            playChannel(idx);          // first start: the first channel
                        } else {
                            // already playing: only the banner number, the picture is not restarted
                            Item cur = shown.get(idx);
                            String sub = cur.categoryRemoteId == null ? ""
                                    : LiveQueue.catNames.get(cur.categoryRemoteId);
                            updateLiveBanner(cur.name, cur.icon, idx + 1, sub);
                            if (chAdapter != null) chAdapter.notifyDataSetChanged();
                        }
                    }
                }
                if (focusAfter && panelVisible() && chOpen) {
                    focusAfter = false;
                    focusCurrent();
                }
            });
        });
    }

    /** Star next to a channel: adds / removes it from the favorite channels. */
    private void toggleFavorite(int pos) {
        if (pos < 0 || pos >= shown.size() || panelPid < 0) return;
        final Item it = shown.get(pos);
        if (it.remoteId == null || it.remoteId.isEmpty()) return;
        final long pid = panelPid;
        final String rid = it.remoteId;
        final boolean wasFav = favIds.contains(rid);
        if (wasFav) favIds.remove(rid);
        else favIds.add(rid);
        boolean inFavCat = selCat >= 0 && selCat < cats.size() && FAV_ID.equals(cats.get(selCat).remoteId);
        if (wasFav && inFavCat && query.isEmpty()) {
            shown.remove(pos);
            chAdapter.notifyItemRemoved(pos);
            chAdapter.notifyItemRangeChanged(pos, shown.size() - pos);
        } else {
            chAdapter.notifyItemChanged(pos);
        }
        Toast.makeText(this, wasFav ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
        final String name = it.name == null ? "" : it.name;
        final String icon = it.icon == null ? "" : it.icon;
        final String stream = it.streamUrl == null ? "" : it.streamUrl;
        final Context app = getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (wasFav) {
                ud.removeFavorite(pid, "live", rid);
                com.myiptv.app.util.Prefs.markHomeDirty();
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = "live";
                f.remoteId = rid;
                f.name = name;
                f.icon = icon;
                f.streamUrl = stream;
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
                com.myiptv.app.util.Prefs.markHomeDirty();
            }
        });
    }

    private void pickChannel(int pos) {
        if (pos < 0 || pos >= shown.size()) return;
        Item it = shown.get(pos);
        if (it.streamUrl == null || it.streamUrl.isEmpty()) {
            Toast.makeText(this, "لا يوجد رابط تشغيل لهذه القناة", Toast.LENGTH_SHORT).show();
            return;
        }
        LiveQueue.set(shown, catNames);
        queueIndex = pos;
        playChannel(pos);
        hidePanel();
    }

    // ------------------------------------------------ reorder packages (long press)

    private void showMoveDialog(final int startPos) {
        if (startPos < SPECIAL || startPos >= cats.size()) return;
        final int[] pos = {startPos};
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        box.setPadding(Ui.dp(this, 22), Ui.dp(this, 18), Ui.dp(this, 22), Ui.dp(this, 10));

        TextView title = new TextView(this);
        String n = cats.get(startPos).name;
        title.setText(n == null ? "" : n);
        title.setTextColor(androidx.core.content.ContextCompat.getColor(this, R.color.text));
        title.setTextSize(16);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        box.addView(title);

        TextView up = Ui.button(this, "▲  نقل للأعلى", true);
        TextView down = Ui.button(this, "▼  نقل للأسفل", true);
        TextView close = Ui.button(this, "تم", false);
        up.setOnClickListener(v -> {
            if (moveCat(pos[0], pos[0] - 1)) pos[0]--;
        });
        down.setOnClickListener(v -> {
            if (moveCat(pos[0], pos[0] + 1)) pos[0]++;
        });
        box.addView(up, dlgLp(14));
        box.addView(down, dlgLp(8));
        box.addView(close, dlgLp(8));

        final androidx.appcompat.app.AlertDialog dlg =
                new androidx.appcompat.app.AlertDialog.Builder(this).setView(box).create();
        close.setOnClickListener(v -> dlg.dismiss());
        dlg.show();
        up.requestFocus();
    }

    private LinearLayout.LayoutParams dlgLp(int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(this, topDp);
        return lp;
    }

    /** Moves a package one place; favorites and "All" always stay first. */
    private boolean moveCat(int from, int to) {
        int n = cats.size();
        if (from < SPECIAL || to < SPECIAL || from >= n || to >= n || from == to) return false;
        Collections.swap(cats, from, to);
        if (selCat == from) selCat = to;
        else if (selCat == to) selCat = from;
        catsShown.clear();
        catsShown.addAll(cats);
        catAdapter.notifyDataSetChanged();
        if (catView != null) catView.scrollToPosition(to);
        final JSONArray arr = new JSONArray();
        for (Category c : cats) {
            if (!isSpecial(c)) arr.put(c.remoteId);
        }
        final long pid = panelPid;
        final Context app = getApplicationContext();
        Async.io(() -> {
            com.myiptv.app.data.OrderPref o = new com.myiptv.app.data.OrderPref();
            o.playlistId = pid;
            o.scope = "cat:live";
            o.json = arr.toString();
            UserDatabase.get(app).dao().putOrder(o);
        });
        return true;
    }

    private interface KeyFn<T> {
        String key(T t);
    }

    /** Sorts by the saved order; anything not in it keeps the provider order after the saved ones. */
    private static <T> List<T> applyOrder(List<T> list, String json, final KeyFn<T> fn) {
        if (json == null || json.isEmpty() || list.size() < 2) return list;
        final Map<String, Integer> rank = new HashMap<>();
        try {
            JSONArray arr = new JSONArray(json);
            for (int i = 0; i < arr.length(); i++) {
                String k = arr.optString(i);
                if (!rank.containsKey(k)) rank.put(k, i);
            }
        } catch (Exception e) {
            return list;
        }
        List<T> copy = new ArrayList<>(list);
        Collections.sort(copy, new Comparator<T>() {
            @Override
            public int compare(T a, T b) {
                Integer ra = rank.get(fn.key(a));
                Integer rb = rank.get(fn.key(b));
                return Integer.compare(ra == null ? Integer.MAX_VALUE : ra,
                        rb == null ? Integer.MAX_VALUE : rb);
            }
        });
        return copy;
    }

    private static class RowVH extends RecyclerView.ViewHolder {
        final TextView num;
        final TextView name;
        final ImageView logo;
        final TextView star;

        RowVH(@NonNull View v, TextView num, TextView name, ImageView logo, TextView star) {
            super(v);
            this.num = num;
            this.name = name;
            this.logo = logo;
            this.star = star;
        }
    }

    /**
     * One list row, always laid out left to right as: name, logo, number (right edge).
     * Channel rows ({@code channel}) also get a favorite star on the far right.
     */
    private RowVH createRow(boolean channel) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 10), Ui.dp(this, 4));
        row.setMinimumHeight(Ui.dp(this, 48));
        row.setBackgroundResource(R.drawable.bg_row);
        row.setFocusable(true);
        row.setClickable(true);
        row.setLayoutParams(new RecyclerView.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView name = new TextView(this);
        name.setTextColor(0xFFFFFFFF);
        name.setTextSize(17);
        // thin yet prominent: light-weight face with a soft shadow so it stays readable on video
        name.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        name.setShadowLayer(4f, 0f, 1f, 0xCC000000);
        // the whole name is shown: it wraps onto a second line instead of being cut
        name.setMaxLines(2);
        name.setEllipsize(android.text.TextUtils.TruncateAt.END);
        name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        name.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        row.addView(name, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        ImageView logo = new ImageView(this);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams llp = new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 30));
        llp.setMarginStart(Ui.dp(this, 4));
        llp.setMarginEnd(Ui.dp(this, 4));
        row.addView(logo, llp);

        TextView num = new TextView(this);
        num.setTextColor(0xFFE3E9EC);
        num.setTextSize(15);
        num.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        num.setShadowLayer(4f, 0f, 1f, 0xCC000000);
        num.setGravity(Gravity.CENTER);
        row.addView(num, new LinearLayout.LayoutParams(Ui.dp(this, channel ? 40 : 32),
                ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView star = null;
        if (channel) {
            star = new TextView(this);
            star.setTextSize(22);
            star.setGravity(Gravity.CENTER);
            star.setClickable(true);
            star.setFocusable(false);
            row.addView(star, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 40)));
        }
        return new RowVH(row, num, name, logo, star);
    }

    /** A logo shared by the channels of one brand (beIN, MBC), or null. */
    private String brandLogo(String name) {
        com.myiptv.app.util.LogoBook b = logoBook;
        return b == null ? null : b.findBrand(name);
    }

    /** Logo of a sibling channel (same name without numbers / quality tags), else the brand logo. */
    private String siblingLogo(String name) {
        com.myiptv.app.util.LogoBook b = logoBook;
        return b == null ? null : b.find(name);
    }

    /** A hairline, see-through white line between two rows (packages and channels alike). */
    private static final class RowDivider extends RecyclerView.ItemDecoration {
        private final android.graphics.Paint paint = new android.graphics.Paint();

        RowDivider() {
            paint.setColor(0x38FFFFFF);
        }

        @Override
        public void onDrawOver(@NonNull android.graphics.Canvas c, @NonNull RecyclerView parent,
                               @NonNull RecyclerView.State state) {
            int inset = (int) (14 * parent.getResources().getDisplayMetrics().density);
            for (int i = 0; i < parent.getChildCount() - 1; i++) {
                View v = parent.getChildAt(i);
                float y = v.getBottom() + v.getTranslationY();
                c.drawRect(v.getLeft() + inset, y - 1f, v.getRight() - inset, y, paint);
            }
        }
    }

    private class CatAdapter extends RecyclerView.Adapter<RowVH> {
        @NonNull
        @Override
        public RowVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return createRow(false);
        }

        @Override
        public void onBindViewHolder(@NonNull RowVH h, int position) {
            Category c = catsShown.get(position);
            h.num.setText(String.format(java.util.Locale.US, "%02d", cats.indexOf(c) + 1));
            h.name.setText(c.name == null ? "" : c.name);
            if (isSpecial(c)) {
                Glide.with(PlayerActivity.this).clear(h.logo);
                h.logo.setImageDrawable(null);
            } else {
                String bl = brandLogo(c.name);
                String ext = com.myiptv.app.util.ExternalLogos.lookup(c.name);
                String pk = catLogos.get(c.remoteId);
                loadListLogo(h.logo, null, Ui.validLogo(pk) ? pk : (ext != null ? ext : bl), Ui.keepIcon(c.name));
            }
            h.itemView.setSelected(selCat >= 0 && selCat < cats.size() && cats.get(selCat) == c);
            h.itemView.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) openCategoryAt(p);
            });
            h.itemView.setOnLongClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p == RecyclerView.NO_POSITION || p >= catsShown.size() || !query.isEmpty()) return false;
                int master = cats.indexOf(catsShown.get(p));
                if (master < SPECIAL) return false; // favorites and "All" stay first
                showMoveDialog(master);
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return catsShown.size();
        }
    }

    private class ChAdapter extends RecyclerView.Adapter<RowVH> {
        @NonNull
        @Override
        public RowVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            return createRow(true);
        }

        @Override
        public void onBindViewHolder(@NonNull RowVH h, int position) {
            final Item it = shown.get(position);
            h.num.setText(String.format(java.util.Locale.US, "%03d", position + 1));
            h.name.setText(it.name == null ? "" : it.name);
            String pkgLogo = it.categoryRemoteId != null ? catLogos.get(it.categoryRemoteId) : null;
            if (pkgLogo == null && selCat >= 0 && selCat < cats.size() && !isSpecial(cats.get(selCat))) {
                pkgLogo = catLogos.get(cats.get(selCat).remoteId);
            }
            String bl = siblingLogo(it.name);   // channels without a logo borrow a sibling's
            // no logo from the provider: the external logo database, then a sibling / package logo
            String ext = Ui.validLogo(it.icon) ? null : com.myiptv.app.util.ExternalLogos.lookup(it.name);
            loadListLogo(h.logo, it.icon, ext != null ? ext : (bl != null ? bl : pkgLogo), Ui.keepIcon(it.name));
            h.itemView.setSelected(url != null && url.equals(it.streamUrl));
            h.itemView.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) pickChannel(p);
            });
            boolean fav = it.remoteId != null && favIds.contains(it.remoteId);
            h.star.setText(fav ? "★" : "☆");
            h.star.setTextColor(fav ? 0xFFFFC107 : 0xFFE3E9EC);
            h.star.setOnClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p != RecyclerView.NO_POSITION) toggleFavorite(p);
            });
            // remote control: long press OK toggles the favorite
            h.itemView.setOnLongClickListener(v -> {
                int p = h.getBindingAdapterPosition();
                if (p == RecyclerView.NO_POSITION) return false;
                toggleFavorite(p);
                return true;
            });
        }

        @Override
        public int getItemCount() {
            return shown.size();
        }
    }
}
