package com.myiptv.app.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextClock;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;

import com.myiptv.app.data.History;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Players;
import com.myiptv.app.util.Ui;

/** Full screen video player. */
public class PlayerActivity extends AppCompatActivity {
    private static final String EXTRA_URL = "url";
    private static final String EXTRA_TITLE = "title";
    private static final String EXTRA_PLAYLIST = "playlist";
    private static final String EXTRA_TYPE = "type";
    private static final String EXTRA_REMOTE = "remote";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_ICON = "icon";
    private static final String EXTRA_EPISODE = "episode";
    private static final String EXTRA_POS = "pos";
    private static final String EXTRA_LIVE = "live";
    private static final String EXTRA_LOGO = "logo";
    private static final String EXTRA_NUM = "num";
    private static final String EXTRA_SUB = "sub";

    public static void start(Context context, String url, String title) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        context.startActivity(i);
    }

    /** Plays a live channel and shows the channel banner (logo, number, name, group). */
    public static void startLive(Context context, String url, String title, String logo,
                                 int number, String subtitle) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_LIVE, true);
        i.putExtra(EXTRA_LOGO, logo);
        i.putExtra(EXTRA_NUM, number);
        i.putExtra(EXTRA_SUB, subtitle);
        context.startActivity(i);
    }

    /** Plays a series episode and remembers where the user stopped (for "series I follow"). */
    public static void startTracked(Context context, String url, String title, long playlistId,
                                    String type, String remoteId, String name, String icon,
                                    String episode, long positionMs) {
        Intent i = new Intent(context, PlayerActivity.class);
        i.putExtra(EXTRA_URL, url);
        i.putExtra(EXTRA_TITLE, title);
        i.putExtra(EXTRA_PLAYLIST, playlistId);
        i.putExtra(EXTRA_TYPE, type);
        i.putExtra(EXTRA_REMOTE, remoteId);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_ICON, icon);
        i.putExtra(EXTRA_EPISODE, episode);
        i.putExtra(EXTRA_POS, positionMs);
        context.startActivity(i);
    }

    private long trackPlaylist = -1;
    private String trackType, trackRemote, trackName, trackIcon, trackEpisode;
    private long startPos;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private PlayerView playerView;
    private TextView message;
    private TextView titleView;
    private View infoBar;
    private boolean live;
    private ExoPlayer player;
    private String url;

    private final Runnable hideTitle = new Runnable() {
        @Override
        public void run() {
            if (titleView != null) titleView.setVisibility(View.GONE);
            if (infoBar != null) infoBar.setVisibility(View.GONE);
        }
    };

    private void showInfo() {
        handler.removeCallbacks(hideTitle);
        if (live && infoBar != null) infoBar.setVisibility(View.VISIBLE);
        else if (titleView != null) titleView.setVisibility(View.VISIBLE);
        handler.postDelayed(hideTitle, 5000);
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_DPAD_UP:
            case KeyEvent.KEYCODE_DPAD_DOWN:
            case KeyEvent.KEYCODE_DPAD_LEFT:
            case KeyEvent.KEYCODE_DPAD_RIGHT:
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_INFO:
            case KeyEvent.KEYCODE_MENU:
                showInfo();
                break;
            default:
                break;
        }
        return super.onKeyDown(keyCode, event);
    }

    private final Player.Listener listener = new Player.Listener() {
        @Override
        public void onPlaybackStateChanged(int state) {
            if (state == Player.STATE_BUFFERING) {
                message.setText("جارٍ التحميل…");
                message.setVisibility(View.VISIBLE);
            } else if (state == Player.STATE_READY) {
                message.setVisibility(View.GONE);
            }
        }

        @Override
        public void onPlayerError(PlaybackException error) {
            message.setText("تعذر تشغيل هذا المحتوى (" + error.getErrorCodeName() + ")");
            message.setVisibility(View.VISIBLE);
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        url = getIntent().getStringExtra(EXTRA_URL);
        String name = getIntent().getStringExtra(EXTRA_TITLE);
        trackPlaylist = getIntent().getLongExtra(EXTRA_PLAYLIST, -1L);
        trackType = getIntent().getStringExtra(EXTRA_TYPE);
        trackRemote = getIntent().getStringExtra(EXTRA_REMOTE);
        trackName = getIntent().getStringExtra(EXTRA_NAME);
        trackIcon = getIntent().getStringExtra(EXTRA_ICON);
        trackEpisode = getIntent().getStringExtra(EXTRA_EPISODE);
        startPos = getIntent().getLongExtra(EXTRA_POS, 0L);
        live = getIntent().getBooleanExtra(EXTRA_LIVE, false);
        if (url == null || url.isEmpty()) {
            finish();
            return;
        }

        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);

        playerView = new PlayerView(this);
        playerView.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        playerView.setKeepScreenOn(true);
        playerView.setUseController(!live);
        playerView.setFocusable(true);
        playerView.setOnClickListener(v -> showInfo());
        root.addView(playerView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        message = new TextView(this);
        message.setTextColor(0xFFFFFFFF);
        message.setTextSize(16);
        message.setGravity(Gravity.CENTER);
        message.setPadding(Ui.dp(this, 24), Ui.dp(this, 12), Ui.dp(this, 24), Ui.dp(this, 12));
        root.addView(message, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.CENTER));

        titleView = new TextView(this);
        titleView.setText(name == null ? "" : name);
        titleView.setTextColor(0xFFFFFFFF);
        titleView.setTextSize(16);
        titleView.setBackgroundColor(0x88000000);
        titleView.setPadding(Ui.dp(this, 16), Ui.dp(this, 10), Ui.dp(this, 16), Ui.dp(this, 10));
        if (live) {
            titleView.setVisibility(View.GONE);
        }
        root.addView(titleView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP));
        if (live) buildLiveOverlay(root, name);

        setContentView(root);

        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat controller = WindowCompat.getInsetsController(getWindow(), root);
        controller.hide(WindowInsetsCompat.Type.systemBars());
        controller.setSystemBarsBehavior(
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);

        handler.postDelayed(hideTitle, 5000);
        playerView.requestFocus();
    }

    /** Clock (top left), channel logo (top right) and the bottom banner with number, name and group. */
    private void buildLiveOverlay(FrameLayout root, String name) {
        String logo = getIntent().getStringExtra(EXTRA_LOGO);
        int num = getIntent().getIntExtra(EXTRA_NUM, 0);
        String sub = getIntent().getStringExtra(EXTRA_SUB);

        TextClock clock = new TextClock(this);
        clock.setFormat24Hour("HH:mm");
        clock.setFormat12Hour("HH:mm");
        clock.setTextColor(0xFFE6E6E6);
        clock.setTextSize(15);
        clock.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        clock.setShadowLayer(4f, 0f, 1f, 0xFF000000);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                Gravity.TOP | Gravity.LEFT);
        cp.setMargins(Ui.dp(this, 28), Ui.dp(this, 14), 0, 0);
        root.addView(clock, cp);

        if (logo != null && logo.startsWith("http")) {
            ImageView mark = new ImageView(this);
            mark.setScaleType(ImageView.ScaleType.FIT_END);
            mark.setAlpha(0.9f);
            Glide.with(this).load(logo).into(mark);
            FrameLayout.LayoutParams mp = new FrameLayout.LayoutParams(
                    Ui.dp(this, 90), Ui.dp(this, 36), Gravity.TOP | Gravity.RIGHT);
            mp.setMargins(0, Ui.dp(this, 12), Ui.dp(this, 28), 0);
            root.addView(mark, mp);
        }

        LinearLayout bar = new LinearLayout(this);
        bar.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundResource(R.drawable.bg_player_bar);
        bar.setPadding(Ui.dp(this, 22), Ui.dp(this, 12), Ui.dp(this, 22), Ui.dp(this, 12));

        ImageView icon = new ImageView(this);
        icon.setScaleType(ImageView.ScaleType.FIT_CENTER);
        if (logo != null && logo.startsWith("http")) {
            Glide.with(this).load(logo).placeholder(R.drawable.ic_live).error(R.drawable.ic_live).into(icon);
        } else {
            icon.setImageResource(R.drawable.ic_live);
        }
        bar.addView(icon, new LinearLayout.LayoutParams(Ui.dp(this, 76), Ui.dp(this, 52)));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        LinearLayout.LayoutParams colp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        colp.setMarginStart(Ui.dp(this, 14));
        bar.addView(col, colp);

        TextView t = new TextView(this);
        t.setText((num > 0 ? num + "   " : "") + (name == null ? "" : name));
        t.setTextColor(0xFFE9EEF0);
        t.setTextSize(20);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
        t.setMaxLines(1);
        t.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        t.setGravity(Gravity.START);
        col.addView(t);

        if (sub != null && !sub.isEmpty()) {
            TextView s2 = new TextView(this);
            s2.setText(sub);
            s2.setTextColor(0xFF9FB4BB);
            s2.setTextSize(13);
            s2.setMaxLines(1);
            s2.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            s2.setGravity(Gravity.START);
            col.addView(s2);
        }

        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM);
        bp.setMargins(Ui.dp(this, 28), 0, Ui.dp(this, 28), Ui.dp(this, 16));
        root.addView(bar, bp);
        infoBar = bar;
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (url == null || url.isEmpty()) return;
        player = Players.create(this);
        player.addListener(listener);
        playerView.setPlayer(player);
        message.setText("جارٍ التحميل…");
        message.setVisibility(View.VISIBLE);
        player.setMediaItem(MediaItem.fromUri(url));
        if (startPos > 0) player.seekTo(startPos);
        player.prepare();
        player.play();
    }

    @Override
    protected void onStop() {
        super.onStop();
        saveHistory();
        releasePlayer();
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(hideTitle);
        super.onDestroy();
    }

    private void saveHistory() {
        if (player == null || trackPlaylist < 0 || trackType == null || trackRemote == null) return;
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        if (pos < 5000) return;
        if (dur > 0 && pos > dur * 95 / 100) pos = 0;
        startPos = pos;
        final History h = new History();
        h.playlistId = trackPlaylist;
        h.type = trackType;
        h.remoteId = trackRemote;
        h.name = trackName == null ? "" : trackName;
        h.icon = trackIcon == null ? "" : trackIcon;
        h.episodeTitle = trackEpisode == null ? "" : trackEpisode;
        h.streamUrl = url;
        h.positionMs = pos;
        h.updatedAt = System.currentTimeMillis();
        final Context app = getApplicationContext();
        Async.io(() -> UserDatabase.get(app).dao().putHistory(h));
    }

    private void releasePlayer() {
        if (player != null) {
            player.removeListener(listener);
            playerView.setPlayer(null);
            player.release();
            player = null;
        }
    }
}
