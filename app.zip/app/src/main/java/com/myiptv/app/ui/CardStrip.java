package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.util.Ui;

import java.util.ArrayList;
import java.util.List;

/**
 * A titled horizontal row of cards, used on the home screen. The cards follow the RONI IPTV look:
 * teal glass tiles with a soft edge, a bright cyan frame on focus, wide channel / match tiles with a
 * round logo, and landscape posters with an info strip (title, year, rating).
 */
public final class CardStrip {
    public static final int POSTER = 0;   // movie / series: landscape picture with an info strip
    public static final int CHANNEL = 1;  // wide tile: round channel logo, name, live badge
    public static final int MATCH = 2;    // wide tile: two round team logos, teams, status and score
    public static final int TEXT = 3;     // text only tile (used when no match data is available)

    public static final class Card {
        public int kind = POSTER;
        public String title = "";
        public String subtitle = "";
        public String badge = "";
        public String image = "";
        public String rating = "";
        public int fallback = R.drawable.ic_movie;
        // match fields
        public String league = "";
        public String home = "";
        public String away = "";
        public String homeLogo = "";
        public String awayLogo = "";
        /** Already ordered left-to-right: "away - home". */
        public String score = "";
        public boolean live;
        /** Small badge on a poster (replaces the rating), e.g. the latest episode. */
        public String note = "";
        /** Prominent label across the bottom of a poster, e.g. the new episode number. */
        public String big = "";
        /** Small eye on the poster corner: the episode on this card has not been watched yet. */
        public boolean eye;
        /** Watched part of the episode, 0..100 (a thin red bar at the bottom); -1 = no bar. */
        public int progress = -1;
        public Runnable click;
        /** Long press (or long press OK on a remote). */
        public Runnable longClick;
        /** When set, a star button is shown on a channel tile; it runs this to toggle the favorite. */
        public Runnable onStar;
        public boolean starred;
    }

    // default sizes (dp); the home screen overrides them to fit the screen and the number of rows
    public static final int POSTER_W = 220;
    public static final int POSTER_H = 114;
    public static final int CHANNEL_W = 220;
    public static final int CHANNEL_H = 106;
    public static final int MATCH_W = 220;
    public static final int MATCH_H = 106;

    /** Gives this strip's poster cards their own size (dp). */
    /** Shows the teal "جديد" tag on the poster cards of this strip. */
    public void setNewBadge(boolean on) {
        adapter.newBadge = on;
    }

    public void setPosterSize(int wDp, int hDp) {
        if (adapter.posterW == wDp && adapter.posterH == hDp) return;
        adapter.posterW = wDp;
        adapter.posterH = hDp;
        list.setAdapter(adapter);   // drops the recycled tiles built with the old size
    }

    /** Size (dp) of the wide channel / match tiles of this strip. */
    public void setChannelSize(int wDp, int hDp) {
        if (adapter.channelW == wDp && adapter.channelH == hDp) return;
        adapter.channelW = wDp;
        adapter.channelH = hDp;
        list.setAdapter(adapter);
    }

    /** Height (dp) of the info strip under a poster. */
    public void setInfoStrip(int hDp) {
        if (adapter.stripH == hDp) return;
        adapter.stripH = hDp;
        list.setAdapter(adapter);
    }

    public final LinearLayout view;
    private final TextView heading;
    private final TextView subtitle;
    private final View liveDot;
    private final TextView more;
    private final TextView hint;
    private final FadeList list;
    private final String emptyHint;
    private final Adapter adapter = new Adapter();
    private boolean forceHidden;
    private String countFormat;

    /** @param emptyHint shown under the title when there are no cards; null hides the whole strip. */
    public CardStrip(Context c, String title, String emptyHint) {
        this.emptyHint = emptyHint;
        view = new LinearLayout(c);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setVisibility(View.GONE);
        view.setClipChildren(false);
        // the home screen reads right to left: titles and first cards on the right
        view.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(c, 6), 0, Ui.dp(c, 6), 0);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout titleRow = new LinearLayout(c);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        liveDot = new View(c);
        liveDot.setBackgroundResource(R.drawable.bg_dot_live);
        liveDot.setVisibility(View.GONE);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Ui.dp(c, 10), Ui.dp(c, 10));
        dp.setMarginEnd(Ui.dp(c, 12));
        titleRow.addView(liveDot, dp);
        heading = new TextView(c);
        heading.setText(title);
        heading.setTextColor(ContextCompat.getColor(c, R.color.text));
        heading.setTextSize(24);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        titleRow.addView(heading);
        col.addView(titleRow);

        subtitle = new TextView(c);
        subtitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
        subtitle.setTextSize(14);
        subtitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        subtitle.setVisibility(View.GONE);
        top.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // "عرض الكل ->" at the far end of the title line
        more = new TextView(c);
        more.setText("عرض الكل \u2039");
        more.setTextColor(ContextCompat.getColor(c, R.color.accent));
        more.setTextSize(16);
        more.setTypeface(Typeface.DEFAULT_BOLD);
        more.setTextDirection(View.TEXT_DIRECTION_RTL);
        more.setGravity(Gravity.CENTER);
        more.setBackgroundResource(R.drawable.bg_more);
        more.setPadding(Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 10), Ui.dp(c, 4));
        more.setFocusable(true);
        more.setClickable(true);
        more.setVisibility(View.GONE);
        // left side of the title line: "عرض الكل" with the count under it
        LinearLayout endCol = new LinearLayout(c);
        endCol.setOrientation(LinearLayout.VERTICAL);
        endCol.setGravity(Gravity.END);
        endCol.addView(more, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        endCol.addView(subtitle, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        top.addView(endCol, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        view.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        hint = new TextView(c);
        hint.setTextColor(ContextCompat.getColor(c, R.color.muted));
        hint.setTextSize(16);
        hint.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        hint.setText(emptyHint == null ? "" : emptyHint);
        hint.setVisibility(View.GONE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = Ui.dp(c, 6);
        hp.setMarginStart(Ui.dp(c, 6));
        view.addView(hint, hp);

        list = new FadeList(c);
        // soft shading on the sides of the row: the cards fade out towards the edge where more cards
        // are hidden, and the shading disappears on a side once the row has reached its first / last card
        list.setHorizontalFadingEdgeEnabled(true);
        list.setVerticalFadingEdgeEnabled(false);
        list.setFadingEdgeLength(Ui.dp(c, 44));
        list.setOverScrollMode(View.OVER_SCROLL_NEVER);
        list.setLayoutManager(new CenteringManager(c));
        list.setAdapter(adapter);
        list.setClipToPadding(false);
        list.setItemViewCacheSize(8);
        list.setClipChildren(false);
        list.setPadding(Ui.dp(c, 4), Ui.dp(c, 14), Ui.dp(c, 4), Ui.dp(c, 14));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 2);
        view.addView(list, lp);
    }

    /** Re-draws the tiles (e.g. after a star was toggled). */
    public void refresh() {
        adapter.notifyDataSetChanged();
    }

    public void setTitle(String t) {
        heading.setText(t);
    }

    public void setHint(String t) {
        hint.setText(t);
    }

    /** Small cyan dot before the title (the "live now" rows). */
    public void setLiveDot(boolean on) {
        liveDot.setVisibility(on ? View.VISIBLE : View.GONE);
    }

    /** Line under the title with the number of cards, e.g. "%d قناة متاحة • مباشر"; null = none. */
    public void setCountFormat(String format) {
        countFormat = format;
        updateSubtitle();
    }

    private void updateSubtitle() {
        int n = adapter.data.size();
        if (countFormat == null || n == 0) {
            subtitle.setVisibility(View.GONE);
        } else {
            subtitle.setText(String.format(java.util.Locale.US, countFormat, n));
            subtitle.setVisibility(View.VISIBLE);
        }
    }

    /** Shows "عرض الكل" at the end of the title line; it runs this when chosen. */
    public void setMore(final Runnable r) {
        more.setVisibility(r == null ? View.GONE : View.VISIBLE);
        more.setOnClickListener(r == null ? null : (View.OnClickListener) v -> r.run());
    }

    /** Hides the strip completely, even when it has an empty-state hint. */
    public void setForceHidden(boolean hidden) {
        forceHidden = hidden;
        if (hidden) view.setVisibility(View.GONE);
    }

    public void set(List<Card> cards) {
        adapter.data = cards == null ? new ArrayList<Card>() : cards;
        adapter.notifyDataSetChanged();
        updateSubtitle();
        boolean empty = adapter.data.isEmpty();
        if (forceHidden || (empty && emptyHint == null)) {
            view.setVisibility(View.GONE);
            return;
        }
        view.setVisibility(View.VISIBLE);
        hint.setVisibility(empty ? View.VISIBLE : View.GONE);
        list.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    /** A row whose side shading only shows where cards are hidden (also right-to-left). */
    private static final class FadeList extends RecyclerView {
        FadeList(Context c) {
            super(c);
        }

        // the scroll offsets of a LinearLayoutManager are physical (left based) also in right-to-left
        @Override
        protected float getLeftFadingEdgeStrength() {
            return computeHorizontalScrollOffset() > 0 ? 1f : 0f;
        }

        @Override
        protected float getRightFadingEdgeStrength() {
            return computeHorizontalScrollOffset() + computeHorizontalScrollExtent()
                    < computeHorizontalScrollRange() ? 1f : 0f;
        }
    }

    /**
     * Remote navigation: whenever a card takes focus the row glides (animated) so that card ends up
     * in the middle, instead of jumping only as far as needed to make it visible.
     */
    private static final class CenteringManager extends LinearLayoutManager {
        CenteringManager(Context c) {
            super(c, HORIZONTAL, false);
        }

        @Override
        public boolean requestChildRectangleOnScreen(@NonNull RecyclerView parent, @NonNull View child,
                                                     @NonNull android.graphics.Rect rect,
                                                     boolean immediate, boolean focusedChildVisible) {
            int parentCenter = getPaddingLeft() + (getWidth() - getPaddingLeft() - getPaddingRight()) / 2;
            int childCenter = (getDecoratedLeft(child) + getDecoratedRight(child)) / 2;
            int dx = childCenter - parentCenter;
            if (dx == 0) return false;
            if (immediate) {
                parent.scrollBy(dx, 0);
            } else {
                parent.smoothScrollBy(dx, 0, new android.view.animation.DecelerateInterpolator(1.4f), 260);
            }
            return true;
        }
    }

    // ------------------------------------------------------------ view helpers

    /** Clips an image view to rounded corners. */
    public static void round(ImageView img, final int radiusPx) {
        img.setClipToOutline(true);
        img.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
    }

    public static void load(ImageView img, String url, int fallback, int w, int h) {
        Context c = img.getContext();
        if (url != null && url.startsWith("/")) {   // a local file (a scene grabbed from the episode)
            Glide.with(c).load(new java.io.File(url)).override(w, h).placeholder(fallback)
                    .error(fallback).into(img);
        } else if (url != null && url.startsWith("http")) {
            Glide.with(c).load(url).override(w, h).placeholder(fallback).error(fallback).into(img);
        } else {
            Glide.with(c).clear(img);
            img.setImageResource(fallback);
        }
    }

    private static final class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        List<Card> data = new ArrayList<>();
        boolean newBadge;
        int posterW = POSTER_W;
        int posterH = POSTER_H;
        int channelW = CHANNEL_W;
        int channelH = CHANNEL_H;
        int stripH = 44;

        @Override
        public int getItemViewType(int position) {
            return data.get(position).kind;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            switch (viewType) {
                case MATCH:
                    return buildMatch(c, channelW, channelH);
                case CHANNEL:
                    return channelW < 140 ? buildChannelCompact(c, channelW, channelH)
                            : buildWide(c, false, channelW, channelH);
                case TEXT:
                    return buildText(c, channelW, channelH);
                default:
                    return buildPoster(c, posterW, posterH, stripH);
            }
        }

        private static RecyclerView.LayoutParams itemLp(Context c, int widthDp, int heightDp) {
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    Ui.dp(c, widthDp), Ui.dp(c, heightDp));
            lp.setMarginEnd(Ui.dp(c, 10));
            return lp;
        }

        private static TextView text(Context c, int sp, int colorRes) {
            TextView t = new TextView(c);
            t.setTextSize(sp);
            t.setTextColor(ContextCompat.getColor(c, colorRes));
            t.setMaxLines(1);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            return t;
        }

        /** Clips a container to the rounded inside of a card frame. */
        private static void clipRound(View v, final int radiusPx) {
            v.setClipToOutline(true);
            v.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
                }
            });
        }

        /** A round tile with a logo inside (dark circle, thin teal edge). */
        private static ImageView logoCircle(Context c, FrameLayout holder, int sizeDp, int leftDp) {
            FrameLayout circle = new FrameLayout(c);
            circle.setBackgroundResource(R.drawable.bg_logo_circle);
            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int pad = Ui.dp(c, Math.max(6, sizeDp / 8));
            img.setPadding(pad, pad, pad, pad);
            circle.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            clipRound(circle, Ui.dp(c, sizeDp) / 2);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.dp(c, sizeDp), Ui.dp(c, sizeDp),
                    Gravity.START | Gravity.CENTER_VERTICAL);
            lp.setMarginStart(Ui.dp(c, leftDp));
            holder.addView(circle, lp);
            return img;
        }

        private static VH buildPoster(Context c, int posterW, int posterH, int stripDp) {
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutParams(itemLp(c, posterW, posterH));
            int edge = Ui.dp(c, 3);
            frame.setPadding(edge, edge, edge, edge);

            LinearLayout inner = new LinearLayout(c);
            inner.setOrientation(LinearLayout.VERTICAL);
            clipRound(inner, Ui.dp(c, 19));
            frame.addView(inner, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // ---- picture area
            FrameLayout art = new FrameLayout(c);
            art.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
            inner.addView(art, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);   // the whole poster is shown
            art.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView inTitle = text(c, 13, R.color.muted);
            inTitle.setMaxLines(3);
            inTitle.setGravity(Gravity.CENTER);
            inTitle.setPadding(Ui.dp(c, 8), 0, Ui.dp(c, 8), 0);
            art.addView(inTitle, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // soft shade rising from the bottom edge of the picture
            View shade = new View(c);
            shade.setBackgroundResource(R.drawable.bg_poster_shade);
            art.addView(shade, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, Math.round(posterH * 0.34f)), Gravity.BOTTOM));

            TextView big = text(c, 11, R.color.text);
            big.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            big.setGravity(Gravity.CENTER);
            big.setBackgroundResource(R.drawable.bg_badge_dark);
            big.setPadding(Ui.dp(c, 8), Ui.dp(c, 2), Ui.dp(c, 8), Ui.dp(c, 2));
            big.setVisibility(View.GONE);
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            bp.setMargins(Ui.dp(c, 8), 0, Ui.dp(c, 8), Ui.dp(c, 8));
            art.addView(big, bp);

            // red progress bar: how much of the episode was already watched
            FrameLayout barTrack = new FrameLayout(c);
            // the bar fills left -> right like a normal timeline
            barTrack.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            barTrack.setBackgroundColor(0x88000000);
            barTrack.setVisibility(View.GONE);
            View barFill = new View(c);
            barFill.setBackgroundColor(0xFFE53935);
            barTrack.addView(barFill, new FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT,
                    Gravity.START));
            art.addView(barTrack, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 4), Gravity.BOTTOM));

            // eye: this (new episode) card has not been watched yet
            ImageView eye = new ImageView(c);
            eye.setImageResource(R.drawable.ic_eye);
            eye.setColorFilter(ContextCompat.getColor(c, R.color.eye));
            eye.setBackgroundResource(R.drawable.bg_badge_dark);
            eye.setPadding(Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3));
            eye.setVisibility(View.GONE);
            FrameLayout.LayoutParams eyp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 28), Ui.dp(c, 28), Gravity.TOP | Gravity.END);
            eyp.setMargins(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), 0);
            art.addView(eye, eyp);

            // teal "جديد" tag, top corner opposite to the rating
            TextView newTag = text(c, 10, R.color.on_accent);
            newTag.setText("جديد");
            newTag.setTypeface(Typeface.DEFAULT_BOLD);
            newTag.setBackgroundResource(R.drawable.bg_new_tag);
            newTag.setPadding(Ui.dp(c, 6), Ui.dp(c, 2), Ui.dp(c, 6), Ui.dp(c, 2));
            newTag.setVisibility(View.GONE);
            FrameLayout.LayoutParams ntp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.END);
            ntp.setMargins(0, Ui.dp(c, 5), Ui.dp(c, 5), 0);
            art.addView(newTag, ntp);

            // ---- info strip: title and meta in the middle, the rating pill at the start
            FrameLayout strip = new FrameLayout(c);
            strip.setBackgroundColor(ContextCompat.getColor(c, R.color.strip_dark));
            inner.addView(strip, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, stripDp)));

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            int side = Ui.dp(c, 4);
            col.setPadding(side, 0, side, 0);
            TextView title = text(c, 13, R.color.text);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setGravity(Gravity.CENTER);
            col.addView(title, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView meta = text(c, 10, R.color.muted);
            meta.setGravity(Gravity.CENTER);
            col.addView(meta, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            strip.addView(col, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView rating = text(c, 11, R.color.text);
            rating.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            rating.setTextDirection(View.TEXT_DIRECTION_LTR);
            rating.setBackgroundResource(R.drawable.bg_pill);
            rating.setPadding(Ui.dp(c, 6), Ui.dp(c, 2), Ui.dp(c, 6), Ui.dp(c, 2));
            FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.TOP | Gravity.START);
            rp.setMargins(Ui.dp(c, 5), Ui.dp(c, 5), 0, 0);
            art.addView(rating, rp);   // small badge on the corner of the poster
            CardFx.attach(frame, frame, title);

            VH h = new VH(frame, frame);
            h.img = img;
            h.title = title;
            h.sub = meta;
            h.shade = shade;
            h.eyeView = eye;
            h.inTitle = inTitle;
            h.rating = rating;
            h.newTag = newTag;
            h.big = big;
            h.barTrack = barTrack;
            h.barFill = barFill;
            h.barWidthPx = Ui.dp(c, Math.max(20, posterW - 6));
            return h;
        }

        /**
         * The wide tile shared by channels and matches: round logo(s) at the start, then the name,
         * a grey line, and at the bottom the live status on one side and a small pill on the other.
         */
        private static VH buildWide(Context c, boolean match, int w, int hgt) {
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutParams(itemLp(c, w, hgt));

            int logo = Math.max(40, Math.round(hgt * (match ? 0.46f : 0.56f)));
            int pad = Ui.dp(c, 14);
            ImageView logoA;
            ImageView logoB = null;
            int logosW;
            if (match) {
                // two overlapping circles: the home team in front of the away team
                logoB = logoCircle(c, frame, logo, 14);
                logoA = logoCircle(c, frame, logo, 14 + Math.round(logo * 0.62f));
                logosW = 14 + Math.round(logo * 1.62f);
            } else {
                logoA = logoCircle(c, frame, logo, 14);
                logosW = 14 + logo;
            }

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_VERTICAL);
            FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            cp.setMarginStart(Ui.dp(c, logosW + 10));
            cp.setMarginEnd(pad);
            cp.topMargin = Ui.dp(c, 6);
            cp.bottomMargin = Ui.dp(c, 8);
            frame.addView(col, cp);

            TextView title = text(c, match ? 14 : 17, R.color.text);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setGravity(Gravity.START);
            title.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
            if (match) title.setMaxLines(2);
            col.addView(title, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView sub = text(c, 11, R.color.muted);
            sub.setGravity(Gravity.START);
            sub.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
            col.addView(sub, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            LinearLayout bottom = new LinearLayout(c);
            bottom.setOrientation(LinearLayout.HORIZONTAL);
            bottom.setGravity(Gravity.CENTER_VERTICAL);
            View dot = new View(c);
            dot.setBackgroundResource(R.drawable.bg_dot_red);
            LinearLayout.LayoutParams dotp = new LinearLayout.LayoutParams(Ui.dp(c, 8), Ui.dp(c, 8));
            dotp.setMarginEnd(Ui.dp(c, 6));
            bottom.addView(dot, dotp);
            TextView status = text(c, 12, R.color.text);
            status.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            bottom.addView(status, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView pill = text(c, 12, R.color.text);
            pill.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            pill.setTextDirection(View.TEXT_DIRECTION_LTR);
            pill.setBackgroundResource(R.drawable.bg_pill);
            pill.setPadding(Ui.dp(c, 9), Ui.dp(c, 2), Ui.dp(c, 9), Ui.dp(c, 2));
            bottom.addView(pill, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bl.topMargin = Ui.dp(c, 5);
            col.addView(bottom, bl);

            // favorite star: tap on a touch screen, long-press OK on a remote
            TextView star = new TextView(c);
            star.setTextSize(15);
            star.setGravity(Gravity.CENTER);
            star.setBackgroundResource(R.drawable.bg_badge_dark);
            star.setClickable(true);
            star.setFocusable(false);
            star.setVisibility(View.GONE);
            FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 26), Ui.dp(c, 26), Gravity.TOP | Gravity.END);
            sp.setMargins(0, Ui.dp(c, 8), Ui.dp(c, 8), 0);
            frame.addView(star, sp);
            CardFx.attach(frame, frame, title);

            VH h = new VH(frame, frame);
            h.img = logoA;
            h.title = title;
            h.sub = sub;
            h.star = star;
            h.liveDotView = dot;
            h.status = status;
            h.pill = pill;
            h.col = col;
            if (match) {
                h.homeLogo = logoA;
                h.awayLogo = logoB;
            }
            return h;
        }

        /** Small channel tile (8 per row): round logo, name under it, live dot. */
        private static VH buildChannelCompact(Context c, int w, int hgt) {
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutParams(itemLp(c, w, hgt));

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            col.setPadding(Ui.dp(c, 4), Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 6));
            frame.addView(col, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            int logo = Math.max(34, Math.round(w * 0.58f));
            FrameLayout circle = new FrameLayout(c);
            circle.setBackgroundResource(R.drawable.bg_logo_circle);
            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int ip = Ui.dp(c, Math.max(5, logo / 8));
            img.setPadding(ip, ip, ip, ip);
            circle.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            clipRound(circle, Ui.dp(c, logo) / 2);
            col.addView(circle, new LinearLayout.LayoutParams(Ui.dp(c, logo), Ui.dp(c, logo)));

            TextView title = text(c, 11, R.color.text);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setMaxLines(2);
            title.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(c, 5);
            col.addView(title, tp);

            LinearLayout bottom = new LinearLayout(c);
            bottom.setOrientation(LinearLayout.HORIZONTAL);
            bottom.setGravity(Gravity.CENTER);
            View dot = new View(c);
            dot.setBackgroundResource(R.drawable.bg_dot_red);
            LinearLayout.LayoutParams dotp = new LinearLayout.LayoutParams(Ui.dp(c, 6), Ui.dp(c, 6));
            dotp.setMarginEnd(Ui.dp(c, 4));
            bottom.addView(dot, dotp);
            TextView status = text(c, 10, R.color.text);
            bottom.addView(status, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bl.topMargin = Ui.dp(c, 3);
            col.addView(bottom, bl);

            TextView star = new TextView(c);
            star.setTextSize(11);
            star.setGravity(Gravity.CENTER);
            star.setBackgroundResource(R.drawable.bg_badge_dark);
            star.setClickable(true);
            star.setFocusable(false);
            star.setVisibility(View.GONE);
            FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 20), Ui.dp(c, 20), Gravity.TOP | Gravity.END);
            sp.setMargins(Ui.dp(c, 4), Ui.dp(c, 4), Ui.dp(c, 4), 0);
            frame.addView(star, sp);
            CardFx.attach(frame, frame, title);

            VH h = new VH(frame, frame);
            h.img = img;
            h.title = title;
            h.sub = new TextView(c);      // not shown on the small tile
            h.pill = new TextView(c);
            h.col = new LinearLayout(c);
            h.star = star;
            h.liveDotView = dot;
            h.status = status;
            return h;
        }

        /** Match tile: each team on its own side with its name under the flag, score in the middle. */
        private static VH buildMatch(Context c, int w, int hgt) {
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);   // away - score - home, like the score
            frame.setLayoutParams(itemLp(c, w, hgt));

            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(c, 6), Ui.dp(c, 8), Ui.dp(c, 6), Ui.dp(c, 8));
            frame.addView(row, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            int logo = Math.max(40, Math.round(hgt * 0.44f));
            TextView[] names = new TextView[2];
            ImageView[] logos = new ImageView[2];
            for (int i = 0; i < 2; i++) {
                LinearLayout team = new LinearLayout(c);
                team.setOrientation(LinearLayout.VERTICAL);
                team.setGravity(Gravity.CENTER_HORIZONTAL);
                FrameLayout circle = new FrameLayout(c);
                circle.setBackgroundResource(R.drawable.bg_logo_circle);
                ImageView img = new ImageView(c);
                img.setScaleType(ImageView.ScaleType.FIT_CENTER);
                int ip = Ui.dp(c, Math.max(5, logo / 8));
                img.setPadding(ip, ip, ip, ip);
                circle.addView(img, new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
                clipRound(circle, Ui.dp(c, logo) / 2);
                team.addView(circle, new LinearLayout.LayoutParams(Ui.dp(c, logo), Ui.dp(c, logo)));
                TextView name = text(c, 11, R.color.text);
                name.setTypeface(Typeface.DEFAULT_BOLD);
                name.setMaxLines(2);
                name.setGravity(Gravity.CENTER);
                LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                np.topMargin = Ui.dp(c, 4);
                team.addView(name, np);
                names[i] = name;
                logos[i] = img;
                if (i == 0) {
                    row.addView(team, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                    row.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 0f)); // placeholder, replaced below
                } else {
                    row.addView(team, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
                }
            }
            // middle column: league, score / time, status
            LinearLayout mid = new LinearLayout(c);
            mid.setOrientation(LinearLayout.VERTICAL);
            mid.setGravity(Gravity.CENTER);
            TextView sub = text(c, 10, R.color.muted);
            sub.setMaxLines(2);
            sub.setGravity(Gravity.CENTER);
            mid.addView(sub, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView pill = text(c, 13, R.color.text);
            pill.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            pill.setTextDirection(View.TEXT_DIRECTION_LTR);
            pill.setBackgroundResource(R.drawable.bg_pill);
            pill.setPadding(Ui.dp(c, 8), Ui.dp(c, 2), Ui.dp(c, 8), Ui.dp(c, 2));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            pp.topMargin = Ui.dp(c, 4);
            mid.addView(pill, pp);
            LinearLayout bottom = new LinearLayout(c);
            bottom.setOrientation(LinearLayout.HORIZONTAL);
            bottom.setGravity(Gravity.CENTER);
            View dot = new View(c);
            dot.setBackgroundResource(R.drawable.bg_dot_red);
            LinearLayout.LayoutParams dotp = new LinearLayout.LayoutParams(Ui.dp(c, 7), Ui.dp(c, 7));
            dotp.setMarginEnd(Ui.dp(c, 4));
            bottom.addView(dot, dotp);
            TextView status = text(c, 11, R.color.text);
            status.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            bottom.addView(status, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bl.topMargin = Ui.dp(c, 4);
            mid.addView(bottom, bl);
            // swap the placeholder for the middle column
            row.removeViewAt(1);
            row.addView(mid, 1, new LinearLayout.LayoutParams(Ui.dp(c, 84), ViewGroup.LayoutParams.WRAP_CONTENT));

            TextView title = new TextView(c);   // kept for the focus effect only
            CardFx.attach(frame, frame, title);

            VH h = new VH(frame, frame);
            h.title = title;
            h.sub = sub;
            h.pill = pill;
            h.status = status;
            h.liveDotView = dot;
            h.star = new TextView(c);
            h.col = new LinearLayout(c);
            h.awayLogo = logos[0];
            h.homeLogo = logos[1];
            h.img = logos[1];
            h.awayName = names[0];
            h.homeName = names[1];
            return h;
        }

        private static VH buildText(Context c, int w, int hgt) {
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_match);
            card.setFocusable(true);
            card.setClickable(true);
            card.setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10));
            card.setLayoutParams(itemLp(c, w, hgt));

            TextView badge = text(c, 11, R.color.muted);
            badge.setPadding(Ui.dp(c, 6), Ui.dp(c, 1), Ui.dp(c, 6), Ui.dp(c, 1));
            card.addView(badge, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView title = text(c, 14, R.color.text);
            title.setMaxLines(2);
            title.setGravity(Gravity.START);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(c, 6);
            card.addView(title, tp);
            TextView sub = text(c, 12, R.color.muted);
            sub.setGravity(Gravity.START);
            card.addView(sub);

            VH h = new VH(card, card);
            h.badge = badge;
            h.title = title;
            h.sub = sub;
            return h;
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Card card = data.get(position);
            Context c = h.itemView.getContext();
            // Entering the side menu from the first card is handled by MainActivity (it picks the
            // menu item of the open section); no per-card key listener any more.
            h.click.setOnKeyListener(null);
            if (card.kind == POSTER || card.kind == CHANNEL || card.kind == MATCH) {
                CardFx.sync(h.itemView, h.click, h.title);
            }
            h.click.setOnClickListener(v -> {
                if (card.click != null) card.click.run();
            });
            if (card.longClick != null) {
                h.click.setOnLongClickListener(v -> {
                    card.longClick.run();
                    return true;
                });
            } else {
                h.click.setOnLongClickListener(null);
            }
            switch (card.kind) {
                case MATCH: {
                    h.click.setBackgroundResource(card.live ? R.drawable.bg_match_live : R.drawable.bg_poster);
                    h.title.setText(card.home + " vs " + card.away);
                    h.homeName.setText(card.home);
                    h.awayName.setText(card.away);
                    h.sub.setText(card.league);
                    h.sub.setVisibility(card.league == null || card.league.isEmpty() ? View.GONE : View.VISIBLE);
                    boolean hasBadge = card.badge != null && !card.badge.isEmpty();
                    h.status.setText(card.badge);
                    h.status.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.liveDotView.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.liveDotView.setBackground(dotDrawable(c, card.live ? 0xFFFF4D5E : 0xFF7FB4BF));
                    h.status.setTextColor(card.live ? 0xFFFF7A88 : ContextCompat.getColor(c, R.color.muted));
                    boolean hasScore = card.score != null && !card.score.isEmpty();
                    h.pill.setVisibility(hasScore ? View.VISIBLE : View.GONE);
                    h.pill.setText(card.score);
                    h.star.setVisibility(View.GONE);
                    load(h.homeLogo, card.homeLogo, R.drawable.ic_live, 120, 120);
                    load(h.awayLogo, card.awayLogo, R.drawable.ic_live, 120, 120);
                    break;
                }
                case CHANNEL: {
                    h.title.setText(card.title);
                    boolean hasSub = card.subtitle != null && !card.subtitle.isEmpty();
                    h.sub.setText(card.subtitle);
                    h.sub.setVisibility(hasSub ? View.VISIBLE : View.GONE);
                    h.status.setText("مباشر");
                    h.status.setTextColor(ContextCompat.getColor(c, R.color.text));
                    h.liveDotView.setVisibility(View.VISIBLE);
                    h.liveDotView.setBackground(dotDrawable(c, 0xFF2CD9E0));
                    boolean hasPill = card.badge != null && !card.badge.isEmpty();
                    h.pill.setVisibility(hasPill ? View.VISIBLE : View.GONE);
                    h.pill.setText(card.badge);
                    load(h.img, card.image, card.fallback, 240, 240);
                    h.col.setPadding(0, 0, card.onStar != null ? Ui.dp(c, 16) : 0, 0);
                    if (card.onStar != null && h.star != null) {
                        h.star.setVisibility(View.VISIBLE);
                        h.star.setText(card.starred ? "\u2605" : "\u2606");
                        h.star.setTextColor(card.starred ? 0xFFFFC107 : ContextCompat.getColor(c, R.color.text));
                        h.star.setOnClickListener(v -> card.onStar.run());
                        if (card.longClick == null) {
                            h.click.setOnLongClickListener(v -> {
                                card.onStar.run();
                                return true;
                            });
                        }
                    } else if (h.star != null) {
                        h.star.setVisibility(View.GONE);
                    }
                    break;
                }
                case TEXT: {
                    h.title.setText(card.title);
                    h.sub.setText(card.subtitle);
                    h.sub.setVisibility(card.subtitle == null || card.subtitle.isEmpty() ? View.GONE : View.VISIBLE);
                    boolean hasBadge = card.badge != null && !card.badge.isEmpty();
                    h.badge.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.badge.setText(card.badge);
                    h.badge.setBackgroundResource(R.drawable.bg_badge_live);
                    h.badge.setTextColor(0xFFFF7A88);
                    break;
                }
                default: {
                    h.title.setText(card.title);
                    boolean hasMeta = card.subtitle != null && !card.subtitle.isEmpty();
                    h.sub.setText(card.subtitle);
                    h.sub.setVisibility(hasMeta ? View.VISIBLE : View.GONE);
                    boolean hasImg = card.image != null
                            && (card.image.startsWith("http") || card.image.startsWith("/"));
                    h.inTitle.setText(card.title);
                    h.inTitle.setVisibility(hasImg ? View.GONE : View.VISIBLE);
                    h.shade.setVisibility(hasImg ? View.VISIBLE : View.GONE);
                    if (hasImg) {
                        h.img.setScaleType(card.image.startsWith("/")
                                ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
                        load(h.img, card.image, android.R.color.transparent, 400, 600);
                    } else {
                        Glide.with(c).clear(h.img);
                        h.img.setImageDrawable(null);
                    }
                    boolean hasRating = card.rating != null && !card.rating.isEmpty()
                            && !"0".equals(card.rating) && !"0.0".equals(card.rating);
                    boolean hasNote = card.note != null && !card.note.isEmpty();
                    boolean hasBig = card.big != null && !card.big.isEmpty();
                    h.eyeView.setVisibility(card.eye ? View.VISIBLE : View.GONE);
                    h.newTag.setVisibility(newBadge && !card.eye ? View.VISIBLE : View.GONE);
                    h.big.setVisibility(hasBig ? View.VISIBLE : View.GONE);
                    h.big.setText(card.big);
                    boolean hasBar = card.progress >= 0;
                    h.barTrack.setVisibility(hasBar ? View.VISIBLE : View.GONE);
                    if (hasBar) {
                        ViewGroup.LayoutParams fp = h.barFill.getLayoutParams();
                        fp.width = Math.max(Ui.dp(c, 3), h.barWidthPx * Math.min(100, card.progress) / 100);
                        h.barFill.setLayoutParams(fp);
                    }
                    // the episode label sits above the bar when there is one
                    FrameLayout.LayoutParams bl = (FrameLayout.LayoutParams) h.big.getLayoutParams();
                    bl.bottomMargin = Ui.dp(c, hasBar ? 12 : 8);
                    h.big.setLayoutParams(bl);
                    if (hasNote) {
                        h.rating.setVisibility(View.VISIBLE);
                        h.rating.setText(card.note);
                    } else {
                        h.rating.setVisibility(hasRating ? View.VISIBLE : View.GONE);
                        h.rating.setText(goldStar(card.rating));
                    }
                    break;
                }
            }
        }

        /** "★ 8.6" with a gold star. */
        private static CharSequence goldStar(String rating) {
            android.text.SpannableString sp = new android.text.SpannableString("\u2605 " + rating);
            sp.setSpan(new android.text.style.ForegroundColorSpan(0xFFFFB300), 0, 1,
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            return sp;
        }

        private static android.graphics.drawable.Drawable dotDrawable(Context c, int color) {
            android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
            d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            d.setColor(color);
            return d;
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static final class VH extends RecyclerView.ViewHolder {
            final View click;
            View barTrack, barFill, shade, liveDotView;
            LinearLayout col;
            int barWidthPx;
            ImageView img, homeLogo, awayLogo, eyeView;
            TextView title, sub, badge, inTitle, rating, star, big, status, pill, homeName, awayName, newTag;

            VH(@NonNull View v, View click) {
                super(v);
                this.click = click;
            }
        }
    }
}
