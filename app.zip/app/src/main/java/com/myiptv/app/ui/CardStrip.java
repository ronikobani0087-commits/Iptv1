package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.util.Ui;

import java.util.ArrayList;
import java.util.List;

/**
 * A titled horizontal row of cards, used on the home screen. The cards follow the RONI IPTV look:
 * teal glass tiles with a soft edge, a bright cyan frame on focus, wide channel / match tiles with a
 * round logo, and landscape posters with an info strip (title, year, rating).
 */
public final class CardStrip {
    public static final int POSTER = 0;   // movie / series: landscape picture with an info strip
    public static final int CHANNEL = 1;  // wide tile: round channel logo, name, live badge
    public static final int MATCH = 2;    // wide tile: two round team logos, teams, status and score
    public static final int TEXT = 3;     // text only tile (used when no match data is available)

    public static final class Card {
        public int kind = POSTER;
        public String title = "";
        public String subtitle = "";
        public String badge = "";
        public String image = "";
        public String rating = "";
        public int fallback = R.drawable.ic_movie;
        // match fields
        public String league = "";
        public String home = "";
        public String away = "";
        public String homeLogo = "";
        public String awayLogo = "";
        /** Already ordered left-to-right: "away - home". */
        public String score = "";
        public boolean live;
        /** Small badge on a poster (replaces the rating), e.g. the latest episode. */
        public String note = "";
        /** Prominent label across the bottom of a poster, e.g. the new episode number. */
        public String big = "";
        /** Small eye on the poster corner: the episode on this card has not been watched yet. */
        public boolean eye;
        /** Watched part of the episode, 0..100 (a thin red bar at the bottom); -1 = no bar. */
        public int progress = -1;
        public Runnable click;
        /** Long press (or long press OK on a remote). */
        public Runnable longClick;
        /** When set, a star button is shown on a channel tile; it runs this to toggle the favorite. */
        public Runnable onStar;
        public boolean starred;
    }

    // default sizes (dp); the home screen overrides them to fit the screen and the number of rows
    public static final int POSTER_W = 220;
    public static final int POSTER_H = 114;
    public static final int CHANNEL_W = 220;
    public static final int CHANNEL_H = 106;
    public static final int MATCH_W = 220;
    public static final int MATCH_H = 106;

    /** Gives this strip's poster cards their own size (dp). */
    public void setPosterSize(int wDp, int hDp) {
        if (adapter.posterW == wDp && adapter.posterH == hDp) return;
        adapter.posterW = wDp;
        adapter.posterH = hDp;
        list.setAdapter(adapter);   // drops the recycled tiles built with the old size
    }

    /** Size (dp) of the wide channel / match tiles of this strip. */
    public void setChannelSize(int wDp, int hDp) {
        if (adapter.channelW == wDp && adapter.channelH == hDp) return;
        adapter.channelW = wDp;
        adapter.channelH = hDp;
        list.setAdapter(adapter);
    }

    /** Height (dp) of the info strip under a poster. */
    public void setInfoStrip(int hDp) {
        if (adapter.stripH == hDp) return;
        adapter.stripH = hDp;
        list.setAdapter(adapter);
    }

    /**
     * Channel tiles as small square cards (big round logo, name under it) so about eight fit in
     * one row instead of three wide tiles. Matches are not affected.
     */
    public void setCompactChannels(boolean on) {
        if (adapter.compact == on) return;
        adapter.compact = on;
        adapter.gap = (on || adapter.portrait) ? 10 : 14;
        list.setAdapter(adapter);
    }

    /**
     * Portrait poster cards (2:3) that show the whole poster picture, with a narrow info strip, so
     * about eight fit in one row.
     */
    public void setFullPosters(boolean on) {
        if (adapter.portrait == on) return;
        adapter.portrait = on;
        adapter.gap = (on || adapter.compact) ? 10 : 14;
        list.setAdapter(adapter);
    }

    public final LinearLayout view;
    private final TextView heading;
    private final TextView subtitle;
    private final View liveDot;
    private final TextView more;
    private final TextView hint;
    private final RecyclerView list;
    private final String emptyHint;
    private final Adapter adapter = new Adapter();
    private boolean forceHidden;
    private String countFormat;

    /** @param emptyHint shown under the title when there are no cards; null hides the whole strip. */
    public CardStrip(Context c, String title, String emptyHint) {
        this.emptyHint = emptyHint;
        view = new LinearLayout(c);
        view.setOrientation(LinearLayout.VERTICAL);
        view.setVisibility(View.GONE);
        view.setClipChildren(false);
        // the home screen reads right to left
        view.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout top = new LinearLayout(c);
        top.setOrientation(LinearLayout.HORIZONTAL);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(Ui.dp(c, 6), 0, Ui.dp(c, 6), 0);

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);

        LinearLayout titleRow = new LinearLayout(c);
        titleRow.setOrientation(LinearLayout.HORIZONTAL);
        titleRow.setGravity(Gravity.CENTER_VERTICAL);
        liveDot = new View(c);
        liveDot.setBackgroundResource(R.drawable.bg_dot_live);
        liveDot.setVisibility(View.GONE);
        LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Ui.dp(c, 10), Ui.dp(c, 10));
        dp.setMarginEnd(Ui.dp(c, 12));
        titleRow.addView(liveDot, dp);
        heading = new TextView(c);
        heading.setText(title);
        heading.setTextColor(ContextCompat.getColor(c, R.color.text));
        heading.setTextSize(24);
        heading.setTypeface(Typeface.DEFAULT_BOLD);
        heading.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        titleRow.addView(heading);
        col.addView(titleRow);

        subtitle = new TextView(c);
        subtitle.setTextColor(ContextCompat.getColor(c, R.color.muted));
        subtitle.setTextSize(14);
        subtitle.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        subtitle.setVisibility(View.GONE);
        col.addView(subtitle);
        top.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        // "عرض الكل ->" at the far end of the title line
        more = new TextView(c);
        more.setText("عرض الكل \u2190");
        more.setTextColor(ContextCompat.getColor(c, R.color.muted));
        more.setTextSize(15);
        more.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        more.setGravity(Gravity.CENTER);
        more.setBackgroundResource(R.drawable.bg_more);
        more.setPadding(Ui.dp(c, 10), Ui.dp(c, 4), Ui.dp(c, 10), Ui.dp(c, 4));
        more.setFocusable(true);
        more.setClickable(true);
        more.setVisibility(View.GONE);
        top.addView(more, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        view.addView(top, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        hint = new TextView(c);
        hint.setTextColor(ContextCompat.getColor(c, R.color.muted));
        hint.setTextSize(16);
        hint.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        hint.setText(emptyHint == null ? "" : emptyHint);
        hint.setVisibility(View.GONE);
        LinearLayout.LayoutParams hp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.topMargin = Ui.dp(c, 6);
        hp.setMarginStart(Ui.dp(c, 6));
        view.addView(hint, hp);

        list = new RecyclerView(c);
        list.setLayoutManager(new CenteringManager(c));
        list.setAdapter(adapter);
        list.setClipToPadding(false);
        list.setItemViewCacheSize(8);
        list.setClipChildren(false);
        list.setPadding(Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 2);
        view.addView(list, lp);
    }

    /** Re-draws the tiles (e.g. after a star was toggled). */
    public void refresh() {
        adapter.notifyDataSetChanged();
    }

    public void setTitle(String t) {
        heading.setText(t);
    }

    public void setHint(String t) {
        hint.setText(t);
    }

    /** Small cyan dot before the title (the "live now" rows). */
    public void setLiveDot(boolean on) {
        liveDot.setVisibility(on ? View.VISIBLE : View.GONE);
    }

    /** Line under the title with the number of cards, e.g. "%d قناة متاحة • مباشر"; null = none. */
    public void setCountFormat(String format) {
        countFormat = format;
        updateSubtitle();
    }

    private void updateSubtitle() {
        int n = adapter.data.size();
        if (countFormat == null || n == 0) {
            subtitle.setVisibility(View.GONE);
        } else {
            subtitle.setText(String.format(java.util.Locale.US, countFormat, n));
            subtitle.setVisibility(View.VISIBLE);
        }
    }

    /** Shows "عرض الكل" at the end of the title line; it runs this when chosen. */
    public void setMore(final Runnable r) {
        more.setVisibility(r == null ? View.GONE : View.VISIBLE);
        more.setOnClickListener(r == null ? null : (View.OnClickListener) v -> r.run());
    }

    /** Hides the strip completely, even when it has an empty-state hint. */
    public void setForceHidden(boolean hidden) {
        forceHidden = hidden;
        if (hidden) view.setVisibility(View.GONE);
    }

    public void set(List<Card> cards) {
        adapter.data = cards == null ? new ArrayList<Card>() : cards;
        adapter.notifyDataSetChanged();
        updateSubtitle();
        boolean empty = adapter.data.isEmpty();
        if (forceHidden || (empty && emptyHint == null)) {
            view.setVisibility(View.GONE);
            return;
        }
        view.setVisibility(View.VISIBLE);
        hint.setVisibility(empty ? View.VISIBLE : View.GONE);
        list.setVisibility(empty ? View.GONE : View.VISIBLE);
    }

    /**
     * Remote navigation: whenever a card takes focus the row glides (animated) so that card ends up
     * in the middle, instead of jumping only as far as needed to make it visible.
     */
    private static final class CenteringManager extends LinearLayoutManager {
        CenteringManager(Context c) {
            super(c, HORIZONTAL, false);
        }

        @Override
        public boolean requestChildRectangleOnScreen(@NonNull RecyclerView parent, @NonNull View child,
                                                     @NonNull android.graphics.Rect rect,
                                                     boolean immediate, boolean focusedChildVisible) {
            int parentCenter = getPaddingLeft() + (getWidth() - getPaddingLeft() - getPaddingRight()) / 2;
            int childCenter = (getDecoratedLeft(child) + getDecoratedRight(child)) / 2;
            int dx = childCenter - parentCenter;
            if (dx == 0) return false;
            if (immediate) {
                parent.scrollBy(dx, 0);
            } else {
                parent.smoothScrollBy(dx, 0, new android.view.animation.DecelerateInterpolator(1.4f), 260);
            }
            return true;
        }
    }

    // ------------------------------------------------------------ view helpers

    /** Clips an image view to rounded corners. */
    public static void round(ImageView img, final int radiusPx) {
        img.setClipToOutline(true);
        img.setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline outline) {
                outline.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
    }

    public static void load(ImageView img, String url, int fallback, int w, int h) {
        Context c = img.getContext();
        if (url != null && url.startsWith("/")) {   // a local file (a scene grabbed from the episode)
            Glide.with(c).load(new java.io.File(url)).override(w, h).placeholder(fallback)
                    .error(fallback).into(img);
        } else if (url != null && url.startsWith("http")) {
            Glide.with(c).load(url).override(w, h).placeholder(fallback).error(fallback).into(img);
        } else {
            Glide.with(c).clear(img);
            img.setImageResource(fallback);
        }
    }

    private static final class Adapter extends RecyclerView.Adapter<Adapter.VH> {
        List<Card> data = new ArrayList<>();
        int posterW = POSTER_W;
        int posterH = POSTER_H;
        int channelW = CHANNEL_W;
        int channelH = CHANNEL_H;
        int stripH = 44;
        boolean compact;    // small square channel tiles
        boolean portrait;   // whole-poster portrait cards
        int gap = 14;       // space between cards (dp)

        @Override
        public int getItemViewType(int position) {
            return data.get(position).kind;
        }

        @NonNull
        @Override
        public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            Context c = parent.getContext();
            switch (viewType) {
                case MATCH:
                    return buildWide(c, true, channelW, channelH);
                case CHANNEL:
                    return compact ? buildCompactChannel(c, channelW, channelH, gap)
                            : buildWide(c, false, channelW, channelH);
                case TEXT:
                    return buildText(c, channelW, channelH);
                default:
                    return buildPoster(c, posterW, posterH, stripH, portrait, gap);
            }
        }

        private static RecyclerView.LayoutParams itemLp(Context c, int widthDp, int heightDp) {
            return itemLp(c, widthDp, heightDp, 14);
        }

        private static RecyclerView.LayoutParams itemLp(Context c, int widthDp, int heightDp, int gapDp) {
            RecyclerView.LayoutParams lp = new RecyclerView.LayoutParams(
                    Ui.dp(c, widthDp), Ui.dp(c, heightDp));
            lp.setMarginEnd(Ui.dp(c, gapDp));
            return lp;
        }

        private static TextView text(Context c, int sp, int colorRes) {
            TextView t = new TextView(c);
            t.setTextSize(sp);
            t.setTextColor(ContextCompat.getColor(c, colorRes));
            t.setMaxLines(1);
            t.setEllipsize(TextUtils.TruncateAt.END);
            t.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
            return t;
        }

        /** Clips a container to the rounded inside of a card frame. */
        private static void clipRound(View v, final int radiusPx) {
            v.setClipToOutline(true);
            v.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radiusPx);
                }
            });
        }

        /** A round tile with a logo inside (dark circle, thin teal edge). */
        private static ImageView logoCircle(Context c, FrameLayout holder, int sizeDp, int leftDp) {
            FrameLayout circle = new FrameLayout(c);
            circle.setBackgroundResource(R.drawable.bg_logo_circle);
            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int pad = Ui.dp(c, Math.max(6, sizeDp / 8));
            img.setPadding(pad, pad, pad, pad);
            circle.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            clipRound(circle, Ui.dp(c, sizeDp) / 2);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.dp(c, sizeDp), Ui.dp(c, sizeDp),
                    Gravity.START | Gravity.CENTER_VERTICAL);
            lp.setMarginStart(Ui.dp(c, leftDp));
            holder.addView(circle, lp);
            return img;
        }

        /**
         * Small square channel tile: a big round logo with the channel name under it. A cyan dot
         * (live) sits in one corner and the favorite star in the other.
         */
        private static VH buildCompactChannel(Context c, int w, int hgt, int gap) {
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutParams(itemLp(c, w, hgt, gap));

            LinearLayout box = new LinearLayout(c);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setGravity(Gravity.CENTER_HORIZONTAL);
            box.setPadding(Ui.dp(c, 5), Ui.dp(c, 8), Ui.dp(c, 5), Ui.dp(c, 5));
            frame.addView(box, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            int logo = Math.max(36, w - 20);
            FrameLayout circle = new FrameLayout(c);
            circle.setBackgroundResource(R.drawable.bg_logo_circle);
            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int ipad = Ui.dp(c, Math.max(5, logo / 8));
            img.setPadding(ipad, ipad, ipad, ipad);
            circle.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            clipRound(circle, Ui.dp(c, logo) / 2);
            box.addView(circle, new LinearLayout.LayoutParams(Ui.dp(c, logo), Ui.dp(c, logo)));

            TextView title = text(c, 11, R.color.text);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setGravity(Gravity.CENTER);
            title.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            title.setMaxLines(2);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
            tp.topMargin = Ui.dp(c, 4);
            box.addView(title, tp);

            View dot = new View(c);
            dot.setBackgroundResource(R.drawable.bg_dot_red);
            FrameLayout.LayoutParams dp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 7), Ui.dp(c, 7), Gravity.TOP | Gravity.START);
            dp.setMargins(Ui.dp(c, 7), Ui.dp(c, 7), 0, 0);
            frame.addView(dot, dp);

            TextView star = new TextView(c);
            star.setTextSize(13);
            star.setGravity(Gravity.CENTER);
            star.setBackgroundResource(R.drawable.bg_badge_dark);
            star.setClickable(true);
            star.setFocusable(false);
            star.setVisibility(View.GONE);
            FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 22), Ui.dp(c, 22), Gravity.TOP | Gravity.END);
            sp.setMargins(0, Ui.dp(c, 5), Ui.dp(c, 5), 0);
            frame.addView(star, sp);
            CardFx.attach(frame, frame, title);

            VH h = new VH(frame, frame);
            h.img = img;
            h.title = title;
            h.star = star;
            h.liveDotView = dot;
            // the bind code fills these too, but this small tile has no room for them
            h.sub = text(c, 11, R.color.muted);
            h.status = text(c, 12, R.color.text);
            h.pill = text(c, 12, R.color.text);
            h.col = new LinearLayout(c);
            return h;
        }

        private static VH buildPoster(Context c, int posterW, int posterH, int stripDp,
                                      boolean portrait, int gap) {
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutParams(itemLp(c, posterW, posterH, gap));
            int edge = Ui.dp(c, 3);
            frame.setPadding(edge, edge, edge, edge);

            LinearLayout inner = new LinearLayout(c);
            inner.setOrientation(LinearLayout.VERTICAL);
            clipRound(inner, Ui.dp(c, 19));
            frame.addView(inner, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // ---- picture area
            FrameLayout art = new FrameLayout(c);
            art.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
            inner.addView(art, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

            ImageView img = new ImageView(c);
            // portrait cards show the whole poster; the wide cards fill the picture area
            img.setScaleType(portrait ? ImageView.ScaleType.FIT_CENTER : ImageView.ScaleType.CENTER_CROP);
            art.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView inTitle = text(c, 13, R.color.muted);
            inTitle.setMaxLines(3);
            inTitle.setGravity(Gravity.CENTER);
            inTitle.setPadding(Ui.dp(c, 8), 0, Ui.dp(c, 8), 0);
            art.addView(inTitle, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            // soft shade rising from the bottom edge of the picture
            View shade = new View(c);
            shade.setBackgroundResource(R.drawable.bg_poster_shade);
            art.addView(shade, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, Math.round(posterH * 0.34f)), Gravity.BOTTOM));

            TextView big = text(c, 13, R.color.text);
            big.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            big.setGravity(Gravity.CENTER);
            big.setBackgroundResource(R.drawable.bg_badge_dark);
            big.setPadding(Ui.dp(c, 8), Ui.dp(c, 2), Ui.dp(c, 8), Ui.dp(c, 2));
            big.setVisibility(View.GONE);
            FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                    Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL);
            bp.setMargins(Ui.dp(c, 8), 0, Ui.dp(c, 8), Ui.dp(c, 8));
            art.addView(big, bp);

            // red progress bar: how much of the episode was already watched
            FrameLayout barTrack = new FrameLayout(c);
            // the bar fills left -> right like a normal timeline
            barTrack.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            barTrack.setBackgroundColor(0x88000000);
            barTrack.setVisibility(View.GONE);
            View barFill = new View(c);
            barFill.setBackgroundColor(0xFFE53935);
            barTrack.addView(barFill, new FrameLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT,
                    Gravity.START));
            art.addView(barTrack, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, 4), Gravity.BOTTOM));

            // eye: this (new episode) card has not been watched yet
            ImageView eye = new ImageView(c);
            eye.setImageResource(R.drawable.ic_eye);
            eye.setColorFilter(ContextCompat.getColor(c, R.color.eye));
            eye.setBackgroundResource(R.drawable.bg_badge_dark);
            eye.setPadding(Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3), Ui.dp(c, 3));
            eye.setVisibility(View.GONE);
            FrameLayout.LayoutParams eyp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 28), Ui.dp(c, 28), Gravity.TOP | Gravity.END);
            eyp.setMargins(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), 0);
            art.addView(eye, eyp);

            // ---- info strip: title and meta in the middle, the rating pill at the start
            FrameLayout strip = new FrameLayout(c);
            strip.setBackgroundColor(ContextCompat.getColor(c, R.color.strip_dark));
            inner.addView(strip, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, Ui.dp(c, stripDp)));

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            // portrait cards are narrow: the rating pill moves onto the picture, the strip is all text
            int side = Ui.dp(c, portrait ? 4 : 58);
            col.setPadding(side, 0, side, 0);
            TextView title = text(c, portrait ? 12 : 15, R.color.text);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setGravity(Gravity.CENTER);
            col.addView(title, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView meta = text(c, portrait ? 10 : 12, R.color.muted);
            meta.setGravity(Gravity.CENTER);
            col.addView(meta, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            strip.addView(col, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            TextView rating = text(c, portrait ? 11 : 13, R.color.text);
            rating.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            rating.setTextDirection(View.TEXT_DIRECTION_LTR);
            rating.setBackgroundResource(R.drawable.bg_pill);
            if (portrait) {
                rating.setPadding(Ui.dp(c, 5), Ui.dp(c, 1), Ui.dp(c, 5), Ui.dp(c, 1));
                FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        Gravity.TOP | Gravity.START);
                rp.setMargins(Ui.dp(c, 4), Ui.dp(c, 4), 0, 0);
                art.addView(rating, rp);
            } else {
                rating.setPadding(Ui.dp(c, 9), Ui.dp(c, 3), Ui.dp(c, 9), Ui.dp(c, 3));
                FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
                        Gravity.START | Gravity.CENTER_VERTICAL);
                rp.setMarginStart(Ui.dp(c, 10));
                strip.addView(rating, rp);
            }
            CardFx.attach(frame, frame, title);

            VH h = new VH(frame, frame);
            h.portrait = portrait;
            h.img = img;
            h.title = title;
            h.sub = meta;
            h.shade = shade;
            h.eyeView = eye;
            h.inTitle = inTitle;
            h.rating = rating;
            h.big = big;
            h.barTrack = barTrack;
            h.barFill = barFill;
            h.barWidthPx = Ui.dp(c, Math.max(20, posterW - 28));
            return h;
        }

        /**
         * The wide tile shared by channels and matches: round logo(s) at the start, then the name,
         * a grey line, and at the bottom the live status on one side and a small pill on the other.
         */
        private static VH buildWide(Context c, boolean match, int w, int hgt) {
            if (match) return buildMatch(c, w, hgt);
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutParams(itemLp(c, w, hgt));

            int logo = Math.max(40, Math.round(hgt * (match ? 0.46f : 0.56f)));
            int pad = Ui.dp(c, 14);
            ImageView logoA;
            ImageView logoB = null;
            int logosW;
            if (match) {
                // two overlapping circles: the home team in front of the away team
                logoB = logoCircle(c, frame, logo, 14);
                logoA = logoCircle(c, frame, logo, 14 + Math.round(logo * 0.62f));
                logosW = 14 + Math.round(logo * 1.62f);
            } else {
                logoA = logoCircle(c, frame, logo, 14);
                logosW = 14 + logo;
            }

            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_VERTICAL);
            FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            cp.setMarginStart(Ui.dp(c, logosW + 10));
            cp.setMarginEnd(pad);
            cp.topMargin = Ui.dp(c, 6);
            cp.bottomMargin = Ui.dp(c, 8);
            frame.addView(col, cp);

            TextView title = text(c, match ? 14 : 17, R.color.text);
            title.setTypeface(Typeface.DEFAULT_BOLD);
            title.setGravity(Gravity.START);
            title.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
            if (match) title.setMaxLines(2);
            col.addView(title, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView sub = text(c, 11, R.color.muted);
            sub.setGravity(Gravity.START);
            sub.setTextAlignment(View.TEXT_ALIGNMENT_GRAVITY);
            col.addView(sub, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            LinearLayout bottom = new LinearLayout(c);
            bottom.setOrientation(LinearLayout.HORIZONTAL);
            bottom.setGravity(Gravity.CENTER_VERTICAL);
            View dot = new View(c);
            dot.setBackgroundResource(R.drawable.bg_dot_red);
            LinearLayout.LayoutParams dotp = new LinearLayout.LayoutParams(Ui.dp(c, 8), Ui.dp(c, 8));
            dotp.setMarginEnd(Ui.dp(c, 6));
            bottom.addView(dot, dotp);
            TextView status = text(c, 12, R.color.text);
            status.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            bottom.addView(status, new LinearLayout.LayoutParams(
                    0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            TextView pill = text(c, 12, R.color.text);
            pill.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            pill.setTextDirection(View.TEXT_DIRECTION_LTR);
            pill.setBackgroundResource(R.drawable.bg_pill);
            pill.setPadding(Ui.dp(c, 9), Ui.dp(c, 2), Ui.dp(c, 9), Ui.dp(c, 2));
            bottom.addView(pill, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bl.topMargin = Ui.dp(c, 5);
            col.addView(bottom, bl);

            // favorite star: tap on a touch screen, long-press OK on a remote
            TextView star = new TextView(c);
            star.setTextSize(15);
            star.setGravity(Gravity.CENTER);
            star.setBackgroundResource(R.drawable.bg_badge_dark);
            star.setClickable(true);
            star.setFocusable(false);
            star.setVisibility(View.GONE);
            FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(
                    Ui.dp(c, 26), Ui.dp(c, 26), Gravity.TOP | Gravity.END);
            sp.setMargins(0, Ui.dp(c, 8), Ui.dp(c, 8), 0);
            frame.addView(star, sp);
            CardFx.attach(frame, frame, title);

            VH h = new VH(frame, frame);
            h.img = logoA;
            h.title = title;
            h.sub = sub;
            h.star = star;
            h.liveDotView = dot;
            h.status = status;
            h.pill = pill;
            h.col = col;
            if (match) {
                h.homeLogo = logoA;
                h.awayLogo = logoB;
            }
            return h;
        }

        /** One team: a round flag/logo with the team name written under it. */
        private static LinearLayout teamColumn(Context c, int logoDp, ImageView[] imgOut, TextView[] nameOut) {
            LinearLayout col = new LinearLayout(c);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER_HORIZONTAL);
            FrameLayout circle = new FrameLayout(c);
            circle.setBackgroundResource(R.drawable.bg_logo_circle);
            ImageView img = new ImageView(c);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            int pad = Ui.dp(c, Math.max(6, logoDp / 8));
            img.setPadding(pad, pad, pad, pad);
            circle.addView(img, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            clipRound(circle, Ui.dp(c, logoDp) / 2);
            col.addView(circle, new LinearLayout.LayoutParams(Ui.dp(c, logoDp), Ui.dp(c, logoDp)));
            TextView name = text(c, 13, R.color.text);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setGravity(Gravity.CENTER);
            name.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            name.setMaxLines(2);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            np.topMargin = Ui.dp(c, 6);
            col.addView(name, np);
            imgOut[0] = img;
            nameOut[0] = name;
            return col;
        }

        /**
         * Match tile: each team on its own side (the first team on the start side, the second on
         * the end side) with its name under its logo; the league, the time/score and the status
         * sit in the middle.
         */
        private static VH buildMatch(Context c, int w, int hgt) {
            FrameLayout frame = new FrameLayout(c);
            frame.setBackgroundResource(R.drawable.bg_poster);
            frame.setFocusable(true);
            frame.setClickable(true);
            frame.setLayoutParams(itemLp(c, w, hgt));

            int logo = Math.max(40, Math.round(hgt * 0.40f));
            LinearLayout row = new LinearLayout(c);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(Ui.dp(c, 10), Ui.dp(c, 8), Ui.dp(c, 10), Ui.dp(c, 8));
            frame.addView(row, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

            ImageView[] im = new ImageView[1];
            TextView[] nm = new TextView[1];
            LinearLayout homeCol = teamColumn(c, logo, im, nm);
            ImageView homeImg = im[0];
            TextView homeName = nm[0];
            LinearLayout awayCol = teamColumn(c, logo, im, nm);
            ImageView awayImg = im[0];
            TextView awayName = nm[0];

            LinearLayout mid = new LinearLayout(c);
            mid.setOrientation(LinearLayout.VERTICAL);
            mid.setGravity(Gravity.CENTER);
            TextView sub = text(c, 10, R.color.muted);
            sub.setGravity(Gravity.CENTER);
            sub.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
            sub.setMaxLines(2);
            sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
            mid.addView(sub, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView pill = text(c, 14, R.color.text);
            pill.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            pill.setTextDirection(View.TEXT_DIRECTION_LTR);
            pill.setBackgroundResource(R.drawable.bg_pill);
            pill.setPadding(Ui.dp(c, 10), Ui.dp(c, 3), Ui.dp(c, 10), Ui.dp(c, 3));
            LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            pp.topMargin = Ui.dp(c, 6);
            mid.addView(pill, pp);
            LinearLayout bottom = new LinearLayout(c);
            bottom.setOrientation(LinearLayout.HORIZONTAL);
            bottom.setGravity(Gravity.CENTER);
            View dot = new View(c);
            dot.setBackgroundResource(R.drawable.bg_dot_red);
            LinearLayout.LayoutParams dotp = new LinearLayout.LayoutParams(Ui.dp(c, 8), Ui.dp(c, 8));
            dotp.setMarginEnd(Ui.dp(c, 6));
            bottom.addView(dot, dotp);
            TextView status = text(c, 12, R.color.text);
            status.setTypeface(Typeface.create("sans-serif-medium", Typeface.BOLD));
            bottom.addView(status, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            bl.topMargin = Ui.dp(c, 6);
            mid.addView(bottom, bl);

            // team | middle | team  (the middle gets a bit more room than a team)
            row.addView(homeCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            row.addView(mid, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 0.9f));
            row.addView(awayCol, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

            CardFx.attach(frame, frame, homeName);

            VH h = new VH(frame, frame);
            h.img = homeImg;
            h.title = homeName;
            h.awayName = awayName;
            h.sub = sub;
            h.liveDotView = dot;
            h.status = status;
            h.pill = pill;
            h.homeLogo = homeImg;
            h.awayLogo = awayImg;
            return h;
        }

        private static VH buildText(Context c, int w, int hgt) {
            LinearLayout card = new LinearLayout(c);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setBackgroundResource(R.drawable.bg_match);
            card.setFocusable(true);
            card.setClickable(true);
            card.setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 10));
            card.setLayoutParams(itemLp(c, w, hgt));

            TextView badge = text(c, 11, R.color.muted);
            badge.setPadding(Ui.dp(c, 6), Ui.dp(c, 1), Ui.dp(c, 6), Ui.dp(c, 1));
            card.addView(badge, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            TextView title = text(c, 14, R.color.text);
            title.setMaxLines(2);
            title.setGravity(Gravity.START);
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            tp.topMargin = Ui.dp(c, 6);
            card.addView(title, tp);
            TextView sub = text(c, 12, R.color.muted);
            sub.setGravity(Gravity.START);
            card.addView(sub);

            VH h = new VH(card, card);
            h.badge = badge;
            h.title = title;
            h.sub = sub;
            return h;
        }

        @Override
        public void onBindViewHolder(@NonNull VH h, int position) {
            final Card card = data.get(position);
            Context c = h.itemView.getContext();
            // The last card is next to the side menu (on the right): one more press enters the menu.
            final int last = data.size() - 1;
            h.click.setOnKeyListener((v, keyCode, ev) -> {
                if (keyCode != android.view.KeyEvent.KEYCODE_DPAD_RIGHT
                        || ev.getAction() != android.view.KeyEvent.ACTION_DOWN) return false;
                if (h.getBindingAdapterPosition() != last) return false;
                View nav = v.getRootView().findViewById(R.id.nav_home);
                if (nav != null && nav.getVisibility() == View.VISIBLE) {
                    nav.requestFocus();
                    return true;
                }
                return false;
            });
            if (card.kind == POSTER || card.kind == CHANNEL || card.kind == MATCH) {
                CardFx.sync(h.itemView, h.click, h.title);
            }
            h.click.setOnClickListener(v -> {
                if (card.click != null) card.click.run();
            });
            if (card.longClick != null) {
                h.click.setOnLongClickListener(v -> {
                    card.longClick.run();
                    return true;
                });
            } else {
                h.click.setOnLongClickListener(null);
            }
            switch (card.kind) {
                case MATCH: {
                    h.click.setBackgroundResource(card.live ? R.drawable.bg_match_live : R.drawable.bg_poster);
                    h.title.setText(card.home);
                    h.awayName.setText(card.away);
                    h.sub.setText(card.league);
                    h.sub.setVisibility(card.league == null || card.league.isEmpty() ? View.GONE : View.VISIBLE);
                    boolean hasBadge = card.badge != null && !card.badge.isEmpty();
                    h.status.setText(card.badge);
                    h.status.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.liveDotView.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.liveDotView.setBackground(dotDrawable(c, card.live ? 0xFFFF4D5E : 0xFF7FB4BF));
                    h.status.setTextColor(card.live ? 0xFFFF7A88 : ContextCompat.getColor(c, R.color.muted));
                    boolean hasScore = card.score != null && !card.score.isEmpty();
                    h.pill.setVisibility(hasScore ? View.VISIBLE : View.GONE);
                    h.pill.setText(card.score);
                    if (h.star != null) h.star.setVisibility(View.GONE);
                    load(h.homeLogo, card.homeLogo, R.drawable.ic_live, 120, 120);
                    load(h.awayLogo, card.awayLogo, R.drawable.ic_live, 120, 120);
                    break;
                }
                case CHANNEL: {
                    h.title.setText(card.title);
                    boolean hasSub = card.subtitle != null && !card.subtitle.isEmpty();
                    h.sub.setText(card.subtitle);
                    h.sub.setVisibility(hasSub ? View.VISIBLE : View.GONE);
                    h.status.setText("مباشر");
                    h.status.setTextColor(ContextCompat.getColor(c, R.color.text));
                    h.liveDotView.setVisibility(View.VISIBLE);
                    h.liveDotView.setBackground(dotDrawable(c, 0xFF2CD9E0));
                    boolean hasPill = card.badge != null && !card.badge.isEmpty();
                    h.pill.setVisibility(hasPill ? View.VISIBLE : View.GONE);
                    h.pill.setText(card.badge);
                    load(h.img, card.image, card.fallback, 240, 240);
                    h.col.setPadding(0, 0, card.onStar != null ? Ui.dp(c, 16) : 0, 0);
                    if (card.onStar != null && h.star != null) {
                        h.star.setVisibility(View.VISIBLE);
                        h.star.setText(card.starred ? "\u2605" : "\u2606");
                        h.star.setTextColor(card.starred ? 0xFFFFC107 : ContextCompat.getColor(c, R.color.text));
                        h.star.setOnClickListener(v -> card.onStar.run());
                        if (card.longClick == null) {
                            h.click.setOnLongClickListener(v -> {
                                card.onStar.run();
                                return true;
                            });
                        }
                    } else if (h.star != null) {
                        h.star.setVisibility(View.GONE);
                    }
                    break;
                }
                case TEXT: {
                    h.title.setText(card.title);
                    h.sub.setText(card.subtitle);
                    h.sub.setVisibility(card.subtitle == null || card.subtitle.isEmpty() ? View.GONE : View.VISIBLE);
                    boolean hasBadge = card.badge != null && !card.badge.isEmpty();
                    h.badge.setVisibility(hasBadge ? View.VISIBLE : View.GONE);
                    h.badge.setText(card.badge);
                    h.badge.setBackgroundResource(R.drawable.bg_badge_live);
                    h.badge.setTextColor(0xFFFF7A88);
                    break;
                }
                default: {
                    h.title.setText(card.title);
                    boolean hasMeta = card.subtitle != null && !card.subtitle.isEmpty();
                    h.sub.setText(card.subtitle);
                    h.sub.setVisibility(hasMeta ? View.VISIBLE : View.GONE);
                    boolean hasImg = card.image != null
                            && (card.image.startsWith("http") || card.image.startsWith("/"));
                    h.inTitle.setText(card.title);
                    h.inTitle.setVisibility(hasImg ? View.GONE : View.VISIBLE);
                    h.shade.setVisibility(hasImg ? View.VISIBLE : View.GONE);
                    if (hasImg) {
                        if (h.portrait) {
                            load(h.img, card.image, android.R.color.transparent, 320, 480);
                        } else {
                            load(h.img, card.image, android.R.color.transparent, 480, 300);
                        }
                    } else {
                        Glide.with(c).clear(h.img);
                        h.img.setImageDrawable(null);
                    }
                    boolean hasRating = card.rating != null && !card.rating.isEmpty()
                            && !"0".equals(card.rating) && !"0.0".equals(card.rating);
                    boolean hasNote = card.note != null && !card.note.isEmpty();
                    boolean hasBig = card.big != null && !card.big.isEmpty();
                    h.eyeView.setVisibility(card.eye ? View.VISIBLE : View.GONE);
                    h.big.setVisibility(hasBig ? View.VISIBLE : View.GONE);
                    h.big.setText(card.big);
                    boolean hasBar = card.progress >= 0;
                    h.barTrack.setVisibility(hasBar ? View.VISIBLE : View.GONE);
                    if (hasBar) {
                        ViewGroup.LayoutParams fp = h.barFill.getLayoutParams();
                        fp.width = Math.max(Ui.dp(c, 3), h.barWidthPx * Math.min(100, card.progress) / 100);
                        h.barFill.setLayoutParams(fp);
                    }
                    // the episode label sits above the bar when there is one
                    FrameLayout.LayoutParams bl = (FrameLayout.LayoutParams) h.big.getLayoutParams();
                    bl.bottomMargin = Ui.dp(c, hasBar ? 12 : 8);
                    h.big.setLayoutParams(bl);
                    if (hasNote) {
                        h.rating.setVisibility(View.VISIBLE);
                        h.rating.setText(card.note);
                    } else {
                        h.rating.setVisibility(hasRating ? View.VISIBLE : View.GONE);
                        h.rating.setText(card.rating + " \u2605");
                    }
                    break;
                }
            }
        }

        private static android.graphics.drawable.Drawable dotDrawable(Context c, int color) {
            android.graphics.drawable.GradientDrawable d = new android.graphics.drawable.GradientDrawable();
            d.setShape(android.graphics.drawable.GradientDrawable.OVAL);
            d.setColor(color);
            return d;
        }

        @Override
        public int getItemCount() {
            return data.size();
        }

        static final class VH extends RecyclerView.ViewHolder {
            final View click;
            View barTrack, barFill, shade, liveDotView;
            LinearLayout col;
            int barWidthPx;
            boolean portrait;
            ImageView img, homeLogo, awayLogo, eyeView;
            TextView title, awayName, sub, badge, inTitle, rating, star, big, status, pill;

            VH(@NonNull View v, View click) {
                super(v);
                this.click = click;
            }
        }
    }
}
