package com.myiptv.app.util;

import com.myiptv.app.data.Item;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * The channel list the user was browsing when opening the full screen player,
 * so the remote can flip to the next / previous channel or jump to a channel number.
 * Lives in memory only (same process), so it never goes through an Intent.
 */
public final class LiveQueue {
    private LiveQueue() {}

    public static volatile List<Item> items = new ArrayList<>();
    public static volatile Map<String, String> catNames = new HashMap<>();

    public static void set(List<Item> list, Map<String, String> names) {
        items = new ArrayList<Item>(list);
        if (names == null) {
            catNames = new HashMap<String, String>();
        } else {
            catNames = new HashMap<String, String>(names);
        }
    }

    public static void clear() {
        items = new ArrayList<Item>();
        catNames = new HashMap<String, String>();
    }
}
