package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.view.View;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

/**
 * A halo of the screen's own smoke behind the sidebar logo: the same background picture, drawn at
 * exactly the place it has on the screen (so the smoke continues the smoke around the sidebar),
 * lit up and kept only in a soft round window around the logo, with a gentle shadow in the middle
 * so the logo stays readable. The logo then looks part of the background, not painted on it.
 */
public class SmokeHaloView extends View {
    private final Paint shade = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint mask = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Drawable lit;
    private View bgRef;
    private View logo;

    public SmokeHaloView(Context c) {
        super(c);
        init();
    }

    public SmokeHaloView(Context c, AttributeSet a) {
        super(c, a);
        init();
    }

    private void init() {
        mask.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_IN));
        setFocusable(false);
        setClickable(false);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        getViewTreeObserver().addOnGlobalLayoutListener(this::invalidate);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (w == 0 || h == 0) return;
        View root = getRootView();
        if (bgRef == null) bgRef = root.findViewById(R.id.app_bg);
        if (logo == null) logo = root.findViewById(R.id.side_logo);
        if (bgRef == null || logo == null || logo.getWidth() == 0 || bgRef.getWidth() == 0) return;
        if (lit == null) {
            Drawable d = ContextCompat.getDrawable(getContext(), R.drawable.bg_main);
            if (d == null) return;
            lit = d.mutate();
            ColorMatrix cm = new ColorMatrix(new float[]{
                    1.7f, 0, 0, 0, 5,
                    0, 2.5f, 0, 0, 12,
                    0, 0, 2.5f, 0, 14,
                    0, 0, 0, 1, 0});
            lit.setColorFilter(new ColorMatrixColorFilter(cm));
        }

        int[] me = new int[2], lg = new int[2], bl = new int[2];
        getLocationInWindow(me);
        logo.getLocationInWindow(lg);
        bgRef.getLocationInWindow(bl);
        float cx = lg[0] - me[0] + logo.getWidth() / 2f;
        float cy = lg[1] - me[1] + logo.getHeight() / 2f;
        // never wider than the sidebar, so the halo has faded out before the sidebar's edge
        float radius = Math.min(logo.getHeight() * 2.1f, Math.min(cx, w - cx) * 0.98f);
        if (radius <= 0) return;

        // soft shadow under the logo
        float shadeR = radius * 0.78f;
        shade.setShader(new RadialGradient(cx, cy, shadeR,
                new int[]{0x99000A12, 0x55000A12, 0x00000A12}, new float[]{0f, 0.55f, 1f},
                Shader.TileMode.CLAMP));
        // the lit smoke, in the screen's own coordinates (the picture is centre-cropped over the whole screen)
        int bgW = bgRef.getWidth(), bgH = bgRef.getHeight();
        float sc = Math.max(bgW / (float) lit.getIntrinsicWidth(), bgH / (float) lit.getIntrinsicHeight());
        int dw = Math.round(lit.getIntrinsicWidth() * sc), dh = Math.round(lit.getIntrinsicHeight() * sc);
        int left = bl[0] - me[0] + (bgW - dw) / 2, top = bl[1] - me[1] + (bgH - dh) / 2;
        lit.setBounds(left, top, left + dw, top + dh);

        int layer = canvas.saveLayer(0, 0, w, h, null);
        lit.draw(canvas);
        mask.setShader(new RadialGradient(cx, cy, radius,
                new int[]{0x66000000, 0xC0000000, 0x66000000, 0x00000000},
                new float[]{0f, 0.38f, 0.72f, 1f}, Shader.TileMode.CLAMP));
        canvas.drawRect(0, 0, w, h, mask);
        canvas.restoreToCount(layer);

        canvas.drawCircle(cx, cy, shadeR, shade);
    }
}
