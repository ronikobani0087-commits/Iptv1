package com.myiptv.app.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import com.myiptv.app.R;

/**
 * Five second opening (new RONI IPTV logo): the "RONI IPTV" letters slide in from the left to the middle of the screen,
 * the symbol falls from the top onto them and completes the logo (with an impact on the beat of
 * the music), a light sweep passes over it, then everything fades away.
 */
public final class IntroView extends FrameLayout {
    public static final int DURATION_MS = 5000;
    private static final int FADE_OUT_MS = 600;
    /** The symbol lands on the beat of the music (4 beats at 128 bpm). */
    private static final int IMPACT = 1875;
    /** Row (in the original 640x565 artwork) where the symbol ends and the letters begin. */
    private static final int SPLIT_BASE = 427;
    private static final int BASE_H = 565;

    private final Stage stage;
    private MediaPlayer player;
    private ValueAnimator animator;
    private Runnable onDone;
    private boolean finished;

    public IntroView(Context c) {
        super(c);
        setClickable(true);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setClipChildren(false);
        stage = new Stage(c);
        addView(stage, new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Starts the animation and the music; [done] runs once, when the intro has ended. */
    public void start(Runnable done) {
        onDone = done;
        final Context c = getContext();
        // the music is prepared on a background thread; the animation starts together with it,
        // so the opening never stalls on loading the sound
        com.myiptv.app.util.Async.io(() -> {
            MediaPlayer mp = null;
            try {
                mp = MediaPlayer.create(c, R.raw.intro_music);
                if (mp != null) mp.setVolume(0.9f, 0.9f);
            } catch (Throwable ignored) {
                mp = null;
            }
            final MediaPlayer ready = mp;
            com.myiptv.app.util.Async.main(() -> begin(ready));
        });
    }

    private void begin(MediaPlayer mp) {
        if (finished) {
            if (mp != null) {
                try {
                    mp.release();
                } catch (Throwable ignored) {
                }
            }
            return;
        }
        player = mp;
        if (player != null) {
            try {
                player.start();
            } catch (Throwable ignored) {
            }
        }
        animator = ValueAnimator.ofInt(0, DURATION_MS);
        animator.setDuration(DURATION_MS);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            int t = (Integer) a.getAnimatedValue();
            stage.setTime(t);
            int fadeStart = DURATION_MS - FADE_OUT_MS;
            setAlpha(t <= fadeStart ? 1f : Math.max(0f, 1f - (t - fadeStart) / (float) FADE_OUT_MS));
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                finish();
            }
        });
        animator.start();
    }

    /** Ends the intro at once (used when the app leaves the screen). Safe to call repeatedly. */
    public void finish() {
        if (finished) return;
        finished = true;
        if (animator != null) {
            animator.removeAllListeners();
            animator.cancel();
        }
        if (player != null) {
            try {
                player.stop();
            } catch (Throwable ignored) {
            }
            try {
                player.release();
            } catch (Throwable ignored) {
            }
            player = null;
        }
        Runnable r = onDone;
        onDone = null;
        if (r != null) r.run();
    }

    // The intro swallows every key and touch until it is over.
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return true;
    }

    /** Draws the glow, the rings, the logo and the light sweep for a given time in ms. */
    private static final class Stage extends View {
        private final Bitmap logo;
        private final Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sweep = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint backdrop = new Paint();
        private final Paint part = new Paint(Paint.ANTI_ALIAS_FLAG);
        private static final int PN = 22;
        private final float[] px = new float[PN];
        private final float[] py = new float[PN];
        private final float[] pr = new float[PN];
        private final float[] psp = new float[PN];
        private final float[] pph = new float[PN];
        private final Matrix m = new Matrix();
        private final RectF rect = new RectF();
        private final RectF dst = new RectF();
        private final android.graphics.Rect srcText = new android.graphics.Rect();
        private final android.graphics.Rect srcIcon = new android.graphics.Rect();
        private final float density;
        private final int cyan;
        private LinearGradient sweepShader;
        private RadialGradient backShader;
        private int t;
        /** Split row scaled to the real size of the (high resolution) logo bitmap. */
        private final int split;

        Stage(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
            cyan = androidx.core.content.ContextCompat.getColor(c, R.color.snow);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            o.inSampleSize = 2;   // 960 px is plenty and decodes 4x faster
            logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.logo_roni, o);
            split = logo == null ? SPLIT_BASE
                    : Math.round(SPLIT_BASE * logo.getHeight() / (float) BASE_H);
            part.setColor(cyan);
            java.util.Random rnd = new java.util.Random(7);
            for (int i = 0; i < PN; i++) {
                px[i] = rnd.nextFloat();
                py[i] = rnd.nextFloat();
                pr[i] = 1.2f + rnd.nextFloat() * 2.2f;
                psp[i] = 0.6f + rnd.nextFloat();
                pph[i] = rnd.nextFloat() * 6.28f;
            }
            glow.setShader(new RadialGradient(0f, 0f, 1f,
                    new int[]{(cyan & 0xFFFFFF) | 0xFF000000, cyan & 0xFFFFFF},
                    new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(2f * density);
            sweep.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
            bar.setStrokeCap(Paint.Cap.ROUND);
            bar.setStrokeWidth(2f * density);
            setFocusable(false);
        }

        void setTime(int ms) {
            t = ms;
            invalidate();
        }

        private static float clamp(float v) {
            return v < 0f ? 0f : (v > 1f ? 1f : v);
        }

        /** 0..1 progress of the span [from, to] in ms. */
        private float span(int from, int to) {
            return clamp((t - from) / (float) (to - from));
        }

        private static float easeOut(float x) {
            float k = 1f - x;
            return 1f - k * k * k;
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float r = Math.max(w, h) * 0.75f;
            backShader = new RadialGradient(w / 2f, h / 2f, r,
                    new int[]{0xFF133450, 0xFF0D1E31, 0xFF080E19}, new float[]{0f, 0.55f, 1f},
                    Shader.TileMode.CLAMP);
            backdrop.setShader(backShader);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w == 0 || h == 0 || logo == null) return;
            canvas.drawRect(0, 0, w, h, backdrop);

            float cx = w / 2f;
            float cy = h / 2f - 6f * density;
            float lh = h * 0.44f;   // smaller logo / play circle
            float lw = lh * logo.getWidth() / (float) logo.getHeight();
            if (lw > w * 0.55f) {
                lw = w * 0.55f;
                lh = lw * logo.getHeight() / (float) logo.getWidth();
            }
            float k = lh / logo.getHeight();          // logo pixels -> screen
            float left = cx - lw / 2f;
            float top = cy - lh / 2f;
            float iconH = split * k;
            float iconBottom = top + iconH;

            float impact = span(IMPACT - 80, IMPACT + 700);   // 0 before, rises after the landing

            // soft glow behind the logo, flashes when the symbol lands
            float g = easeOut(span(300, 1800)) * 0.55f + (1f - impact) * easeOut(span(IMPACT - 80, IMPACT)) * 0.5f;
            float gr = Math.max(lw, lh) * (0.8f + 0.25f * easeOut(impact));
            glow.setAlpha((int) (0x80 * Math.min(1f, g)));
            canvas.save();
            canvas.translate(cx, cy);
            canvas.scale(gr, gr);
            canvas.drawCircle(0f, 0f, 1f, glow);
            canvas.restore();

            // a few soft lights drifting upwards
            float pin = easeOut(span(200, 1400));
            for (int i = 0; i < PN; i++) {
                float yy = ((py[i] - t * psp[i] / 9000f) % 1f + 1f) % 1f;
                float tw = 0.5f + 0.5f * (float) Math.sin(t / 650f + pph[i]);
                part.setAlpha((int) (110 * tw * pin));
                canvas.drawCircle(px[i] * w, yy * h, pr[i] * density, part);
            }

            // shock rings from the landing point
            for (int i = 0; i < 3; i++) {
                float p = span(IMPACT + i * 170, IMPACT + 1500 + i * 170);
                if (p <= 0f || p >= 1f) continue;
                ring.setColor(cyan);
                ring.setAlpha((int) (140 * (1f - p)));
                canvas.drawCircle(cx, iconBottom - iconH * 0.45f, lh * (0.15f + 0.85f * easeOut(p)), ring);
            }

            // letters: slide in from the left edge to the middle
            float tp = span(250, 1350);
            float te = easeOut(tp);
            float textW = lw;
            float textOffset = -(left + textW) * (1f - te);
            // symbol: falls from above the screen, lands on the beat, small bounce
            float fall = span(850, IMPACT);
            float dyIcon = -(top + iconH) * (1f - fall * fall);
            if (t > IMPACT) {
                float bq = span(IMPACT, IMPACT + 450);
                dyIcon = -(float) Math.abs(Math.sin(bq * Math.PI)) * (1f - bq) * 16f * density;
            }

            rect.set(left, top, left + lw, top + lh);
            // slow, gentle zoom while the logo builds up
            float zoom = 0.92f + 0.08f * easeOut(span(0, 3400));
            canvas.save();
            canvas.scale(zoom, zoom, cx, cy);
            float s = span(IMPACT + 450, IMPACT + 1650);
            boolean sweeping = s > 0f && s < 1f;
            // an offscreen layer is only needed while the light sweep is clipped to the logo
            int layer = sweeping
                    ? canvas.saveLayer(rect.left - 20f * density, rect.top - 24f * density,
                            rect.right + 20f * density, rect.bottom + 8f * density, null)
                    : -1;
            bmp.setAlpha((int) (255 * Math.min(1f, tp * 2f)));
            srcText.set(0, split, logo.getWidth(), logo.getHeight());
            dst.set(left + textOffset, top + iconH, left + textOffset + textW, top + lh);
            canvas.drawBitmap(logo, srcText, dst, bmp);
            bmp.setAlpha(fall > 0f ? 255 : 0);
            srcIcon.set(0, 0, logo.getWidth(), split);
            dst.set(left, top + dyIcon, left + lw, top + iconH + dyIcon);
            canvas.drawBitmap(logo, srcIcon, dst, bmp);

            // light sweep, only where the logo is drawn (after it is complete)
            if (sweeping) {
                float band = lw * 0.35f;
                if (sweepShader == null) {
                    sweepShader = new LinearGradient(0, 0, band, 0,
                            new int[]{0x00FFFFFF, 0xB8FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f},
                            Shader.TileMode.CLAMP);
                }
                float x = rect.left - band + (lw + band * 2f) * easeOut(s);
                m.reset();
                m.postRotate(18f);
                m.postTranslate(x, rect.top);
                sweepShader.setLocalMatrix(m);
                sweep.setShader(sweepShader);
                canvas.drawRect(rect, sweep);
            }
            if (layer >= 0) canvas.restoreToCount(layer);
            canvas.restore();

            // thin loading line under the logo
            float bp = span(300, 4400);
            float barW = 96f * density;
            float by = Math.min(h - 18f * density, rect.bottom + 22f * density);
            bar.setColor(cyan);
            bar.setAlpha(50);
            canvas.drawLine(cx - barW / 2f, by, cx + barW / 2f, by, bar);
            bar.setAlpha((int) (230 * easeOut(span(250, 900))));
            canvas.drawLine(cx - barW / 2f, by, cx - barW / 2f + barW * bp, by, bar);
        }
    }
}
