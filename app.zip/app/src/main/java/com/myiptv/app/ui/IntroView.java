package com.myiptv.app.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.FrameLayout;

import com.myiptv.app.R;

/**
 * Five second opening: the logo fades in over a soft cyan glow, signal rings spread out,
 * a light sweep passes over the logo while a piano phrase plays, then everything fades away.
 */
public final class IntroView extends FrameLayout {
    public static final int DURATION_MS = 5000;
    private static final int FADE_OUT_MS = 600;

    private final Stage stage;
    private MediaPlayer player;
    private ValueAnimator animator;
    private Runnable onDone;
    private boolean finished;

    public IntroView(Context c) {
        super(c);
        setClickable(true);
        setFocusable(true);
        setFocusableInTouchMode(true);
        setClipChildren(false);
        addView(new SnowView(c, 26, 5L), new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        stage = new Stage(c);
        addView(stage, new LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** Starts the animation and the music; [done] runs once, when the intro has ended. */
    public void start(Runnable done) {
        onDone = done;
        try {
            player = MediaPlayer.create(getContext(), R.raw.intro_piano);
            if (player != null) {
                player.setVolume(0.9f, 0.9f);
                player.start();
            }
        } catch (Throwable ignored) {
            player = null;
        }
        animator = ValueAnimator.ofInt(0, DURATION_MS);
        animator.setDuration(DURATION_MS);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> {
            int t = (Integer) a.getAnimatedValue();
            stage.setTime(t);
            int fadeStart = DURATION_MS - FADE_OUT_MS;
            setAlpha(t <= fadeStart ? 1f : Math.max(0f, 1f - (t - fadeStart) / (float) FADE_OUT_MS));
        });
        animator.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator animation) {
                finish();
            }
        });
        animator.start();
    }

    /** Ends the intro at once (used when the app leaves the screen). Safe to call repeatedly. */
    public void finish() {
        if (finished) return;
        finished = true;
        if (animator != null) {
            animator.removeAllListeners();
            animator.cancel();
        }
        if (player != null) {
            try {
                player.stop();
            } catch (Throwable ignored) {
            }
            try {
                player.release();
            } catch (Throwable ignored) {
            }
            player = null;
        }
        Runnable r = onDone;
        onDone = null;
        if (r != null) r.run();
    }

    // The intro swallows every key and touch until it is over.
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        return true;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        return true;
    }

    /** Draws the glow, the rings, the logo and the light sweep for a given time in ms. */
    private static final class Stage extends View {
        private final Bitmap logo;
        private final Paint bmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint sweep = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint bar = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint backdrop = new Paint();
        private final Matrix m = new Matrix();
        private final RectF rect = new RectF();
        private final float density;
        private final int cyan;
        private LinearGradient sweepShader;
        private RadialGradient backShader;
        private int t;

        Stage(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
            cyan = androidx.core.content.ContextCompat.getColor(c, R.color.snow);
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inScaled = false;
            logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.logo_roni, o);
            ring.setStyle(Paint.Style.STROKE);
            ring.setStrokeWidth(2f * density);
            sweep.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
            bar.setStrokeCap(Paint.Cap.ROUND);
            bar.setStrokeWidth(2f * density);
            setFocusable(false);
        }

        void setTime(int ms) {
            t = ms;
            invalidate();
        }

        private static float clamp(float v) {
            return v < 0f ? 0f : (v > 1f ? 1f : v);
        }

        /** 0..1 progress of the span [from, to] in ms. */
        private float span(int from, int to) {
            return clamp((t - from) / (float) (to - from));
        }

        private static float easeOut(float x) {
            float k = 1f - x;
            return 1f - k * k * k;
        }

        @Override
        protected void onSizeChanged(int w, int h, int ow, int oh) {
            super.onSizeChanged(w, h, ow, oh);
            float r = Math.max(w, h) * 0.75f;
            backShader = new RadialGradient(w / 2f, h / 2f, r,
                    new int[]{0xFF0F3342, 0xFF081B25, 0xFF040C11}, new float[]{0f, 0.55f, 1f},
                    Shader.TileMode.CLAMP);
            backdrop.setShader(backShader);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w == 0 || h == 0 || logo == null) return;
            canvas.drawRect(0, 0, w, h, backdrop);

            float cx = w / 2f;
            float cy = h / 2f - 12f * density;
            float lh = h * 0.52f;
            float lw = lh * logo.getWidth() / (float) logo.getHeight();
            if (lw > w * 0.7f) {
                lw = w * 0.7f;
                lh = lw * logo.getHeight() / (float) logo.getWidth();
            }

            // soft glow behind the logo
            float g = easeOut(span(200, 1800));
            float pulse = 1f + 0.04f * (float) Math.sin(t / 420.0);
            float gr = Math.max(lw, lh) * 0.85f * pulse;
            glow.setShader(new RadialGradient(cx, cy, gr,
                    new int[]{(int) (0x55 * g) << 24 | (cyan & 0xFFFFFF), 0x00000000},
                    new float[]{0f, 1f}, Shader.TileMode.CLAMP));
            canvas.drawCircle(cx, cy, gr, glow);

            // signal rings spreading out of the logo
            for (int i = 0; i < 3; i++) {
                float p = span(1500 + i * 380, 3700 + i * 380);
                if (p <= 0f || p >= 1f) continue;
                float rr = lh * (0.3f + 0.9f * easeOut(p));
                ring.setColor(cyan);
                ring.setAlpha((int) (110 * (1f - p)));
                canvas.drawCircle(cx, cy, rr, ring);
            }

            // the logo itself
            float a = easeOut(span(450, 1700));
            float sc = 0.84f + 0.16f * easeOut(span(450, 1900));
            sc *= 1f + 0.012f * (float) Math.sin(t / 500.0) * span(1900, 2200);
            float dy = (1f - easeOut(span(450, 1900))) * 20f * density;
            rect.set(cx - lw / 2f, cy - lh / 2f + dy, cx + lw / 2f, cy + lh / 2f + dy);
            canvas.save();
            canvas.scale(sc, sc, cx, cy + dy);
            int layer = canvas.saveLayer(rect, null);
            bmp.setAlpha((int) (255 * a));
            canvas.drawBitmap(logo, null, rect, bmp);

            // light sweep, only where the logo is drawn
            float s = span(2200, 3500);
            if (s > 0f && s < 1f) {
                float band = lw * 0.35f;
                if (sweepShader == null) {
                    sweepShader = new LinearGradient(0, 0, band, 0,
                            new int[]{0x00FFFFFF, 0xB8FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f},
                            Shader.TileMode.CLAMP);
                    sweep.setShader(sweepShader);
                }
                float x = rect.left - band + (lw + band * 2f) * easeOut(s);
                m.reset();
                m.setScale(1f, 1f);
                m.postRotate(18f);
                m.postTranslate(x, rect.top);
                sweepShader.setLocalMatrix(m);
                sweep.setShader(sweepShader);
                canvas.drawRect(rect, sweep);
            }
            canvas.restoreToCount(layer);
            canvas.restore();

            // thin loading line under the logo
            float bp = span(600, 4400);
            float barW = 96f * density;
            float by = Math.min(h - 18f * density, rect.bottom + 22f * density);
            bar.setColor(cyan);
            bar.setAlpha(50);
            canvas.drawLine(cx - barW / 2f, by, cx + barW / 2f, by, bar);
            bar.setAlpha((int) (230 * a));
            canvas.drawLine(cx - barW / 2f, by, cx - barW / 2f + barW * bp, by, bar);
        }
    }
}
