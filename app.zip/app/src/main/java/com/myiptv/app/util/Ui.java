package com.myiptv.app.util;

import android.app.UiModeManager;
import android.content.Context;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.view.Gravity;
import android.graphics.drawable.Drawable;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.bumptech.glide.RequestBuilder;
import com.bumptech.glide.load.model.GlideUrl;
import com.bumptech.glide.load.model.LazyHeaders;
import com.myiptv.app.R;

public final class Ui {
    private Ui() {}


    /**
     * Phone mode: on small touch screens (smallest width under 600dp, not a TV) the whole interface
     * is drawn smaller, exactly like the TV layout shrunk to fit. Returns 1 when nothing changes.
     */
    public static float phoneScale(Context c) {
        try {
            Configuration cfg = c.getResources().getConfiguration();
            if (cfg.smallestScreenWidthDp <= 0 || cfg.smallestScreenWidthDp >= 600) return 1f;
            UiModeManager um = (UiModeManager) c.getSystemService(Context.UI_MODE_SERVICE);
            if (um != null && um.getCurrentModeType() == Configuration.UI_MODE_TYPE_TELEVISION) return 1f;
            if (!c.getPackageManager().hasSystemFeature(PackageManager.FEATURE_TOUCHSCREEN)) return 1f;
            float s = cfg.smallestScreenWidthDp / 600f;
            return Math.max(0.58f, Math.min(1f, s));
        } catch (Throwable t) {
            return 1f;
        }
    }

    /** The configuration with density and the dp sizes of the screen moved by the same factor. */
    public static Configuration scaledConfig(Configuration base, float s) {
        Configuration out = new Configuration(base);
        if (s >= 0.999f || base.densityDpi <= 0) return out;
        out.densityDpi = Math.max(80, Math.round(base.densityDpi * s));
        if (base.screenWidthDp > 0) out.screenWidthDp = Math.round(base.screenWidthDp / s);
        if (base.screenHeightDp > 0) out.screenHeightDp = Math.round(base.screenHeightDp / s);
        if (base.smallestScreenWidthDp > 0) {
            out.smallestScreenWidthDp = Math.round(base.smallestScreenWidthDp / s);
        }
        return out;
    }

    /** Wraps a base context so that dp / sp are scaled for phones (no-op on TV and tablets). */
    public static Context scaledContext(Context base) {
        float s = phoneScale(base);
        if (s >= 0.999f) return base;
        return base.createConfigurationContext(scaledConfig(base.getResources().getConfiguration(), s));
    }

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** True when the url is a real logo: http(s) and not the provider's "no logo" placeholder picture. */
    private static final String LOGO_UA = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36";

    private static GlideUrl logoUrl(String url) {
        return new GlideUrl(url, new LazyHeaders.Builder()
                .addHeader("User-Agent", LOGO_UA)
                .addHeader("Accept", "image/*,*/*;q=0.8")
                .build());
    }

    /**
     * Loads a club / national-team logo (or any remote image) the tolerant way: a browser-like
     * User-Agent (some CDNs refuse the default one that TV boxes send) and, when the https request
     * fails (old TV firmware with an outdated certificate store), one more try over plain http.
     * {@code fallback} is shown while loading and when both tries fail.
     */
    public static void loadLogo(ImageView img, String url, int fallback, int w, int h) {
        Context c = img.getContext();
        if (!validLogo(url)) {
            Glide.with(c).clear(img);
            img.setImageResource(fallback);
            return;
        }
        RequestBuilder<Drawable> req = Glide.with(c).load(logoUrl(url)).dontAnimate().placeholder(fallback);
        if (w > 0 && h > 0) req = req.override(w, h);
        if (url.startsWith("https://")) {
            RequestBuilder<Drawable> plain = Glide.with(c).load(logoUrl("http://" + url.substring(8)))
                    .dontAnimate().error(fallback);
            if (w > 0 && h > 0) plain = plain.override(w, h);
            req = req.error(plain);
        } else {
            req = req.error(fallback);
        }
        req.into(img);
    }

    public static boolean validLogo(String url) {
        if (url == null || !url.startsWith("http")) return false;
        String letters = url.toLowerCase(java.util.Locale.US).replaceAll("[^a-z]", "");
        return !letters.contains("nologo");
    }

    /** MBC and beIN Sports channels / packages (Latin or Arabic spelling): they always keep an icon. */
    public static boolean keepIcon(String name) {
        return brand(name) != null;
    }

    /** "bein", "mbc" or null: which of the two brands the channel / package name belongs to. */
    public static String brand(String name) {
        if (name == null || name.isEmpty()) return null;
        String n = name.toLowerCase(java.util.Locale.US)
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ة', 'ه').replace('ى', 'ي');
        String compact = n.replaceAll("[^a-z\\u0600-\\u06FF]", "");
        if (compact.contains("bein") || compact.contains("بيانسبور") || compact.contains("بينسبورت")) {
            return "bein";
        }
        if (compact.contains("mbc") || compact.contains("امبيسي")) return "mbc";
        return null;
    }

    /** Closes the on-screen keyboard (used when the login / save button is pressed). */
    public static void hideKeyboard(android.view.View v) {
        if (v == null) return;
        try {
            android.view.inputmethod.InputMethodManager imm = (android.view.inputmethod.InputMethodManager)
                    v.getContext().getSystemService(Context.INPUT_METHOD_SERVICE);
            if (imm != null) imm.hideSoftInputFromWindow(v.getWindowToken(), 0);
        } catch (Exception ignored) {
            // nothing to hide
        }
    }

    public static TextView button(Context c, String text, boolean primary) {
        TextView b = new TextView(c);
        b.setText(text);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(ContextCompat.getColor(c, primary ? R.color.on_accent : R.color.text));
        b.setBackgroundResource(primary ? R.drawable.bg_button : R.drawable.bg_button_secondary);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 18), dp(c, 11), dp(c, 18), dp(c, 11));
        return b;
    }
}
