package com.myiptv.app.util;

import android.content.Context;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

public final class Ui {
    private Ui() {}

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    public static TextView button(Context c, String text, boolean primary) {
        TextView b = new TextView(c);
        b.setText(text);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(ContextCompat.getColor(c, primary ? R.color.on_accent : R.color.text));
        b.setBackgroundResource(primary ? R.drawable.bg_button : R.drawable.bg_button_secondary);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 18), dp(c, 11), dp(c, 18), dp(c, 11));
        return b;
    }

    /**
     * Makes the focused card obvious when moving with a remote: a bright ring (set as foreground by the
     * caller), the card grows a little and rises above its neighbours, and its title lights up.
     * {@code focus} is the focusable view, {@code scale} the whole card (poster and title).
     */
    public static void focusPop(final View focus, final View scale, final TextView title,
                                final int normalColor, final int focusColor) {
        final float z = dp(focus.getContext(), 8);
        focus.setOnFocusChangeListener((v, has) -> popApply(scale, title, has, true, z, normalColor, focusColor));
        focus.addOnAttachStateChangeListener(new View.OnAttachStateChangeListener() {
            @Override
            public void onViewAttachedToWindow(View v) {
                // nothing: the focus listener drives the effect
            }

            @Override
            public void onViewDetachedFromWindow(View v) {
                // a recycled card must never come back enlarged
                popApply(scale, title, false, false, z, normalColor, focusColor);
            }
        });
    }

    private static void popApply(View scale, TextView title, boolean on, boolean animate, float z,
                                 int normalColor, int focusColor) {
        scale.animate().cancel();
        float s = on ? 1.07f : 1f;
        if (animate) {
            scale.animate().scaleX(s).scaleY(s).translationZ(on ? z : 0f).setDuration(140).start();
        } else {
            scale.setScaleX(s);
            scale.setScaleY(s);
            scale.setTranslationZ(on ? z : 0f);
        }
        if (title != null) {
            title.setTextColor(on ? focusColor : normalColor);
            title.setTypeface(on ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        }
    }
}
