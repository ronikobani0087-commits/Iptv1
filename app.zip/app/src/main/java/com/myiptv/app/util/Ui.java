package com.myiptv.app.util;

import android.content.Context;
import android.view.Gravity;
import android.widget.TextView;

import androidx.core.content.ContextCompat;

import com.myiptv.app.R;

public final class Ui {
    private Ui() {}

    /** A phone: touch screen, not a TV, shortest side under 480dp. TVs and tablets are left untouched. */
    public static boolean isPhone(Context base) {
        android.content.res.Configuration cfg = base.getResources().getConfiguration();
        boolean tv = (cfg.uiMode & android.content.res.Configuration.UI_MODE_TYPE_MASK)
                == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION;
        boolean touch = base.getPackageManager()
                .hasSystemFeature(android.content.pm.PackageManager.FEATURE_TOUCHSCREEN);
        return !tv && touch && cfg.smallestScreenWidthDp > 0 && cfg.smallestScreenWidthDp < 480;
    }

    /**
     * The whole interface was drawn for a 540dp-high TV screen. A phone held sideways is only about
     * 360dp high, so everything (dp and sp alike) is scaled down evenly to give the same layout the
     * room it was designed for. Returns the context unchanged on TVs and tablets.
     */
    public static Context scaled(Context base) {
        try {
            if (!isPhone(base)) return base;
            android.content.res.Configuration o = base.getResources().getConfiguration();
            float s = Math.max(0.75f, Math.min(1f, o.smallestScreenWidthDp / 480f));
            if (s >= 0.995f || o.densityDpi <= 0) return base;
            android.content.res.Configuration c = new android.content.res.Configuration(o);
            int dpi = Math.round(o.densityDpi * s);
            float k = (float) o.densityDpi / dpi;   // dp units grow by the same factor
            c.densityDpi = dpi;
            c.screenWidthDp = Math.round(o.screenWidthDp * k);
            c.screenHeightDp = Math.round(o.screenHeightDp * k);
            c.smallestScreenWidthDp = Math.round(o.smallestScreenWidthDp * k);
            return base.createConfigurationContext(c);
        } catch (Throwable t) {
            return base;
        }
    }

    public static int dp(Context c, int v) {
        return Math.round(v * c.getResources().getDisplayMetrics().density);
    }

    /** True when the url is a real logo: http(s) and not the provider's "no logo" placeholder picture. */
    public static boolean validLogo(String url) {
        if (url == null || !url.startsWith("http")) return false;
        String letters = url.toLowerCase(java.util.Locale.US).replaceAll("[^a-z]", "");
        return !letters.contains("nologo");
    }

    /** MBC and beIN Sports channels / packages (Latin or Arabic spelling): they always keep an icon. */
    public static boolean keepIcon(String name) {
        return brand(name) != null;
    }

    /** "bein", "mbc" or null: which of the two brands the channel / package name belongs to. */
    public static String brand(String name) {
        if (name == null || name.isEmpty()) return null;
        String n = name.toLowerCase(java.util.Locale.US)
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ة', 'ه').replace('ى', 'ي');
        String compact = n.replaceAll("[^a-z\\u0600-\\u06FF]", "");
        if (compact.contains("bein") || compact.contains("بيانسبور") || compact.contains("بينسبورت")) {
            return "bein";
        }
        if (compact.contains("mbc") || compact.contains("امبيسي")) return "mbc";
        return null;
    }

    public static TextView button(Context c, String text, boolean primary) {
        TextView b = new TextView(c);
        b.setText(text);
        b.setTextSize(15);
        b.setGravity(Gravity.CENTER);
        b.setTextColor(ContextCompat.getColor(c, primary ? R.color.on_accent : R.color.text));
        b.setBackgroundResource(primary ? R.drawable.bg_button : R.drawable.bg_button_secondary);
        b.setFocusable(true);
        b.setClickable(true);
        b.setPadding(dp(c, 18), dp(c, 11), dp(c, 18), dp(c, 11));
        return b;
    }
}
