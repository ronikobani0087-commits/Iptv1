package com.myiptv.app.util;

import android.content.Context;
import android.util.Base64;

import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

/** Reads the short program guide (EPG) of sports channels from an Xtream server and finds matches. */
public final class EpgRepository {
    public static final class Match {
        public String title;
        /** Guide description (some providers put the teams there, not in the title). */
        public String desc = "";
        public String channel;
        public String streamUrl;
        public long start;
        public long stop;
    }

    private static final Pattern MATCH_LIKE =
            Pattern.compile("(?i)(\\bvs?\\b|\\sx\\s|×|ضد|\\s-\\s|–)");
    private static final long CACHE_MS = 5 * 60 * 1000L;

    private static List<Match> cache;
    private static long cacheTime;
    private static long cachePlaylist = -1;

    private EpgRepository() {}

    public static List<Match> load(Playlist p, List<Item> channels) throws Exception {
        synchronized (EpgRepository.class) {
            if (cache != null && cachePlaylist == p.id
                    && System.currentTimeMillis() - cacheTime < CACHE_MS) {
                return cache;
            }
        }
        final String base = p.url;
        final String uenc = URLEncoder.encode(p.username, "UTF-8");
        final String penc = URLEncoder.encode(p.password, "UTF-8");

        List<Callable<List<Match>>> tasks = new ArrayList<>();
        for (final Item ch : channels) {
            tasks.add(new Callable<List<Match>>() {
                @Override
                public List<Match> call() {
                    return fetchOne(base, uenc, penc, ch);
                }
            });
        }
        ExecutorService ex = Executors.newFixedThreadPool(6);
        List<Match> all = new ArrayList<>();
        try {
            List<Future<List<Match>>> futures = ex.invokeAll(tasks, 30, TimeUnit.SECONDS);
            for (Future<List<Match>> f : futures) {
                try {
                    all.addAll(f.get());
                } catch (Exception ignored) {
                    // a slow or failing channel is skipped
                }
            }
        } finally {
            ex.shutdownNow();
        }

        long now = System.currentTimeMillis() / 1000L;
        long limit = now + 36 * 3600L;
        Set<String> seen = new HashSet<>();
        List<Match> out = new ArrayList<>();
        for (Match m : all) {
            if (m.stop <= now || m.start > limit) continue;
            if (!MATCH_LIKE.matcher(m.title).find()) continue;
            String key = m.title.toLowerCase(Locale.ROOT) + "|" + m.start;
            if (!seen.add(key)) continue;
            out.add(m);
        }
        Collections.sort(out, new Comparator<Match>() {
            @Override
            public int compare(Match a, Match b) {
                return Long.compare(a.start, b.start);
            }
        });
        if (out.size() > 30) out = new ArrayList<>(out.subList(0, 30));

        synchronized (EpgRepository.class) {
            cache = out;
            cacheTime = System.currentTimeMillis();
            cachePlaylist = p.id;
        }
        return out;
    }

    private static List<Match> rawCache;
    private static long rawTime;
    private static long rawPlaylist = -1;

    /**
     * Every upcoming / running guide entry of the given channels (no "x vs y" filter, no cap),
     * used to find which channel carries one particular match. Cached for 5 minutes.
     */
    public static List<Match> loadRaw(Playlist p, List<Item> channels) throws Exception {
        synchronized (EpgRepository.class) {
            if (rawCache != null && rawPlaylist == p.id
                    && System.currentTimeMillis() - rawTime < CACHE_MS) {
                return rawCache;
            }
        }
        final String base = p.url;
        final String uenc = URLEncoder.encode(p.username, "UTF-8");
        final String penc = URLEncoder.encode(p.password, "UTF-8");
        List<Callable<List<Match>>> tasks = new ArrayList<>();
        for (final Item ch : channels) {
            tasks.add(new Callable<List<Match>>() {
                @Override
                public List<Match> call() {
                    return fetchOne(base, uenc, penc, ch);
                }
            });
        }
        ExecutorService ex = Executors.newFixedThreadPool(6);
        List<Match> all = new ArrayList<>();
        try {
            for (Future<List<Match>> f : ex.invokeAll(tasks, 25, TimeUnit.SECONDS)) {
                try {
                    all.addAll(f.get());
                } catch (Exception ignored) {
                    // a slow or failing channel is skipped
                }
            }
        } finally {
            ex.shutdownNow();
        }
        long now = System.currentTimeMillis() / 1000L;
        List<Match> out = new ArrayList<>();
        for (Match m : all) {
            if (m.stop > now) out.add(m);
        }
        if (!out.isEmpty()) {
            synchronized (EpgRepository.class) {
                rawCache = out;
                rawTime = System.currentTimeMillis();
                rawPlaylist = p.id;
            }
        }
        return out;
    }

    private static List<Match> fetchOne(String base, String uenc, String penc, Item ch) {
        List<Match> list = new ArrayList<>();
        try {
            String api = base + "/player_api.php?username=" + uenc + "&password=" + penc
                    + "&action=get_short_epg&stream_id=" + URLEncoder.encode(ch.remoteId, "UTF-8")
                    + "&limit=6";
            JSONObject o = new JSONObject(Http.readString(api));
            JSONArray arr = o.optJSONArray("epg_listings");
            if (arr == null) return list;
            for (int i = 0; i < arr.length(); i++) {
                JSONObject e = arr.optJSONObject(i);
                if (e == null) continue;
                String title = decode(e.optString("title", ""));
                if (title.isEmpty()) continue;
                Match m = new Match();
                m.title = title;
                m.desc = decode(e.optString("description", ""));
                m.channel = ch.name == null ? "" : ch.name;
                m.streamUrl = ch.streamUrl;
                m.start = toLong(e.optString("start_timestamp", "0"));
                m.stop = toLong(e.optString("stop_timestamp", "0"));
                if (m.start <= 0 || m.stop <= 0) continue;
                list.add(m);
            }
        } catch (Exception ignored) {
            // no guide for this channel
        }
        return list;
    }

    private static final Pattern B64 = Pattern.compile("^[A-Za-z0-9+/=\\r\\n]+$");

    /** Xtream sends Base64, but some panels send plain text: never turn plain text into garbage. */
    private static String decode(String s) {
        if (s == null || s.isEmpty()) return "";
        String t = s.trim();
        if (t.length() % 4 == 0 && B64.matcher(t).matches()) {
            try {
                String d = new String(Base64.decode(t, Base64.DEFAULT), "UTF-8").trim();
                if (!d.isEmpty() && d.indexOf('\uFFFD') < 0) return d;
            } catch (Exception ignored) {
                // not Base64 after all
            }
        }
        return t;
    }

    private static long toLong(String s) {
        try {
            return Long.parseLong(s.trim());
        } catch (Exception e) {
            return 0L;
        }
    }
}
