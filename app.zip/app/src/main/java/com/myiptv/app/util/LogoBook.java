package com.myiptv.app.util;

import com.myiptv.app.data.AppDao;
import com.myiptv.app.data.NameLogo;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Logos borrowed between sibling channels: a channel without a logo of its own takes the logo of
 * another channel with the same name once quality tags, numbers and letters are removed
 * (e.g. "SD - بي ان سبورت 2" and "بي ان سبورت 1" share one logo).
 */
public final class LogoBook {
    private final Map<String, String> byKey = new HashMap<String, String>();
    private String bein;
    private String mbc;

    private static final java.util.regex.Pattern BRACKETS =
            java.util.regex.Pattern.compile("\\([^)]*\\)|\\[[^\\]]*\\]");
    private static final java.util.regex.Pattern SPLIT =
            java.util.regex.Pattern.compile("[^a-z0-9\\u0600-\\u06FF]+");
    private static final java.util.regex.Pattern DIGITS = java.util.regex.Pattern.compile("[0-9]+");
    private static final java.util.regex.Pattern SHORT = java.util.regex.Pattern.compile("[a-z0-9]{1,2}");

    private LogoBook() {}

    public static LogoBook load(AppDao dao, long playlistId) {
        LogoBook b = new LogoBook();
        for (NameLogo n : dao.logoNames(playlistId)) {
            String k = key(n.name);
            if (k != null && !b.byKey.containsKey(k)) b.byKey.put(k, n.icon);
        }
        b.bein = dao.beinLogo(playlistId);
        b.mbc = dao.mbcLogo(playlistId);
        return b;
    }

    /** Logo of the same brand as the name (beIN / MBC only), or null. */
    public String findBrand(String name) {
        String brand = Ui.brand(name);
        if ("bein".equals(brand)) return bein;
        if ("mbc".equals(brand)) return mbc;
        return null;
    }

    /** Logo of a sibling channel (same name key), else the brand logo, or null. */
    public String find(String name) {
        String k = key(name);
        String v = k == null ? null : byKey.get(k);
        return v != null ? v : findBrand(name);
    }

    private static boolean tag(String t) {
        return t.equals("fhd") || t.equals("uhd") || t.equals("hevc") || t.equals("raw")
                || t.equals("backup") || t.equals("live") || t.equals("sd") || t.equals("hd")
                || t.equals("4k") || t.equals("8k");
    }

    /** Name without country prefix, quality tags, numbers and a trailing letter; null if nothing is left. */
    static String key(String name) {
        if (name == null || name.isEmpty()) return null;
        String n = BRACKETS.matcher(name.toLowerCase(Locale.US)).replaceAll(" ")
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ة', 'ه').replace('ى', 'ي');
        StringBuilder sb = new StringBuilder();
        for (String t : SPLIT.split(n)) {
            if (t.isEmpty() || tag(t)) continue;
            if (DIGITS.matcher(t).matches()) continue;
            if (SHORT.matcher(t).matches()) continue;   // "ar", "a", "b", "2k" ...
            sb.append(t);
        }
        return sb.length() < 3 ? null : sb.toString();
    }
}
