package com.myiptv.app.data;

import android.net.Uri;

import java.util.Locale;

/** Builds a Playlist from what the user typed: M3U link, Xtream server, or full get.php link. */
public final class PlaylistFactory {
    private PlaylistFactory() {}

    public static Playlist build(String name, String server, String user, String pass) {
        String s = server.trim();
        if (!s.toLowerCase(Locale.ROOT).startsWith("http://") && !s.toLowerCase(Locale.ROOT).startsWith("https://")) {
            s = "http://" + s;
        }
        Uri uri = Uri.parse(s);
        String host = uri.getHost();
        if (host == null || host.isEmpty()) {
            throw new IllegalArgumentException("الرابط غير صالح");
        }
        user = user == null ? "" : user.trim();
        pass = pass == null ? "" : pass.trim();

        Playlist p = new Playlist();
        p.name = (name == null || name.trim().isEmpty()) ? host : name.trim();
        p.username = "";
        p.password = "";

        String lower = s.toLowerCase(Locale.ROOT);
        String qu = uri.getQueryParameter("username");
        String qp = uri.getQueryParameter("password");
        int idx = lower.indexOf("/get.php");
        if (idx < 0) idx = lower.indexOf("/player_api.php");

        if (qu != null && qp != null && idx > 0) {
            p.type = "xtream";
            p.url = trimSlash(s.substring(0, idx));
            p.username = qu;
            p.password = qp;
            return p;
        }
        if (!user.isEmpty() || !pass.isEmpty()) {
            if (user.isEmpty() || pass.isEmpty()) {
                throw new IllegalArgumentException("أدخل اسم المستخدم وكلمة المرور معاً");
            }
            String base = s;
            int i = base.toLowerCase(Locale.ROOT).indexOf("/player_api.php");
            if (i > 0) base = base.substring(0, i);
            p.type = "xtream";
            p.url = trimSlash(base);
            p.username = user;
            p.password = pass;
            return p;
        }
        p.type = "m3u";
        p.url = s;
        return p;
    }

    private static String trimSlash(String s) {
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
}
