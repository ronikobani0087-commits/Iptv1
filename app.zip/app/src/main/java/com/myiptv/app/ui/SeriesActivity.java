package com.myiptv.app.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SeriesRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.util.List;

/** Series details: poster, story, play / favorite buttons, seasons and the list of episodes. */
public class SeriesActivity extends BaseActivity {
    private static final String EXTRA_PID = "pid";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_ID = "sid";
    private static final String EXTRA_ICON = "icon";

    public static void start(Context context, long playlistId, String name, String seriesId,
                             String icon) {
        Intent i = new Intent(context, SeriesActivity.class);
        i.putExtra(EXTRA_PID, playlistId);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_ID, seriesId);
        i.putExtra(EXTRA_ICON, icon);
        context.startActivity(i);
    }

    private long pid = -1;
    private String seriesName = "";
    private String seriesId = "";
    private String icon = "";

    private SeriesRepository.Info info;
    private History hist;
    private boolean fav;
    private int season = 1;
    private SeriesRepository.Episode resumeEp;
    /** Url of the episode the person opened last: the selection returns to it after the player. */
    private String lastPlayedUrl = "";

    private ImageView backdrop;
    private ImageView poster;
    private TextView titleView;
    private TextView metaView;
    private TextView plotView;
    private TextView castView;
    private TextView playBtn;
    private TextView favBtn;
    private LinearLayout seasonRow;
    private HorizontalScrollView seasonScroll;
    private LinearLayout episodesBox;
    private ScrollView episodeScroll;
    private TextView statusView;
    private int rowHeightPx;
    private View lineMeta, linePlot;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pid = getIntent().getLongExtra(EXTRA_PID, -1L);
        String n = getIntent().getStringExtra(EXTRA_NAME);
        String id = getIntent().getStringExtra(EXTRA_ID);
        String ic = getIntent().getStringExtra(EXTRA_ICON);
        seriesName = n == null ? "" : n;
        seriesId = id == null ? "" : id;
        icon = ic == null ? "" : ic;
        if (pid < 0 || seriesId.isEmpty()) {
            finish();
            return;
        }
        setContentView(buildUi());
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (info == null) return;
        final Context app = getApplicationContext();
        Async.io(() -> {
            final History h = UserDatabase.get(app).dao().getHistory(pid, "series", seriesId);
            Async.main(() -> {
                if (isFinishing() || isDestroyed()) return;
                hist = h;
                updatePlayButton();
                showSeason(season);
            });
        });
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackgroundColor(ContextCompat.getColor(c, R.color.bg));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView appBg = new ImageView(c);
        appBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        appBg.setImageResource(R.drawable.bg_main);
        root.addView(appBg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        backdrop = new ImageView(c);
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setAlpha(0.45f);
        root.addView(backdrop, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // the poster and the details (title, plot, buttons) stay fixed; only the episodes list scrolls
        LinearLayout outer = new LinearLayout(c);
        outer.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(outer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // short (phone) screens: a tighter header, so the list below gets room for six episodes
        final boolean compact = getResources().getDisplayMetrics().heightPixels
                / getResources().getDisplayMetrics().density < 480f;
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, compact ? 6 : 12), Ui.dp(c, 24), Ui.dp(c, compact ? 4 : 16));
        outer.addView(col, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        poster = new ImageView(c);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
        CardStrip.round(poster, Ui.dp(c, 12));

        // the poster (big, 2:3) sits on the left, the details, seasons and episodes on the right
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int posterH = Math.min(Ui.dp(c, 460), dm.heightPixels - Ui.dp(c, 56));
        int posterW = Math.round(posterH * 0.68f);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(posterW, posterH);
        pp.setMarginStart(Ui.dp(c, 4));
        pp.setMarginEnd(Ui.dp(c, 24));
        pp.topMargin = Ui.dp(c, 20);
        outer.addView(poster, pp);
        // the episodes list is narrower than the details column: about 72% of it, on the start side
        int colW = dm.widthPixels - posterW - Ui.dp(c, 28) - Ui.dp(c, 48);
        final int listW = Math.round(colW * 0.86f);

        titleView = new TextView(c);
        titleView.setText(seriesName);
        titleView.setTextColor(ContextCompat.getColor(c, R.color.text));
        titleView.setTextSize(compact ? 22 : 26);
        titleView.setShadowLayer(6f, 0f, 2f, 0xCC000000);
        titleView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        titleView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        titleView.setGravity(Gravity.START);
        col.addView(titleView);

        metaView = new TextView(c);
        metaView.setTextColor(ContextCompat.getColor(c, R.color.muted));
        metaView.setTextSize(compact ? 13 : 15);
        metaView.setShadowLayer(5f, 0f, 1f, 0xCC000000);
        metaView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        metaView.setGravity(Gravity.START);
        metaView.setVisibility(View.GONE);
        col.addView(metaView, topMargin(c, compact ? 1 : 4));
        lineMeta = thinLine(c);
        lineMeta.setVisibility(View.GONE);
        col.addView(lineMeta, lineLp(c, compact ? 4 : 8));

        plotView = new TextView(c);
        plotView.setTextColor(ContextCompat.getColor(c, R.color.text));
        plotView.setTextSize(compact ? 15 : 19);
        plotView.setShadowLayer(6f, 0f, 2f, 0xE6000000);
        plotView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        plotView.setLineSpacing(0, 1.25f);
        plotView.setMaxLines(2);
        plotView.setEllipsize(TextUtils.TruncateAt.END);
        plotView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        plotView.setGravity(Gravity.START);
        plotView.setVisibility(View.GONE);
        col.addView(plotView, topMargin(c, compact ? 4 : 10));
        linePlot = thinLine(c);
        linePlot.setVisibility(View.GONE);
        col.addView(linePlot, lineLp(c, compact ? 4 : 8));

        castView = new TextView(c);
        castView.setTextColor(ContextCompat.getColor(c, R.color.muted));
        castView.setTextSize(compact ? 13 : 16);
        castView.setShadowLayer(5f, 0f, 1f, 0xCC000000);
        castView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        castView.setMaxLines(1);
        castView.setEllipsize(TextUtils.TruncateAt.END);
        castView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        castView.setGravity(Gravity.START);
        castView.setVisibility(View.GONE);
        col.addView(castView, topMargin(c, compact ? 4 : 8));

        LinearLayout buttons = new LinearLayout(c);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        col.addView(buttons, topMargin(c, compact ? 5 : 10));

        playBtn = Ui.button(c, "جارٍ التحميل…", true);
        playBtn.setVisibility(View.GONE); // no play button on this page: episodes are played from the list

        favBtn = Ui.button(c, "☆ إضافة إلى المفضلة", false);
        favBtn.setOnClickListener(v -> toggleFavorite());
        LinearLayout.LayoutParams fbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fbp.setMarginStart(0);
        buttons.addView(favBtn, fbp);

        // seasons: on the buttons row, to the left of "add to favourites"
        seasonScroll = new HorizontalScrollView(c);
        seasonScroll.setHorizontalScrollBarEnabled(false);
        seasonScroll.setVisibility(View.GONE);
        seasonRow = new LinearLayout(c);
        seasonRow.setOrientation(LinearLayout.HORIZONTAL);
        seasonScroll.addView(seasonRow, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams ssp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ssp.setMarginStart(Ui.dp(c, 10));
        buttons.addView(seasonScroll, ssp);

        // episodes
        episodesBox = new LinearLayout(c);
        episodesBox.setOrientation(LinearLayout.VERTICAL);
        episodesBox.setBackgroundResource(R.drawable.bg_episodes_panel);
        episodesBox.setPadding(Ui.dp(c, 8), Ui.dp(c, compact ? 2 : 4), Ui.dp(c, 8), Ui.dp(c, compact ? 2 : 4));
        episodeScroll = new ScrollView(c);
        episodeScroll.setFillViewport(false);
        episodeScroll.setVerticalScrollBarEnabled(false);
        episodeScroll.addView(episodesBox, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams esp = new LinearLayout.LayoutParams(listW, 0, 1f);
        esp.gravity = Gravity.START;
        esp.topMargin = Ui.dp(c, compact ? 5 : 10);
        col.addView(episodeScroll, esp);

        statusView = new TextView(c);
        statusView.setText("جارٍ تحميل الحلقات…");
        statusView.setTextColor(ContextCompat.getColor(c, R.color.muted));
        statusView.setTextSize(14);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, Ui.dp(c, 24), 0, Ui.dp(c, 24));
        episodesBox.addView(statusView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // size the episode rows so that six of them are always fully visible
        episodeScroll.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            int h = b - t;
            if (h <= 0 || h == ob - ot) return;
            int pad = episodesBox.getPaddingTop() + episodesBox.getPaddingBottom();
            int per = (h - pad) / 6;
            int margins = 2 * Ui.dp(c, 1);
            int rh = Math.max(Ui.dp(c, 24), Math.min(Ui.dp(c, 64), per - margins));
            if (rh != rowHeightPx) {
                rowHeightPx = rh;
                if (info != null) episodeScroll.post(() -> showSeason(season, false));
            }
        });

        // the cover from the list shows right away, before the details arrive
        CardStrip.load(poster, icon, R.drawable.ic_series, 420, 620);
        return root;
    }

    /** Thin translucent white divider between the year line, the story and the cast. */
    private static View thinLine(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0x4DFFFFFF);
        return v;
    }

    private static LinearLayout.LayoutParams lineLp(Context c, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(c, 1)));
        lp.topMargin = Ui.dp(c, topDp);
        return lp;
    }

    private static LinearLayout.LayoutParams topMargin(Context c, int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, dp);
        return lp;
    }

    // ---------------------------------------------------------------- data

    private void load() {
        final Context app = getApplicationContext();
        Async.io(() -> {
            try {
                Playlist p = AppDatabase.get(app).dao().getPlaylist(pid);
                final SeriesRepository.Info inf = SeriesRepository.load(p, seriesId);
                UserDao ud = UserDatabase.get(app).dao();
                final History h = ud.getHistory(pid, "series", seriesId);
                final boolean isFav = ud.favoriteIds(pid, "series").contains(seriesId);
                Async.main(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    onLoaded(inf, h, isFav);
                });
            } catch (Exception ex) {
                final String m = ex.getMessage() == null ? "تعذر تحميل الحلقات" : ex.getMessage();
                Async.main(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText(m);
                    playBtn.setText("تعذر التحميل");
                });
            }
        });
    }

    private void onLoaded(SeriesRepository.Info inf, History h, boolean isFav) {
        info = inf;
        hist = h;
        fav = isFav;

        if (!inf.name.isEmpty()) titleView.setText(inf.name);

        StringBuilder meta = new StringBuilder();
        append(meta, inf.year);
        append(meta, inf.genre);
        if (!inf.rating.isEmpty() && !"0".equals(inf.rating)) append(meta, "★ " + inf.rating);
        metaView.setText(meta.toString());
        metaView.setVisibility(meta.length() == 0 ? View.GONE : View.VISIBLE);

        plotView.setText(inf.plot);
        plotView.setVisibility(inf.plot.isEmpty() ? View.GONE : View.VISIBLE);
        linePlot.setVisibility(inf.plot.isEmpty() ? View.GONE : View.VISIBLE);
        lineMeta.setVisibility(meta.length() == 0 ? View.GONE : View.VISIBLE);
        castView.setText(inf.cast.isEmpty() ? "" : "البطولة: " + inf.cast);
        castView.setVisibility(inf.cast.isEmpty() ? View.GONE : View.VISIBLE);

        String cover = inf.cover.startsWith("http") ? inf.cover : icon;
        CardStrip.load(poster, cover, R.drawable.ic_series, 420, 620);
        String back = inf.backdrop.startsWith("http") ? inf.backdrop : cover;
        if (back != null && back.startsWith("http")) {
            Glide.with(this).load(back).into(backdrop);
        }

        // start on the season of the last watched episode
        season = 1;
        List<Integer> seasons = inf.seasons();
        if (!seasons.isEmpty()) season = seasons.get(0);
        if (h != null && h.streamUrl != null) {
            for (SeriesRepository.Episode e : inf.episodes) {
                if (h.streamUrl.equals(e.url)) {
                    season = e.season;
                    break;
                }
            }
        }

        updateFavButton();
        updatePlayButton();
        buildSeasonRow();
        showSeason(season);
    }

    private static void append(StringBuilder sb, String part) {
        if (part == null || part.isEmpty()) return;
        if (sb.length() > 0) sb.append("  ·  ");
        sb.append(part);
    }

    // ------------------------------------------------------------ buttons

    private void updatePlayButton() {
        if (info == null) return;
        resumeEp = null;
        boolean resume = false;
        if (hist != null && hist.streamUrl != null) {
            for (SeriesRepository.Episode e : info.episodes) {
                if (hist.streamUrl.equals(e.url)) {
                    resumeEp = e;
                    resume = true;
                    break;
                }
            }
        }
        if (resumeEp == null && !info.episodes.isEmpty()) resumeEp = info.episodes.get(0);
        if (resumeEp == null) {
            playBtn.setText("لا توجد حلقات");
            playBtn.setOnClickListener(null);
            return;
        }
        final SeriesRepository.Episode target = resumeEp;
        final long pos = resume && hist != null ? hist.positionMs : 0L;
        playBtn.setText((resume ? "▶ متابعة " : "▶ تشغيل ") + target.shortLabel());
        playBtn.setOnClickListener(v -> playEpisode(target, pos));
    }

    private void updateFavButton() {
        favBtn.setText(fav ? "★ في المفضلة" : "☆ إضافة إلى المفضلة");
    }

    private void toggleFavorite() {
        final boolean was = fav;
        fav = !fav;
        updateFavButton();
        Toast.makeText(this, was ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
        final Context app = getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (was) {
                ud.removeFavorite(pid, "series", seriesId);
                com.myiptv.app.util.Prefs.markHomeDirty();
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = "series";
                f.remoteId = seriesId;
                f.name = seriesName;
                f.icon = icon;
                f.streamUrl = "";
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
                com.myiptv.app.util.Prefs.markHomeDirty();
            }
        });
    }

    // ------------------------------------------------------ seasons / episodes

    private void buildSeasonRow() {
        seasonRow.removeAllViews();
        List<Integer> seasons = info.seasons();
        seasonScroll.setVisibility(seasons.isEmpty() ? View.GONE : View.VISIBLE);
        for (final Integer s : seasons) {
            boolean sel = s == season;
            TextView chip = Ui.button(this, "الموسم " + s, sel);
            chip.setTextSize(13);
            chip.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8));
            chip.setOnClickListener(v -> {
                season = s;
                buildSeasonRow();
                showSeason(season, false);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(Ui.dp(this, 8));
            seasonRow.addView(chip, lp);
        }
    }

    private void showSeason(int s) {
        showSeason(s, true);
    }

    private void showSeason(int s, boolean focusFirst) {
        episodesBox.removeAllViews();
        if (info == null) return;
        View firstRow = null;
        View targetRow = null;
        // the saved place first (it also follows an episode opened from the player's "next" box)
        String wanted = hist != null && hist.streamUrl != null && !hist.streamUrl.isEmpty()
                ? hist.streamUrl : lastPlayedUrl;
        int shown = 0;
        for (final SeriesRepository.Episode e : info.episodes) {
            if (e.season != s) continue;
            View row = buildRow(e);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = Ui.dp(this, 1);
            rlp.bottomMargin = Ui.dp(this, 1);
            if (rowHeightPx > 0) rlp.height = rowHeightPx;
            episodesBox.addView(row, rlp);
            if (shown == 0) firstRow = row;
            if (!wanted.isEmpty() && wanted.equals(e.url)) targetRow = row;
            shown++;
        }
        // the selection rectangle stays on the episode watched last (the first one when none yet)
        View focusRow = targetRow != null ? targetRow : firstRow;
        if (focusRow != null && focusFirst) {
            final View fr = focusRow;
            episodeScroll.post(() -> {
                fr.requestFocus();
                int y = fr.getTop() - Math.max(0, (episodeScroll.getHeight() - fr.getHeight()) / 2);
                episodeScroll.scrollTo(0, Math.max(0, y));
            });
        }
        if (shown == 0) {
            TextView none = new TextView(this);
            none.setText("لا توجد حلقات لهذا الموسم");
            none.setTextColor(ContextCompat.getColor(this, R.color.muted));
            none.setGravity(Gravity.CENTER);
            none.setPadding(0, Ui.dp(this, 24), 0, Ui.dp(this, 24));
            episodesBox.addView(none);
        }
    }

    private View buildRow(final SeriesRepository.Episode e) {
        Context c = this;
        final boolean current = hist != null && e.url.equals(hist.streamUrl);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(c, 12), 0, Ui.dp(c, 12), 0);
        row.setBackgroundResource(R.drawable.bg_episode);
        row.setSelected(current);
        row.setFocusable(true);
        row.setClickable(true);
        row.setOnClickListener(v -> playEpisode(e, current && hist != null ? hist.positionMs : 0L));

        TextView num = new TextView(c);
        num.setText(String.valueOf(e.number));
        num.setTextColor(ContextCompat.getColor(c, R.color.muted));
        // text and eye follow the row height, so a short row never clips them
        final float rowDp = rowHeightPx > 0 ? rowHeightPx / c.getResources().getDisplayMetrics().density : 64f;
        final float nameSp = Math.max(13f, Math.min(23f, rowDp * 0.5f));
        num.setTextSize(Math.max(12f, Math.min(20f, nameSp * 0.9f)));
        num.setGravity(Gravity.CENTER);
        row.addView(num, new LinearLayout.LayoutParams(Ui.dp(c, 44), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView name = new TextView(c);
        String title = e.title.isEmpty() ? e.longLabel() : e.title;
        name.setText((current ? "▶ " : "") + title);
        name.setTextColor(ContextCompat.getColor(c, R.color.text));
        name.setTextSize(nameSp);
        name.setMaxLines(1);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        name.setGravity(Gravity.START);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        np.setMarginStart(Ui.dp(c, 6));
        np.setMarginEnd(Ui.dp(c, 6));
        row.addView(name, np);

        // eye: bright when the episode is not watched yet, dim when it was watched
        boolean seen = current || Prefs.isSeen(c, pid, seriesId, e.url, e.longLabel(), e.shortLabel());
        ImageView eye = new ImageView(c);
        eye.setImageResource(R.drawable.ic_eye);
        eye.setColorFilter(seen ? ContextCompat.getColor(c, R.color.muted) : ContextCompat.getColor(c, R.color.eye));
        eye.setAlpha(seen ? 0.45f : 1f);
        eye.setContentDescription(seen ? "تمت المشاهدة" : "لم تُشاهد");
        int eyeDp = Math.round(Math.max(18f, Math.min(32f, rowDp * 0.7f)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(Ui.dp(c, eyeDp), Ui.dp(c, eyeDp));
        ep.setMarginEnd(Ui.dp(c, 10));
        row.addView(eye, ep);

        return row;
    }

    // ------------------------------------------------------------- actions

    private void playEpisode(SeriesRepository.Episode e, long positionMs) {
        lastPlayedUrl = e.url;
        PlayerActivity.startTracked(this, e.url, seriesName + " - " + e.longLabel(), pid, "series",
                seriesId, seriesName, icon, e.longLabel(), positionMs);
    }
}
