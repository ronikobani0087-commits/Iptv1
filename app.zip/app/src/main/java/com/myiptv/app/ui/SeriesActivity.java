package com.myiptv.app.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SeriesRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.util.List;

/** Series details: poster, story, play / favorite buttons, seasons and the list of episodes. */
public class SeriesActivity extends BaseActivity {
    private static final String EXTRA_PID = "pid";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_ID = "sid";
    private static final String EXTRA_ICON = "icon";

    public static void start(Context context, long playlistId, String name, String seriesId,
                             String icon) {
        Intent i = new Intent(context, SeriesActivity.class);
        i.putExtra(EXTRA_PID, playlistId);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_ID, seriesId);
        i.putExtra(EXTRA_ICON, icon);
        context.startActivity(i);
    }

    private long pid = -1;
    private String seriesName = "";
    private String seriesId = "";
    private String icon = "";

    private SeriesRepository.Info info;
    private History hist;
    private boolean fav;
    private int season = 1;
    private SeriesRepository.Episode resumeEp;
    /** Url of the episode the person opened last: the selection returns to it after the player. */
    private String lastPlayedUrl = "";
    /** When that episode was opened (a newer watch-history entry means the player moved on to another). */
    private long lastPlayedAt = 0L;

    private ImageView backdrop;
    private ImageView poster;
    private TextView titleView;
    private TextView metaView;
    private TextView plotView;
    private TextView castView;
    private TextView playBtn;
    private TextView favBtn;
    private LinearLayout seasonRow;
    private HorizontalScrollView seasonScroll;
    private LinearLayout episodesBox;
    private ScrollView episodeScroll;
    private TextView statusView;
    private int rowHeightPx;
    private View lineTitle, lineMeta, linePlot;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pid = getIntent().getLongExtra(EXTRA_PID, -1L);
        String n = getIntent().getStringExtra(EXTRA_NAME);
        String id = getIntent().getStringExtra(EXTRA_ID);
        String ic = getIntent().getStringExtra(EXTRA_ICON);
        seriesName = n == null ? "" : n;
        seriesId = id == null ? "" : id;
        icon = ic == null ? "" : ic;
        if (pid < 0 || seriesId.isEmpty()) {
            finish();
            return;
        }
        setContentView(buildUi());
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (info == null) return;
        refreshFromHistory(true);
        // the player saves its place when it is closed, which can be a moment AFTER this page is shown
        // again: read the history once more so the rectangle and the eyes follow the episode just watched
        if (lastPlayedAt > 0) {
            episodesBox.postDelayed(() -> {
                if (!isFinishing() && !isDestroyed()) refreshFromHistory(false);
            }, 1200);
        }
    }

    private void refreshFromHistory(final boolean force) {
        final Context app = getApplicationContext();
        Async.io(() -> {
            final History h = UserDatabase.get(app).dao().getHistory(pid, "series", seriesId);
            Async.main(() -> {
                if (isFinishing() || isDestroyed() || info == null) return;
                boolean same = hist == null ? h == null
                        : h != null && hist.updatedAt == h.updatedAt && sameUrl(hist.streamUrl, h.streamUrl);
                if (!force && same) return;
                hist = h;
                updatePlayButton();
                showSeason(season);
            });
        });
    }

    private static boolean sameUrl(String a, String b) {
        return (a == null ? "" : a).equals(b == null ? "" : b);
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackgroundColor(ContextCompat.getColor(c, R.color.bg));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView appBg = new ImageView(c);
        appBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        appBg.setImageResource(R.drawable.bg_main);
        root.addView(appBg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        backdrop = new ImageView(c);
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setAlpha(0.5f);    // the same picture, dimmed, behind the whole page (the scrim darkens it further)
        root.addView(backdrop, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        View scrim = new View(c);
        scrim.setBackgroundResource(R.drawable.bg_series_scrim);
        root.addView(scrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // the poster and the details (title, plot, buttons) stay fixed; only the episodes list scrolls
        LinearLayout outer = new LinearLayout(c);
        outer.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(outer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // short (phone) screens: a tighter header, so the list below gets room for six episodes
        final boolean compact = getResources().getDisplayMetrics().heightPixels
                / getResources().getDisplayMetrics().density < 480f;
        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, compact ? 6 : 12), Ui.dp(c, 24), Ui.dp(c, compact ? 4 : 16));
        outer.addView(col, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        poster = new ImageView(c);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
        CardStrip.round(poster, Ui.dp(c, 11));

        // the poster (big, 2:3) sits on the left in its own card, the details, seasons and episodes on the right
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int posterH = Math.min(Ui.dp(c, 460), dm.heightPixels - Ui.dp(c, 56));
        int posterW = Math.round(posterH * 0.68f);
        FrameLayout posterCard = new FrameLayout(c);
        posterCard.setBackgroundResource(R.drawable.bg_poster_card);
        int cardPad = Ui.dp(c, 3);
        posterCard.setPadding(cardPad, cardPad, cardPad, cardPad);
        posterCard.addView(poster, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(posterW, posterH);
        pp.setMarginStart(Ui.dp(c, 4));
        pp.setMarginEnd(Ui.dp(c, 24));
        pp.topMargin = Ui.dp(c, 20);
        outer.addView(posterCard, pp);

        // title, then "النوع | السنة | المخرج", a line, the cast, a line, the story
        titleView = new TextView(c);
        titleView.setText(seriesName);
        titleView.setTextColor(ContextCompat.getColor(c, R.color.text));
        titleView.setTextSize(compact ? 24 : 30);
        titleView.setShadowLayer(6f, 0f, 2f, 0xCC000000);
        titleView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        titleView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        titleView.setGravity(Gravity.START);
        titleView.setSingleLine(true);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(titleView);
        // translucent white line between the title and the genre line
        lineTitle = thinLine(c);
        lineTitle.setVisibility(View.GONE);
        col.addView(lineTitle, lineLp(c, compact ? 4 : 8));

        metaView = new TextView(c);
        metaView.setTextColor(0xFFE3EDF0);
        metaView.setTextSize(compact ? 13 : 16);
        metaView.setShadowLayer(5f, 0f, 1f, 0xCC000000);
        metaView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        metaView.setGravity(Gravity.START);
        metaView.setSingleLine(true);
        metaView.setEllipsize(TextUtils.TruncateAt.END);
        metaView.setVisibility(View.GONE);
        col.addView(metaView, topMargin(c, compact ? 2 : 6));
        lineMeta = thinLine(c);
        lineMeta.setVisibility(View.GONE);
        col.addView(lineMeta, lineLp(c, compact ? 4 : 10));

        castView = new TextView(c);
        castView.setTextColor(0xFFE3EDF0);
        castView.setTextSize(compact ? 13 : 16);
        castView.setShadowLayer(5f, 0f, 1f, 0xCC000000);
        castView.setMaxLines(2);
        castView.setEllipsize(TextUtils.TruncateAt.END);
        castView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        castView.setGravity(Gravity.START);
        castView.setVisibility(View.GONE);
        col.addView(castView, topMargin(c, compact ? 4 : 10));
        linePlot = thinLine(c);
        linePlot.setVisibility(View.GONE);
        col.addView(linePlot, lineLp(c, compact ? 4 : 10));

        plotView = new TextView(c);
        plotView.setTextColor(ContextCompat.getColor(c, R.color.text));
        plotView.setTextSize(compact ? 14 : 18);
        plotView.setShadowLayer(6f, 0f, 2f, 0xE6000000);
        plotView.setLineSpacing(0, 1.3f);
        plotView.setMaxLines(compact ? 2 : 3);
        plotView.setEllipsize(TextUtils.TruncateAt.END);
        plotView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        plotView.setGravity(Gravity.START);
        plotView.setVisibility(View.GONE);
        col.addView(plotView, topMargin(c, compact ? 4 : 10));

        LinearLayout buttons = new LinearLayout(c);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        col.addView(buttons, topMargin(c, compact ? 6 : 14));

        playBtn = Ui.button(c, "جارٍ التحميل…", true);
        playBtn.setVisibility(View.GONE); // no play button on this page: episodes are played from the list

        // "المفضلة" first (right side), the season chip beside it on the left
        favBtn = Ui.button(c, "☆ المفضلة", false);
        stylePill(favBtn, false);
        favBtn.setOnClickListener(v -> toggleFavorite());
        LinearLayout.LayoutParams fbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fbp.setMarginStart(0);
        buttons.addView(favBtn, fbp);

        seasonScroll = new HorizontalScrollView(c);
        seasonScroll.setHorizontalScrollBarEnabled(false);
        seasonScroll.setVisibility(View.GONE);
        seasonRow = new LinearLayout(c);
        seasonRow.setOrientation(LinearLayout.HORIZONTAL);
        seasonScroll.addView(seasonRow, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams ssp = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        ssp.setMarginStart(Ui.dp(c, 12));
        buttons.addView(seasonScroll, ssp);

        // episodes: one rounded panel, as wide as the details column
        episodesBox = new LinearLayout(c);
        episodesBox.setOrientation(LinearLayout.VERTICAL);
        episodesBox.setBackgroundResource(R.drawable.bg_episodes_panel);
        episodesBox.setPadding(Ui.dp(c, 8), Ui.dp(c, compact ? 3 : 6), Ui.dp(c, 8), Ui.dp(c, compact ? 3 : 6));
        episodeScroll = new ScrollView(c);
        episodeScroll.setFillViewport(false);
        episodeScroll.setVerticalScrollBarEnabled(false);
        episodeScroll.addView(episodesBox, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams esp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        esp.topMargin = Ui.dp(c, compact ? 6 : 14);
        col.addView(episodeScroll, esp);

        statusView = new TextView(c);
        statusView.setText("جارٍ تحميل الحلقات…");
        statusView.setTextColor(ContextCompat.getColor(c, R.color.muted));
        statusView.setTextSize(14);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, Ui.dp(c, 24), 0, Ui.dp(c, 24));
        episodesBox.addView(statusView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // size the episode rows so that six of them are always fully visible (a 1dp divider between rows)
        episodeScroll.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            int h = b - t;
            if (h <= 0 || h == ob - ot) return;
            int pad = episodesBox.getPaddingTop() + episodesBox.getPaddingBottom();
            int per = (h - pad) / 6;
            int rh = Math.max(Ui.dp(c, 24), Math.min(Ui.dp(c, 64), per));
            if (rh != rowHeightPx) {
                rowHeightPx = rh;
                if (info != null) episodeScroll.post(() -> showSeason(season, false));
            }
        });

        // the cover from the list shows right away, before the details arrive
        CardStrip.load(poster, icon, R.drawable.ic_series, 420, 620);
        return root;
    }

    /** Rounded pill look of "المفضلة" and the season chips (cyan edge when selected). */
    private void stylePill(TextView b, boolean selected) {
        b.setBackgroundResource(R.drawable.bg_pill_btn);
        b.setSelected(selected);
        b.setTextColor(ContextCompat.getColor(this, selected ? R.color.eye : R.color.text));
        b.setTextSize(15);
        b.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        b.setPadding(Ui.dp(this, 22), Ui.dp(this, 9), Ui.dp(this, 22), Ui.dp(this, 9));
    }

    /** "النوع: دراما | 2026 | المخرج: ..." with the labels in the accent colour. */
    private CharSequence buildMeta(SeriesRepository.Info inf) {
        android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder();
        int cyan = 0xFFE3EDF0; // labels share the colour of the text beside them
        appendPart(sb, "النوع:", inf.genre, cyan);
        appendPart(sb, null, inf.year, cyan);
        appendPart(sb, "المخرج:", inf.director, cyan);
        if (inf.rating != null && !inf.rating.isEmpty() && !"0".equals(inf.rating)) {
            appendPart(sb, null, "★ " + inf.rating, cyan);
        }
        return sb;
    }

    private static void appendPart(android.text.SpannableStringBuilder sb, String label, String value, int labelColor) {
        if (value == null || value.trim().isEmpty()) return;
        if (sb.length() > 0) sb.append("   |   ");
        if (label != null) {
            int st = sb.length();
            sb.append(label);
            sb.setSpan(new android.text.style.ForegroundColorSpan(labelColor), st, sb.length(),
                    android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            sb.append(' ');
        }
        sb.append(value.trim());
    }

    /** The cast line: "البطولة:" in the accent colour, then the names. */
    private CharSequence buildCast(String cast) {
        android.text.SpannableStringBuilder sb = new android.text.SpannableStringBuilder("البطولة:");
        sb.setSpan(new android.text.style.ForegroundColorSpan(0xFFE3EDF0),
                0, sb.length(), android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.setSpan(new android.text.style.StyleSpan(android.graphics.Typeface.BOLD), 0, sb.length(),
                android.text.Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        sb.append(' ').append(cast.trim());
        return sb;
    }

    /** Thin translucent white divider between the year line, the story and the cast. */
    private static View thinLine(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0x4DFFFFFF);
        return v;
    }

    private static LinearLayout.LayoutParams lineLp(Context c, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(c, 1)));
        lp.topMargin = Ui.dp(c, topDp);
        return lp;
    }

    private static LinearLayout.LayoutParams topMargin(Context c, int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, dp);
        return lp;
    }

    // ---------------------------------------------------------------- data

    private void load() {
        final Context app = getApplicationContext();
        Async.net(() -> {
            try {
                Playlist p = AppDatabase.get(app).dao().getPlaylist(pid);
                final SeriesRepository.Info inf = SeriesRepository.load(p, seriesId);
                UserDao ud = UserDatabase.get(app).dao();
                final History h = ud.getHistory(pid, "series", seriesId);
                final boolean isFav = ud.favoriteIds(pid, "series").contains(seriesId);
                Async.main(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    onLoaded(inf, h, isFav);
                });
            } catch (Exception ex) {
                final String m = ex.getMessage() == null ? "تعذر تحميل الحلقات" : ex.getMessage();
                Async.main(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText(m);
                    playBtn.setText("تعذر التحميل");
                });
            }
        });
    }

    private void onLoaded(SeriesRepository.Info inf, History h, boolean isFav) {
        info = inf;
        hist = h;
        fav = isFav;

        if (!inf.name.isEmpty()) {
            String t = inf.name;
            if (!inf.year.isEmpty() && !t.contains(inf.year)) t += " (" + inf.year + ")";
            titleView.setText(t);
        }

        CharSequence meta = buildMeta(inf);
        metaView.setText(meta);
        metaView.setVisibility(meta.length() == 0 ? View.GONE : View.VISIBLE);
        lineTitle.setVisibility(meta.length() == 0 ? View.GONE : View.VISIBLE);   // title | genre
        boolean hasCast = !inf.cast.trim().isEmpty();
        lineMeta.setVisibility(meta.length() > 0 && hasCast ? View.VISIBLE : View.GONE);   // genre | cast

        castView.setText(inf.cast.trim().isEmpty() ? "" : buildCast(inf.cast));
        castView.setVisibility(inf.cast.trim().isEmpty() ? View.GONE : View.VISIBLE);
        linePlot.setVisibility(View.GONE);

        plotView.setText(inf.plot);
        plotView.setVisibility(inf.plot.isEmpty() ? View.GONE : View.VISIBLE);

        String cover = inf.cover.startsWith("http") ? inf.cover : icon;
        CardStrip.load(poster, cover, R.drawable.ic_series, 420, 620);
        String back = inf.backdrop.startsWith("http") ? inf.backdrop : cover;
        if (back != null && back.startsWith("http")) {
            Glide.with(this).load(back).into(backdrop);
        }

        // start on the season of the last watched episode
        season = 1;
        List<Integer> seasons = inf.seasons();
        if (!seasons.isEmpty()) season = seasons.get(0);
        if (h != null && h.streamUrl != null) {
            for (SeriesRepository.Episode e : inf.episodes) {
                if (h.streamUrl.equals(e.url)) {
                    season = e.season;
                    break;
                }
            }
        }

        updateFavButton();
        updatePlayButton();
        buildSeasonRow();
        showSeason(season);
    }

    private static void append(StringBuilder sb, String part) {
        if (part == null || part.isEmpty()) return;
        if (sb.length() > 0) sb.append("  ·  ");
        sb.append(part);
    }

    // ------------------------------------------------------------ buttons

    private void updatePlayButton() {
        if (info == null) return;
        resumeEp = null;
        boolean resume = false;
        if (hist != null && hist.streamUrl != null) {
            for (SeriesRepository.Episode e : info.episodes) {
                if (hist.streamUrl.equals(e.url)) {
                    resumeEp = e;
                    resume = true;
                    break;
                }
            }
        }
        if (resumeEp == null && !info.episodes.isEmpty()) resumeEp = info.episodes.get(0);
        if (resumeEp == null) {
            playBtn.setText("لا توجد حلقات");
            playBtn.setOnClickListener(null);
            return;
        }
        final SeriesRepository.Episode target = resumeEp;
        final long pos = resume && hist != null ? hist.positionMs : 0L;
        playBtn.setText((resume ? "▶ متابعة " : "▶ تشغيل ") + target.shortLabel());
        playBtn.setOnClickListener(v -> playEpisode(target, pos));
    }

    private void updateFavButton() {
        favBtn.setText(fav ? "★ في المفضلة" : "☆ المفضلة");
    }

    private void toggleFavorite() {
        final boolean was = fav;
        fav = !fav;
        updateFavButton();
        Toast.makeText(this, was ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
        final Context app = getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (was) {
                ud.removeFavorite(pid, "series", seriesId);
                com.myiptv.app.util.Prefs.markHomeDirty();
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = "series";
                f.remoteId = seriesId;
                f.name = seriesName;
                f.icon = icon;
                f.streamUrl = "";
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
                com.myiptv.app.util.Prefs.markHomeDirty();
            }
        });
    }

    // ------------------------------------------------------ seasons / episodes

    private void buildSeasonRow() {
        seasonRow.removeAllViews();
        List<Integer> seasons = info.seasons();
        seasonScroll.setVisibility(seasons.isEmpty() ? View.GONE : View.VISIBLE);
        for (final Integer s : seasons) {
            boolean sel = s == season;
            TextView chip = Ui.button(this, "الموسم " + s, false);
            stylePill(chip, false);   // same look and colour as "المفضلة"
            chip.setOnClickListener(v -> {
                season = s;
                buildSeasonRow();
                showSeason(season, false);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(Ui.dp(this, 8));
            seasonRow.addView(chip, lp);
        }
    }

    private void showSeason(int s) {
        showSeason(s, true);
    }

    private void showSeason(int s, boolean focusFirst) {
        episodesBox.removeAllViews();
        if (info == null) return;
        View firstRow = null;
        View targetRow = null;
        // the saved place first (it also follows an episode opened from the player's "next" box)
        String wanted = followedUrl();
        int shown = 0;
        for (final SeriesRepository.Episode e : info.episodes) {
            if (e.season != s) continue;
            View row = buildRow(e, !wanted.isEmpty() && wanted.equals(e.url));
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            if (rowHeightPx > 0) rlp.height = rowHeightPx;
            episodesBox.addView(row, rlp);
            if (shown == 0) firstRow = row;
            if (!wanted.isEmpty() && wanted.equals(e.url)) targetRow = row;
            shown++;
        }
        // the selection rectangle stays on the episode watched last (the first one when none yet)
        View focusRow = targetRow != null ? targetRow : firstRow;
        if (focusRow != null && focusFirst) {
            final View fr = focusRow;
            episodeScroll.post(() -> {
                fr.requestFocus();
                int y = fr.getTop() - Math.max(0, (episodeScroll.getHeight() - fr.getHeight()) / 2);
                episodeScroll.scrollTo(0, Math.max(0, y));
            });
        }
        if (shown == 0) {
            TextView none = new TextView(this);
            none.setText("لا توجد حلقات لهذا الموسم");
            none.setTextColor(ContextCompat.getColor(this, R.color.muted));
            none.setGravity(Gravity.CENTER);
            none.setPadding(0, Ui.dp(this, 24), 0, Ui.dp(this, 24));
            episodesBox.addView(none);
        }
    }

    /**
     * The episode the person followed last: the one he just opened from this page, or - when the player's
     * "next episode" moved him on - the newer one saved in the watch history.
     */
    private String followedUrl() {
        String wanted = lastPlayedUrl;
        if (hist != null && hist.streamUrl != null && !hist.streamUrl.isEmpty()
                && hist.updatedAt >= lastPlayedAt) {
            wanted = hist.streamUrl;
        }
        return wanted == null ? "" : wanted;
    }

    /** "حب أسود - S01E01 - Episode 1 - (2026)" -> "S01E01 - Episode 1 - (2026)" (the series name has its own place). */
    private String episodeLabel(SeriesRepository.Episode e) {
        String t = e.title == null ? "" : e.title.trim();
        String sn = (info != null && !info.name.isEmpty() ? info.name : seriesName).trim();
        if (!t.isEmpty() && !sn.isEmpty()) {
            int i = t.indexOf(sn);
            if (i >= 0) t = (t.substring(0, i) + t.substring(i + sn.length())).trim();
            // the year is already in the page title: keep it only when nothing else is left
        }
        // separators left at the edges
        t = t.replaceAll("^[\\s\\-–—:|]+", "").replaceAll("[\\s\\-–—:|]+$", "");
        return t.isEmpty() ? e.longLabel() : t;
    }

    /** Watched episode: the same eye, but see-through and colourless (grey), so it differs from the cyan unwatched eye. */
    private static final int SEEN_EYE_ALPHA = 90;
    private static final int SEEN_EYE_COLOR = 0xFFCFD8DC;

    private View buildRow(final SeriesRepository.Episode e, final boolean followed) {
        Context c = this;

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(c, 14), 0, Ui.dp(c, 14), 0);
        row.setBackgroundResource(R.drawable.bg_episode);
        row.setSelected(followed);
        row.setFocusable(true);
        row.setClickable(true);
        row.setOnClickListener(v -> playEpisode(e,
                followed && hist != null && e.url.equals(hist.streamUrl) ? hist.positionMs : 0L));

        // right side: the number, then the series name; the middle: the episode label; far left: the eye
        TextView num = new TextView(c);
        num.setText(String.valueOf(e.number));
        num.setTextColor(ContextCompat.getColor(c, R.color.text));
        // text and eye follow the row height, so a short row never clips them
        final float rowDp = rowHeightPx > 0 ? rowHeightPx / c.getResources().getDisplayMetrics().density : 64f;
        final float nameSp = Math.max(13f, Math.min(22f, rowDp * 0.46f));
        num.setTextSize(Math.max(12f, Math.min(20f, nameSp * 0.95f)));
        num.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        num.setGravity(Gravity.CENTER);
        row.addView(num, new LinearLayout.LayoutParams(Ui.dp(c, 36), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView name = new TextView(c);
        String sn = info != null && !info.name.isEmpty() ? info.name : seriesName;
        name.setText(sn);
        name.setTextColor(ContextCompat.getColor(c, R.color.text));
        name.setTextSize(nameSp);
        name.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        name.setSingleLine(true);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setMaxWidth(Ui.dp(c, 190));
        name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        name.setGravity(Gravity.START);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        np.setMarginStart(Ui.dp(c, 8));
        row.addView(name, np);

        TextView label = new TextView(c);
        label.setText(episodeLabel(e));
        label.setTextColor(0xFFDCE7EA);
        label.setTextSize(Math.max(12f, nameSp * 0.9f));
        label.setSingleLine(true);
        label.setEllipsize(TextUtils.TruncateAt.END);
        label.setTextDirection(View.TEXT_DIRECTION_LTR);
        label.setMaxWidth(Ui.dp(c, 230));
        LinearLayout.LayoutParams lbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lbp.setMarginStart(Ui.dp(c, 10));
        row.addView(label, lbp);

        // eye: sits where the episode label used to be. Not watched: a cyan eye. Watched: the same eye
        // but see-through and without colour (grey). SEEN_EYE_ALPHA: 0 = invisible .. 255 = solid
        boolean seen = followed || Prefs.isSeen(c, pid, seriesId, e.url, e.longLabel(), e.shortLabel());
        ImageView eye = new ImageView(c);
        eye.setImageResource(R.drawable.ic_eye);
        eye.setColorFilter(seen ? SEEN_EYE_COLOR : ContextCompat.getColor(c, R.color.eye));
        eye.setImageAlpha(seen ? SEEN_EYE_ALPHA : 255);
        eye.setContentDescription(seen ? "تمت المشاهدة" : "لم تُشاهد");
        int eyeDp = Math.round(Math.max(20f, Math.min(32f, rowDp * 0.7f)));
        LinearLayout.LayoutParams ep = new LinearLayout.LayoutParams(Ui.dp(c, eyeDp), Ui.dp(c, eyeDp));
        ep.setMarginStart(Ui.dp(c, 40));
        row.addView(eye, ep);

        // empty space on the far left
        row.addView(new View(c), new LinearLayout.LayoutParams(0, 1, 1f));

        return row;
    }

    // ------------------------------------------------------------- actions

    private void playEpisode(SeriesRepository.Episode e, long positionMs) {
        lastPlayedUrl = e.url;
        lastPlayedAt = System.currentTimeMillis();
        // marked at once: when the person comes back (the player saves the history only after this page
        // is shown again) the rectangle is on this episode and its eye already shows it was followed
        Prefs.markSeen(getApplicationContext(), pid, seriesId, e.url, e.longLabel(), e.shortLabel());
        PlayerActivity.startTracked(this, e.url, seriesName + " - " + e.longLabel(), pid, "series",
                seriesId, seriesName, icon, e.longLabel(), positionMs);
    }
}
