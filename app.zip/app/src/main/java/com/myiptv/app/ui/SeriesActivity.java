package com.myiptv.app.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.bumptech.glide.Glide;
import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SeriesRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.util.List;

/** Series details: poster, story, play / favorite buttons, seasons and the list of episodes. */
public class SeriesActivity extends AppCompatActivity {
    private static final String EXTRA_PID = "pid";
    private static final String EXTRA_NAME = "name";
    private static final String EXTRA_ID = "sid";
    private static final String EXTRA_ICON = "icon";

    public static void start(Context context, long playlistId, String name, String seriesId,
                             String icon) {
        Intent i = new Intent(context, SeriesActivity.class);
        i.putExtra(EXTRA_PID, playlistId);
        i.putExtra(EXTRA_NAME, name);
        i.putExtra(EXTRA_ID, seriesId);
        i.putExtra(EXTRA_ICON, icon);
        context.startActivity(i);
    }

    private long pid = -1;
    private String seriesName = "";
    private String seriesId = "";
    private String icon = "";

    private SeriesRepository.Info info;
    private History hist;
    private boolean fav;
    private int season = 1;
    private SeriesRepository.Episode resumeEp;

    private ImageView backdrop;
    private ImageView poster;
    private TextView titleView;
    private TextView metaView;
    private TextView plotView;
    private TextView castView;
    private TextView genreView;
    private TextView directorView;
    private View divTop;
    private View divBottom;
    private TextView playBtn;
    private TextView favBtn;
    private LinearLayout seasonRow;
    private HorizontalScrollView seasonScroll;
    private LinearLayout episodesBox;
    private ScrollView episodeScroll;
    private TextView statusView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pid = getIntent().getLongExtra(EXTRA_PID, -1L);
        String n = getIntent().getStringExtra(EXTRA_NAME);
        String id = getIntent().getStringExtra(EXTRA_ID);
        String ic = getIntent().getStringExtra(EXTRA_ICON);
        seriesName = n == null ? "" : n;
        seriesId = id == null ? "" : id;
        icon = ic == null ? "" : ic;
        if (pid < 0 || seriesId.isEmpty()) {
            finish();
            return;
        }
        setContentView(buildUi());
        load();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (info == null) return;
        final Context app = getApplicationContext();
        Async.io(() -> {
            final History h = UserDatabase.get(app).dao().getHistory(pid, "series", seriesId);
            Async.main(() -> {
                if (isFinishing() || isDestroyed()) return;
                hist = h;
                updatePlayButton();
                showSeason(season);
            });
        });
    }

    // ------------------------------------------------------------------ UI

    private View buildUi() {
        final Context c = this;
        FrameLayout root = new FrameLayout(c);
        root.setBackgroundColor(ContextCompat.getColor(c, R.color.bg));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        ImageView appBg = new ImageView(c);
        appBg.setScaleType(ImageView.ScaleType.CENTER_CROP);
        appBg.setImageResource(R.drawable.bg_main);
        root.addView(appBg, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        backdrop = new ImageView(c);
        backdrop.setScaleType(ImageView.ScaleType.CENTER_CROP);
        backdrop.setAlpha(0.55f);
        root.addView(backdrop, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // dark teal veil over the backdrop so the text stays readable
        View scrim = new View(c);
        scrim.setBackgroundResource(R.drawable.bg_series_scrim);
        root.addView(scrim, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        // the poster and the details stay fixed; only the episodes list scrolls
        LinearLayout outer = new LinearLayout(c);
        outer.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(outer, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        LinearLayout col = new LinearLayout(c);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(Ui.dp(c, 24), Ui.dp(c, 16), Ui.dp(c, 24), Ui.dp(c, 16));
        outer.addView(col, new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.MATCH_PARENT, 1f));

        poster = new ImageView(c);
        poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackgroundColor(ContextCompat.getColor(c, R.color.card2));
        CardStrip.round(poster, Ui.dp(c, 8));

        // a big poster fills the left side from top to bottom; details and episodes are on the right
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(
                Ui.dp(c, 300), ViewGroup.LayoutParams.MATCH_PARENT);
        pp.setMarginStart(Ui.dp(c, 4));
        pp.setMarginEnd(Ui.dp(c, 24));
        pp.topMargin = Ui.dp(c, 24);
        pp.bottomMargin = Ui.dp(c, 24);
        outer.addView(poster, pp);

        titleView = new TextView(c);
        titleView.setText(seriesName);
        titleView.setTextColor(ContextCompat.getColor(c, R.color.text));
        titleView.setTextSize(30);
        titleView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        titleView.setMaxLines(2);
        titleView.setEllipsize(TextUtils.TruncateAt.END);
        titleView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        titleView.setGravity(Gravity.START);
        col.addView(titleView);

        // genre / year / director, stacked like a small info sheet
        LinearLayout infoBox = new LinearLayout(c);
        infoBox.setOrientation(LinearLayout.VERTICAL);
        col.addView(infoBox, topMargin(c, 8));

        genreView = infoLine(c);
        infoBox.addView(genreView);
        metaView = infoLine(c);
        infoBox.addView(metaView, topMargin(c, 4));
        directorView = infoLine(c);
        infoBox.addView(directorView, topMargin(c, 4));

        divTop = divider(c);
        col.addView(divTop, dividerParams(c, 10));

        castView = new TextView(c);
        castView.setTextColor(ContextCompat.getColor(c, R.color.text));
        castView.setTextSize(15);
        castView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        castView.setMaxLines(2);
        castView.setEllipsize(TextUtils.TruncateAt.END);
        castView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        castView.setGravity(Gravity.START);
        castView.setVisibility(View.GONE);
        col.addView(castView, topMargin(c, 8));

        divBottom = divider(c);
        col.addView(divBottom, dividerParams(c, 8));

        plotView = new TextView(c);
        plotView.setTextColor(ContextCompat.getColor(c, R.color.text));
        plotView.setTextSize(16);
        plotView.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        plotView.setLineSpacing(0, 1.35f);
        plotView.setMaxLines(4);
        plotView.setEllipsize(TextUtils.TruncateAt.END);
        plotView.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        plotView.setGravity(Gravity.START);
        plotView.setVisibility(View.GONE);
        col.addView(plotView, topMargin(c, 10));

        LinearLayout buttons = new LinearLayout(c);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER_VERTICAL);
        col.addView(buttons, topMargin(c, 14));

        playBtn = Ui.button(c, "جارٍ التحميل…", true);
        playBtn.setVisibility(View.GONE); // no play button on this page: episodes are played from the list

        favBtn = Ui.button(c, "☆ إضافة إلى المفضلة", false);
        favBtn.setBackgroundResource(R.drawable.bg_button_fav);
        favBtn.setOnClickListener(v -> toggleFavorite());
        LinearLayout.LayoutParams fbp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        fbp.setMarginStart(0);
        buttons.addView(favBtn, fbp);

        // season header: a darker band above the episodes, "الموسم 1" (tap to switch when there are several)
        seasonScroll = new HorizontalScrollView(c);
        seasonScroll.setHorizontalScrollBarEnabled(false);
        seasonScroll.setBackgroundColor(0x55000000);
        seasonScroll.setVisibility(View.GONE);
        seasonRow = new LinearLayout(c);
        seasonRow.setOrientation(LinearLayout.HORIZONTAL);
        seasonRow.setPadding(Ui.dp(c, 8), Ui.dp(c, 2), Ui.dp(c, 8), Ui.dp(c, 2));
        seasonScroll.addView(seasonRow, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams ssp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ssp.topMargin = Ui.dp(c, 14);
        col.addView(seasonScroll, ssp);

        // episodes: plain lines, no box
        episodesBox = new LinearLayout(c);
        episodesBox.setOrientation(LinearLayout.VERTICAL);
        episodesBox.setPadding(Ui.dp(c, 4), Ui.dp(c, 2), Ui.dp(c, 4), Ui.dp(c, 2));
        episodeScroll = new ScrollView(c);
        episodeScroll.setFillViewport(false);
        episodeScroll.setVerticalScrollBarEnabled(false);
        episodeScroll.addView(episodesBox, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams esp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f);
        esp.topMargin = Ui.dp(c, 4);
        col.addView(episodeScroll, esp);

        statusView = new TextView(c);
        statusView.setText("جارٍ تحميل الحلقات…");
        statusView.setTextColor(ContextCompat.getColor(c, R.color.muted));
        statusView.setTextSize(14);
        statusView.setGravity(Gravity.CENTER);
        statusView.setPadding(0, Ui.dp(c, 24), 0, Ui.dp(c, 24));
        episodesBox.addView(statusView, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        // the cover from the list shows right away, before the details arrive
        CardStrip.load(poster, icon, R.drawable.ic_series, 300, 440);
        return root;
    }

    private static TextView infoLine(Context c) {
        TextView t = new TextView(c);
        t.setTextColor(ContextCompat.getColor(c, R.color.muted));
        t.setTextSize(14);
        t.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        t.setGravity(Gravity.START);
        t.setVisibility(View.GONE);
        return t;
    }

    private static View divider(Context c) {
        View v = new View(c);
        v.setBackgroundColor(0x40FFFFFF);
        v.setVisibility(View.GONE);
        return v;
    }

    private static LinearLayout.LayoutParams dividerParams(Context c, int topDp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, Ui.dp(c, 1)));
        lp.topMargin = Ui.dp(c, topDp);
        return lp;
    }

    private static LinearLayout.LayoutParams topMargin(Context c, int dp) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, dp);
        return lp;
    }

    // ---------------------------------------------------------------- data

    private void load() {
        final Context app = getApplicationContext();
        Async.io(() -> {
            try {
                Playlist p = AppDatabase.get(app).dao().getPlaylist(pid);
                final SeriesRepository.Info inf = SeriesRepository.load(p, seriesId);
                UserDao ud = UserDatabase.get(app).dao();
                final History h = ud.getHistory(pid, "series", seriesId);
                final boolean isFav = ud.favoriteIds(pid, "series").contains(seriesId);
                Async.main(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    onLoaded(inf, h, isFav);
                });
            } catch (Exception ex) {
                final String m = ex.getMessage() == null ? "تعذر تحميل الحلقات" : ex.getMessage();
                Async.main(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    statusView.setText(m);
                    playBtn.setText("تعذر التحميل");
                });
            }
        });
    }

    private void onLoaded(SeriesRepository.Info inf, History h, boolean isFav) {
        info = inf;
        hist = h;
        fav = isFav;

        if (!inf.name.isEmpty()) titleView.setText(inf.name);

        genreView.setText(inf.genre.isEmpty() ? "" : "النوع: " + inf.genre);
        genreView.setVisibility(inf.genre.isEmpty() ? View.GONE : View.VISIBLE);

        StringBuilder meta = new StringBuilder();
        append(meta, inf.year);
        if (!inf.rating.isEmpty() && !"0".equals(inf.rating)) append(meta, "★ " + inf.rating);
        metaView.setText(meta.toString());
        metaView.setVisibility(meta.length() == 0 ? View.GONE : View.VISIBLE);

        directorView.setText(inf.director.isEmpty() ? "" : "المخرج: " + inf.director);
        directorView.setVisibility(inf.director.isEmpty() ? View.GONE : View.VISIBLE);

        plotView.setText(inf.plot);
        plotView.setVisibility(inf.plot.isEmpty() ? View.GONE : View.VISIBLE);
        castView.setText(inf.cast);
        castView.setVisibility(inf.cast.isEmpty() ? View.GONE : View.VISIBLE);
        divTop.setVisibility(inf.cast.isEmpty() ? View.GONE : View.VISIBLE);
        divBottom.setVisibility(inf.cast.isEmpty() || inf.plot.isEmpty() ? View.GONE : View.VISIBLE);

        String cover = inf.cover.startsWith("http") ? inf.cover : icon;
        CardStrip.load(poster, cover, R.drawable.ic_series, 300, 440);
        String back = inf.backdrop.startsWith("http") ? inf.backdrop : cover;
        if (back != null && back.startsWith("http")) {
            Glide.with(this).load(back).into(backdrop);
        }

        // start on the season of the last watched episode
        season = 1;
        List<Integer> seasons = inf.seasons();
        if (!seasons.isEmpty()) season = seasons.get(0);
        if (h != null && h.streamUrl != null) {
            for (SeriesRepository.Episode e : inf.episodes) {
                if (h.streamUrl.equals(e.url)) {
                    season = e.season;
                    break;
                }
            }
        }

        updateFavButton();
        updatePlayButton();
        buildSeasonRow();
        showSeason(season);
    }

    private static void append(StringBuilder sb, String part) {
        if (part == null || part.isEmpty()) return;
        if (sb.length() > 0) sb.append("  ·  ");
        sb.append(part);
    }

    // ------------------------------------------------------------ buttons

    private void updatePlayButton() {
        if (info == null) return;
        resumeEp = null;
        boolean resume = false;
        if (hist != null && hist.streamUrl != null) {
            for (SeriesRepository.Episode e : info.episodes) {
                if (hist.streamUrl.equals(e.url)) {
                    resumeEp = e;
                    resume = true;
                    break;
                }
            }
        }
        if (resumeEp == null && !info.episodes.isEmpty()) resumeEp = info.episodes.get(0);
        if (resumeEp == null) {
            playBtn.setText("لا توجد حلقات");
            playBtn.setOnClickListener(null);
            return;
        }
        final SeriesRepository.Episode target = resumeEp;
        final long pos = resume && hist != null ? hist.positionMs : 0L;
        playBtn.setText((resume ? "▶ متابعة " : "▶ تشغيل ") + target.shortLabel());
        playBtn.setOnClickListener(v -> playEpisode(target, pos));
    }

    private void updateFavButton() {
        favBtn.setText(fav ? "★ في المفضلة" : "☆ إضافة إلى المفضلة");
    }

    private void toggleFavorite() {
        final boolean was = fav;
        fav = !fav;
        updateFavButton();
        Toast.makeText(this, was ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
        final Context app = getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (was) {
                ud.removeFavorite(pid, "series", seriesId);
                com.myiptv.app.util.Prefs.markHomeDirty();
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = "series";
                f.remoteId = seriesId;
                f.name = seriesName;
                f.icon = icon;
                f.streamUrl = "";
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
                com.myiptv.app.util.Prefs.markHomeDirty();
            }
        });
    }

    // ------------------------------------------------------ seasons / episodes

    private void buildSeasonRow() {
        seasonRow.removeAllViews();
        List<Integer> seasons = info.seasons();
        seasonScroll.setVisibility(seasons.isEmpty() ? View.GONE : View.VISIBLE);
        for (final Integer s : seasons) {
            boolean sel = s == season;
            TextView chip = new TextView(this);
            chip.setText("الموسم " + s);
            chip.setTextSize(15);
            chip.setTextColor(ContextCompat.getColor(this, sel ? R.color.eye : R.color.text));
            chip.setTypeface(sel ? android.graphics.Typeface.DEFAULT_BOLD : android.graphics.Typeface.DEFAULT);
            chip.setBackgroundResource(R.drawable.bg_nav);
            chip.setFocusable(true);
            chip.setClickable(true);
            chip.setPadding(Ui.dp(this, 14), Ui.dp(this, 8), Ui.dp(this, 14), Ui.dp(this, 8));
            chip.setOnClickListener(v -> {
                season = s;
                buildSeasonRow();
                showSeason(season, false);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.setMarginEnd(Ui.dp(this, 8));
            seasonRow.addView(chip, lp);
        }
    }

    private void showSeason(int s) {
        showSeason(s, true);
    }

    private void showSeason(int s, boolean focusFirst) {
        episodesBox.removeAllViews();
        if (info == null) return;
        View firstRow = null;
        int shown = 0;
        for (final SeriesRepository.Episode e : info.episodes) {
            if (e.season != s) continue;
            View row = buildRow(e);
            LinearLayout.LayoutParams rlp = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            rlp.topMargin = Ui.dp(this, 1);
            rlp.bottomMargin = Ui.dp(this, 1);
            episodesBox.addView(row, rlp);
            if (shown == 0) firstRow = row;
            shown++;
        }
        // the selection rectangle starts on the first episode
        if (firstRow != null && focusFirst) {
            final View fr = firstRow;
            episodeScroll.post(() -> fr.requestFocus());
        }
        if (shown == 0) {
            TextView none = new TextView(this);
            none.setText("لا توجد حلقات لهذا الموسم");
            none.setTextColor(ContextCompat.getColor(this, R.color.muted));
            none.setGravity(Gravity.CENTER);
            none.setPadding(0, Ui.dp(this, 24), 0, Ui.dp(this, 24));
            episodesBox.addView(none);
        }
    }

    private View buildRow(final SeriesRepository.Episode e) {
        Context c = this;
        final boolean current = hist != null && e.url.equals(hist.streamUrl);

        // watched episodes are dimmed (the old eye icon is gone)
        boolean seen = current || Prefs.isSeen(c, pid, seriesId, e.url, e.longLabel(), e.shortLabel());

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setPadding(Ui.dp(c, 12), Ui.dp(c, 9), Ui.dp(c, 12), Ui.dp(c, 9));
        row.setBackgroundResource(R.drawable.bg_episode);
        row.setSelected(current);
        row.setFocusable(true);
        row.setClickable(true);
        row.setOnClickListener(v -> playEpisode(e, current && hist != null ? hist.positionMs : 0L));

        TextView num = new TextView(c);
        num.setText(String.valueOf(e.number));
        num.setTextColor(ContextCompat.getColor(c, R.color.muted));
        num.setTextSize(15);
        num.setGravity(Gravity.CENTER);
        row.addView(num, new LinearLayout.LayoutParams(Ui.dp(c, 34), ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView name = new TextView(c);
        String title = e.title.isEmpty() ? e.longLabel() : e.title;
        name.setText((current ? "▶ " : "") + title);
        name.setTextColor(ContextCompat.getColor(c, seen && !current ? R.color.muted : R.color.text));
        name.setTextSize(17);
        name.setMaxLines(2);
        name.setEllipsize(TextUtils.TruncateAt.END);
        name.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        name.setGravity(Gravity.START);
        LinearLayout.LayoutParams np = new LinearLayout.LayoutParams(
                0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        np.setMarginStart(Ui.dp(c, 6));
        np.setMarginEnd(Ui.dp(c, 6));
        row.addView(name, np);

        return row;
    }

    // ------------------------------------------------------------- actions

    private void playEpisode(SeriesRepository.Episode e, long positionMs) {
        PlayerActivity.startTracked(this, e.url, seriesName + " - " + e.longLabel(), pid, "series",
                seriesId, seriesName, icon, e.longLabel(), positionMs);
    }
}
