package com.myiptv.app.ui;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.view.animation.LinearInterpolator;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import com.myiptv.app.R;

import java.util.Random;

/**
 * Full screen intro shown when the app opens: the emblem glides in from the right edge while the
 * letters of the name glide in from the left edge, and they meet in the middle of the screen with a
 * soft flash, signal rings and a light sweep, to a short piece of music. After 5.5 seconds the app opens.
 */
public class IntroActivity extends AppCompatActivity {
    private static final long DURATION_MS = 5500L;

    private ValueAnimator animator;
    private MediaPlayer music;
    private boolean launched;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        WindowInsetsControllerCompat ctl = WindowCompat.getInsetsController(getWindow(), getWindow().getDecorView());
        if (ctl != null) {
            ctl.hide(WindowInsetsCompat.Type.systemBars());
            ctl.setSystemBarsBehavior(WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
        }

        final IntroView view = new IntroView(this);
        setContentView(view);

        startMusic();

        animator = ValueAnimator.ofFloat(0f, 1f);
        animator.setDuration(DURATION_MS);
        animator.setInterpolator(new LinearInterpolator());
        animator.addUpdateListener(a -> view.setProgress((Float) a.getAnimatedValue()));
        animator.addListener(new AnimatorListenerAdapter() {
            private boolean cancelled;

            @Override
            public void onAnimationCancel(Animator animation) {
                cancelled = true;
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                if (!cancelled) openApp();
            }
        });
        animator.start();
    }

    private void startMusic() {
        try {
            music = MediaPlayer.create(this, R.raw.intro_music);
            if (music != null) {
                music.setVolume(0.9f, 0.9f);
                music.start();
            }
        } catch (Exception e) {
            music = null; // the intro simply plays without sound
        }
    }

    private void openApp() {
        if (launched || isFinishing()) return;
        launched = true;
        startActivity(new Intent(this, MainActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override
    protected void onDestroy() {
        if (animator != null) {
            animator.cancel();
            animator = null;
        }
        if (music != null) {
            try {
                music.release();
            } catch (Exception ignored) {
                // ignore
            }
            music = null;
        }
        super.onDestroy();
    }

    // ------------------------------------------------------------------ drawing

    private static final class IntroView extends View {
        private static final float TOTAL = DURATION_MS / 1000f;
        private static final float IMPACT = 2.0f;      // emblem and letters meet (music hit)
        private static final float SETTLED = 2.15f;    // everything is in place
        private static final float SWEEP_START = 3.0f;
        private static final float SWEEP_END = 4.1f;
        // horizontal extent of each letter of "RONI IPTV" in the 960 px artwork
        private static final int[][] LETTERS = {
                {212, 281}, {281, 370}, {370, 452}, {452, 498}, {498, 535}, {535, 603}, {603, 668}, {668, 748}};

        private final Paint bgPaint = new Paint();
        private final Paint glowPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint ringPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint dotPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint logoPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
        private final Paint sweepPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Paint fadePaint = new Paint();
        private final Matrix sweepMatrix = new Matrix();
        private final RectF logoRect = new RectF();
        private final RectF dst = new RectF();
        private final Rect src = new Rect();
        private final Paint flashPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final Bitmap logo;
        private float scaleK = 1f;
        private int splitY;
        private final float density;

        private float progress;
        private RadialGradient bgShader;
        private RadialGradient glowShader;
        private float[] px = new float[0];
        private float[] py = new float[0];
        private float[] pr = new float[0];
        private float[] pv = new float[0];
        private float[] pp = new float[0];
        private LinearGradient sweepShader;
        private float bandW;

        IntroView(Context c) {
            super(c);
            density = c.getResources().getDisplayMetrics().density;
            logo = BitmapFactory.decodeResource(c.getResources(), R.drawable.splash_logo);
            sweepPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.SRC_ATOP));
            ringPaint.setStyle(Paint.Style.STROKE);
            fadePaint.setColor(0xFF0A1F2A);
        }

        void setProgress(float p) {
            progress = p;
            invalidate();
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            if (w <= 0 || h <= 0) return;
            float cx = w / 2f;
            float cy = h / 2f;
            float rad = Math.max(w, h) * 0.75f;
            bgShader = new RadialGradient(cx, cy * 0.95f, rad,
                    new int[]{0xFF12414D, 0xFF0A1F2A, 0xFF050E14}, new float[]{0f, 0.55f, 1f},
                    Shader.TileMode.CLAMP);
            bgPaint.setShader(bgShader);

            float d = Math.min(w, h) * 0.95f;
            logoRect.set(cx - d / 2f, cy - d / 2f, cx + d / 2f, cy + d / 2f);
            scaleK = d / logo.getWidth();
            // the emblem is the upper part of the artwork, the letters are the lower part
            splitY = Math.round(logo.getHeight() * (600f / 960f));
            float gr = d * 0.62f;
            glowShader = new RadialGradient(cx, cy, gr,
                    new int[]{0x7000D0D8, 0x2800D0D8, 0x0000D0D8}, new float[]{0f, 0.5f, 1f},
                    Shader.TileMode.CLAMP);
            glowPaint.setShader(glowShader);

            bandW = d * 0.28f;
            sweepShader = new LinearGradient(0, 0, bandW, 0,
                    new int[]{0x00FFFFFF, 0xC8FFFFFF, 0x00FFFFFF}, new float[]{0f, 0.5f, 1f},
                    Shader.TileMode.CLAMP);
            sweepPaint.setShader(sweepShader);

            Random rnd = new Random(5);
            int n = 70;
            px = new float[n];
            py = new float[n];
            pr = new float[n];
            pv = new float[n];
            pp = new float[n];
            for (int i = 0; i < n; i++) {
                px[i] = rnd.nextFloat() * w;
                py[i] = rnd.nextFloat() * h;
                pr[i] = (0.8f + rnd.nextFloat() * 2.0f) * density;
                pv[i] = (6f + rnd.nextFloat() * 14f) * density; // px per second, upwards
                pp[i] = rnd.nextFloat() * 6.28f;
            }
        }

        private static float clamp(float v) {
            return v < 0f ? 0f : (v > 1f ? 1f : v);
        }

        private static float seg(float t, float a, float b) {
            return clamp((t - a) / (b - a));
        }

        private static float easeOut(float x) {
            float k = 1f - x;
            return 1f - k * k * k;
        }

        private static float easeOutQuart(float x) {
            float k = 1f - x;
            return 1f - k * k * k * k;
        }

        private static float easeInOut(float x) {
            return x * x * (3f - 2f * x);
        }

        /** Draws the emblem shifted by dx; while it moves fast a few fading ghosts trail behind it (motion blur). */
        private void drawEmblem(Canvas c, float dx, float alpha, float speed, int w) {
            src.set(0, 0, logo.getWidth(), splitY);
            for (int g = 3; g >= 0; g--) {
                float back = g * speed * w * 0.035f; // trails towards the right edge it came from
                float a = g == 0 ? alpha : alpha * 0.16f * (4 - g) / 3f * Math.min(1f, speed * 1.6f);
                if (a <= 0.01f) continue;
                dst.set(logoRect.left + dx + back, logoRect.top, logoRect.right + dx + back, logoRect.top + splitY * scaleK);
                logoPaint.setAlpha((int) (255 * clamp(a)));
                c.drawBitmap(logo, src, dst, logoPaint);
            }
        }

        private void drawLetter(Canvas c, int i, float dx, float alpha, float speed, int w) {
            float bw = logo.getWidth();
            src.set(Math.round(LETTERS[i][0] * bw / 960f), splitY, Math.round(LETTERS[i][1] * bw / 960f), logo.getHeight());
            for (int g = 3; g >= 0; g--) {
                float back = -g * speed * w * 0.035f; // trails towards the left edge it came from
                float a = g == 0 ? alpha : alpha * 0.16f * (4 - g) / 3f * Math.min(1f, speed * 1.6f);
                if (a <= 0.01f) continue;
                dst.set(logoRect.left + LETTERS[i][0] * scaleK + dx + back, logoRect.top + splitY * scaleK,
                        logoRect.left + LETTERS[i][1] * scaleK + dx + back, logoRect.bottom);
                logoPaint.setAlpha((int) (255 * clamp(a)));
                c.drawBitmap(logo, src, dst, logoPaint);
            }
        }

        @Override
        protected void onDraw(Canvas canvas) {
            int w = getWidth();
            int h = getHeight();
            if (w <= 0 || h <= 0 || logo == null) return;
            float t = progress * TOTAL;
            float cx = w / 2f;
            float cy = h / 2f;

            canvas.drawRect(0, 0, w, h, bgPaint);
            final float ringCy = cy - logoRect.height() * 0.05f;

            // floating light particles
            float pin = easeInOut(seg(t, 0f, 1.2f));
            for (int i = 0; i < px.length; i++) {
                float y = py[i] - pv[i] * t;
                y = ((y % h) + h) % h;
                float tw = 0.5f + 0.5f * (float) Math.sin(t * 1.6f + pp[i]);
                int a = (int) (110 * pin * (0.35f + 0.65f * tw));
                dotPaint.setColor((a << 24) | 0x0000D0D8);
                canvas.drawCircle(px[i], y, pr[i], dotPaint);
            }

            // glow behind the logo (swells with the reveal, pulses with the light sweep)
            float glow = easeInOut(seg(t, 0.8f, 2.4f));
            float pulse = 0.18f * (float) Math.sin(Math.PI * seg(t, SWEEP_START, SWEEP_END));
            glowPaint.setAlpha((int) (255 * clamp(glow * (0.8f + pulse))));
            canvas.drawCircle(cx, cy, logoRect.width() * 0.62f, glowPaint);

            // signal rings spreading from the emblem (like the waves of the logo)
            float[] starts = {IMPACT, IMPACT + 0.65f, IMPACT + 1.3f};
            for (float s0 : starts) {
                float k = seg(t, s0, s0 + 1.9f);
                if (k <= 0f || k >= 1f) continue;
                float e = easeOut(k);
                float r = logoRect.width() * (0.12f + 0.55f * e);
                ringPaint.setStrokeWidth((2.2f - 1.4f * k) * density);
                ringPaint.setColor((((int) (120 * (1f - k))) << 24) | 0x0000D0D8);
                canvas.drawCircle(cx, ringCy, r, ringPaint);
            }

            // impact: a small pop, a soft flash and rings at the moment the two halves meet
            float pop = 1f + 0.035f * (float) Math.sin(Math.PI * seg(t, IMPACT, IMPACT + 0.55f));
            float fk = seg(t, IMPACT - 0.05f, IMPACT + 0.7f);
            if (fk > 0f && fk < 1f) {
                float fr = logoRect.width() * (0.10f + 0.42f * easeOut(fk));
                flashPaint.setShader(new RadialGradient(cx, ringCy, Math.max(1f, fr),
                        new int[]{(((int) (150 * (1f - fk))) << 24) | 0x00BFFFFF,
                                (((int) (60 * (1f - fk))) << 24) | 0x0000D0D8, 0x0000D0D8},
                        new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP));
                canvas.drawCircle(cx, ringCy, fr, flashPaint);
            }

            int save = canvas.save();
            canvas.scale(pop, pop, cx, cy);
            if (t < SETTLED) {
                // the emblem glides in from the right edge ...
                float ek = seg(t, 0.5f, 1.9f);
                float ee = easeOutQuart(ek);
                float ev = 4f * (1f - ek) * (1f - ek) * (1f - ek); // speed (1 = fast, 0 = stopped)
                float eAlpha = clamp(ek * 4f);
                if (ek > 0f) drawEmblem(canvas, w * (1f - ee), eAlpha, ev, w);
                // ... while the letters glide in from the left edge, the right-most one leading
                for (int i = 0; i < LETTERS.length; i++) {
                    float lk = seg(t, 0.5f + (LETTERS.length - 1 - i) * 0.04f, 1.8f + (LETTERS.length - 1 - i) * 0.04f);
                    if (lk <= 0f) continue;
                    float le = easeOutQuart(lk);
                    float lv = 4f * (1f - lk) * (1f - lk) * (1f - lk);
                    drawLetter(canvas, i, -w * (1f - le), clamp(lk * 4f), lv, w);
                }
            } else if (t >= SWEEP_START && t <= SWEEP_END) {
                // light sweep, clipped to the shape of the logo
                int layer = canvas.saveLayer(logoRect, null);
                logoPaint.setAlpha(255);
                canvas.drawBitmap(logo, null, logoRect, logoPaint);
                float k = easeInOut(seg(t, SWEEP_START, SWEEP_END));
                float tx = logoRect.left - bandW + (logoRect.width() + bandW) * k;
                sweepMatrix.reset();
                sweepMatrix.setRotate(18f);
                sweepMatrix.postTranslate(tx, logoRect.top);
                sweepShader.setLocalMatrix(sweepMatrix);
                canvas.drawRect(logoRect, sweepPaint);
                canvas.restoreToCount(layer);
            } else {
                logoPaint.setAlpha(255);
                canvas.drawBitmap(logo, null, logoRect, logoPaint);
            }
            canvas.restoreToCount(save);

            // fade into the app background at the end
            float out = easeInOut(seg(t, TOTAL - 0.5f, TOTAL));
            if (out > 0f) {
                fadePaint.setAlpha((int) (255 * out));
                canvas.drawRect(0, 0, w, h, fadePaint);
            }
        }
    }
}
