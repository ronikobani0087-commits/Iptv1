package com.myiptv.app.util;

import java.text.Normalizer;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Arabic names for the clubs of the followed competitions (falls back to the English name). */
public final class TeamNames {
    private static final Map<String, String> AR = new HashMap<>();

    private static void p(String ar, String... en) {
        for (String e : en) AR.put(norm(e), ar);
    }

    static {
        // Spain
        p("ريال مدريد", "Real Madrid");
        p("برشلونة", "Barcelona");
        p("أتلتيكو مدريد", "Atletico Madrid", "Atlético Madrid", "Atletico de Madrid");
        p("أتلتيك بلباو", "Athletic Club", "Athletic Bilbao");
        p("ريال سوسيداد", "Real Sociedad");
        p("فياريال", "Villarreal");
        p("ريال بيتيس", "Real Betis", "Betis");
        p("إشبيلية", "Sevilla");
        p("فالنسيا", "Valencia");
        p("سيلتا فيغو", "Celta Vigo", "Celta");
        p("جيرونا", "Girona");
        p("أوساسونا", "Osasuna");
        p("خيتافي", "Getafe");
        p("رايو فاليكانو", "Rayo Vallecano");
        p("ريال مايوركا", "Mallorca", "Real Mallorca");
        p("ألافيس", "Alaves", "Deportivo Alaves", "Alavés");
        p("إسبانيول", "Espanyol");
        p("ليفانتي", "Levante");
        p("إلتشي", "Elche");
        p("ريال أوفييدو", "Real Oviedo", "Oviedo");
        // England
        p("مانشستر سيتي", "Manchester City", "Man City");
        p("مانشستر يونايتد", "Manchester United", "Man United", "Man Utd");
        p("ليفربول", "Liverpool");
        p("أرسنال", "Arsenal");
        p("تشيلسي", "Chelsea");
        p("توتنهام", "Tottenham Hotspur", "Tottenham", "Spurs");
        p("نيوكاسل يونايتد", "Newcastle United", "Newcastle");
        p("أستون فيلا", "Aston Villa");
        p("برايتون", "Brighton & Hove Albion", "Brighton");
        p("وست هام", "West Ham United", "West Ham");
        p("كريستال بالاس", "Crystal Palace");
        p("بورنموث", "AFC Bournemouth", "Bournemouth");
        p("برينتفورد", "Brentford");
        p("فولهام", "Fulham");
        p("إيفرتون", "Everton");
        p("وولفرهامبتون", "Wolverhampton Wanderers", "Wolves");
        p("نوتنغهام فورست", "Nottingham Forest");
        p("ليدز يونايتد", "Leeds United", "Leeds");
        p("سندرلاند", "Sunderland");
        p("بيرنلي", "Burnley");
        // Turkey
        p("غلطة سراي", "Galatasaray");
        p("فنربخشة", "Fenerbahce", "Fenerbahçe");
        p("بشكتاش", "Besiktas", "Beşiktaş");
        p("طرابزون سبور", "Trabzonspor");
        p("باشاك شهير", "Istanbul Basaksehir", "Basaksehir", "İstanbul Başakşehir", "Başakşehir");
        p("سامسون سبور", "Samsunspor");
        p("قونيا سبور", "Konyaspor");
        p("ألانيا سبور", "Alanyaspor");
        p("أنطاليا سبور", "Antalyaspor");
        p("قيصري سبور", "Kayserispor");
        p("غازي عنتاب", "Gaziantep");
        p("ريزه سبور", "Rizespor", "Caykur Rizespor");
        p("غوزتبه", "Goztepe", "Göztepe");
        p("إيوب سبور", "Eyupspor", "Eyüpspor");
        p("قاسم باشا", "Kasimpasa", "Kasımpaşa");
        p("سيفاس سبور", "Sivasspor");
        p("هاتاي سبور", "Hatayspor");
        p("بودروم سبور", "Bodrum");
        p("كوجالي سبور", "Kocaelispor");
        p("جنجلربيرليغي", "Genclerbirligi", "Gençlerbirliği");
        p("قره كوم", "Karagumruk", "Fatih Karagumruk", "Karagümrük");
        // Europe
        p("باريس سان جيرمان", "Paris Saint-Germain", "Paris Saint Germain", "PSG");
        p("بايرن ميونخ", "Bayern Munich", "Bayern Munchen", "Bayern München");
        p("بوروسيا دورتموند", "Borussia Dortmund", "Dortmund");
        p("باير ليفركوزن", "Bayer Leverkusen");
        p("آر بي لايبزيغ", "RB Leipzig");
        p("آينتراخت فرانكفورت", "Eintracht Frankfurt");
        p("يوفنتوس", "Juventus");
        p("إنتر ميلان", "Inter Milan", "Internazionale", "Inter");
        p("ميلان", "AC Milan", "Milan");
        p("نابولي", "Napoli");
        p("روما", "AS Roma", "Roma");
        p("لاتسيو", "Lazio");
        p("أتالانتا", "Atalanta");
        p("فيورنتينا", "Fiorentina");
        p("بنفيكا", "Benfica", "SL Benfica");
        p("بورتو", "Porto", "FC Porto");
        p("سبورتينغ لشبونة", "Sporting CP", "Sporting Lisbon", "Sporting");
        p("أياكس", "Ajax");
        p("آيندهوفن", "PSV Eindhoven", "PSV");
        p("فينورد", "Feyenoord");
        p("موناكو", "AS Monaco", "Monaco");
        p("مارسيليا", "Marseille", "Olympique Marseille", "Olympique de Marseille");
        p("ليون", "Lyon", "Olympique Lyonnais");
        p("ليل", "Lille", "LOSC Lille");
        p("كلوب بروج", "Club Brugge");
        p("شاختار دونيتسك", "Shakhtar Donetsk");
        p("سلتيك", "Celtic");
        p("رينجرز", "Rangers");
        p("أولمبياكوس", "Olympiacos");
        p("باناثينايكوس", "Panathinaikos");
        p("سالزبورغ", "Red Bull Salzburg", "RB Salzburg", "Salzburg");
        p("كوبنهاغن", "FC Copenhagen", "Copenhagen");
        p("النجم الأحمر", "Red Star Belgrade", "Crvena Zvezda");
        p("يانغ بويز", "Young Boys", "BSC Young Boys");
        p("سبارتا براغ", "Sparta Prague");
        p("فيكتوريا بلزن", "Viktoria Plzen", "Viktoria Plzeň");
        p("دينامو زغرب", "Dinamo Zagreb", "GNK Dinamo Zagreb");
        p("بودو غليمت", "Bodo/Glimt", "Bodø/Glimt");
        p("كايرات ألماتي", "Kairat Almaty", "Kairat");
        p("أنتويرب", "Royal Antwerp", "Antwerp");
        p("أولمبيك ليون", "Olympique Lyon");
        p("بشكتاش", "Besiktas JK");
        p("سلافيا براغ", "Slavia Prague");
        p("غالاتا", "Galatasaray SK");
        p("ستراسبورغ", "Strasbourg", "RC Strasbourg");
        p("نيس", "Nice", "OGC Nice");
        p("فرايبورغ", "SC Freiburg", "Freiburg");
        p("شتوتغارت", "VfB Stuttgart", "Stuttgart");
        p("فيرتيس", "Maccabi Tel Aviv");
        p("بيتيس", "Real Betis Balompie");
        p("ميدتييلاند", "Midtjylland", "FC Midtjylland");
        p("فيردر بريمن", "Werder Bremen");
        p("غنت", "Gent", "KAA Gent");
        p("برافا", "Braga", "SC Braga", "Sporting Braga");
        p("أوتريخت", "FC Utrecht", "Utrecht");
        p("بلزن", "Plzen");
        p("غنك", "Genk", "KRC Genk");
        p("ألكمار", "AZ Alkmaar", "AZ");
        p("لودوغوريتس", "Ludogorets", "PFC Ludogorets");
        p("بازل", "FC Basel", "Basel");
        p("فيينورد", "Feyenoord Rotterdam");
        p("لاسك", "LASK");
        p("هوفنهايم", "TSG Hoffenheim", "Hoffenheim");
        p("روما الإيطالي", "AS Roma Italy");
        // national teams
        p("السعودية", "Saudi Arabia");
        p("مصر", "Egypt");
        p("المغرب", "Morocco");
        p("الجزائر", "Algeria");
        p("تونس", "Tunisia");
        p("ليبيا", "Libya");
        p("العراق", "Iraq");
        p("سوريا", "Syria");
        p("الأردن", "Jordan");
        p("لبنان", "Lebanon");
        p("فلسطين", "Palestine");
        p("الكويت", "Kuwait");
        p("قطر", "Qatar");
        p("الإمارات", "United Arab Emirates", "UAE");
        p("عمان", "Oman");
        p("البحرين", "Bahrain");
        p("السودان", "Sudan");
        p("اليمن", "Yemen");
        p("موريتانيا", "Mauritania");
        p("تركيا", "Turkey", "Türkiye", "Turkiye");
        p("إيران", "Iran", "IR Iran");
        p("اليابان", "Japan");
        p("كوريا الجنوبية", "South Korea", "Korea Republic");
        p("أستراليا", "Australia");
        p("أوزبكستان", "Uzbekistan");
        p("الصين", "China", "China PR");
        p("الهند", "India");
        p("فرنسا", "France");
        p("ألمانيا", "Germany");
        p("إسبانيا", "Spain");
        p("إنجلترا", "England");
        p("إيطاليا", "Italy");
        p("البرتغال", "Portugal");
        p("هولندا", "Netherlands");
        p("بلجيكا", "Belgium");
        p("كرواتيا", "Croatia");
        p("سويسرا", "Switzerland");
        p("الدنمارك", "Denmark");
        p("السويد", "Sweden");
        p("النرويج", "Norway");
        p("بولندا", "Poland");
        p("أوكرانيا", "Ukraine");
        p("النمسا", "Austria");
        p("التشيك", "Czechia", "Czech Republic");
        p("صربيا", "Serbia");
        p("اسكتلندا", "Scotland");
        p("ويلز", "Wales");
        p("أيرلندا", "Republic of Ireland", "Ireland");
        p("أيرلندا الشمالية", "Northern Ireland");
        p("اليونان", "Greece");
        p("المجر", "Hungary");
        p("رومانيا", "Romania");
        p("سلوفاكيا", "Slovakia");
        p("سلوفينيا", "Slovenia");
        p("ألبانيا", "Albania");
        p("جورجيا", "Georgia");
        p("فنلندا", "Finland");
        p("أيسلندا", "Iceland");
        p("روسيا", "Russia");
        p("البوسنة والهرسك", "Bosnia and Herzegovina", "Bosnia-Herzegovina");
        p("بلغاريا", "Bulgaria");
        p("إسرائيل", "Israel");
        p("كوسوفو", "Kosovo");
        p("مقدونيا الشمالية", "North Macedonia");
        p("الجبل الأسود", "Montenegro");
        p("لوكسمبورغ", "Luxembourg");
        p("قبرص", "Cyprus");
        p("البرازيل", "Brazil");
        p("الأرجنتين", "Argentina");
        p("أوروغواي", "Uruguay");
        p("كولومبيا", "Colombia");
        p("تشيلي", "Chile");
        p("باراغواي", "Paraguay");
        p("الإكوادور", "Ecuador");
        p("بيرو", "Peru");
        p("فنزويلا", "Venezuela");
        p("بوليفيا", "Bolivia");
        p("المكسيك", "Mexico");
        p("الولايات المتحدة", "United States", "USA", "USMNT");
        p("كندا", "Canada");
        p("كوستاريكا", "Costa Rica");
        p("بنما", "Panama");
        p("جامايكا", "Jamaica");
        p("هندوراس", "Honduras");
        p("السنغال", "Senegal");
        p("نيجيريا", "Nigeria");
        p("الكاميرون", "Cameroon");
        p("غانا", "Ghana");
        p("ساحل العاج", "Ivory Coast", "Côte d'Ivoire", "Cote d'Ivoire");
        p("مالي", "Mali");
        p("بوركينا فاسو", "Burkina Faso");
        p("جنوب أفريقيا", "South Africa");
        p("الكونغو الديمقراطية", "DR Congo", "Congo DR");
        p("الجابون", "Gabon");
        p("غينيا", "Guinea");
        p("الرأس الأخضر", "Cape Verde", "Cabo Verde");
        p("زامبيا", "Zambia");
        p("أنغولا", "Angola");
        p("نيوزيلندا", "New Zealand");
    }

    private TeamNames() {}

    static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        n = n.toLowerCase(Locale.ROOT).replace("ı", "i").replace("ø", "o").replace("ł", "l");
        n = n.replaceAll("\\b(fc|cf|afc|sc|ac|ss|fk|ssc)\\b", " ").replaceAll("[^a-z0-9& ]", " ")
                .replaceAll("\\s+", " ").trim();
        return n;
    }

    /** Arabic name for any of the given English names; {@code fallback} when the club is unknown. */
    public static String ar(List<String> names, String fallback) {
        if (names != null) {
            for (String n : names) {
                String v = AR.get(norm(n));
                if (v != null) return v;
            }
        }
        String v = AR.get(norm(fallback));
        return v != null ? v : fallback;
    }
}
