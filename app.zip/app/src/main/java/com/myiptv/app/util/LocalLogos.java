package com.myiptv.app.util;

import android.content.Context;

import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Logos bundled with the app (res/drawable-nodpi/lg_*.png) for channels and packages whose
 * provider gives no logo: beIN SPORTS (without a number), MBC channels, Al Jazeera, Dubai TV, Rotana.
 */
public final class LocalLogos {
    private LocalLogos() {}

    private static final Pattern BEIN_MAX = Pattern.compile("(max|\u0645\u0627\u0643\u0633)([1-3])");
    private static final Pattern MBC_NUM = Pattern.compile("(mbc|\u0627\u0645\u0628\u064a\u0633\u064a)([1-4])(?![0-9])");

    /** Drawable id of the bundled logo for this channel / package name, or 0 when there is none. */
    public static int res(Context c, String name) {
        String key = key(name);
        if (key == null) return 0;
        return c.getResources().getIdentifier("lg_" + key, "drawable", c.getPackageName());
    }

    static String key(String name) {
        if (name == null || name.isEmpty()) return null;
        String n = name.toLowerCase(Locale.US)
                .replace('\u0623', '\u0627').replace('\u0625', '\u0627').replace('\u0622', '\u0627')
                .replace('\u0649', '\u064a').replace('\u0629', '\u0647');
        String s = n.replaceAll("[^a-z0-9\\u0600-\\u06FF]", "");
        if (s.contains("bein") || s.contains("\u0628\u064a\u0627\u0646\u0633\u0628\u0648\u0631")
                || s.contains("\u0628\u064a\u0646\u0633\u0628\u0648\u0631\u062a")) {
            Matcher m = BEIN_MAX.matcher(s);
            if (m.find()) return "bein_sports_max_" + m.group(2);
            // the 4K channels get the 4K logo, the others the plain one - both without a number
            return s.contains("4k") ? "bein_sports_4k" : "bein_sports";
        }
        if (s.contains("mbc") || s.contains("\u0627\u0645\u0628\u064a\u0633\u064a")) {
            if (s.contains("masr") || s.contains("\u0645\u0635\u0631")) return "mbc_masr";
            if (s.contains("drama") || s.contains("\u062f\u0631\u0627\u0645\u0627")) return "mbc_drama";
            if (s.contains("action") || s.contains("\u0627\u0643\u0634\u0646")) return "mbc_action";
            if (s.contains("bollywood") || s.contains("\u0628\u0648\u0644\u064a\u0648\u062f")) return "mbc_bollywood";
            Matcher m = MBC_NUM.matcher(s);
            if (m.find()) return "mbc_" + m.group(2);
            return "mbc";
        }
        if (s.contains("jazeera") || s.contains("\u062c\u0632\u064a\u0631")) return "al_jazeera";
        if ((s.contains("dubai") || s.contains("\u062f\u0628\u064a"))
                && !s.contains("sport") && !s.contains("\u0631\u064a\u0627\u0636")) return "dubai_tv";
        if (s.contains("rotana") || s.contains("\u0631\u0648\u062a\u0627\u0646\u0627")) {
            if (s.contains("cinema") || s.contains("\u0633\u064a\u0646\u0645\u0627")) return "rotana_cinema";
            if (s.contains("music") || s.contains("\u0645\u0648\u0633\u064a\u0642") || s.contains("clip")) return "rotana_music";
        }
        return null;
    }
}
