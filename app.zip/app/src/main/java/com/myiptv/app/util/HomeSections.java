package com.myiptv.app.util;

import android.content.Context;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * Which sections the home screen shows: the three built-in ones can be switched on / off and the
 * user can add extra sections (a category of the provider: channels, movies or series).
 */
public final class HomeSections {
    private HomeSections() {}

    public static final String MATCHES = "matches";
    public static final String FAV_LIVE = "fav_live";
    public static final String FAV_SERIES = "fav_series";

    /** An extra home section made from one category of the provider. */
    public static final class Section {
        /** "live", "movie" or "series" */
        public String type = "";
        public String catId = "";
        public String name = "";
        public boolean on = true;

        public boolean same(String t, String c) {
            return type.equals(t) && catId.equals(c);
        }
    }

    // ------------------------------------------------------------ built-in sections

    public static boolean isOn(Context c, String key) {
        return Prefs.getBool(c, "home_show_" + key, true);
    }

    public static void setOn(Context c, String key, boolean on) {
        Prefs.markHomeDirty();
        Prefs.putBool(c, "home_show_" + key, on);
    }

    // ------------------------------------------------------------ added sections

    private static String key(long playlistId) {
        return "home_sections_" + playlistId;
    }

    public static List<Section> custom(Context c, long playlistId) {
        List<Section> out = new ArrayList<Section>();
        if (playlistId < 0) return out;
        String raw = Prefs.getString(c, key(playlistId));
        if (raw.isEmpty()) return out;
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                Section s = new Section();
                s.type = o.optString("t", "");
                s.catId = o.optString("c", "");
                s.name = o.optString("n", "");
                s.on = o.optBoolean("on", true);
                if (s.type.isEmpty() || s.catId.isEmpty()) continue;
                out.add(s);
            }
        } catch (JSONException e) {
            // damaged value: start again with an empty list
        }
        return out;
    }

    private static void save(Context c, long playlistId, List<Section> list) {
        JSONArray arr = new JSONArray();
        try {
            for (Section s : list) {
                JSONObject o = new JSONObject();
                o.put("t", s.type);
                o.put("c", s.catId);
                o.put("n", s.name);
                o.put("on", s.on);
                arr.put(o);
            }
        } catch (JSONException e) {
            return;
        }
        Prefs.putString(c, key(playlistId), arr.toString());
    }

    /** Adds a section; returns false when the same category was already added. */
    public static boolean add(Context c, long playlistId, String type, String catId, String name) {
        if (playlistId < 0 || type == null || catId == null) return false;
        List<Section> list = custom(c, playlistId);
        for (Section s : list) {
            if (s.same(type, catId)) return false;
        }
        Section n = new Section();
        n.type = type;
        n.catId = catId;
        n.name = name == null ? "" : name;
        n.on = true;
        list.add(n);
        save(c, playlistId, list);
        return true;
    }

    public static boolean has(Context c, long playlistId, String type, String catId) {
        for (Section s : custom(c, playlistId)) {
            if (s.same(type, catId)) return true;
        }
        return false;
    }

    public static void setSectionOn(Context c, long playlistId, String type, String catId, boolean on) {
        Prefs.markHomeDirty();
        List<Section> list = custom(c, playlistId);
        for (Section s : list) {
            if (s.same(type, catId)) s.on = on;
        }
        save(c, playlistId, list);
    }

    public static void remove(Context c, long playlistId, String type, String catId) {
        List<Section> list = custom(c, playlistId);
        for (int i = list.size() - 1; i >= 0; i--) {
            if (list.get(i).same(type, catId)) list.remove(i);
        }
        save(c, playlistId, list);
    }
}
