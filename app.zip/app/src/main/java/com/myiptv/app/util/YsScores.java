package com.myiptv.app.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Channel of a match from https://www.ysscores.com (Yalla Shoot): the home page lists the matches
 * (links to the match pages), the match page has a "القناة" line with the channel name.
 * Both pages are cached, so opening several matches costs very little.
 */
public final class YsScores {
    private static final String BASE = "https://www.ysscores.com";
    private static final long TTL_MS = 5L * 60L * 1000L;
    private static final Pattern LINK = Pattern.compile(
            "(?is)<a\\s[^>]*?href=\"([^\"]*?/ar/match/(\\d+)/([^\"/?#]*))\"[^>]*>(.*?)</a>");

    private static String homeHtml;
    private static long homeTime;
    private static final Map<String, List<String>> CHANNELS = new ConcurrentHashMap<>();
    private static final Map<String, Long> CHANNELS_AT = new ConcurrentHashMap<>();
    /** Last outcome, for diagnostics. */
    public static volatile String lastStatus = "";

    private YsScores() {}

    /** Channel names as the site writes them ("بي إن سبورت 1"); empty when not found. Blocking (network). */
    public static List<String> channelsFor(SportsRepository.Match m) {
        try {
            String url = findMatchUrl(m);
            if (url == null) {
                lastStatus = "match not in list";
                return new ArrayList<>();
            }
            List<String> ch = channelsOf(url);
            lastStatus = ch.isEmpty() ? "no channel on page" : "ok";
            return ch;
        } catch (Exception e) {
            lastStatus = String.valueOf(e.getMessage());
            return new ArrayList<>();
        }
    }

    private static String findMatchUrl(SportsRepository.Match m) throws Exception {
        String html;
        synchronized (YsScores.class) {
            if (homeHtml == null || System.currentTimeMillis() - homeTime > TTL_MS) {
                homeHtml = Http.readStringBrowser(BASE + "/ar/home");
                homeTime = System.currentTimeMillis();
            }
            html = homeHtml;
        }
        Matcher mt = LINK.matcher(html);
        while (mt.find()) {
            String text = mt.group(4).replaceAll("(?s)<[^>]+>", " ");
            String slug = mt.group(3).replace('-', ' ');
            try {
                slug = java.net.URLDecoder.decode(slug, "UTF-8");
            } catch (Exception ignored) {
                // keep the raw slug
            }
            String t = MatchBroadcast.norm(text + " " + slug);
            if (MatchBroadcast.hasTeam(t, m.homeNames, m.home) && MatchBroadcast.hasTeam(t, m.awayNames, m.away)) {
                String href = mt.group(1);
                return href.startsWith("http") ? href : BASE + href;
            }
        }
        return null;
    }

    private static List<String> channelsOf(String url) throws Exception {
        Long at = CHANNELS_AT.get(url);
        if (at != null && System.currentTimeMillis() - at < 2 * TTL_MS && CHANNELS.get(url) != null) {
            return CHANNELS.get(url);
        }
        String html = Http.readStringBrowser(url);
        html = html.replaceAll("(?is)<(script|style)[^>]*>.*?</\\1>", " ");
        html = html.replaceAll("(?s)<[^>]+>", "\n");
        String[] lines = html.split("\n");
        List<String> out = new ArrayList<>();
        for (int i = 0; i < lines.length && out.isEmpty(); i++) {
            if (!lines[i].trim().equals("القناة")) continue;
            for (int j = i + 1; j < lines.length && j < i + 8; j++) {
                String l = lines[j].trim();
                if (l.isEmpty()) continue;
                if (l.equals("المعلق") || l.equals("المزيد") || l.startsWith("معلومات")) break;
                if (!out.contains(l) && l.length() < 40) out.add(l);
            }
        }
        CHANNELS.put(url, out);
        CHANNELS_AT.put(url, System.currentTimeMillis());
        return out;
    }
}
