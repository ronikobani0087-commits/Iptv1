package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Category;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.HomeSections;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.util.ArrayList;
import java.util.List;

/** "الإعدادات": choose which sections the home screen shows, and add new ones. */
public class SettingsFragment extends Fragment {
    private static final int ROW_W = 320;

    private LinearLayout list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setSmoothScrollingEnabled(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int pad = Ui.dp(c, 24);
        root.setPadding(pad, Ui.dp(c, 20), pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(c);
        title.setText("إعدادات الشاشة الرئيسية");
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sub = new TextView(c);
        sub.setText("شغّل أو أوقف أي قسم ليظهر في الشاشة الرئيسية أو يختفي.");
        sub.setTextColor(ContextCompat.getColor(c, R.color.muted));
        sub.setTextSize(13);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = Ui.dp(c, 6);
        root.addView(sub, sp);

        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 12);
        root.addView(list, lp);

        FrameLayout page = new FrameLayout(c);
        page.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rebuild();
        return page;
    }

    private interface OnChange {
        void run(boolean on);
    }

    private long activePlaylist() {
        return Prefs.getActive(requireContext().getApplicationContext());
    }

    /** Draws the three built-in switches, the sections the user added, and the "+" button. */
    private void rebuild() {
        if (list == null || !isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        list.removeAllViews();

        addToggleRow("مباريات اليوم", HomeSections.isOn(app, HomeSections.MATCHES),
                on -> HomeSections.setOn(app, HomeSections.MATCHES, on), null);
        addToggleRow("القنوات المفضلة", HomeSections.isOn(app, HomeSections.FAV_LIVE),
                on -> HomeSections.setOn(app, HomeSections.FAV_LIVE, on), null);
        addToggleRow("المسلسلات المفضلة", HomeSections.isOn(app, HomeSections.FAV_SERIES),
                on -> HomeSections.setOn(app, HomeSections.FAV_SERIES, on), null);

        final long pid = activePlaylist();
        for (final HomeSections.Section s : HomeSections.custom(app, pid)) {
            addToggleRow(s.name.isEmpty() ? typeLabel(s.type) : s.name, s.on,
                    on -> HomeSections.setSectionOn(app, pid, s.type, s.catId, on),
                    () -> confirmRemove(pid, s));
        }
        addAddRow();
    }

    private void addToggleRow(String text, boolean checked, final OnChange change,
                              @Nullable final Runnable onDelete) {
        Context c = requireContext();
        LinearLayout wrap = new LinearLayout(c);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setBackgroundResource(R.drawable.bg_setting_row);
        row.setFocusable(true);
        row.setClickable(true);
        row.setPadding(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 4));
        row.setContentDescription(text);

        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(ContextCompat.getColor(c, R.color.text));
        tv.setTextSize(17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final PillToggle toggle = new PillToggle(c);
        toggle.setChecked(checked);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(Ui.dp(c, 50), Ui.dp(c, 30));
        tp.setMarginStart(Ui.dp(c, 12));
        row.addView(toggle, tp);

        row.setOnClickListener(v -> {
            boolean on = !toggle.isChecked();
            toggle.setChecked(on);
            change.run(on);
        });

        wrap.addView(row, new LinearLayout.LayoutParams(Ui.dp(c, ROW_W), Ui.dp(c, 44)));

        if (onDelete != null) {
            TextView del = new TextView(c);
            del.setText("✕");
            del.setTextSize(14);
            del.setGravity(Gravity.CENTER);
            del.setTextColor(ContextCompat.getColor(c, R.color.text));
            del.setBackgroundResource(R.drawable.bg_button_secondary);
            del.setFocusable(true);
            del.setClickable(true);
            del.setContentDescription("حذف القسم");
            del.setOnClickListener(v -> onDelete.run());
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Ui.dp(c, 38), Ui.dp(c, 38));
            dp.setMarginStart(Ui.dp(c, 8));
            wrap.addView(del, dp);
        }

        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wp.topMargin = Ui.dp(c, 6);
        list.addView(wrap, wp);
    }

    /** Green "+" : "إضافة قسم جديد للشاشة الرئيسية". */
    private void addAddRow() {
        Context c = requireContext();
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setBackgroundResource(R.drawable.bg_setting_row);
        row.setFocusable(true);
        row.setClickable(true);
        row.setPadding(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 4));
        row.setContentDescription("إضافة قسم جديد للشاشة الرئيسية");

        TextView tv = new TextView(c);
        tv.setText("إضافة قسم جديد للشاشة الرئيسية");
        tv.setTextColor(ContextCompat.getColor(c, R.color.text));
        tv.setTextSize(17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView plus = new TextView(c);
        plus.setText("+");
        plus.setTextSize(24);
        plus.setTypeface(Typeface.DEFAULT_BOLD);
        plus.setGravity(Gravity.CENTER);
        plus.setIncludeFontPadding(false);
        plus.setTextColor(0xFF04231F);
        plus.setBackgroundResource(R.drawable.bg_add_green);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 36));
        pp.setMarginStart(Ui.dp(c, 12));
        row.addView(plus, pp);

        row.setOnClickListener(v -> chooseType());

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                Ui.dp(c, ROW_W), ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = Ui.dp(c, 18);
        list.addView(row, rp);
    }

    private static String typeLabel(String type) {
        if ("live".equals(type)) return "القنوات";
        if ("movie".equals(type)) return "الأفلام";
        return "المسلسلات";
    }

    // ------------------------------------------------------------ add a section

    /** Step 1: channels, movies or series. */
    private void chooseType() {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        if (activePlaylist() < 0) {
            Toast.makeText(app, "أضف حساباً أولاً من قائمة الحساب", Toast.LENGTH_SHORT).show();
            return;
        }
        final String[] types = {"live", "movie", "series"};
        final String[] labels = {"القنوات المباشرة", "الأفلام", "المسلسلات"};
        final AlertDialog dlg = new AlertDialog.Builder(requireContext())
                .setTitle("أقسام مزود الخدمة")
                .setItems(labels, (d, which) -> chooseCategory(types[which], labels[which]))
                .setNegativeButton("إلغاء", null)
                .create();
        styled(dlg);
    }

    /** Step 2: the provider's categories of that kind; the picked one becomes a home section. */
    private void chooseCategory(final String type, final String typeName) {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final long pid = activePlaylist();
        if (pid < 0) return;
        Async.io(() -> {
            final List<Category> cats = AppDatabase.get(app).dao().getCategories(pid, type);
            Async.main(() -> {
                if (!isAdded()) return;
                if (cats.isEmpty()) {
                    Toast.makeText(app, "لا توجد أقسام هنا. حدّث المكتبة أولاً", Toast.LENGTH_LONG).show();
                    return;
                }
                final List<String> labels = new ArrayList<String>();
                for (Category cat : cats) {
                    String n = cat.name == null || cat.name.isEmpty() ? "-" : cat.name;
                    labels.add(HomeSections.has(app, pid, type, cat.remoteId) ? "✓  " + n : n);
                }
                final AlertDialog dlg = new AlertDialog.Builder(requireContext())
                        .setTitle(typeName)
                        .setItems(labels.toArray(new String[0]), (d, which) -> {
                            Category cat = cats.get(which);
                            if (cat.remoteId == null) return;
                            boolean added = HomeSections.add(app, pid, type, cat.remoteId, cat.name);
                            Toast.makeText(app, added ? "تمت إضافة القسم إلى الشاشة الرئيسية"
                                    : "هذا القسم مضاف مسبقاً", Toast.LENGTH_SHORT).show();
                            rebuild();
                        })
                        .setNegativeButton("إلغاء", null)
                        .create();
                styled(dlg);
            });
        });
    }

    private void confirmRemove(final long pid, final HomeSections.Section s) {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final AlertDialog dlg = new AlertDialog.Builder(requireContext())
                .setMessage("حذف القسم «" + s.name + "» من الشاشة الرئيسية؟")
                .setPositiveButton("حذف", (d, w) -> {
                    HomeSections.remove(app, pid, s.type, s.catId);
                    rebuild();
                })
                .setNegativeButton("إلغاء", null)
                .create();
        styled(dlg);
    }

    /** Shows the dialog with the app's background colour, slightly transparent. */
    private static void styled(AlertDialog dlg) {
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
    }
}
