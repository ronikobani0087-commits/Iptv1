package com.myiptv.app.ui;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Category;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.HomeSections;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.util.ArrayList;
import java.util.List;

/** "الإعدادات": choose which sections the home screen shows, and add new ones. */
public class SettingsFragment extends Fragment {
    private static final int ROW_W = 320;

    private LinearLayout list;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setSmoothScrollingEnabled(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        int pad = Ui.dp(c, 24);
        root.setPadding(pad, Ui.dp(c, 20), pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView title = new TextView(c);
        title.setText("إعدادات الشاشة الرئيسية");
        title.setTextColor(ContextCompat.getColor(c, R.color.text));
        title.setTextSize(20);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        root.addView(title, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        TextView sub = new TextView(c);
        sub.setText("شغّل أو أوقف أي قسم ليظهر في الشاشة الرئيسية أو يختفي.");
        sub.setTextColor(ContextCompat.getColor(c, R.color.muted));
        sub.setTextSize(13);
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        sp.topMargin = Ui.dp(c, 6);
        root.addView(sub, sp);

        list = new LinearLayout(c);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 12);
        root.addView(list, lp);

        FrameLayout page = new FrameLayout(c);
        page.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        rebuild();
        // internet speed test in the free area on the left
        FrameLayout.LayoutParams sp2 = new FrameLayout.LayoutParams(
                Ui.dp(c, 250), ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.LEFT | Gravity.TOP);
        sp2.setMargins(Ui.dp(c, 24), Ui.dp(c, 20), 0, 0);
        page.addView(buildSpeedCard(c), sp2);
        return page;
    }

    private volatile boolean speedRunning;
    private volatile boolean speedStop;
    private SpeedGaugeView speedValue;
    private TextView speedInfo, speedBtn;

    @Override
    public void onDestroyView() {
        speedStop = true;
        super.onDestroyView();
    }

    private View buildSpeedCard(Context c) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setGravity(Gravity.CENTER_HORIZONTAL);
        card.setBackgroundResource(R.drawable.bg_panel);
        int p = Ui.dp(c, 14);
        card.setPadding(p, p, p, p);

        TextView t = new TextView(c);
        t.setText("اختبار سرعة الإنترنت");
        t.setTextColor(ContextCompat.getColor(c, R.color.text));
        t.setTextSize(16);
        t.setTypeface(Typeface.DEFAULT_BOLD);
        card.addView(t);

        speedValue = new SpeedGaugeView(c);
        speedValue.setText("—");
        LinearLayout.LayoutParams gp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gp.topMargin = Ui.dp(c, 8);
        card.addView(speedValue, gp);

        speedInfo = new TextView(c);
        speedInfo.setTextColor(ContextCompat.getColor(c, R.color.muted));
        speedInfo.setTextSize(12);
        speedInfo.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        ip.topMargin = Ui.dp(c, 6);
        card.addView(speedInfo, ip);

        speedBtn = Ui.button(c, "ابدأ الاختبار", true);
        speedBtn.setOnClickListener(v -> startSpeedTest());
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        bp.topMargin = Ui.dp(c, 10);
        card.addView(speedBtn, bp);
        return card;
    }

    private static final String[] SPEED_URLS = {
            "https://speed.cloudflare.com/__down?bytes=100000000",
            "https://proof.ovh.net/files/100Mb.dat",
            "https://cachefly.cachefly.net/100mb.test",
            "http://speedtest.tele2.net/100MB.zip",
            "http://ipv4.download.thinkbroadband.com/100MB.zip"
    };

    /** Downloads a test file for ~8 seconds and shows the average speed while it runs. */
    private void startSpeedTest() {
        if (speedRunning) return;
        speedRunning = true;
        speedStop = false;
        speedValue.setText("…");
        speedInfo.setText("جارٍ الاختبار…");
        speedBtn.setText("جارٍ الاختبار");
        Async.io(() -> {
            double mbps = 0;
            long pingMs = -1;
            String lastError = "";
            for (String u : SPEED_URLS) {
                if (speedStop) break;
                java.net.HttpURLConnection con = null;
                long bytes = 0;
                double cur = 0;
                try {
                    long t0 = System.nanoTime();
                    con = (java.net.HttpURLConnection) new java.net.URL(u).openConnection();
                    con.setConnectTimeout(6000);
                    con.setReadTimeout(6000);
                    con.setInstanceFollowRedirects(true);
                    con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) RoniIPTV");
                    con.setRequestProperty("Accept-Encoding", "identity");
                    int code = con.getResponseCode();
                    if (code != 200) {
                        lastError = "HTTP " + code;
                        continue;
                    }
                    java.io.InputStream in = con.getInputStream();
                    pingMs = (System.nanoTime() - t0) / 1_000_000L;
                    byte[] buf = new byte[64 * 1024];
                    long start = System.nanoTime();
                    long lastUi = start;
                    int n;
                    while (!speedStop && (n = in.read(buf)) > 0) {
                        bytes += n;
                        long now = System.nanoTime();
                        double secs = (now - start) / 1e9;
                        if (secs > 0.3) cur = bytes * 8 / secs / 1e6;
                        if (now - lastUi > 250_000_000L) {
                            lastUi = now;
                            final double shown = cur;
                            Async.main(() -> {
                                if (isAdded() && speedValue != null) {
                                    speedValue.setText(String.format(java.util.Locale.US, "%.1f", shown));
                                }
                            });
                        }
                        if (secs >= 8) break;
                    }
                    in.close();
                    if (cur > 0) {
                        mbps = cur;
                        break;
                    }
                } catch (Exception e) {
                    lastError = e.getClass().getSimpleName();
                } finally {
                    if (con != null) con.disconnect();
                }
            }
            final double result = mbps;
            final long ping = pingMs;
            final String err = lastError;
            Async.main(() -> {
                speedRunning = false;
                if (!isAdded() || speedValue == null) return;
                speedBtn.setText("إعادة الاختبار");
                if (result <= 0) {
                    speedValue.setText("—");
                    speedInfo.setText("تعذر الاتصال بخوادم الاختبار" + (err.isEmpty() ? "" : " (" + err + ")"));
                } else {
                    speedValue.setText(String.format(java.util.Locale.US, "%.1f", result));
                    speedInfo.setText(ping >= 0 ? "زمن الاستجابة: " + ping + " م.ث" : "");
                }
            });
        });
    }

    private interface OnChange {
        void run(boolean on);
    }

    private long activePlaylist() {
        return Prefs.getActive(requireContext().getApplicationContext());
    }

    /** Draws the three built-in switches, the sections the user added, and the "+" button. */
    private void rebuild() {
        if (list == null || !isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        list.removeAllViews();

        addToggleRow("مباريات اليوم", HomeSections.isOn(app, HomeSections.MATCHES),
                on -> HomeSections.setOn(app, HomeSections.MATCHES, on), null);
        addToggleRow("القنوات المفضلة", HomeSections.isOn(app, HomeSections.FAV_LIVE),
                on -> HomeSections.setOn(app, HomeSections.FAV_LIVE, on), null);
        addToggleRow("المسلسلات المفضلة", HomeSections.isOn(app, HomeSections.FAV_SERIES),
                on -> HomeSections.setOn(app, HomeSections.FAV_SERIES, on), null);

        final long pid = activePlaylist();
        for (final HomeSections.Section s : HomeSections.custom(app, pid)) {
            addToggleRow(s.name.isEmpty() ? typeLabel(s.type) : s.name, s.on,
                    on -> HomeSections.setSectionOn(app, pid, s.type, s.catId, on),
                    () -> confirmRemove(pid, s));
        }
        addAddRow();
    }

    private void addToggleRow(String text, boolean checked, final OnChange change,
                              @Nullable final Runnable onDelete) {
        Context c = requireContext();
        LinearLayout wrap = new LinearLayout(c);
        wrap.setOrientation(LinearLayout.HORIZONTAL);
        wrap.setGravity(Gravity.CENTER_VERTICAL);
        wrap.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setBackgroundResource(R.drawable.bg_setting_row);
        row.setFocusable(true);
        row.setClickable(true);
        row.setPadding(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 4));
        row.setContentDescription(text);

        TextView tv = new TextView(c);
        tv.setText(text);
        tv.setTextColor(ContextCompat.getColor(c, R.color.text));
        tv.setTextSize(17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        tv.setSingleLine(true);
        tv.setEllipsize(TextUtils.TruncateAt.END);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        final PillToggle toggle = new PillToggle(c);
        toggle.setChecked(checked);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(Ui.dp(c, 50), Ui.dp(c, 30));
        tp.setMarginStart(Ui.dp(c, 12));
        row.addView(toggle, tp);

        row.setOnClickListener(v -> {
            boolean on = !toggle.isChecked();
            toggle.setChecked(on);
            change.run(on);
        });

        wrap.addView(row, new LinearLayout.LayoutParams(Ui.dp(c, ROW_W), Ui.dp(c, 44)));

        if (onDelete != null) {
            TextView del = new TextView(c);
            del.setText("✕");
            del.setTextSize(14);
            del.setGravity(Gravity.CENTER);
            del.setTextColor(ContextCompat.getColor(c, R.color.text));
            del.setBackgroundResource(R.drawable.bg_button_secondary);
            del.setFocusable(true);
            del.setClickable(true);
            del.setContentDescription("حذف القسم");
            del.setOnClickListener(v -> onDelete.run());
            LinearLayout.LayoutParams dp = new LinearLayout.LayoutParams(Ui.dp(c, 38), Ui.dp(c, 38));
            dp.setMarginStart(Ui.dp(c, 8));
            wrap.addView(del, dp);
        }

        LinearLayout.LayoutParams wp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        wp.topMargin = Ui.dp(c, 6);
        list.addView(wrap, wp);
        addDivider();
    }

    /** Thin translucent white line that separates one setting from the next. */
    private void addDivider() {
        Context c = requireContext();
        View d = new View(c);
        d.setBackgroundColor(0x38FFFFFF);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(c, ROW_W), Ui.dp(c, 1));
        lp.topMargin = Ui.dp(c, 6);
        list.addView(d, lp);
    }

    /** Green "+" : "إضافة قسم جديد للشاشة الرئيسية". */
    private void addAddRow() {
        Context c = requireContext();
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setBackgroundResource(R.drawable.bg_setting_row);
        row.setFocusable(true);
        row.setClickable(true);
        row.setPadding(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 4));
        row.setContentDescription("إضافة قسم جديد للشاشة الرئيسية");

        TextView tv = new TextView(c);
        tv.setText("إضافة قسم جديد للشاشة الرئيسية");
        tv.setTextColor(ContextCompat.getColor(c, R.color.text));
        tv.setTextSize(17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        TextView plus = new TextView(c);
        plus.setText("+");
        plus.setTextSize(24);
        plus.setTypeface(Typeface.DEFAULT_BOLD);
        plus.setGravity(Gravity.CENTER);
        plus.setIncludeFontPadding(false);
        plus.setTextColor(0xFF04231F);
        plus.setBackgroundResource(R.drawable.bg_add_green);
        LinearLayout.LayoutParams pp = new LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 36));
        pp.setMarginStart(Ui.dp(c, 12));
        row.addView(plus, pp);

        row.setOnClickListener(v -> chooseType());

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                Ui.dp(c, ROW_W), ViewGroup.LayoutParams.WRAP_CONTENT);
        rp.topMargin = Ui.dp(c, 18);
        list.addView(row, rp);
        addDivider();
        addAccountRow();
        addDivider();
        addServerInfo();
    }

    /**
     * Cards of every saved server, the connected one first (with a tick). Tap another card to switch to
     * it; press and hold a card to delete that connection.
     */
    private void addServerInfo() {
        final Context c = requireContext();
        TextView head = new TextView(c);
        head.setText("السيرفرات — اضغط على بطاقة للتبديل، واضغط مطولاً للحذف");
        head.setTextColor(ContextCompat.getColor(c, R.color.muted));
        head.setTextSize(13);
        head.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        LinearLayout.LayoutParams hlp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hlp.topMargin = Ui.dp(c, 14);
        list.addView(head, hlp);

        final android.widget.HorizontalScrollView hs = new android.widget.HorizontalScrollView(c);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        final LinearLayout cards = new LinearLayout(c);
        cards.setOrientation(LinearLayout.HORIZONTAL);
        cards.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        hs.addView(cards, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                Ui.dp(c, 700), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 8);
        list.addView(hs, lp);

        final Context app = c.getApplicationContext();
        final long active = activePlaylist();
        Async.io(() -> {
            final java.util.List<com.myiptv.app.data.Playlist> all =
                    com.myiptv.app.data.AppDatabase.get(app).dao().getPlaylists();
            Async.main(() -> {
                if (!isAdded()) return;
                if (all.isEmpty()) {
                    TextView none = infoLine(c, 15, R.color.muted, false);
                    none.setText("لا يوجد حساب متصل");
                    cards.addView(none, new LinearLayout.LayoutParams(Ui.dp(c, ROW_W),
                            ViewGroup.LayoutParams.WRAP_CONTENT));
                    return;
                }
                // the connected server first (right side), the others beside it
                for (com.myiptv.app.data.Playlist p : all) {
                    if (p.id == active) cards.addView(serverCard(c, p, true), cardLp(c));
                }
                for (com.myiptv.app.data.Playlist p : all) {
                    if (p.id != active) cards.addView(serverCard(c, p, false), cardLp(c));
                }
            });
        });
    }

    private static LinearLayout.LayoutParams cardLp(Context c) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                Ui.dp(c, ROW_W), ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.setMarginEnd(Ui.dp(c, 12));
        return lp;
    }

    private View serverCard(final Context c, final com.myiptv.app.data.Playlist p, boolean isActive) {
        LinearLayout card = new LinearLayout(c);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        card.setBackgroundResource(R.drawable.bg_card_focus);
        card.setFocusable(true);
        card.setClickable(true);
        card.setLongClickable(true);
        card.setSelected(isActive);
        card.setPadding(Ui.dp(c, 16), Ui.dp(c, 12), Ui.dp(c, 16), Ui.dp(c, 12));

        TextView head = new TextView(c);
        head.setText(isActive ? "✓ السيرفر المتصل به" : "اضغط للاتصال بهذا السيرفر");
        head.setTextColor(ContextCompat.getColor(c, isActive ? R.color.eye : R.color.muted));
        head.setTextSize(12);
        head.setGravity(Gravity.START);
        card.addView(head);

        final TextView name = infoLine(c, 17, R.color.text, true);
        final TextView server = infoLine(c, 13, R.color.muted, false);
        final TextView user = infoLine(c, 13, R.color.muted, false);
        final TextView exp = infoLine(c, 14, R.color.text, false);
        card.addView(name);
        card.addView(server);
        card.addView(user);
        card.addView(exp);

        name.setText(p.name);
        String host = p.url;
        try {
            String h = android.net.Uri.parse(p.url).getHost();
            if (h != null) host = h;
        } catch (Exception ignored) {
        }
        final boolean x = "xtream".equals(p.type);
        server.setText((x ? "Xtream · " : "M3U · ") + host);
        server.setTextDirection(View.TEXT_DIRECTION_LTR);
        user.setText(x ? "👤 " + p.username : "");
        user.setTextDirection(View.TEXT_DIRECTION_LTR);
        user.setVisibility(x ? View.VISIBLE : View.GONE);
        if (x) {
            final Context app = c.getApplicationContext();
            String cached = com.myiptv.app.util.AccountInfo.cached(app, p.id);
            exp.setText("ينتهي الاشتراك: " + (cached.isEmpty() ? "…" : cached));
            Async.io(() -> {
                final String t = com.myiptv.app.util.AccountInfo.fetch(app, p.id);
                Async.main(() -> {
                    if (isAdded() && !t.isEmpty()) exp.setText("ينتهي الاشتراك: " + t);
                });
            });
        } else {
            exp.setText("تاريخ الانتهاء غير متوفر لقوائم M3U");
        }

        card.setOnClickListener(v -> {
            if (isActive) return;
            Prefs.setActive(c.getApplicationContext(), p.id);
            Prefs.markHomeDirty();
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).refreshExpiry();
            rebuild();
        });
        card.setOnLongClickListener(v -> {
            confirmDeleteServer(p);
            return true;
        });
        return card;
    }

    /** Press and hold on a server card: delete that connection (and its downloaded library). */
    private void confirmDeleteServer(final com.myiptv.app.data.Playlist p) {
        final Context app = requireContext().getApplicationContext();
        final AlertDialog dlg = new AlertDialog.Builder(requireContext())
                .setMessage("حذف الاتصال بالسيرفر \"" + p.name + "\" وكل بياناته من الجهاز؟")
                .setPositiveButton("حذف الاتصال", (d, w) -> Async.io(() -> {
                    com.myiptv.app.data.AppDao dao = com.myiptv.app.data.AppDatabase.get(app).dao();
                    dao.deleteItems(p.id);
                    dao.deleteCategories(p.id);
                    dao.deletePlaylist(p.id);
                    if (Prefs.getActive(app) == p.id) {
                        java.util.List<com.myiptv.app.data.Playlist> rest = dao.getPlaylists();
                        Prefs.setActive(app, rest.isEmpty() ? -1 : rest.get(0).id);
                    }
                    Prefs.markHomeDirty();
                    Async.main(() -> {
                        if (!isAdded()) return;
                        if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).refreshExpiry();
                        rebuild();
                    });
                }))
                .setNegativeButton("إلغاء", null)
                .create();
        styled(dlg);
    }

    private static TextView infoLine(Context c, int sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setTextColor(ContextCompat.getColor(c, color));
        t.setTextSize(sp);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        t.setTextDirection(View.TEXT_DIRECTION_ANY_RTL);
        t.setGravity(Gravity.START);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.topMargin = Ui.dp(c, 4);
        t.setLayoutParams(lp);
        return t;
    }

    /** "الحساب" (moved here from the side menu): opens the accounts / playlists manager. */
    private void addAccountRow() {
        Context c = requireContext();
        LinearLayout row = new LinearLayout(c);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        row.setBackgroundResource(R.drawable.bg_setting_row);
        row.setFocusable(true);
        row.setClickable(true);
        row.setPadding(Ui.dp(c, 12), Ui.dp(c, 4), Ui.dp(c, 12), Ui.dp(c, 4));
        row.setContentDescription("الحساب");

        TextView tv = new TextView(c);
        tv.setText("الحساب");
        tv.setTextColor(ContextCompat.getColor(c, R.color.text));
        tv.setTextSize(17);
        tv.setTypeface(Typeface.DEFAULT_BOLD);
        row.addView(tv, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        android.widget.ImageView icon = new android.widget.ImageView(c);
        icon.setImageResource(R.drawable.ic_account);
        icon.setPadding(Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6), Ui.dp(c, 6));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(Ui.dp(c, 36), Ui.dp(c, 36));
        ip.setMarginStart(Ui.dp(c, 12));
        row.addView(icon, ip);

        row.setOnClickListener(v -> {
            if (getActivity() instanceof MainActivity) ((MainActivity) getActivity()).openAddPlaylist();
        });

        LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(
                Ui.dp(c, ROW_W), Ui.dp(c, 48));
        rp.topMargin = Ui.dp(c, 10);
        list.addView(row, rp);
    }

    private static String typeLabel(String type) {
        if ("live".equals(type)) return "القنوات";
        if ("movie".equals(type)) return "الأفلام";
        return "المسلسلات";
    }

    // ------------------------------------------------------------ add a section

    /** Step 1: channels, movies or series. */
    private void chooseType() {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        if (activePlaylist() < 0) {
            Toast.makeText(app, "أضف حساباً أولاً من قائمة الحساب", Toast.LENGTH_SHORT).show();
            return;
        }
        final String[] types = {"live", "movie", "series"};
        final String[] labels = {"القنوات المباشرة", "الأفلام", "المسلسلات"};
        final AlertDialog dlg = new AlertDialog.Builder(requireContext())
                .setTitle("أقسام مزود الخدمة")
                .setItems(labels, (d, which) -> chooseCategory(types[which], labels[which]))
                .setNegativeButton("إلغاء", null)
                .create();
        styled(dlg);
    }

    /** Step 2: the provider's categories of that kind; the picked one becomes a home section. */
    private void chooseCategory(final String type, final String typeName) {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final long pid = activePlaylist();
        if (pid < 0) return;
        Async.io(() -> {
            final List<Category> cats = AppDatabase.get(app).dao().getCategories(pid, type);
            Async.main(() -> {
                if (!isAdded()) return;
                if (cats.isEmpty()) {
                    Toast.makeText(app, "لا توجد أقسام هنا. حدّث المكتبة أولاً", Toast.LENGTH_LONG).show();
                    return;
                }
                final List<String> labels = new ArrayList<String>();
                for (Category cat : cats) {
                    String n = cat.name == null || cat.name.isEmpty() ? "-" : cat.name;
                    labels.add(HomeSections.has(app, pid, type, cat.remoteId) ? "✓  " + n : n);
                }
                final AlertDialog dlg = new AlertDialog.Builder(requireContext())
                        .setTitle(typeName)
                        .setItems(labels.toArray(new String[0]), (d, which) -> {
                            Category cat = cats.get(which);
                            if (cat.remoteId == null) return;
                            boolean added = HomeSections.add(app, pid, type, cat.remoteId, cat.name);
                            Toast.makeText(app, added ? "تمت إضافة القسم إلى الشاشة الرئيسية"
                                    : "هذا القسم مضاف مسبقاً", Toast.LENGTH_SHORT).show();
                            rebuild();
                        })
                        .setNegativeButton("إلغاء", null)
                        .create();
                styled(dlg);
            });
        });
    }

    private void confirmRemove(final long pid, final HomeSections.Section s) {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final AlertDialog dlg = new AlertDialog.Builder(requireContext())
                .setMessage("حذف القسم «" + s.name + "» من الشاشة الرئيسية؟")
                .setPositiveButton("حذف", (d, w) -> {
                    HomeSections.remove(app, pid, s.type, s.catId);
                    rebuild();
                })
                .setNegativeButton("إلغاء", null)
                .create();
        styled(dlg);
    }

    /** Shows the dialog with the app's background colour, slightly transparent. */
    private static void styled(AlertDialog dlg) {
        dlg.show();
        if (dlg.getWindow() != null) {
            dlg.getWindow().setBackgroundDrawableResource(R.drawable.bg_dialog);
        }
    }
}
