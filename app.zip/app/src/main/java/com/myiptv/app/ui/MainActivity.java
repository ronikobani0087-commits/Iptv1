package com.myiptv.app.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.myiptv.app.R;

public class MainActivity extends AppCompatActivity {
    private static final int[] NAV = {
            R.id.nav_home, R.id.nav_live, R.id.nav_movies, R.id.nav_series,
            R.id.nav_search, R.id.nav_downloads, R.id.nav_settings
    };
    private static final String KEY_NAV = "nav";

    private int selectedNav = R.id.nav_home;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        boolean labels = getResources().getBoolean(R.bool.show_nav_labels);
        for (int id : NAV) {
            TextView tv = findViewById(id);
            if (!labels) {
                tv.setText("");
                tv.setGravity(Gravity.CENTER);
                tv.setCompoundDrawablePadding(0);
            }
            tv.setOnClickListener(v -> select(v.getId()));
        }

        if (savedInstanceState == null) {
            select(R.id.nav_home);
            findViewById(R.id.nav_home).requestFocus();
        } else {
            markSelected(savedInstanceState.getInt(KEY_NAV, R.id.nav_home));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_NAV, selectedNav);
    }

    private void markSelected(int id) {
        selectedNav = id;
        for (int navId : NAV) {
            findViewById(navId).setSelected(navId == id);
        }
    }

    public void select(int navId) {
        markSelected(navId);
        FragmentManager fm = getSupportFragmentManager();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        fm.beginTransaction().replace(R.id.content, fragmentFor(navId)).commit();
    }

    public void goHome() {
        select(R.id.nav_home);
    }

    public void openAddPlaylist() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.content, new AddPlaylistFragment())
                .addToBackStack(null)
                .commit();
    }

    private Fragment fragmentFor(int navId) {
        if (navId == R.id.nav_home) return new HomeFragment();
        if (navId == R.id.nav_settings) return new PlaylistsFragment();
        if (navId == R.id.nav_live) return BrowseFragment.newInstance("live");
        if (navId == R.id.nav_movies) return BrowseFragment.newInstance("movie");
        if (navId == R.id.nav_series) return BrowseFragment.newInstance("series");
        View v = findViewById(navId);
        CharSequence title = v.getContentDescription();
        return PlaceholderFragment.newInstance(title == null ? "" : title.toString());
    }
}
