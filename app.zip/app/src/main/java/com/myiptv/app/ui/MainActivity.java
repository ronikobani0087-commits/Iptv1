package com.myiptv.app.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.myiptv.app.R;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.AccountInfo;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;

public class MainActivity extends AppCompatActivity {
    private static final int[] NAV = {
            R.id.nav_home, R.id.nav_live, R.id.nav_movies, R.id.nav_series,
            R.id.nav_refresh, R.id.nav_settings
    };
    private static final String KEY_NAV = "nav";

    private int selectedNav = R.id.nav_home;
    private View sidebar;

    /** In full screen live TV the Back button returns to the home screen (the menu is hidden). */
    private final OnBackPressedCallback liveBack = new OnBackPressedCallback(false) {
        @Override
        public void handleOnBackPressed() {
            goHome();
        }
    };

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sidebar = findViewById(R.id.sidebar);
        getOnBackPressedDispatcher().addCallback(this, liveBack);

        boolean labels = getResources().getBoolean(R.bool.show_nav_labels);
        for (int id : NAV) {
            TextView tv = findViewById(id);
            if (!labels) {
                tv.setText("");
                tv.setGravity(Gravity.CENTER);
                tv.setCompoundDrawablePadding(0);
            }
            tv.setOnClickListener(v -> onNav(v.getId()));
        }

        if (savedInstanceState == null) {
            select(R.id.nav_home);
            findViewById(R.id.nav_home).requestFocus();
        } else {
            markSelected(savedInstanceState.getInt(KEY_NAV, R.id.nav_home));
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_NAV, selectedNav);
    }

    private void onNav(int id) {
        if (id == R.id.nav_refresh) doRefresh();
        else select(id);
    }

    @Override
    protected void onResume() {
        super.onResume();
        showExpiry(false);
    }

    /** Shows the subscription end date under the menu (asks the server when asked to). */
    private void showExpiry(boolean fetch) {
        final TextView tv = findViewById(R.id.expiry);
        final long pid = Prefs.getActive(this);
        if (tv == null || pid < 0) {
            if (tv != null) tv.setVisibility(View.GONE);
            return;
        }
        final android.content.Context app = getApplicationContext();
        final String cached = AccountInfo.cached(app, pid);
        setExpiry(tv, cached);
        if (!fetch && !cached.isEmpty()) return;
        Async.io(() -> {
            final String t = AccountInfo.fetch(app, pid);
            Async.main(() -> {
                if (!isFinishing() && !isDestroyed()) setExpiry(tv, t);
            });
        });
    }

    private static void setExpiry(TextView tv, String date) {
        if (date == null || date.isEmpty()) {
            tv.setVisibility(View.GONE);
        } else {
            tv.setText("ينتهي الاشتراك\n" + date);
            tv.setVisibility(View.VISIBLE);
        }
    }

    /** "تحديث": reloads channels, movies and series from the server and the expiry date. */
    private void doRefresh() {
        final long pid = Prefs.getActive(this);
        if (pid < 0) {
            Toast.makeText(this, "لا توجد قائمة. أضف حساباً من الإعدادات", Toast.LENGTH_SHORT).show();
            return;
        }
        final View btn = findViewById(R.id.nav_refresh);
        btn.setEnabled(false);
        Toast.makeText(this, "جارٍ تحديث المكتبة…", Toast.LENGTH_SHORT).show();
        SyncRepository.sync(this, pid, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
            }

            @Override
            public void onDone() {
                btn.setEnabled(true);
                if (isFinishing() || isDestroyed()) return;
                Toast.makeText(MainActivity.this, "تم تحديث المكتبة", Toast.LENGTH_SHORT).show();
                showExpiry(true);
                select(selectedNav);
            }

            @Override
            public void onError(String message) {
                btn.setEnabled(true);
                if (isFinishing() || isDestroyed()) return;
                Toast.makeText(MainActivity.this, "تعذر التحديث: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    private void markSelected(int id) {
        selectedNav = id;
        for (int navId : NAV) {
            findViewById(navId).setSelected(navId == id);
        }
        // live, movies and series take the whole screen: the side menu is hidden there
        boolean full = id == R.id.nav_live || id == R.id.nav_movies || id == R.id.nav_series;
        if (sidebar != null) sidebar.setVisibility(full ? View.GONE : View.VISIBLE);
        liveBack.setEnabled(full);
    }

    public void select(int navId) {
        markSelected(navId);
        FragmentManager fm = getSupportFragmentManager();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        fm.beginTransaction().replace(R.id.content, fragmentFor(navId)).commit();
    }

    public void goHome() {
        select(R.id.nav_home);
        View home = findViewById(R.id.nav_home);
        if (home != null) home.requestFocus();
    }

    public void openAddPlaylist() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.content, new AddPlaylistFragment())
                .addToBackStack(null)
                .commit();
    }

    private Fragment fragmentFor(int navId) {
        if (navId == R.id.nav_home) return new HomeFragment();
        if (navId == R.id.nav_settings) return new PlaylistsFragment();
        if (navId == R.id.nav_live) return BrowseFragment.newInstance("live");
        if (navId == R.id.nav_movies) return BrowseFragment.newInstance("movie");
        if (navId == R.id.nav_series) return BrowseFragment.newInstance("series");
        View v = findViewById(navId);
        CharSequence title = v.getContentDescription();
        return PlaceholderFragment.newInstance(title == null ? "" : title.toString());
    }
}
