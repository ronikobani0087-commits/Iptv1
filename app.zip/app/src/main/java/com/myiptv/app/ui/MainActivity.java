package com.myiptv.app.ui;

import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.OnBackPressedCallback;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;

import com.myiptv.app.R;
import com.myiptv.app.data.SyncRepository;
import com.myiptv.app.util.AccountInfo;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

public class MainActivity extends BaseActivity {
    private static final int[] NAV = {
            R.id.nav_home, R.id.nav_live, R.id.nav_series, R.id.nav_movies,
            R.id.nav_refresh, R.id.nav_settings
    };
    private static final String KEY_NAV = "nav";

    private int selectedNav = R.id.nav_home;
    private View sidebar;

    /** In full screen live TV the Back button returns to the home screen (the menu is hidden). */
    private final OnBackPressedCallback liveBack = new OnBackPressedCallback(false) {
        @Override
        public void handleOnBackPressed() {
            goHome();
        }
    };

    /** Back is ignored while the opening intro plays. */
    private final OnBackPressedCallback introBack = new OnBackPressedCallback(false) {
        @Override
        public void handleOnBackPressed() {
        }
    };
    private IntroView intro;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        sidebar = findViewById(R.id.sidebar);
        getOnBackPressedDispatcher().addCallback(this, introBack);
        getOnBackPressedDispatcher().addCallback(this, liveBack);

        boolean labels = getResources().getBoolean(R.bool.show_nav_labels);
        for (int id : NAV) {
            TextView tv = findViewById(id);
            if (!labels) {
                tv.setText("");
                tv.setGravity(Gravity.CENTER);
                tv.setCompoundDrawablePadding(0);
            }
            tv.setOnClickListener(v -> onNav(v.getId()));
        }

        if (savedInstanceState == null) {
            select(R.id.nav_home);
            findViewById(R.id.nav_home).requestFocus();
            // no account yet: the add-account screen shows right after the intro
            if (Prefs.getActive(this) < 0) openAddPlaylist();
        } else {
            markSelected(savedInstanceState.getInt(KEY_NAV, R.id.nav_home));
        }
        // the intro plays every time the app is opened (not on rotation / re-creation)
        if (savedInstanceState == null) showIntro();
    }

    private void showIntro() {
        final ViewGroup host = findViewById(android.R.id.content);
        final IntroView v = new IntroView(this);
        intro = v;
        introBack.setEnabled(true);
        host.addView(v, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        v.requestFocus();
        v.start(() -> {
            if (intro == v) intro = null;
            introBack.setEnabled(false);
            host.removeView(v);
            if (!isFinishing() && !isDestroyed() && sidebar != null
                    && sidebar.getVisibility() == View.VISIBLE) {
                View home = findViewById(R.id.nav_home);
                if (home != null) home.requestFocus();
            }
        });
    }

    @Override
    public boolean dispatchKeyEvent(android.view.KeyEvent event) {
        if (intro != null) return true;
        // Back from anywhere inside the home / settings content jumps straight to the side menu
        if (event.getKeyCode() == android.view.KeyEvent.KEYCODE_BACK && sidebar != null
                && sidebar.getVisibility() == View.VISIBLE) {
            View f = getCurrentFocus();
            boolean inMenu = false;
            for (View v = f; v != null; ) {
                if (v == sidebar) {
                    inMenu = true;
                    break;
                }
                android.view.ViewParent p = v.getParent();
                v = p instanceof View ? (View) p : null;
            }
            if (!inMenu && f != null && selectedNav == R.id.nav_home) {
                if (event.getAction() == android.view.KeyEvent.ACTION_UP) {
                    findViewById(selectedNav).requestFocus();
                }
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (intro != null) intro.finish();
    }

    @Override
    protected void onDestroy() {
        if (intro != null) intro.finish();
        super.onDestroy();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putInt(KEY_NAV, selectedNav);
    }

    private void onNav(int id) {
        if (id == R.id.nav_refresh) doRefresh();
        else if (id == R.id.nav_live) PlayerActivity.startBrowse(this); // channels open straight in the player
        else select(id);
    }

    @Override
    protected void onResume() {
        super.onResume();
        showExpiry(false);
    }

    /** Re-reads the subscription date under the menu (after switching or deleting a server). */
    public void refreshExpiry() {
        showExpiry(false);
    }

    /** Shows the subscription end date under the menu (asks the server when asked to). */
    private void showExpiry(boolean fetch) {
        final TextView tv = findViewById(R.id.expiry);
        final long pid = Prefs.getActive(this);
        if (tv == null || pid < 0) {
            if (tv != null) tv.setVisibility(View.GONE);
            return;
        }
        final android.content.Context app = getApplicationContext();
        final String cached = AccountInfo.cached(app, pid);
        setExpiry(tv, cached);
        if (!fetch && !cached.isEmpty()) return;
        Async.io(() -> {
            final String t = AccountInfo.fetch(app, pid);
            Async.main(() -> {
                if (!isFinishing() && !isDestroyed()) setExpiry(tv, t);
            });
        });
    }

    private static void setExpiry(TextView tv, String date) {
        if (date == null || date.isEmpty()) {
            tv.setVisibility(View.GONE);
        } else {
            tv.setText("ينتهي الاشتراك\n" + date);
            tv.setVisibility(View.VISIBLE);
        }
    }

    /** "تحديث": reloads channels, movies and series from the server and the expiry date. */
    private void doRefresh() {
        final long pid = Prefs.getActive(this);
        if (pid < 0) {
            Toast.makeText(this, "لا توجد قائمة. أضف حساباً من الإعدادات", Toast.LENGTH_SHORT).show();
            return;
        }
        final View btn = findViewById(R.id.nav_refresh);
        btn.setEnabled(false);
        Toast.makeText(this, "جارٍ تحديث المكتبة…", Toast.LENGTH_SHORT).show();
        SyncRepository.sync(this, pid, new SyncRepository.Callback() {
            @Override
            public void onProgress(String message) {
            }

            @Override
            public void onDone() {
                btn.setEnabled(true);
                if (isFinishing() || isDestroyed()) return;
                Toast.makeText(MainActivity.this, "تم تحديث المكتبة", Toast.LENGTH_SHORT).show();
                showExpiry(true);
                select(selectedNav);
            }

            @Override
            public void onError(String message) {
                btn.setEnabled(true);
                if (isFinishing() || isDestroyed()) return;
                Toast.makeText(MainActivity.this, "تعذر التحديث: " + message, Toast.LENGTH_LONG).show();
            }
        });
    }

    public void confirmLogout(final long pid) {
        new androidx.appcompat.app.AlertDialog.Builder(this)
                .setMessage("تسجيل الخروج من الحساب الحالي وحذف بياناته من الجهاز؟")
                .setPositiveButton("تسجيل الخروج", (d, w) -> {
                    final android.content.Context app = getApplicationContext();
                    Async.io(() -> {
                        com.myiptv.app.data.AppDao dao = com.myiptv.app.data.AppDatabase.get(app).dao();
                        dao.deleteItems(pid);
                        dao.deleteCategories(pid);
                        dao.deletePlaylist(pid);
                        java.util.List<com.myiptv.app.data.Playlist> rest = dao.getPlaylists();
                        Prefs.setActive(app, rest.isEmpty() ? -1 : rest.get(0).id);
                        final boolean none = rest.isEmpty();
                        Async.main(() -> {
                            if (isFinishing() || isDestroyed()) return;
                            showExpiry(false);
                            goHome();
                            if (none) openAddPlaylist();
                        });
                    });
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void markSelected(int id) {
        selectedNav = id;
        for (int navId : NAV) {
            findViewById(navId).setSelected(navId == id);
        }
        // live, movies and series take the whole screen: the side menu is hidden there
        boolean full = id == R.id.nav_live || id == R.id.nav_movies || id == R.id.nav_series;
        if (sidebar != null) sidebar.setVisibility(full ? View.GONE : View.VISIBLE);
        // Back returns to the home screen from the full screen sections and from the settings
        liveBack.setEnabled(full || id == R.id.nav_settings);
    }

    public void select(int navId) {
        markSelected(navId);
        FragmentManager fm = getSupportFragmentManager();
        fm.popBackStack(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        fm.beginTransaction().replace(R.id.content, fragmentFor(navId)).commit();
    }

    public void goHome() {
        select(R.id.nav_home);
        View home = findViewById(R.id.nav_home);
        if (home != null) home.requestFocus();
    }

    /** With no account yet the screen is shown alone (no side menu, no cancel button). */
    public void openAddPlaylist() {
        final boolean first = Prefs.getActive(this) < 0;
        // first start: logo + three boxes only; later (الحساب): the full list manager
        final Fragment screen = first ? new FirstLaunchFragment() : new AccountFragment();
        androidx.fragment.app.FragmentTransaction t = getSupportFragmentManager().beginTransaction()
                .replace(R.id.content, screen);
        if (first) {
            if (sidebar != null) sidebar.setVisibility(View.GONE);
        } else {
            t.addToBackStack(null);
        }
        t.commit();
    }

    /** The add-playlist form (Xtream / M3U tabs), opened from the "+" tile of the account screen. */
    public void openAddForm() {
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.content, AddPlaylistFragment.newInstance(false))
                .addToBackStack(null)
                .commit();
    }

    private Fragment fragmentFor(int navId) {
        if (navId == R.id.nav_home) return new HomeFragment();
        if (navId == R.id.nav_live) return BrowseFragment.newInstance("live");
        if (navId == R.id.nav_movies) return BrowseFragment.newInstance("movie");
        if (navId == R.id.nav_series) return BrowseFragment.newInstance("series");
        if (navId == R.id.nav_settings) return new SettingsFragment();
        View v = findViewById(navId);
        CharSequence title = v.getContentDescription();
        return PlaceholderFragment.newInstance(title == null ? "" : title.toString());
    }
}
