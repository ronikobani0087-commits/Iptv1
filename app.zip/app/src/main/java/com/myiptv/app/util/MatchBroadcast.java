package com.myiptv.app.util;

import android.content.Context;

import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Finds the channel of the user's own subscription that carries a match:
 * 1) the provider's program guide (EPG) of the beIN channels names both teams around the kick-off;
 * 2) otherwise the broadcaster ESPN lists (e.g. "beIN SPORTS 1"), when it names a channel number
 *    that exists in the subscription.
 * No result means "broadcast details not available".
 */
public final class MatchBroadcast {
    public static final class Result {
        /** Channel name shown in the details ("beIN SPORTS 1"). */
        public String label = "";
        /** The channel to open; null when only a name is known. */
        public Item channel;
        /** The list the channel was found in (for next / previous channel on the remote). */
        public List<Item> queue = new ArrayList<>();
        /** 1-based position of the channel in {@link #queue}. */
        public int number = 1;

        public boolean playable() {
            return channel != null && channel.streamUrl != null && !channel.streamUrl.isEmpty();
        }
    }

    private static final long WINDOW_MS = 3L * 3600L * 1000L;

    private MatchBroadcast() {}

    /** Blocking (network + database): call from a background thread. Never returns null. */
    public static Result resolve(Context ctx, SportsRepository.Match m) {
        Result r = new Result();
        try {
            Context app = ctx.getApplicationContext();
            long pid = Prefs.getActive(app);
            Playlist p = pid < 0 ? null : AppDatabase.get(app).dao().getPlaylist(pid);
            List<Item> channels = p == null ? new ArrayList<Item>()
                    : AppDatabase.get(app).dao().beinChannels(p.id, 80);
            r.queue = channels;

            // 1) the provider's program guide
            if (p != null && !channels.isEmpty()) {
                try {
                    List<EpgRepository.Match> epg = EpgRepository.loadRaw(p, channels);
                    for (EpgRepository.Match e : epg) {
                        if (!sameTime(e, m) || !namesBoth(e.title, m)) continue;
                        int idx = indexOfUrl(channels, e.streamUrl);
                        if (idx < 0) continue;
                        r.channel = channels.get(idx);
                        r.number = idx + 1;
                        r.label = clean(r.channel.name);
                        return r;
                    }
                } catch (Exception ignored) {
                    // guide not available: try the next source
                }
            }

            // 2) ESPN's broadcaster name, matched by brand and channel number
            for (String b : m.broadcasts) {
                if (!"bein".equals(Ui.brand(b))) continue;
                int num = digit(b);
                if (num <= 0) continue;
                for (int i = 0; i < channels.size(); i++) {
                    Item it = channels.get(i);
                    if (digit(it.name) == num && "bein".equals(Ui.brand(it.name))) {
                        r.channel = it;
                        r.number = i + 1;
                        r.label = clean(it.name);
                        return r;
                    }
                }
                if (r.label.isEmpty()) r.label = b; // named, but not in this subscription
            }
        } catch (Exception ignored) {
            // fall through: nothing found
        }
        return r;
    }

    private static boolean sameTime(EpgRepository.Match e, SportsRepository.Match m) {
        long es = e.start * 1000L, ee = e.stop * 1000L;
        long now = System.currentTimeMillis();
        if ("in".equals(m.state) && es <= now && ee >= now) return true;
        return Math.abs(es - m.start) <= WINDOW_MS;
    }

    private static boolean namesBoth(String title, SportsRepository.Match m) {
        String t = norm(title);
        return hasTeam(t, m.homeNames, m.home) && hasTeam(t, m.awayNames, m.away);
    }

    private static boolean hasTeam(String t, List<String> names, String arabic) {
        List<String> all = new ArrayList<>(names);
        all.add(arabic);
        for (String n : all) {
            String k = norm(n);
            if (k.length() >= 3 && t.contains(k)) return true;
        }
        return false;
    }

    private static int indexOfUrl(List<Item> list, String url) {
        if (url == null) return -1;
        for (int i = 0; i < list.size(); i++) {
            if (url.equals(list.get(i).streamUrl)) return i;
        }
        return -1;
    }

    private static int digit(String s) {
        if (s == null) return 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '1' && c <= '9') return c - '0';
        }
        return 0;
    }

    /** Channel name without the provider's prefixes like "AR:" or "|AR|". */
    private static String clean(String n) {
        if (n == null) return "";
        return n.replaceAll("^[\\s|\\[\\(]*[A-Za-z]{2,3}[\\s|\\]\\):\\-]+", "").trim();
    }

    private static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        n = n.toLowerCase(Locale.ROOT)
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ة', 'ه').replace('ى', 'ي');
        return n.replaceAll("[^a-z0-9\\u0600-\\u06FF]", "");
    }
}
