package com.myiptv.app.util;

import android.content.Context;

import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Finds the channel of the user's own subscription that carries a match:
 * 1) kooralive.la names the channel that carries the match;
 * 2) otherwise tvguideapi.com, then the broadcaster ESPN lists (e.g. "beIN SPORTS 1"), when it names a channel number
 *    that exists in the subscription.
 * Order: kooralive.la, ysscores.com, tvguideapi, ESPN (all light and cached). The heavy program-guide (EPG) lookup was removed.
 * No result means "broadcast details not available".
 */
public final class MatchBroadcast {
    public static final class Result {
        /** Channel name shown in the details ("beIN SPORTS 1"). */
        public String label = "";
        /** The channel to open; null when only a name is known. */
        public Item channel;
        /** The list the channel was found in (for next / previous channel on the remote). */
        public List<Item> queue = new ArrayList<>();
        /** 1-based position of the channel in {@link #queue}. */
        public int number = 1;
        /** Why no channel was found (shown in the details to help fixing the source). */
        public String debug = "";
        /** Every version of the carrying channel in the subscription (HD, FHD, 4K, SD...). */
        public List<Item> variants = new ArrayList<>();

        public boolean playable() {
            return channel != null && channel.streamUrl != null && !channel.streamUrl.isEmpty();
        }
    }

    private MatchBroadcast() {}

    /** Blocking (network + database): call from a background thread. Never returns null. */
    public static Result resolve(Context ctx, SportsRepository.Match m) {
        Result r = new Result();
        try {
            Context app = ctx.getApplicationContext();
            long pid = Prefs.getActive(app);
            Playlist p = pid < 0 ? null : AppDatabase.get(app).dao().getPlaylist(pid);
            List<Item> channels = new ArrayList<>();
            if (p != null) {
                channels.addAll(AppDatabase.get(app).dao().beinChannels(p.id, 80));
                java.util.Set<Long> have = new java.util.HashSet<>();
                for (Item it : channels) have.add(it.id);
                for (Item it : AppDatabase.get(app).dao().sportsChannels(p.id, 200)) {
                    if (have.add(it.id)) channels.add(it);
                }
            }
            r.queue = channels;

            // 0) some providers publish a channel named after the match ("FRANCE vs ITALY")
            if (p != null) {
                Item ev = findEventChannel(app, p.id, m);
                if (ev != null) {
                    int idx = indexOfUrl(channels, ev.streamUrl);
                    if (idx < 0) {
                        channels.add(0, ev);
                        idx = 0;
                    }
                    r.channel = ev;
                    r.number = idx + 1;
                    r.label = clean(ev.name);
                    return r;
                }
            }

            // 1) kooralive.la: names the exact channel ("beIN SPORTS HD 1") of the match
            if (!channels.isEmpty()) {
                String name = KooraLive.channelFor(m);
                r.debug = "kooralive: " + KooraLive.lastStatus;
                if (!name.isEmpty()) {
                    List<Item> v = findVariants(app, p, channels, name);
                    if (!v.isEmpty()) {
                        fill(r, channels, v, name);
                        return r;
                    }
                    if (r.label.isEmpty()) r.label = clean(name); // named, but not in this subscription
                }
            }

            // 2) ysscores.com: the match page names the channel (also for matches kooralive does not list)
            if (!channels.isEmpty()) {
                List<String> ys = YsScores.channelsFor(m);
                r.debug += " | ysscores: " + YsScores.lastStatus;
                for (String name : ys) {
                    List<Item> v = findVariants(app, p, channels, name);
                    if (!v.isEmpty()) {
                        fill(r, channels, v, name);
                        return r;
                    }
                    if (r.label.isEmpty()) r.label = latinize(name); // named, but not in this subscription
                }
            }

            // 3) tvguideapi.com: one light request that names the channel carrying the match
            if (!channels.isEmpty()) {
                List<String> tv = TvGuideApi.channelsFor(m);
                r.debug += " | tvguide: " + TvGuideApi.lastStatus;
                for (String name : tv) {
                    List<Item> v = findVariants(app, p, channels, name);
                    if (!v.isEmpty()) {
                        fill(r, channels, v, name);
                        return r;
                    }
                    if (r.label.isEmpty()) r.label = name; // named, but not in this subscription
                }
            }

            // 4) ESPN's broadcaster name, matched by brand and channel number
            for (String b : m.broadcasts) {
                if (!"bein".equals(Ui.brand(b)) || number(b) <= 0) continue;
                List<Item> v = findVariants(app, p, channels, b);
                if (!v.isEmpty()) {
                    fill(r, channels, v, b);
                    return r;
                }
                if (r.label.isEmpty()) r.label = b; // named, but not in this subscription
            }
        } catch (Exception ignored) {
            // fall through: nothing found
        }
        return r;
    }

    static boolean hasTeam(String t, List<String> names, String arabic) {
        List<String> all = new ArrayList<>(names);
        all.add(arabic);
        for (String n : all) {
            String k = norm(n);
            if (k.length() >= 3 && t.contains(k)) return true;
            // the "ال" prefix is often dropped in guides and channel names (الدنمارك / دنمارك)
            if (k.startsWith("ال") && k.length() >= 5 && t.contains(k.substring(2))) return true;
        }
        return false;
    }

    /** A live channel whose own name carries both teams (event channels), or null. Blocking (database). */
    private static Item findEventChannel(Context app, long playlistId, SportsRepository.Match m) {
        try {
            List<String> queries = new ArrayList<>();
            for (String n : m.homeNames) queries.add(n);
            for (String n : m.awayNames) queries.add(n);
            queries.add(m.home);
            queries.add(m.away);
            java.util.Set<Long> seen = new java.util.HashSet<>();
            for (String q : queries) {
                if (q == null || q.trim().length() < 3) continue;
                for (Item it : AppDatabase.get(app).dao().searchItems(playlistId, "live", q.trim(), 40)) {
                    if (!seen.add(it.id)) continue;
                    String t = norm(it.name);
                    if (it.streamUrl == null || it.streamUrl.isEmpty()) continue;
                    if (hasTeam(t, m.homeNames, m.home) && hasTeam(t, m.awayNames, m.away)) return it;
                }
            }
        } catch (Exception ignored) {
            // no event channel
        }
        return null;
    }

    private static int indexOfUrl(List<Item> list, String url) {
        if (url == null) return -1;
        for (int i = 0; i < list.size(); i++) {
            if (url.equals(list.get(i).streamUrl)) return i;
        }
        return -1;
    }

    private static void fill(Result r, List<Item> queue, List<Item> variants, String name) {
        for (Item it : variants) {
            if (indexOfUrl(queue, it.streamUrl) < 0) queue.add(it);
        }
        variants = new ArrayList<>(variants);
        java.util.Collections.sort(variants, (a, b) -> rank(a.name) - rank(b.name));
        r.variants = variants;
        r.channel = variants.get(0);
        r.number = indexOfUrl(queue, r.channel.streamUrl) + 1;
        if (r.number <= 0) r.number = 1;
        r.label = clean(latinize(name));
    }

    /** Every version of the named channel (beIN SPORTS 3 -> HD, FHD, 4K, SD...), in playlist order. */
    static List<Item> variantsOf(List<Item> channels, String wanted) {
        wanted = latinize(wanted);
        List<Item> out = new ArrayList<>();
        String brand = Ui.brand(wanted);
        int num = number(wanted);
        String key = norm(clean(wanted));
        String special = specialKey(wanted);
        for (Item it : channels) {
            if (it.streamUrl == null || it.streamUrl.isEmpty()) continue;
            boolean same;
            if (brand != null && num > 0) {
                same = brand.equals(Ui.brand(it.name)) && number(it.name) == num
                        && special.equals(specialKey(it.name));
            } else {
                same = genericMatch(it.name, wanted);
            }
            if (same) out.add(it);
        }
        return out;
    }

    /** Words that say nothing about which channel it is. */
    private static final java.util.Set<String> STOP = new java.util.HashSet<>(java.util.Arrays.asList(
            "الرياضيه", "الرياضية", "رياضه", "رياضية", "قناه", "قناة", "تي", "في", "tv", "hd", "fhd", "sd",
            "sport", "sports", "channel", "the", "al", "plus", "live", "4k", "8k"));

    /** Search keys for the Arab / regional sports channels the guides write in Arabic. */
    private static List<String> aliases(String word) {
        String w = norm(word);
        List<String> a = new ArrayList<>();
        a.add(w);
        if (w.startsWith("ال") && w.length() > 4) a.add(w.substring(2));
        String[][] table = {
                {"سعود", "ssc", "saudi", "ksa", "السعودية"},
                {"كويت", "kuwait", "kwt", "الكويت"},
                {"دبي", "dubai", "dubaisport"},
                {"ابوظبي", "abudhabi", "adsport", "abudhabisport"},
                {"ابو", "abu"},
                {"شارقه", "sharjah"},
                {"عمان", "oman"},
                {"قطر", "qatar", "alkass", "الكاس"},
                {"كاس", "alkass"},
                {"بحرين", "bahrain"},
                {"جزاير", "algeria", "algerie"},
                {"مغرب", "maroc", "morocco", "arryadia", "الرياضيه"},
                {"تونس", "tunisia", "tunisie", "watania"},
                {"اردن", "jordan"},
                {"عراق", "iraq", "iraqi"},
                {"ليبيا", "libya"},
                {"مصر", "egypt", "ontime", "nile", "on"},
                {"اون", "ontime", "on"},
                {"نايل", "nile"},
                {"ثمانيه", "thmanyah", "8"},
                {"اس", "ssc"},
        };
        for (String[] row : table) {
            if (w.contains(row[0])) {
                for (int i = 1; i < row.length; i++) a.add(row[i]);
            }
        }
        return a;
    }

    /** Does this playlist channel carry the same channel as the guide's (maybe Arabic) name? */
    static boolean genericMatch(String itemName, String wanted) {
        String item = norm(latinize(itemName)) + "|" + norm(itemName);
        String w = latinize(wanted).replaceAll("[0-9]+", " ");
        int wn = number(wanted), in = number(itemName);
        if (wn > 0 && in > 0 && wn != in) return false;
        if (wn > 0 && in == 0) return false;
        int tokens = 0, hit = 0;
        for (String tok : w.split("[^\\p{L}]+")) {
            String t = norm(tok);
            if (t.length() < 2 || STOP.contains(t)) continue;
            tokens++;
            for (String al : aliases(tok)) {
                if (al.length() >= 2 && item.contains(al)) {
                    hit++;
                    break;
                }
            }
        }
        return tokens > 0 && hit == tokens;
    }

    /** Versions of the channel in the loaded list; otherwise searched in the whole live list of the playlist. */
    private static List<Item> findVariants(Context app, Playlist p, List<Item> channels, String name) {
        List<Item> v = variantsOf(channels, name);
        if (!v.isEmpty() || p == null) return v;
        try {
            List<Item> pool = new ArrayList<>();
            java.util.Set<Long> seen = new java.util.HashSet<>();
            String w = latinize(name).replaceAll("[0-9]+", " ");
            for (String tok : w.split("[^\\p{L}]+")) {
                String t = norm(tok);
                if (t.length() < 2 || STOP.contains(t)) continue;
                for (String al : aliases(tok)) {
                    if (al.length() < 3) continue;
                    for (Item it : AppDatabase.get(app).dao().searchItems(p.id, "live", al, 60)) {
                        if (seen.add(it.id)) pool.add(it);
                    }
                }
            }
            return variantsOf(pool, name);
        } catch (Exception e) {
            return v;
        }
    }

    /** Lower is better: plain / HD / FHD first, then the rest, 4K, 8K and SD last. */
    private static int rank(String n) {
        String l = n == null ? "" : n.toLowerCase(Locale.ROOT);
        if (l.contains("8k")) return 5;
        if (l.contains("4k")) return 4;
        if (l.contains("sd")) return 3;
        if (l.contains("fhd") || l.contains("1080")) return 0;
        if (l.contains("hd")) return 1;
        return 2;
    }

    /** Arabic channel names of the guides ("بي إن سبورت 1") written like the playlist does ("beIN SPORTS 1"). */
    static String latinize(String n) {
        if (n == null) return "";
        String x = n.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا');
        x = x.replaceAll("بي\\s*ان\\s*سبورت[س]?", "beIN SPORTS")
                .replaceAll("اكسترا", "XTRA").replaceAll("ماكس", "MAX").replaceAll("نيوز|اخبار", "NEWS")
                .replaceAll("اس\\s*اس\\s*سي", "SSC").replaceAll("الكاس", "Alkass")
                .replaceAll("ثمانيه|ثمانية", "Thmanyah");
        StringBuilder sb = new StringBuilder();
        for (char c : x.toCharArray()) {
            sb.append(c >= '\u0660' && c <= '\u0669' ? (char) ('0' + (c - '\u0660')) : c);
        }
        return sb.toString();
    }

    /** "max", "news", "xtra", "premium" or "": a Xtra 1 is not the same channel as beIN 1. */
    private static String specialKey(String n) {
        String l = latinize(n).toLowerCase(Locale.ROOT);
        for (String k : new String[]{"xtra", "max", "news", "premium"}) {
            if (l.contains(k)) return k;
        }
        return "";
    }

    /** Channel number in a name: "Bein Sport 03 HD" -> 3, "beIN SPORTS 3 (8K)" -> 3, "BeIN Sports 4K" -> 0. */
    static int number(String name) {
        if (name == null) return 0;
        String n = latinize(name).replaceAll("(?i)\\b[48]\\s*k\\b", " ");
        java.util.regex.Matcher mt = java.util.regex.Pattern.compile("(\\d{1,2})").matcher(n);
        if (mt.find()) {
            try {
                return Integer.parseInt(mt.group(1));
            } catch (NumberFormatException ignored) {
                return 0;
            }
        }
        return 0;
    }

    /** Channel name without the provider's prefixes like "AR:" or "|AR|". */
    private static String clean(String n) {
        if (n == null) return "";
        return n.replaceAll("^[\\s|\\[\\(]*[A-Za-z]{2,3}[\\s|\\]\\):\\-]+", "").trim();
    }

    static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        n = n.toLowerCase(Locale.ROOT)
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ة', 'ه').replace('ى', 'ي');
        return n.replaceAll("[^a-z0-9\\u0600-\\u06FF]", "");
    }
}
