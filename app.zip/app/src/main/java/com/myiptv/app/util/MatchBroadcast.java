package com.myiptv.app.util;

import android.content.Context;

import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Finds the channel of the user's own subscription that carries a match:
 * 1) the provider's program guide (EPG) of the beIN channels names both teams around the kick-off;
 * 2) otherwise the broadcaster ESPN lists (e.g. "beIN SPORTS 1"), when it names a channel number
 *    that exists in the subscription.
 * No result means "broadcast details not available".
 */
public final class MatchBroadcast {
    public static final class Result {
        /** Channel name shown in the details ("beIN SPORTS 1"). */
        public String label = "";
        /** The channel to open; null when only a name is known. */
        public Item channel;
        /** The list the channel was found in (for next / previous channel on the remote). */
        public List<Item> queue = new ArrayList<>();
        /** 1-based position of the channel in {@link #queue}. */
        public int number = 1;

        public boolean playable() {
            return channel != null && channel.streamUrl != null && !channel.streamUrl.isEmpty();
        }
    }

    /** Wide on purpose: many providers publish guide times shifted by their server's time zone. */
    private static final long WINDOW_MS = 14L * 3600L * 1000L;

    private MatchBroadcast() {}

    /** Blocking (network + database): call from a background thread. Never returns null. */
    public static Result resolve(Context ctx, SportsRepository.Match m) {
        Result r = new Result();
        try {
            Context app = ctx.getApplicationContext();
            long pid = Prefs.getActive(app);
            Playlist p = pid < 0 ? null : AppDatabase.get(app).dao().getPlaylist(pid);
            List<Item> channels = new ArrayList<>();
            if (p != null) {
                channels.addAll(AppDatabase.get(app).dao().beinChannels(p.id, 80));
                java.util.Set<Long> have = new java.util.HashSet<>();
                for (Item it : channels) have.add(it.id);
                for (Item it : AppDatabase.get(app).dao().sportsChannels(p.id, 200)) {
                    if (have.add(it.id)) channels.add(it);
                }
            }
            r.queue = channels;

            // 0) some providers publish a channel named after the match ("FRANCE vs ITALY")
            if (p != null) {
                Item ev = findEventChannel(app, p.id, m);
                if (ev != null) {
                    int idx = indexOfUrl(channels, ev.streamUrl);
                    if (idx < 0) {
                        channels.add(0, ev);
                        idx = 0;
                    }
                    r.channel = ev;
                    r.number = idx + 1;
                    r.label = clean(ev.name);
                    return r;
                }
            }

            // 1) the provider's program guide
            if (p != null && !channels.isEmpty()) {
                try {
                    List<EpgRepository.Match> epg = EpgRepository.loadRaw(p, channels);
                    EpgRepository.Match best = null;
                    int bestIdx = -1;
                    long bestGap = Long.MAX_VALUE;
                    for (EpgRepository.Match e : epg) {
                        if (!sameTime(e, m) || !namesBoth(e.title + " " + e.desc, m)) continue;
                        int idx = indexOfUrl(channels, e.streamUrl);
                        if (idx < 0) continue;
                        long gap = Math.abs(e.start * 1000L - m.start);
                        if (gap < bestGap) {
                            best = e;
                            bestIdx = idx;
                            bestGap = gap;
                        }
                    }
                    if (best != null) {
                        r.channel = channels.get(bestIdx);
                        r.number = bestIdx + 1;
                        r.label = clean(r.channel.name);
                        return r;
                    }
                } catch (Exception ignored) {
                    // guide not available: try the next source
                }
            }

            // 2) Kooora's "watch live on" list (Arabic market: beIN Sports Mena N)
            if (!channels.isEmpty()) {
                int num = koooraChannel(m);
                if (num > 0) {
                    for (int i = 0; i < channels.size(); i++) {
                        Item it = channels.get(i);
                        if (digit(it.name) == num && "bein".equals(Ui.brand(it.name))) {
                            r.channel = it;
                            r.number = i + 1;
                            r.label = clean(it.name);
                            return r;
                        }
                    }
                    r.label = "beIN SPORTS " + num; // named, but not in this subscription
                }
            }

            // 3) ESPN's broadcaster name, matched by brand and channel number
            for (String b : m.broadcasts) {
                if (!"bein".equals(Ui.brand(b))) continue;
                int num = digit(b);
                if (num <= 0) continue;
                for (int i = 0; i < channels.size(); i++) {
                    Item it = channels.get(i);
                    if (digit(it.name) == num && "bein".equals(Ui.brand(it.name))) {
                        r.channel = it;
                        r.number = i + 1;
                        r.label = clean(it.name);
                        return r;
                    }
                }
                if (r.label.isEmpty()) r.label = b; // named, but not in this subscription
            }
        } catch (Exception ignored) {
            // fall through: nothing found
        }
        return r;
    }

    private static final String KOOORA =
            "https://www.kooora.com/%D9%83%D8%B1%D8%A9-%D8%A7%D9%84%D9%82%D8%AF%D9%85/"
                    + "%D9%85%D8%A8%D8%A7%D8%B1%D9%8A%D8%A7%D8%AA-%D8%A7%D9%84%D9%8A%D9%88%D9%85";
    private static final java.util.regex.Pattern MATCH_HREF = java.util.regex.Pattern
            .compile("(?i)(?:%D9%85%D8%A8%D8%A7%D8%B1%D8%A7%D8%A9|\u0645\u0628\u0627\u0631\u0627\u0629)/");
    private static final java.util.regex.Pattern MENA = java.util.regex.Pattern
            .compile("(?i)bein\\s*sports?\\s*mena\\s*(\\d)");
    private static final java.util.regex.Pattern PLAIN = java.util.regex.Pattern
            .compile("(?i)bein\\s*sports?\\s*(\\d)(?![\\d]|\\s*\\()");
    private static String koooraHtml;
    private static long koooraTime;

    /** beIN channel number Kooora lists for this match, or 0. Blocking (network). */
    private static int koooraChannel(SportsRepository.Match m) {
        try {
            String html;
            synchronized (MatchBroadcast.class) {
                if (koooraHtml != null && System.currentTimeMillis() - koooraTime < 5L * 60L * 1000L) {
                    html = koooraHtml;
                } else {
                    html = Http.readString(KOOORA);
                    koooraHtml = html;
                    koooraTime = System.currentTimeMillis();
                }
            }
            // one block per match: from its link up to the next match link
            java.util.regex.Matcher hm = MATCH_HREF.matcher(html);
            List<Integer> starts = new ArrayList<>();
            while (hm.find()) starts.add(hm.start());
            for (int i = 0; i < starts.size(); i++) {
                int end = i + 1 < starts.size() ? starts.get(i + 1) : Math.min(html.length(), starts.get(i) + 6000);
                String block = html.substring(starts.get(i), end);
                String t = norm(block);
                if (!hasTeam(t, m.homeNames, m.home) || !hasTeam(t, m.awayNames, m.away)) continue;
                java.util.regex.Matcher a = MENA.matcher(block);
                if (a.find()) return a.group(1).charAt(0) - '0';
                java.util.regex.Matcher b = PLAIN.matcher(block);
                if (b.find()) return b.group(1).charAt(0) - '0';
                return 0;
            }
        } catch (Exception ignored) {
            // site not reachable: try the next source
        }
        return 0;
    }

    private static boolean sameTime(EpgRepository.Match e, SportsRepository.Match m) {
        long es = e.start * 1000L, ee = e.stop * 1000L;
        long now = System.currentTimeMillis();
        if ("in".equals(m.state) && es <= now && ee >= now) return true;
        return Math.abs(es - m.start) <= WINDOW_MS;
    }

    private static boolean namesBoth(String title, SportsRepository.Match m) {
        String t = norm(title);
        return hasTeam(t, m.homeNames, m.home) && hasTeam(t, m.awayNames, m.away);
    }

    private static boolean hasTeam(String t, List<String> names, String arabic) {
        List<String> all = new ArrayList<>(names);
        all.add(arabic);
        for (String n : all) {
            String k = norm(n);
            if (k.length() >= 3 && t.contains(k)) return true;
            // the "ال" prefix is often dropped in guides and channel names (الدنمارك / دنمارك)
            if (k.startsWith("ال") && k.length() >= 5 && t.contains(k.substring(2))) return true;
        }
        return false;
    }

    /** A live channel whose own name carries both teams (event channels), or null. Blocking (database). */
    private static Item findEventChannel(Context app, long playlistId, SportsRepository.Match m) {
        try {
            List<String> queries = new ArrayList<>();
            for (String n : m.homeNames) queries.add(n);
            for (String n : m.awayNames) queries.add(n);
            queries.add(m.home);
            queries.add(m.away);
            java.util.Set<Long> seen = new java.util.HashSet<>();
            for (String q : queries) {
                if (q == null || q.trim().length() < 3) continue;
                for (Item it : AppDatabase.get(app).dao().searchItems(playlistId, "live", q.trim(), 40)) {
                    if (!seen.add(it.id)) continue;
                    String t = norm(it.name);
                    if (it.streamUrl == null || it.streamUrl.isEmpty()) continue;
                    if (hasTeam(t, m.homeNames, m.home) && hasTeam(t, m.awayNames, m.away)) return it;
                }
            }
        } catch (Exception ignored) {
            // no event channel
        }
        return null;
    }

    private static int indexOfUrl(List<Item> list, String url) {
        if (url == null) return -1;
        for (int i = 0; i < list.size(); i++) {
            if (url.equals(list.get(i).streamUrl)) return i;
        }
        return -1;
    }

    private static int digit(String s) {
        if (s == null) return 0;
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c >= '1' && c <= '9') return c - '0';
        }
        return 0;
    }

    /** Channel name without the provider's prefixes like "AR:" or "|AR|". */
    private static String clean(String n) {
        if (n == null) return "";
        return n.replaceAll("^[\\s|\\[\\(]*[A-Za-z]{2,3}[\\s|\\]\\):\\-]+", "").trim();
    }

    private static String norm(String s) {
        if (s == null) return "";
        String n = Normalizer.normalize(s, Normalizer.Form.NFD).replaceAll("\\p{M}", "");
        n = n.toLowerCase(Locale.ROOT)
                .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')
                .replace('ة', 'ه').replace('ى', 'ي');
        return n.replaceAll("[^a-z0-9\\u0600-\\u06FF]", "");
    }
}
