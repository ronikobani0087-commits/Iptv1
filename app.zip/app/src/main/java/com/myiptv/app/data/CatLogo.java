package com.myiptv.app.data;

/** Query result: the logo shown next to a live package in the channel list. */
public class CatLogo {
    public String catId;
    public String icon;
}
