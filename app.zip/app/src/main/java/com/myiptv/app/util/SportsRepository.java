package com.myiptv.app.util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Today's football matches with team logos, scores and the live minute.
 * Data comes from ESPN's public scoreboard JSON (no key). Any failure just yields an empty list,
 * and the home screen falls back to the provider's own program guide.
 */
public final class SportsRepository {
    public static final class Match {
        public String id = "";
        public String league = "";
        public String home = "", away = "";
        public String homeLogo = "", awayLogo = "";
        public List<String> homeNames = new ArrayList<>();
        public List<String> awayNames = new ArrayList<>();
        public int homeScore, awayScore;
        /** "pre", "in" or "post". */
        public String state = "pre";
        public String clock = "";
        public long start;
        /** Stadium name (empty when ESPN has none). */
        public String venue = "";
        /** Broadcaster names as ESPN lists them (may be empty or not Arabic-market). */
        public List<String> broadcasts = new ArrayList<>();
        /** Arabic round name ("الجولة 5"); empty when ESPN gives none. */
        public String round = "";
        /** Result of the first leg ("home (1 - 1) away"); empty when this is not a second leg. */
        public String firstLeg = "";
        /** Referee name, filled by {@link #loadExtras}. */
        public String referee = "";
        public boolean extrasLoaded;
    }

    private static final String[] HOSTS = {
            "https://site.api.espn.com/apis/site/v2/sports/soccer/",
            "https://site.web.api.espn.com/apis/site/v2/sports/soccer/"};
    /** Last network / parsing problem, shown on the home screen when no match could be loaded. */
    public static volatile String lastError = "";
    private static final long CACHE_MS = 5 * 60 * 1000L;

    /** ESPN league slug -> Arabic name. */
    private static final Map<String, String> LEAGUES = new LinkedHashMap<>();

    static {
        LEAGUES.put("uefa.champions", "دوري أبطال أوروبا");
        LEAGUES.put("uefa.europa", "كأس الاتحاد الأوروبي");
        LEAGUES.put("esp.1", "الدوري الإسباني");
        LEAGUES.put("eng.1", "الدوري الإنجليزي");
        LEAGUES.put("tur.1", "الدوري التركي");
        // national teams and major international competitions
        LEAGUES.put("fifa.world", "كأس العالم");
        LEAGUES.put("fifa.worldq.uefa", "تصفيات كأس العالم - أوروبا");
        LEAGUES.put("fifa.worldq.caf", "تصفيات كأس العالم - أفريقيا");
        LEAGUES.put("fifa.worldq.afc", "تصفيات كأس العالم - آسيا");
        LEAGUES.put("fifa.worldq.conmebol", "تصفيات كأس العالم - أمريكا الجنوبية");
        LEAGUES.put("fifa.worldq.concacaf", "تصفيات كأس العالم - كونكاكاف");
        LEAGUES.put("fifa.friendly", "مباراة دولية ودية");
        LEAGUES.put("uefa.nations", "دوري الأمم الأوروبية");
        LEAGUES.put("uefa.euro", "كأس أمم أوروبا");
        LEAGUES.put("uefa.euroq", "تصفيات أمم أوروبا");
        LEAGUES.put("conmebol.america", "كوبا أمريكا");
        LEAGUES.put("caf.nations", "كأس الأمم الأفريقية");
        LEAGUES.put("afc.asian.cup", "كأس آسيا");
        LEAGUES.put("concacaf.gold", "الكأس الذهبية");
        LEAGUES.put("fifa.cwc", "كأس العالم للأندية");
    }

    private static List<Match> cache;
    private static long cacheTime;
    /** Every match of the last load, so the details screen can find it by id. */
    private static final Map<String, Match> BY_ID = new java.util.concurrent.ConcurrentHashMap<>();

    /** The match with this id from the last load, or null. */
    public static Match find(String id) {
        return id == null ? null : BY_ID.get(id);
    }

    private SportsRepository() {}

    public static List<Match> today() {
        synchronized (SportsRepository.class) {
            if (cache != null && System.currentTimeMillis() - cacheTime < CACHE_MS) return cache;
        }
        lastError = "";
        final String range = dateRange();
        List<Callable<List<Match>>> tasks = new ArrayList<>();
        for (final Map.Entry<String, String> e : LEAGUES.entrySet()) {
            tasks.add(new Callable<List<Match>>() {
                @Override
                public List<Match> call() {
                    return fetch(e.getKey(), e.getValue(), range);
                }
            });
        }
        List<Match> all = new ArrayList<>();
        ExecutorService ex = Executors.newFixedThreadPool(12);
        try {
            List<Future<List<Match>>> fs = ex.invokeAll(tasks, 20, TimeUnit.SECONDS);
            for (Future<List<Match>> f : fs) {
                try {
                    all.addAll(f.get());
                } catch (Exception ignored) {
                    // one league failing must not hide the others
                }
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } finally {
            ex.shutdownNow();
        }

        Calendar todayStart = Calendar.getInstance();
        todayStart.set(Calendar.HOUR_OF_DAY, 0);
        todayStart.set(Calendar.MINUTE, 0);
        todayStart.set(Calendar.SECOND, 0);
        todayStart.set(Calendar.MILLISECOND, 0);
        long from = todayStart.getTimeInMillis();
        long to = from + 24L * 3600L * 1000L;
        long upcomingTo = from + 4L * 24L * 3600L * 1000L;
        boolean anyToday = false;
        for (Match m : all) {
            if ("in".equals(m.state) || (m.start >= from && m.start < to)) {
                anyToday = true;
                break;
            }
        }
        if (!anyToday) to = upcomingTo; // nothing today: show the coming days instead

        Set<String> seen = new HashSet<>();
        List<Match> out = new ArrayList<>();
        for (Match m : all) {
            boolean live = "in".equals(m.state);
            boolean today = m.start >= from && m.start < to;
            if (!live && !today) continue;
            if (!anyToday && "post".equals(m.state)) continue;
            if (!seen.add(m.id + "|" + m.home)) continue;
            out.add(m);
        }
        Collections.sort(out, new Comparator<Match>() {
            @Override
            public int compare(Match a, Match b) {
                int ra = rank(a), rb = rank(b);
                if (ra != rb) return Integer.compare(ra, rb);
                return Long.compare(a.start, b.start);
            }
        });
        if (out.size() > 36) out = new ArrayList<>(out.subList(0, 36));

        for (Match m : out) BY_ID.put(m.id, m);
        if (!out.isEmpty()) { // never keep an empty / failed result: retry on the next visit
            synchronized (SportsRepository.class) {
                cache = out;
                cacheTime = System.currentTimeMillis();
            }
        }
        return out;
    }

    private static int rank(Match m) {
        if ("in".equals(m.state)) return 0;
        if ("pre".equals(m.state)) return 1;
        return 2;
    }

    private static String dateRange() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        Calendar a = Calendar.getInstance();
        a.add(Calendar.DAY_OF_YEAR, -1);
        Calendar b = Calendar.getInstance();
        b.add(Calendar.DAY_OF_YEAR, 4);
        return f.format(a.getTime()) + "-" + f.format(b.getTime());
    }

    private static List<Match> fetch(String slug, String leagueAr, String range) {
        List<Match> list = new ArrayList<>();
        // try the date range first, then just today; and a second ESPN host if the first one fails
        String[] dates = {range, new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date())};
        JSONArray events = null;
        outer:
        for (String d : dates) {
            for (String base : HOSTS) {
                try {
                    String json = Http.readString(base + slug + "/scoreboard?limit=100&dates=" + d);
                    JSONArray ev = new JSONObject(json).optJSONArray("events");
                    if (ev != null && ev.length() > 0) {
                        events = ev;
                        break outer;
                    }
                } catch (Exception e) {
                    String msg = String.valueOf(e.getMessage());
                    // a competition ESPN does not know (HTTP 4xx) is simply skipped, it is not an outage
                    if (!msg.contains("(400)") && !msg.contains("(404)")) lastError = slug + ": " + msg;
                }
            }
        }
        if (events == null) return list;
        try {
            for (int i = 0; i < events.length(); i++) {
                JSONObject ev = events.optJSONObject(i);
                if (ev == null) continue;
                JSONArray comps = ev.optJSONArray("competitions");
                if (comps == null || comps.length() == 0) continue;
                JSONArray cs = comps.optJSONObject(0).optJSONArray("competitors");
                if (cs == null || cs.length() < 2) continue;

                Match m = new Match();
                m.id = slug + ":" + ev.optString("id", String.valueOf(i));
                m.league = leagueAr;
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject c = cs.optJSONObject(k);
                    if (c == null) continue;
                    JSONObject t = c.optJSONObject("team");
                    if (t == null) continue;
                    boolean isHome = "home".equals(c.optString("homeAway"));
                    String name = t.optString("shortDisplayName", t.optString("displayName", ""));
                    String logo = t.optString("logo", "");
                    int score = toInt(c.optString("score", "0"));
                    List<String> names = new ArrayList<>();
                    addName(names, t.optString("displayName"));
                    addName(names, t.optString("shortDisplayName"));
                    addName(names, t.optString("name"));
                    if (isHome) {
                        m.home = name;
                        m.homeLogo = logo;
                        m.homeScore = score;
                        m.homeNames = names;
                    } else {
                        m.away = name;
                        m.awayLogo = logo;
                        m.awayScore = score;
                        m.awayNames = names;
                    }
                }
                if (m.home.isEmpty() || m.away.isEmpty()) continue;
                m.home = TeamNames.ar(m.homeNames, m.home);
                m.away = TeamNames.ar(m.awayNames, m.away);

                JSONObject st = ev.optJSONObject("status");
                if (st != null) {
                    m.clock = st.optString("displayClock", "");
                    JSONObject type = st.optJSONObject("type");
                    if (type != null) m.state = type.optString("state", "pre");
                }
                JSONObject comp = comps.optJSONObject(0);
                JSONObject venue = comp.optJSONObject("venue");
                if (venue != null) m.venue = venue.optString("fullName", "").trim();
                JSONArray bc = comp.optJSONArray("broadcasts");
                if (bc != null) {
                    for (int b = 0; b < bc.length(); b++) {
                        JSONObject bo = bc.optJSONObject(b);
                        JSONArray names = bo == null ? null : bo.optJSONArray("names");
                        if (names == null) continue;
                        for (int k = 0; k < names.length(); k++) {
                            String bn = names.optString(k, "").trim();
                            if (!bn.isEmpty() && !m.broadcasts.contains(bn)) m.broadcasts.add(bn);
                        }
                    }
                }
                m.round = roundText(comp, ev);
                m.firstLeg = firstLegText(comp, m);
                m.start = parseDate(ev.optString("date", ""));
                if (m.start <= 0) continue;
                list.add(m);
            }
        } catch (Exception ignored) {
            // league not available right now
        }
        return list;
    }

    /** "Matchday 5" / "Round of 16" ... -> Arabic; empty when unknown. */
    private static String roundText(JSONObject comp, JSONObject ev) {
        try {
            String h = "";
            JSONArray notes = comp.optJSONArray("notes");
            if (notes == null) notes = ev.optJSONArray("notes");
            if (notes != null && notes.length() > 0 && notes.optJSONObject(0) != null) {
                h = notes.optJSONObject(0).optString("headline", "");
            }
            if (h.isEmpty()) {
                JSONObject t = comp.optJSONObject("type");
                if (t != null) h = t.optString("text", "");
            }
            return arabicRound(h);
        } catch (Exception e) {
            return "";
        }
    }

    static String arabicRound(String h) {
        if (h == null) return "";
        String t = h.trim();
        if (t.isEmpty()) return "";
        String l = t.toLowerCase(Locale.ROOT);
        java.util.regex.Matcher n = java.util.regex.Pattern
                .compile("(?:matchday|match day|round|week|jornada|spieltag)\\s*(\\d+)").matcher(l);
        if (n.find()) return "الجولة " + n.group(1);
        if (l.contains("round of 16")) return "دور الـ16";
        if (l.contains("round of 32")) return "دور الـ32";
        if (l.contains("quarter")) return "ربع النهائي";
        if (l.contains("semi")) return "نصف النهائي";
        if (l.contains("third") || l.contains("3rd")) return "تحديد المركز الثالث";
        if (l.contains("final")) return "النهائي";
        if (l.contains("play-off") || l.contains("playoff")) return "الملحق";
        if (l.contains("group")) return "دور المجموعات";
        if (l.contains("league phase")) return "مرحلة الدوري";
        if (l.contains("knockout")) return "الأدوار الإقصائية";
        return t.matches(".*[A-Za-z].*") ? "" : t; // keep it only when it is already Arabic
    }

    /** Second leg: the aggregate of the first leg as ESPN lists it before kick-off. */
    private static String firstLegText(JSONObject comp, Match m) {
        try {
            JSONObject leg = comp.optJSONObject("leg");
            if (leg == null || leg.optInt("value", 0) != 2) return "";
            JSONArray cs = comp.optJSONArray("competitors");
            if (cs == null) return "";
            String h = "", a = "";
            for (int i = 0; i < cs.length(); i++) {
                JSONObject c = cs.optJSONObject(i);
                if (c == null || !c.has("aggregateScore")) return "";
                String v = String.valueOf((int) c.optDouble("aggregateScore", 0));
                if ("home".equals(c.optString("homeAway"))) h = v; else a = v;
            }
            if (h.isEmpty() || a.isEmpty() || !"pre".equals(m.state)) return "";
            return m.home + " (" + h + " - " + a + ") " + m.away;
        } catch (Exception e) {
            return "";
        }
    }

    /**
     * Details ESPN only gives per match (referee, and the round when the scoreboard had none).
     * Blocking: call from a background thread. Failure just leaves the fields empty.
     */
    public static void loadExtras(Match m) {
        if (m == null || m.extrasLoaded) return;
        int c = m.id.indexOf(':');
        if (c <= 0) return;
        String slug = m.id.substring(0, c), id = m.id.substring(c + 1);
        for (String base : HOSTS) {
            try {
                JSONObject o = new JSONObject(Http.readString(base + slug + "/summary?event=" + id));
                JSONObject gi = o.optJSONObject("gameInfo");
                JSONArray off = gi == null ? null : gi.optJSONArray("officials");
                if (off != null) {
                    String first = "";
                    for (int i = 0; i < off.length(); i++) {
                        JSONObject f = off.optJSONObject(i);
                        if (f == null) continue;
                        String name = f.optString("fullName", f.optString("displayName", "")).trim();
                        if (name.isEmpty()) continue;
                        if (first.isEmpty()) first = name;
                        JSONObject pos = f.optJSONObject("position");
                        String pn = pos == null ? "" : pos.optString("displayName", "");
                        if (pn.toLowerCase(Locale.ROOT).contains("referee")
                                && !pn.toLowerCase(Locale.ROOT).contains("assistant")
                                && !pn.toLowerCase(Locale.ROOT).contains("video")) {
                            first = name;
                            break;
                        }
                    }
                    m.referee = first;
                }
                if (m.round.isEmpty()) {
                    JSONObject hd = o.optJSONObject("header");
                    JSONArray hc = hd == null ? null : hd.optJSONArray("competitions");
                    JSONObject c0 = hc == null ? null : hc.optJSONObject(0);
                    if (c0 != null) m.round = roundText(c0, new JSONObject());
                }
                m.extrasLoaded = true;
                return;
            } catch (Exception ignored) {
                // try the other host
            }
        }
    }

    private static void addName(List<String> names, String n) {
        if (n == null) return;
        n = n.trim();
        if (n.length() >= 3 && !names.contains(n)) names.add(n);
    }

    private static long parseDate(String s) {
        String[] patterns = {"yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String p : patterns) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(p, Locale.US);
                f.setTimeZone(TimeZone.getTimeZone("UTC"));
                return f.parse(s).getTime();
            } catch (Exception ignored) {
                // try next format
            }
        }
        return 0L;
    }

    private static int toInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }
}
