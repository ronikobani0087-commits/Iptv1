package com.myiptv.app.util;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.TimeZone;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;

/**
 * Today's football matches with team logos, scores and the live minute.
 * Data comes from ESPN's public scoreboard JSON (no key). Any failure just yields an empty list,
 * and the home screen falls back to the provider's own program guide.
 */
public final class SportsRepository {
    public static final class Match {
        public String id = "";
        public String league = "";
        public String home = "", away = "";
        public String homeLogo = "", awayLogo = "";
        public List<String> homeNames = new ArrayList<>();
        public List<String> awayNames = new ArrayList<>();
        public int homeScore, awayScore;
        /** "pre", "in" or "post". */
        public String state = "pre";
        public String clock = "";
        public long start;
    }

    private static final String BASE = "https://site.api.espn.com/apis/site/v2/sports/soccer/";
    private static final long CACHE_MS = 60 * 1000L;

    /** ESPN league slug -> Arabic name. */
    private static final Map<String, String> LEAGUES = new LinkedHashMap<>();

    static {
        LEAGUES.put("ksa.1", "دوري روشن السعودي");
        LEAGUES.put("uefa.champions", "دوري أبطال أوروبا");
        LEAGUES.put("uefa.europa", "الدوري الأوروبي");
        LEAGUES.put("uefa.europa.conf", "دوري المؤتمر الأوروبي");
        LEAGUES.put("esp.1", "الدوري الإسباني");
        LEAGUES.put("esp.copa_del_rey", "كأس ملك إسبانيا");
        LEAGUES.put("eng.1", "الدوري الإنجليزي");
        LEAGUES.put("eng.fa", "كأس الاتحاد الإنجليزي");
        LEAGUES.put("eng.league_cup", "كأس الرابطة الإنجليزية");
        LEAGUES.put("ita.1", "الدوري الإيطالي");
        LEAGUES.put("ita.coppa_italia", "كأس إيطاليا");
        LEAGUES.put("ger.1", "الدوري الألماني");
        LEAGUES.put("ger.dfb_pokal", "كأس ألمانيا");
        LEAGUES.put("fra.1", "الدوري الفرنسي");
        LEAGUES.put("fra.coupe_de_france", "كأس فرنسا");
        LEAGUES.put("ned.1", "الدوري الهولندي");
        LEAGUES.put("por.1", "الدوري البرتغالي");
        LEAGUES.put("tur.1", "الدوري التركي");
        LEAGUES.put("egy.1", "الدوري المصري");
        LEAGUES.put("afc.champions", "دوري أبطال آسيا");
        LEAGUES.put("caf.champions", "دوري أبطال أفريقيا");
        LEAGUES.put("fifa.world", "كأس العالم");
        LEAGUES.put("uefa.nations", "دوري الأمم الأوروبية");
        LEAGUES.put("conmebol.libertadores", "كوبا ليبرتادوريس");
        LEAGUES.put("usa.1", "الدوري الأمريكي");
    }

    private static List<Match> cache;
    private static long cacheTime;

    private SportsRepository() {}

    public static List<Match> today() {
        synchronized (SportsRepository.class) {
            if (cache != null && System.currentTimeMillis() - cacheTime < CACHE_MS) return cache;
        }
        final String range = dateRange();
        List<Callable<List<Match>>> tasks = new ArrayList<>();
        for (final Map.Entry<String, String> e : LEAGUES.entrySet()) {
            tasks.add(new Callable<List<Match>>() {
                @Override
                public List<Match> call() {
                    return fetch(e.getKey(), e.getValue(), range);
                }
            });
        }
        List<Match> all = new ArrayList<>();
        ExecutorService ex = Executors.newFixedThreadPool(8);
        try {
            List<Future<List<Match>>> fs = ex.invokeAll(tasks, 20, TimeUnit.SECONDS);
            for (Future<List<Match>> f : fs) {
                try {
                    all.addAll(f.get());
                } catch (Exception ignored) {
                    // one league failing must not hide the others
                }
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } finally {
            ex.shutdownNow();
        }

        Calendar todayStart = Calendar.getInstance();
        todayStart.set(Calendar.HOUR_OF_DAY, 0);
        todayStart.set(Calendar.MINUTE, 0);
        todayStart.set(Calendar.SECOND, 0);
        todayStart.set(Calendar.MILLISECOND, 0);
        long from = todayStart.getTimeInMillis();
        long to = from + 24L * 3600L * 1000L;

        Set<String> seen = new HashSet<>();
        List<Match> out = new ArrayList<>();
        for (Match m : all) {
            boolean live = "in".equals(m.state);
            boolean today = m.start >= from && m.start < to;
            if (!live && !today) continue;
            if (!seen.add(m.id + "|" + m.home)) continue;
            out.add(m);
        }
        Collections.sort(out, new Comparator<Match>() {
            @Override
            public int compare(Match a, Match b) {
                int ra = rank(a), rb = rank(b);
                if (ra != rb) return Integer.compare(ra, rb);
                return Long.compare(a.start, b.start);
            }
        });
        if (out.size() > 30) out = new ArrayList<>(out.subList(0, 30));

        synchronized (SportsRepository.class) {
            cache = out;
            cacheTime = System.currentTimeMillis();
        }
        return out;
    }

    private static int rank(Match m) {
        if ("in".equals(m.state)) return 0;
        if ("pre".equals(m.state)) return 1;
        return 2;
    }

    private static String dateRange() {
        SimpleDateFormat f = new SimpleDateFormat("yyyyMMdd", Locale.US);
        Calendar a = Calendar.getInstance();
        a.add(Calendar.DAY_OF_YEAR, -1);
        Calendar b = Calendar.getInstance();
        b.add(Calendar.DAY_OF_YEAR, 1);
        return f.format(a.getTime()) + "-" + f.format(b.getTime());
    }

    private static List<Match> fetch(String slug, String leagueAr, String range) {
        List<Match> list = new ArrayList<>();
        try {
            String json = Http.readString(BASE + slug + "/scoreboard?limit=100&dates=" + range);
            JSONArray events = new JSONObject(json).optJSONArray("events");
            if (events == null) return list;
            for (int i = 0; i < events.length(); i++) {
                JSONObject ev = events.optJSONObject(i);
                if (ev == null) continue;
                JSONArray comps = ev.optJSONArray("competitions");
                if (comps == null || comps.length() == 0) continue;
                JSONArray cs = comps.optJSONObject(0).optJSONArray("competitors");
                if (cs == null || cs.length() < 2) continue;

                Match m = new Match();
                m.id = slug + ":" + ev.optString("id", String.valueOf(i));
                m.league = leagueAr;
                for (int k = 0; k < cs.length(); k++) {
                    JSONObject c = cs.optJSONObject(k);
                    if (c == null) continue;
                    JSONObject t = c.optJSONObject("team");
                    if (t == null) continue;
                    boolean isHome = "home".equals(c.optString("homeAway"));
                    String name = t.optString("shortDisplayName", t.optString("displayName", ""));
                    String logo = t.optString("logo", "");
                    int score = toInt(c.optString("score", "0"));
                    List<String> names = new ArrayList<>();
                    addName(names, t.optString("displayName"));
                    addName(names, t.optString("shortDisplayName"));
                    addName(names, t.optString("name"));
                    if (isHome) {
                        m.home = name;
                        m.homeLogo = logo;
                        m.homeScore = score;
                        m.homeNames = names;
                    } else {
                        m.away = name;
                        m.awayLogo = logo;
                        m.awayScore = score;
                        m.awayNames = names;
                    }
                }
                if (m.home.isEmpty() || m.away.isEmpty()) continue;

                JSONObject st = ev.optJSONObject("status");
                if (st != null) {
                    m.clock = st.optString("displayClock", "");
                    JSONObject type = st.optJSONObject("type");
                    if (type != null) m.state = type.optString("state", "pre");
                }
                m.start = parseDate(ev.optString("date", ""));
                if (m.start <= 0) continue;
                list.add(m);
            }
        } catch (Exception ignored) {
            // league not available right now
        }
        return list;
    }

    private static void addName(List<String> names, String n) {
        if (n == null) return;
        n = n.trim();
        if (n.length() >= 3 && !names.contains(n)) names.add(n);
    }

    private static long parseDate(String s) {
        String[] patterns = {"yyyy-MM-dd'T'HH:mm'Z'", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
        for (String p : patterns) {
            try {
                SimpleDateFormat f = new SimpleDateFormat(p, Locale.US);
                f.setTimeZone(TimeZone.getTimeZone("UTC"));
                return f.parse(s).getTime();
            } catch (Exception ignored) {
                // try next format
            }
        }
        return 0L;
    }

    private static int toInt(String s) {
        try {
            return Integer.parseInt(s.trim());
        } catch (Exception e) {
            return 0;
        }
    }
}
