package com.myiptv.app.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SeriesRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.HomeSections;
import com.myiptv.app.util.LiveQueue;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.SportsRepository;
import com.myiptv.app.util.Ui;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class HomeFragment extends Fragment {
    private TextView status;
    private TextView action;
    private LinearLayout footer;
    /** Card sizes (dp), worked out from the screen and from how many rows are switched on. */
    private int cardW = 110;      // poster width
    private int posterH = 210;     // poster card height (picture + info strip)
    private int channelW = 80;     // small channel tile (8 per row)
    private int channelH = 116;
    private int matchW = 220;
    private int matchH = 110;
    private int stripH = 40;

    private CardStrip stripMatches;
    private CardStrip stripFav;
    private CardStrip stripFavSeries;
    private CardStrip stripRecent;
    private CardStrip stripArabic;
    /** Sections the user added from the settings (a provider category each). */
    private LinearLayout customHost;
    private long activeId = -1;
    private int loadToken;

    /** Favorite series (with their watch history when there is one), used for "new episodes". */
    private List<History> followList = new ArrayList<>();
    /** The favorite series, in the same order as {@link #followList}. */
    private List<Favorite> favSeriesList = new ArrayList<>();
    /** Recently added series coming from the provider (the cards after the followed episodes). */
    private List<Item> recentItems = new ArrayList<>();

    /** Latest episode the provider has for a followed series (cached for 6 hours). */
    private static final class Latest {
        long time;
        String label = "";
        String url = "";
        String title = "";
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setSmoothScrollingEnabled(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(Ui.dp(c, 14), Ui.dp(c, 10), Ui.dp(c, 14), Ui.dp(c, 14));
        root.setClipChildren(false);
        scroll.setClipChildren(false);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.muted));
        status.setTextSize(17);
        status.setLineSpacing(0, 1.3f);
        status.setVisibility(View.GONE);
        root.addView(status, lp(c, 0));

        stripMatches = new CardStrip(c, "مباريات اليوم",
                "جارٍ تحميل المباريات… إن لم تظهر فتأكد من اتصال الإنترنت أو لا توجد مباريات مهمة حالياً.");
        stripMatches.setLiveDot(true);
        stripMatches.setCountFormat("%d مباراة \u2022 اليوم");
        stripFav = new CardStrip(c, "قنوات مباشرة الآن",
                "اضغط على النجمة ☆ بجانب أي قناة لتظهر هنا.");
        stripFav.setLiveDot(true);
        stripFav.setCountFormat("%d قناة متاحة \u2022 مباشر");
        stripFavSeries = new CardStrip(c, "مسلسلات مفضلة",
                "أضف مسلسلاً إلى المفضلة ليظهر هنا مع آخر حلقة له.");
        stripRecent = new CardStrip(c, "مسلسلات عربية أضيفت حديثاً", null);
        // the two series rows use bigger cards than the channels row
        stripArabic = new CardStrip(c, "أحدث أفلام وبرامج عربية وعالمية", null);

        // "عرض الكل": jumps to the full list of that kind
        final Runnable allLive = () -> {
            if (isAdded()) PlayerActivity.startBrowse(requireActivity());
        };
        final Runnable allSeries = () -> {
            if (isAdded()) ((MainActivity) requireActivity()).select(R.id.nav_series);
        };
        final Runnable allMovies = () -> {
            if (isAdded()) ((MainActivity) requireActivity()).select(R.id.nav_movies);
        };
        stripMatches.setMore(allLive);
        stripFav.setMore(allLive);
        stripFavSeries.setMore(allSeries);
        stripRecent.setMore(allSeries);
        stripArabic.setMore(allMovies);

        // three horizontal sections on one page
        root.addView(stripMatches.view, lp(c, 0));
        root.addView(stripFav.view, lp(c, 10));
        root.addView(stripFavSeries.view, lp(c, 6));
        root.addView(stripRecent.view, lp(c, 6));
        root.addView(stripArabic.view, lp(c, 6));
        customHost = new LinearLayout(c);
        customHost.setOrientation(LinearLayout.VERTICAL);
        customHost.setClipChildren(false);
        root.addView(customHost, lp(c, 0));

        // only shown when no list has been added yet (lists are managed from "الإعدادات")
        footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.VERTICAL);
        action = Ui.button(c, "إضافة قائمة", true);
        footer.addView(action, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        footer.setVisibility(View.GONE);
        root.addView(footer, lp(c, 24));

        // transparent page: the app background image shows through; it reads right to left
        FrameLayout page = new FrameLayout(c);
        page.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        page.setClipChildren(false);
        page.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return page;
    }

    /**
     * Card size: three cards fill the row (like the reference). When the rows of the favorites,
     * the live matches and the added sections are switched off the home screen has more room, so
     * the cards grow; with all of them on they shrink so the screen stays tidy.
     */
    private void applySizes(long pid) {
        Context c = getContext();
        if (c == null) return;
        Context app = c.getApplicationContext();
        // posters: 6 per row while the matches / favorite channels / favorite series rows are on,
        // 8 per row when all of them are switched off
        boolean topOn = HomeSections.isOn(app, HomeSections.MATCHES)
                || HomeSections.isOn(app, HomeSections.FAV_LIVE)
                || HomeSections.isOn(app, HomeSections.FAV_SERIES);
        final int gap = 10;
        float density = c.getResources().getDisplayMetrics().density;
        float sidebar = c.getResources().getDimension(R.dimen.sidebar_width) / density;
        float screen = c.getResources().getConfiguration().screenWidthDp;
        float avail = (screen > 300 ? screen : 600f) - sidebar - 28f - 8f;
        int posters = topOn ? 6 : 8;
        cardW = Math.round(Math.max(64f, (avail - (posters - 1) * gap) / posters));
        stripH = 40;
        // the picture area is 2:3, so the whole poster is visible
        posterH = Math.round(cardW * 1.5f) + stripH + 6;
        // live channels: 8 small tiles per row (logo + name)
        channelW = Math.round(Math.max(64f, (avail - 7 * gap) / 8f));
        channelH = Math.round(channelW * 1.22f);   // no empty space under the name
        // matches: three wide tiles per row
        matchW = Math.round(Math.max(170f, (avail - 2 * gap) / 3f));
        matchH = Math.round(matchW * 0.5f);
        for (CardStrip st : new CardStrip[]{stripFavSeries, stripRecent, stripArabic}) {
            st.setPosterSize(cardW, posterH);
            st.setInfoStrip(stripH);
        }
        stripFav.setChannelSize(channelW, channelH);
        stripMatches.setChannelSize(matchW, matchH);
    }

    /** The year: the small line under a poster title. */
    private static String metaOf(Item it) {
        StringBuilder b = new StringBuilder();
        String y = nz(it.year);
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(19|20)\\d{2}").matcher(y);
        if (m.find()) b.append(m.group());
        return b.toString();   // only the year: no "مسلسل" / "فيلم" word under the poster
    }

    private static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(c, topDp);
        return p;
    }

    private boolean loaded;
    private long lastMatchesAt;

    @Override
    public void onDestroyView() {
        loaded = false;   // the view is gone: the next onResume must build it again
        super.onDestroyView();
    }

    /**
     * The home screen is built once and then left alone: it reloads only when something it shows
     * really changed (favorites, history, sync, settings, playlist). Coming back from the player no
     * longer rebuilds the movie / series rows. Live match scores refresh at most every 5 minutes.
     */
    @Override
    public void onResume() {
        super.onResume();
        boolean dirty = Prefs.consumeHomeDirty();
        long now = System.currentTimeMillis();
        if (!loaded || dirty) {
            loaded = true;
            lastMatchesAt = now;
            load();
        } else if (now - lastMatchesAt > 5L * 60L * 1000L) {
            lastMatchesAt = now;
            loadMatches();
        }
    }

    /** "مباريات اليوم": live scores, or kick-off time and date for matches still to come. */
    private void loadMatches() {
        final Context app = requireContext().getApplicationContext();
        // switched off in the settings: hide the row and skip the download
        final boolean matchesOn = HomeSections.isOn(app, HomeSections.MATCHES);
        stripMatches.setForceHidden(!matchesOn);
        if (!matchesOn) return;
        Async.io(() -> {
            List<SportsRepository.Match> ms;
            try {
                ms = SportsRepository.today();
            } catch (Exception e) {
                ms = new ArrayList<>();
            }
            final List<CardStrip.Card> cards = new ArrayList<>();
            java.text.SimpleDateFormat tf = new java.text.SimpleDateFormat("HH:mm", java.util.Locale.US);
            java.text.SimpleDateFormat df = new java.text.SimpleDateFormat("d/M", java.util.Locale.US);
            java.util.Calendar now = java.util.Calendar.getInstance();
            for (SportsRepository.Match m : ms) {
                CardStrip.Card c = new CardStrip.Card();
                c.kind = CardStrip.MATCH;
                c.league = m.league;
                c.home = m.home;
                c.away = m.away;
                c.homeLogo = m.homeLogo;
                c.awayLogo = m.awayLogo;
                java.util.Date start = new java.util.Date(m.start);
                if ("in".equals(m.state)) {
                    c.live = true;
                    c.badge = "مباشر " + m.clock;
                    c.score = m.awayScore + " - " + m.homeScore;
                } else if ("post".equals(m.state)) {
                    c.badge = "انتهت";
                    c.score = m.awayScore + " - " + m.homeScore;
                } else {
                    java.util.Calendar sc = java.util.Calendar.getInstance();
                    sc.setTime(start);
                    boolean sameDay = sc.get(java.util.Calendar.DAY_OF_YEAR) == now.get(java.util.Calendar.DAY_OF_YEAR)
                            && sc.get(java.util.Calendar.YEAR) == now.get(java.util.Calendar.YEAR);
                    c.badge = sameDay ? "اليوم" : df.format(start);
                    c.score = tf.format(start);
                }
                c.click = () -> {
                    if (isAdded()) PlayerActivity.startBrowse(requireActivity());
                };
                cards.add(c);
            }
            Async.main(() -> {
                if (!isAdded()) return;
                if (cards.isEmpty()) {
                    String err = SportsRepository.lastError;
                    stripMatches.setHint(err.isEmpty()
                            ? "لا توجد مباريات مهمة حالياً"
                            : "تعذر تحميل المباريات — تأكد من الإنترنت (" + err + ")");
                }
                stripMatches.set(cards);
            });
        });
    }

    private void load() {
        loadMatches();
        final Context app = requireContext().getApplicationContext();
        final int token = ++loadToken;
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            UserDao ud = UserDatabase.get(app).dao();
            long id = Prefs.getActive(app);
            final Playlist p = id < 0 ? null : db.dao().getPlaylist(id);

            List<Favorite> favs = new ArrayList<>();
            List<Favorite> favSeries = new ArrayList<>();
            List<History> follow = new ArrayList<>();
            List<Item> recent = new ArrayList<>();
            List<Item> arabic = new ArrayList<>();
            if (p != null) {
                favs = ud.favoritesOfTypeOldestFirst(p.id, "live", 200);
                favSeries = ud.favoritesOfTypeOldestFirst(p.id, "series", 200);
                // the newest episode is looked up for every favorite series
                for (Favorite f : favSeries) {
                    History h = ud.getHistory(p.id, "series", f.remoteId);
                    if (h == null) {
                        h = new History();
                        h.playlistId = p.id;
                        h.type = "series";
                        h.remoteId = f.remoteId;
                        h.name = nz(f.name);
                        h.icon = nz(f.icon);
                        h.episodeTitle = "";
                        h.streamUrl = "";
                        h.positionMs = 0;
                        h.updatedAt = f.addedAt;
                    }
                    follow.add(h);
                }
                recent = recentMix(db, p.id);
                arabic = arabicMix(db, p.id);
            }
            final List<Favorite> fFavs = favs;
            final List<Favorite> fFavSeries = favSeries;
            final List<History> fFollow = follow;
            final List<Item> fRecent = recent;
            final List<Item> fArabic = arabic;

            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                bind(p, fFavs, fFavSeries, fFollow, fRecent, fArabic);
            });

            if (p != null) {
                refreshFollow(app, p, fFollow, token);
            }
        });
    }

    /** Newest Arabic series first, then the other recently added series. */
    private static List<Item> recentMix(AppDatabase db, long pid) {
        List<Item> out = new ArrayList<>(db.dao().recentArabicSeries(pid, 20));
        Set<Long> seen = new java.util.HashSet<>();
        for (Item it : out) seen.add(it.id);
        if (out.size() < 12) {
            for (Item it : db.dao().recentSeries(pid, 600)) {
                if (out.size() >= 20) break;
                if (!seen.contains(it.id) && hasArabic(it.name)) {
                    out.add(it);
                    seen.add(it.id);
                }
            }
        }
        for (Item it : db.dao().recentSeries(pid, 40)) {
            if (out.size() >= 40) break;
            if (seen.add(it.id)) out.add(it);
        }
        return out;
    }

    /** Newest Arabic movies and TV programs, mixed and ordered by the date the provider added them. */
    private static List<Item> arabicMix(AppDatabase db, long pid) {
        List<Item> all = new ArrayList<>(db.dao().recentArabicMovies(pid, 40));
        all.addAll(db.dao().recentPrograms(pid, 40));
        java.util.Collections.sort(all, (a, b) -> Long.compare(b.added, a.added));
        return all.size() > 40 ? new ArrayList<>(all.subList(0, 40)) : all;
    }

    private static <T> List<T> reversed(List<T> in) {
        List<T> out = new ArrayList<>(in);
        java.util.Collections.reverse(out);
        return out;
    }

    private static boolean hasArabic(String s) {
        if (s == null) return false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x0600 && ch <= 0x06FF) return true;
        }
        return false;
    }

    private void bind(@Nullable Playlist p, List<Favorite> favs, List<Favorite> favSeries,
                      List<History> follow, List<Item> recent, List<Item> arabic) {
        final long pid = p == null ? -1 : p.id;
        activeId = pid;
        if (p == null) {
            status.setText("لا توجد قائمة مضافة بعد.\nأضف اشتراكك (Xtream أو M3U) لعرض القنوات والأفلام والمسلسلات.");
            status.setVisibility(View.VISIBLE);
        } else if (!status.getText().toString().startsWith("تعذر")) {
            status.setText("");
            status.setVisibility(View.GONE);
        }
        footer.setVisibility(pid < 0 ? View.VISIBLE : View.GONE);
        action.setOnClickListener(v -> ((MainActivity) requireActivity()).openAddPlaylist());
        final Context app = requireContext().getApplicationContext();
        applySizes(pid);
        stripFav.setForceHidden(pid < 0 || !HomeSections.isOn(app, HomeSections.FAV_LIVE));
        stripFavSeries.setForceHidden(pid < 0 || !HomeSections.isOn(app, HomeSections.FAV_SERIES));
        stripRecent.setForceHidden(pid < 0);
        stripArabic.setForceHidden(pid < 0);

        // Favorite channels
        bindFavs(pid, favs);

        // Favorite series, each followed by a card with its latest episode
        favSeriesList = favSeries;
        followList = follow;
        bindFollow();

        // Recently added series
        // the first card stays fixed at the right; newer cards are added to the left (swipe left)
        recentItems = recent;
        bindRecent();
        stripArabic.set(pid < 0 ? new ArrayList<CardStrip.Card>() : seriesCards(reversed(arabic)));

        // Sections added from the settings
        bindCustom(pid);
    }

    // ------------------------------------------------------- sections added by the user

    /** One row per section the user added (and switched on) in the settings. */
    private void bindCustom(final long pid) {
        if (customHost == null || !isAdded()) return;
        customHost.removeAllViews();
        if (pid < 0) return;
        final Context c = requireContext();
        final Context app = c.getApplicationContext();
        final int token = loadToken;
        for (final HomeSections.Section s : HomeSections.custom(app, pid)) {
            if (!s.on) continue;
            final CardStrip strip = new CardStrip(c, s.name, null);
            if ("live".equals(s.type)) {
                strip.setChannelSize(channelW, channelH);
            } else {
                strip.setPosterSize(cardW, posterH);
                strip.setInfoStrip(stripH);
            }
            strip.setMore("live".equals(s.type)
                    ? (Runnable) () -> { if (isAdded()) PlayerActivity.startBrowse(requireActivity()); }
                    : () -> { if (isAdded()) ((MainActivity) requireActivity())
                            .select("movie".equals(s.type) ? R.id.nav_movies : R.id.nav_series); });
            customHost.addView(strip.view, lp(c, 6));
            Async.io(() -> {
                final List<Item> items = AppDatabase.get(app).dao().getItems(pid, s.type, s.catId, 80, 0);
                Async.main(() -> {
                    if (!isAdded() || token != loadToken) return;
                    strip.set(customCards(s, items));
                });
            });
        }
    }

    private List<CardStrip.Card> customCards(final HomeSections.Section s, final List<Item> items) {
        final boolean live = "live".equals(s.type);
        final java.util.Map<String, String> names = new java.util.HashMap<>();
        names.put(s.catId, s.name);
        List<CardStrip.Card> cards = new ArrayList<>();
        for (int i = 0; i < items.size(); i++) {
            final Item it = items.get(i);
            final int number = i + 1;
            CardStrip.Card c = new CardStrip.Card();
            c.title = nz(it.name);
            c.image = nz(it.icon);
            if (live) {
                c.kind = CardStrip.CHANNEL;
                c.subtitle = nz(s.name);
                c.fallback = R.drawable.ic_live;
                c.click = () -> {
                    if (!isAdded()) return;
                    if (it.streamUrl == null || it.streamUrl.isEmpty()) return;
                    LiveQueue.set(items, names);
                    PlayerActivity.startLive(requireContext(), it.streamUrl, it.name, it.icon,
                            number, nz(s.name));
                };
            } else {
                c.kind = CardStrip.POSTER;
                c.rating = nz(it.rating);
                c.subtitle = metaOf(it);
                c.fallback = "movie".equals(s.type) ? R.drawable.ic_movie : R.drawable.ic_series;
                c.click = () -> {
                    if (!isAdded()) return;
                    if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                        PlayerActivity.start(requireContext(), it.streamUrl, it.name);
                    } else if ("series".equals(s.type)) {
                        SeriesPicker.show(requireActivity(), activeId, it.name, it.remoteId, it.icon);
                    }
                };
            }
            cards.add(c);
        }
        return cards;
    }

    private final java.util.Set<String> liveFavIds = new java.util.HashSet<>();

    /** Favorite channels row: each channel as a tile with its logo and name. */
    private void bindFavs(final long pid, final List<Favorite> favs) {
        liveFavIds.clear();
        for (Favorite f : favs) liveFavIds.add(f.remoteId);
        if (pid < 0) {
            stripFav.set(new ArrayList<CardStrip.Card>());
            return;
        }
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            // a channel without a logo of its own shows the logo of its package (beIN, MBC ...)
            final java.util.Map<String, String> logos = new java.util.HashMap<>();
            try {
                com.myiptv.app.data.AppDao dao = AppDatabase.get(app).dao();
                java.util.Map<String, String> catLogos = new java.util.HashMap<>();
                for (com.myiptv.app.data.CatLogo cl : dao.catLogos(pid)) {
                    if (cl.catId != null && cl.icon != null) catLogos.put(cl.catId, cl.icon);
                }
                com.myiptv.app.util.LogoBook book = com.myiptv.app.util.LogoBook.load(dao, pid);
                for (Favorite f : favs) {
                    if (com.myiptv.app.util.Ui.validLogo(f.icon)) continue;
                    String cat = dao.liveCategoryOf(pid, f.remoteId);
                    String pk = cat == null ? null : catLogos.get(cat);
                    String ext = com.myiptv.app.util.ExternalLogos.lookup(f.name);
                    String bl = book.findBrand(f.name);
                    String pick = com.myiptv.app.util.Ui.validLogo(pk) ? pk
                            : (ext != null ? ext : bl);
                    if (pick != null) logos.put(f.remoteId, pick);
                }
            } catch (Throwable ignored) {
                // no logo: the tile keeps its placeholder icon
            }
            Async.main(() -> {
                if (!isAdded()) return;
                List<CardStrip.Card> favCards = new ArrayList<>();
                for (final Favorite f : favs) {
                    CardStrip.Card c = new CardStrip.Card();
                    c.kind = CardStrip.CHANNEL;
                    c.title = nz(f.name);
                    String own = logos.get(f.remoteId);
                    boolean bein = "bein".equals(com.myiptv.app.util.Ui.brand(f.name));
                    boolean hasOwn = com.myiptv.app.util.Ui.validLogo(f.icon);
                    int local = hasOwn ? 0 : com.myiptv.app.util.LocalLogos.res(app, f.name);
                    if (local != 0) {
                        c.image = "";                       // bundled logo (beIN without a number, MBC ...)
                        c.fallback = local;
                    } else if (bein && !hasOwn) {
                        c.image = "";
                        c.fallback = R.drawable.logo_bein;
                    } else {
                        c.image = own != null ? own : nz(f.icon);
                        c.fallback = R.drawable.ic_live;
                    }
                    c.click = () -> openFavorite(f);
                    c.starred = true;
                    final Item asItem = new Item();
                    asItem.remoteId = f.remoteId;
                    asItem.name = f.name;
                    asItem.icon = f.icon;
                    asItem.streamUrl = f.streamUrl;
                    c.onStar = () -> toggleLiveFavorite(asItem);
                    favCards.add(c);
                }
                stripFav.set(favCards);
            });
        });
    }

    /** Star on a channel tile: adds / removes it from the favorites, which are shown first. */
    private void toggleLiveFavorite(final Item it) {
        if (!isAdded() || activeId < 0 || it.remoteId == null) return;
        final long pid = activeId;
        final boolean was = liveFavIds.contains(it.remoteId);
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (was) {
                ud.removeFavorite(pid, "live", it.remoteId);
                com.myiptv.app.util.Prefs.markHomeDirty();
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = "live";
                f.remoteId = it.remoteId;
                f.name = nz(it.name);
                f.icon = nz(it.icon);
                f.streamUrl = nz(it.streamUrl);
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
                com.myiptv.app.util.Prefs.markHomeDirty();
            }
            final List<Favorite> all = ud.favoritesOfTypeOldestFirst(pid, "live", 200);
            Async.main(() -> {
                if (!isAdded()) return;
                Toast.makeText(app, was ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
                bindFavs(pid, all);
            });
        });
    }

    private List<CardStrip.Card> seriesCards(List<Item> items) {
        List<CardStrip.Card> cards = new ArrayList<>();
        for (final Item it : items) {
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(it.name);
            c.image = nz(it.icon);
            c.rating = nz(it.rating);
            c.subtitle = metaOf(it);
            c.fallback = R.drawable.ic_series;
            c.click = () -> {
                if (!isAdded()) return;
                if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                    PlayerActivity.start(requireContext(), it.streamUrl, it.name);
                } else {
                    SeriesPicker.show(requireActivity(), activeId, it.name, it.remoteId, it.icon);
                }
            };
            cards.add(c);
        }
        return cards;
    }

    // ------------------------------------------------------- series I follow

    private static String latestKey(long pid, String seriesId) {
        return "latest_" + pid + "_" + seriesId;
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ');
    }

    @Nullable
    private static Latest readLatest(Context app, long pid, String seriesId) {
        String raw = Prefs.getString(app, latestKey(pid, seriesId));
        if (raw.isEmpty()) return null;
        String[] parts = raw.split("\t", -1);
        if (parts.length < 4) return null;
        Latest l = new Latest();
        try {
            l.time = Long.parseLong(parts[0]);
        } catch (NumberFormatException e) {
            return null;
        }
        l.label = parts[1];
        l.url = parts[2];
        l.title = parts[3];
        return l;
    }

    private static void writeLatest(Context app, long pid, String seriesId, String label,
                                    String url, String title) {
        Prefs.putString(app, latestKey(pid, seriesId), System.currentTimeMillis() + "\t"
                + clean(label) + "\t" + clean(url) + "\t" + clean(title));
    }

    // ---- daily download of the newest episode (Wi-Fi only, once per new episode)

    private static final class Dl {
        String url = "";
        long id = -1;
        String path = "";
    }

    private static String dlKey(long pid, String seriesId) {
        return "dl_" + pid + "_" + seriesId;
    }

    private static boolean autoDownloadOn(Context app) {
        return false; // downloads were removed from the app
    }

    @Nullable
    private static Dl readDl(Context app, long pid, String seriesId) {
        String[] p = Prefs.getString(app, dlKey(pid, seriesId)).split("\t", -1);
        if (p.length < 3) return null;
        Dl d = new Dl();
        d.url = p[0];
        d.path = p[2];
        try {
            d.id = Long.parseLong(p[1]);
        } catch (NumberFormatException e) {
            return null;
        }
        return d;
    }

    private static boolean dlFinished(Context app, Dl d) {
        try {
            DownloadManager dm = (DownloadManager) app.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return false;
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(d.id));
            if (c == null) return false;
            try {
                if (!c.moveToFirst()) return false;
                int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                return st == DownloadManager.STATUS_SUCCESSFUL && new File(d.path).length() > 0;
            } finally {
                c.close();
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** Queues a download of the episode (unless it was already queued). Returns true if queued. */
    private static boolean enqueueEpisode(Context app, long pid, String seriesId, String seriesName,
                                          SeriesRepository.Episode ep) {
        try {
            Dl old = readDl(app, pid, seriesId);
            if (old != null && old.url.equals(ep.url)) return false;
            DownloadManager dm = (DownloadManager) app.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return false;
            String fileName = (seriesName + " " + ep.shortLabel()).replaceAll("[\\\\/:*?\"<>|]", "_")
                    + "." + (ep.ext == null || ep.ext.isEmpty() ? "mp4" : ep.ext);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(ep.url));
            r.setTitle(seriesName + " - " + ep.shortLabel());
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            r.setDestinationInExternalFilesDir(app, Environment.DIRECTORY_MOVIES, fileName);
            long id = dm.enqueue(r);
            File dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            String path = new File(dir, fileName).getAbsolutePath();
            Prefs.putString(app, dlKey(pid, seriesId), clean(ep.url) + "\t" + id + "\t" + clean(path));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean watched(Context app, History h, Latest lt, @Nullable Dl dl) {
        if (Prefs.isSeen(app, h.playlistId, h.remoteId, lt.url, lt.label)) return true;
        if (lt.url.equals(h.streamUrl) || lt.label.equals(h.episodeTitle)) return true;
        return dl != null && h.streamUrl != null && h.streamUrl.equals(Uri.fromFile(new File(dl.path)).toString());
    }

    /** "الموسم 1 · الحلقة 12" -> "م1 ح12" (other texts are returned as they are). */
    private static String shortFromLong(String t) {
        if (t == null) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern
                .compile("(\\d+)\\D+(\\d+)").matcher(t);
        return m.find() ? "م" + m.group(1) + " ح" + m.group(2) : t;
    }

    /** Next episode after the one in the history, remembered until the history changes. */
    private static final class Next {
        String histUrl = "";
        String label = "";
        String longLabel = "";
        String url = "";
    }

    private static String nextKey(long pid, String seriesId) {
        return "next_" + pid + "_" + seriesId;
    }

    @Nullable
    private static Next readNext(Context app, long pid, String seriesId) {
        String[] p = Prefs.getString(app, nextKey(pid, seriesId)).split("\t", -1);
        if (p.length < 4) return null;
        Next n = new Next();
        n.histUrl = p[0];
        n.label = p[1];
        n.longLabel = p[2];
        n.url = p[3];
        return n;
    }

    private static void writeNext(Context app, long pid, String seriesId, String histUrl,
                                  String label, String longLabel, String url) {
        Prefs.putString(app, nextKey(pid, seriesId), clean(histUrl) + "\t" + clean(label) + "\t"
                + clean(longLabel) + "\t" + clean(url));
    }

    /** Scene image (a frame grabbed from the episode itself) of the episode a follow card points to. */
    private static String stillKey(long pid, String seriesId) {
        return "still_" + pid + "_" + seriesId;
    }

    /** Saved scene file path for this episode url; null = none yet (or a failed grab worth retrying). */
    @Nullable
    private static String readStill(Context app, long pid, String seriesId, String episodeUrl) {
        String[] p = Prefs.getString(app, stillKey(pid, seriesId)).split("\t", -1);
        if (p.length < 3 || episodeUrl == null || !p[0].equals(episodeUrl)) return null;
        if (!p[1].isEmpty()) return new java.io.File(p[1]).exists() ? p[1] : null;
        long t = 0;
        try { t = Long.parseLong(p[2]); } catch (NumberFormatException ignored) { }
        // a failed grab is retried after 6 hours; until then the full poster is shown
        return System.currentTimeMillis() - t > 6L * 3600L * 1000L ? null : "";
    }

    private static void writeStill(Context app, long pid, String seriesId, String episodeUrl,
                                   String path) {
        Prefs.putString(app, stillKey(pid, seriesId), clean(episodeUrl) + "\t" + clean(path) + "\t"
                + System.currentTimeMillis());
    }

    /** Grabs one frame of the episode video and saves it as a small jpg; returns its path or "". */
    private static String grabFrame(Context app, String url, long atMs) {
        android.media.MediaMetadataRetriever r = new android.media.MediaMetadataRetriever();
        try {
            r.setDataSource(url, new java.util.HashMap<String, String>());
            android.graphics.Bitmap b = r.getFrameAtTime(Math.max(0L, atMs) * 1000L,
                    android.media.MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (b == null) return "";
            int w = 480;
            int h = Math.max(1, b.getHeight() * w / Math.max(1, b.getWidth()));
            android.graphics.Bitmap sm = android.graphics.Bitmap.createScaledBitmap(b, w, h, true);
            java.io.File dir = new java.io.File(app.getFilesDir(), "stills");
            if (!dir.exists() && !dir.mkdirs()) return "";
            java.io.File f = new java.io.File(dir, "s" + Integer.toHexString(url.hashCode()) + ".jpg");
            java.io.FileOutputStream out = new java.io.FileOutputStream(f);
            try {
                sm.compress(android.graphics.Bitmap.CompressFormat.JPEG, 85, out);
            } finally {
                out.close();
            }
            return f.getAbsolutePath();
        } catch (Throwable t) {
            return "";
        } finally {
            try { r.release(); } catch (Throwable ignored) { }
        }
    }

    /** The episode is not finished and more than a minute of it is left. */
    private static boolean unfinished(History h) {
        if (h.streamUrl == null || h.streamUrl.isEmpty() || h.positionMs <= 0) return false;
        return h.durationMs <= 0 || h.durationMs - h.positionMs > 60000;
    }

    /**
     * Builds the favorite series row: every series is followed by a card for the episode to watch
     * next: the same episode (with a red bar of what was watched) while it is not finished, else the
     * episode after it. The newest episode the provider has goes to "recently added series".
     */
    private void bindFollow() {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final long pid = activeId;
        if (pid < 0) {
            stripFavSeries.set(new ArrayList<CardStrip.Card>());
            bindRecent();
            return;
        }
        Set<String> done = Prefs.getCompleted(app, pid);
        List<CardStrip.Card> cards = new ArrayList<>();
        for (int i = 0; i < favSeriesList.size(); i++) {
            final Favorite f = favSeriesList.get(i);
            CardStrip.Card sc = new CardStrip.Card();
            sc.kind = CardStrip.POSTER;
            sc.title = nz(f.name);
            sc.image = nz(f.icon);
            sc.fallback = R.drawable.ic_series;
            sc.click = () -> openFavorite(f);
            cards.add(sc);

            if (i >= followList.size() || done.contains(f.remoteId)) continue;
            final History h = followList.get(i);
            if (h.streamUrl == null || h.streamUrl.isEmpty()) continue;
            final Latest lt = readLatest(app, pid, h.remoteId);
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(h.name);
            c.image = nz(h.icon);
            c.fallback = R.drawable.ic_series;
            String target = "";
            if (unfinished(h)) {
                target = h.streamUrl;
                c.big = shortFromLong(h.episodeTitle);
                c.progress = h.durationMs > 0 ? (int) (h.positionMs * 100 / h.durationMs) : -1;
                c.click = () -> resume(h);
            } else {
                final Next nx = readNext(app, pid, h.remoteId);
                if (nx == null || !nx.histUrl.equals(h.streamUrl) || nx.url.isEmpty()) continue;
                target = nx.url;
                c.big = nx.label;
                c.eye = true;   // not watched yet
                c.click = () -> {
                    if (!isAdded()) return;
                    PlayerActivity.startTracked(requireContext(), nx.url, nz(h.name) + " - " + nx.label,
                            h.playlistId, "series", h.remoteId, h.name, h.icon, nx.longLabel, 0L);
                };
            }
            // a scene from the episode instead of the poster (the poster is the fallback)
            String still = readStill(app, pid, h.remoteId, target);
            if (still != null && !still.isEmpty()) c.image = still;
            c.longClick = () -> followOptions(h, lt);
            cards.add(c);
        }
        stripFavSeries.set(cards);
        bindRecent();
    }

    /**
     * "Recently added series": first (fixed) the newest episode of every favorite series, with the
     * episode number on the card, then the series the provider added lately.
     */
    private void bindRecent() {
        if (!isAdded() || stripRecent == null) return;
        final Context app = requireContext().getApplicationContext();
        final long pid = activeId;
        if (pid < 0) {
            stripRecent.set(new ArrayList<CardStrip.Card>());
            return;
        }
        List<CardStrip.Card> cards = new ArrayList<>();
        Set<String> done = Prefs.getCompleted(app, pid);
        for (int i = 0; i < favSeriesList.size() && i < followList.size(); i++) {
            Favorite f = favSeriesList.get(i);
            if (done.contains(f.remoteId)) continue;
            final History h = followList.get(i);
            final Latest lt = readLatest(app, pid, h.remoteId);
            if (lt == null || lt.label.isEmpty() || lt.url.isEmpty()) continue;
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(h.name);
            c.image = nz(h.icon);
            c.fallback = R.drawable.ic_series;
            Dl dl = readDl(app, pid, h.remoteId);
            boolean isDl = dl != null && dl.url.equals(lt.url) && dlFinished(app, dl);
            c.big = (isDl ? "⬇ " : "") + lt.label;
            c.eye = !watched(app, h, lt, dl);   // the eye is shown only while it has not been watched
            c.click = () -> playLatest(h, lt);
            c.longClick = () -> followOptions(h, lt);
            cards.add(c);
        }
        cards.addAll(seriesCards(reversed(recentItems)));
        stripRecent.set(cards);
    }

    /** Once every few hours asks the provider for the newest episode of each followed series. */
    private void refreshFollow(final Context app, final Playlist p, final List<History> follow,
                               final int token) {
        if (!"xtream".equals(p.type) || follow.isEmpty()) return;
        new Thread(() -> {
            boolean changed = false;
            Set<String> done = Prefs.getCompleted(app, p.id);
            final int[] dlCount = {0};
            for (History h : follow) {
                if (token != loadToken) return;
                if (done.contains(h.remoteId)) continue;
                // finished episode: find the one after it (once per history change)
                if (h.streamUrl != null && !h.streamUrl.isEmpty() && !unfinished(h)) {
                    Next nx = readNext(app, p.id, h.remoteId);
                    if (nx == null || !nx.histUrl.equals(h.streamUrl)) {
                        try {
                            SeriesRepository.Info inf = SeriesRepository.load(p, h.remoteId);
                            int at = -1;
                            for (int k = 0; k < inf.episodes.size(); k++) {
                                if (h.streamUrl.equals(inf.episodes.get(k).url)) { at = k; break; }
                            }
                            if (at >= 0 && at + 1 < inf.episodes.size()) {
                                SeriesRepository.Episode ne = inf.episodes.get(at + 1);
                                writeNext(app, p.id, h.remoteId, h.streamUrl, ne.shortLabel(),
                                        ne.longLabel(), ne.url);
                            } else {
                                writeNext(app, p.id, h.remoteId, h.streamUrl, "", "", "");
                            }
                            changed = true;
                        } catch (Exception ex) {
                            // try again next time
                        }
                    }
                }
                // scene image of the episode the follow card points to (fetched once per episode)
                try {
                    String target = "";
                    if (h.streamUrl != null && !h.streamUrl.isEmpty()) {
                        if (unfinished(h)) {
                            target = h.streamUrl;
                        } else {
                            Next n2 = readNext(app, p.id, h.remoteId);
                            if (n2 != null && n2.histUrl.equals(h.streamUrl)) target = n2.url;
                        }
                    }
                    if (!target.isEmpty() && readStill(app, p.id, h.remoteId, target) == null) {
                        long at = unfinished(h) ? h.positionMs : 90000L;
                        writeStill(app, p.id, h.remoteId, target, grabFrame(app, target, at));
                        changed = true;
                    }
                } catch (Exception ex) {
                    // try again next time
                }
                Latest old = readLatest(app, p.id, h.remoteId);
                long age = old == null ? Long.MAX_VALUE : System.currentTimeMillis() - old.time;
                if (age < 6L * 3600L * 1000L) continue;
                try {
                    SeriesRepository.Info inf = SeriesRepository.load(p, h.remoteId);
                    if (inf.episodes.isEmpty()) {
                        writeLatest(app, p.id, h.remoteId, "", "", "");
                    } else {
                        SeriesRepository.Episode last = inf.episodes.get(inf.episodes.size() - 1);
                        writeLatest(app, p.id, h.remoteId, last.shortLabel(), last.url, last.title);
                        Latest nl = new Latest();
                        nl.url = nz(last.url);
                        nl.label = last.shortLabel();
                        if (autoDownloadOn(app) && dlCount[0] < 3 && !nl.url.isEmpty()
                                && !watched(app, h, nl, readDl(app, p.id, h.remoteId))
                                && enqueueEpisode(app, p.id, h.remoteId, nz(h.name), last)) {
                            dlCount[0]++;
                            changed = true;
                        }
                    }
                    changed = true;
                } catch (Exception ex) {
                    // keep what we had and try again later
                    writeLatest(app, p.id, h.remoteId,
                            old == null ? "" : old.label,
                            old == null ? "" : old.url,
                            old == null ? "" : old.title);
                }
            }
            if (changed) {
                Async.main(() -> {
                    if (!isAdded() || token != loadToken) return;
                    bindFollow();
                });
            }
        }).start();
    }

    private void followOptions(final History h, @Nullable final Latest lt) {
        if (!isAdded()) return;
        final List<String> labels = new ArrayList<>();
        final List<Integer> actions = new ArrayList<>();
        if (lt != null && !lt.url.isEmpty()) {
            labels.add("▶ تشغيل آخر حلقة (" + lt.label + ")");
            actions.add(0);
        }
        labels.add("الحلقات والمواسم");
        actions.add(1);
        labels.add("✓ اكتمل المسلسل (إزالة من القائمة)");
        actions.add(2);
        new AlertDialog.Builder(requireContext())
                .setTitle(nz(h.name))
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    int a = actions.get(which);
                    if (a == 0 && lt != null) {
                        playLatest(h, lt);
                    } else if (a == 1) {
                        if (isAdded()) {
                            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
                        }
                    } else if (a == 2) {
                        markCompleted(h);
                    }
                })
                .show();
    }

    private void playLatest(History h, Latest lt) {
        if (!isAdded()) return;
        Context app = requireContext().getApplicationContext();
        Dl dl = readDl(app, activeId, h.remoteId);
        String url = lt.url;
        if (dl != null && dl.url.equals(lt.url) && dlFinished(app, dl)) {
            url = Uri.fromFile(new File(dl.path)).toString(); // play the downloaded copy
        }
        long pos = watched(app, h, lt, dl) && h.streamUrl != null && h.streamUrl.equals(url) ? h.positionMs : 0L;
        PlayerActivity.startTracked(requireContext(), url, nz(h.name) + " - " + lt.label,
                h.playlistId, "series", h.remoteId, h.name, h.icon, lt.label, pos);
    }

    private void downloadNow(final History h) {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final Playlist[] holder = new Playlist[1];
        Toast.makeText(app, "جارٍ التحضير للتنزيل…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                holder[0] = AppDatabase.get(app).dao().getPlaylist(activeId);
                SeriesRepository.Info inf = SeriesRepository.load(holder[0], h.remoteId);
                if (inf.episodes.isEmpty()) {
                    msg = "لا توجد حلقات";
                } else {
                    SeriesRepository.Episode last = inf.episodes.get(inf.episodes.size() - 1);
                    msg = enqueueEpisode(app, activeId, h.remoteId, nz(h.name), last)
                            ? "بدأ التنزيل: " + last.shortLabel() : "هذه الحلقة قيد التنزيل أو منزّلة";
                }
            } catch (Exception ex) {
                msg = "تعذر بدء التنزيل";
            }
            final String m = msg;
            Async.main(() -> Toast.makeText(app, m, Toast.LENGTH_SHORT).show());
        }).start();
    }

    private void markCompleted(History h) {
        if (!isAdded()) return;
        Prefs.setCompleted(requireContext().getApplicationContext(), activeId, h.remoteId, true);
        Toast.makeText(requireContext(), "اكتمل المسلسل وأُزيل من القائمة", Toast.LENGTH_SHORT).show();
        bindFollow();
    }

    // ---------------------------------------------------------------- actions

    private void play(String url, String title) {
        if (!isAdded() || url == null || url.isEmpty()) return;
        PlayerActivity.start(requireContext(), url, title);
    }

    private void openFavorite(Favorite f) {
        if (!isAdded()) return;
        if ("series".equals(f.type) && (f.streamUrl == null || f.streamUrl.isEmpty())) {
            SeriesPicker.show(requireActivity(), activeId, f.name, f.remoteId, f.icon);
        } else if ("live".equals(f.type) && f.streamUrl != null && !f.streamUrl.isEmpty()) {
            LiveQueue.clear();
            PlayerActivity.startLive(requireContext(), f.streamUrl, f.name, f.icon, 0, "بث مباشر");
        } else {
            play(f.streamUrl, f.name);
        }
    }

    private void resume(History h) {
        if (!isAdded()) return;
        if (h.streamUrl == null || h.streamUrl.isEmpty()) {
            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
            return;
        }
        PlayerActivity.startTracked(requireContext(), h.streamUrl, h.name + " - " + nz(h.episodeTitle),
                h.playlistId, "series", h.remoteId, h.name, h.icon, h.episodeTitle, h.positionMs);
    }

    private static int iconFor(String type) {
        if ("movie".equals(type)) return R.drawable.ic_movie;
        if ("series".equals(type)) return R.drawable.ic_series;
        return R.drawable.ic_live;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
