package com.myiptv.app.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SeriesRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.EpgRepository;
import com.myiptv.app.util.LiveQueue;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.SportsRepository;
import com.myiptv.app.util.Ui;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public class HomeFragment extends Fragment {
    private TextView status;
    private TextView action;
    private LinearLayout footer;
    private CardStrip stripMatches;
    private CardStrip stripFollow;
    private CardStrip stripFav;
    private CardStrip stripRecent;
    private CardStrip stripArabic;
    private long activeId = -1;
    private int loadToken;

    /** Provider guide entries and beIN channels, used to find a channel for a match. */
    private volatile List<EpgRepository.Match> epgMatches = new ArrayList<>();
    private volatile List<Item> beinList = new ArrayList<>();

    /** Series the user watches, newest first (filtered by the "completed" list when shown). */
    private List<History> followList = new ArrayList<>();

    /** Latest episode the provider has for a followed series (cached for 6 hours). */
    private static final class Latest {
        long time;
        String label = "";
        String url = "";
        String title = "";
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setSmoothScrollingEnabled(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 16);
        root.setPadding(pad, pad, pad, pad);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.muted));
        status.setTextSize(13);
        status.setLineSpacing(0, 1.3f);
        status.setVisibility(View.GONE);
        root.addView(status, lp(c, 0));

        stripMatches = new CardStrip(c, "مباريات اليوم", null);
        stripFollow = new CardStrip(c, "مسلسلات أتابعها", null);
        stripFav = new CardStrip(c, "المفضلة",
                "اضغط على النجمة ☆ بجانب أي قناة أو فيلم أو مسلسل ليظهر هنا.");
        stripRecent = new CardStrip(c, "مسلسلات أُضيفت حديثاً", null);
        stripArabic = new CardStrip(c, "مسلسلات وبرامج عربية أُضيفت مؤخراً", null);
        root.addView(stripFav.view, lp(c, 4));
        root.addView(stripMatches.view, lp(c, 18));
        root.addView(stripFollow.view, lp(c, 18));
        root.addView(stripArabic.view, lp(c, 18));
        root.addView(stripRecent.view, lp(c, 18));

        // only shown when no list has been added yet (lists are managed from "الإعدادات")
        footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.VERTICAL);
        action = Ui.button(c, "إضافة قائمة", true);
        footer.addView(action, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        footer.setVisibility(View.GONE);
        root.addView(footer, lp(c, 24));
        return scroll;
    }

    private static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(c, topDp);
        return p;
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        final Context app = requireContext().getApplicationContext();
        final int token = ++loadToken;
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            UserDao ud = UserDatabase.get(app).dao();
            long id = Prefs.getActive(app);
            final Playlist p = id < 0 ? null : db.dao().getPlaylist(id);

            List<Favorite> favs = new ArrayList<>();
            List<History> follow = new ArrayList<>();
            List<Item> recent = new ArrayList<>();
            List<Item> arabic = new ArrayList<>();
            List<Item> bein = new ArrayList<>();
            if (p != null) {
                favs = ud.favorites(p.id, 40);
                follow = new ArrayList<>(ud.recentHistory(p.id, "series", 30));
                // favorite series are followed too (the newest episode is looked up for them)
                Set<String> have = new java.util.HashSet<>();
                for (History h : follow) have.add(h.remoteId);
                for (Favorite f : ud.favoritesOfType(p.id, "series", 100)) {
                    if (have.contains(f.remoteId)) continue;
                    History h = new History();
                    h.playlistId = p.id;
                    h.type = "series";
                    h.remoteId = f.remoteId;
                    h.name = nz(f.name);
                    h.icon = nz(f.icon);
                    h.episodeTitle = "";
                    h.streamUrl = "";
                    h.positionMs = 0;
                    h.updatedAt = f.addedAt;
                    follow.add(h);
                }
                java.util.Collections.sort(follow, new java.util.Comparator<History>() {
                    @Override
                    public int compare(History a, History b) {
                        return Long.compare(b.updatedAt, a.updatedAt);
                    }
                });
                recent = db.dao().recentSeries(p.id, 20);
                arabic = arabicRecent(db, p.id);
                bein = db.dao().beinChannels(p.id, 24);
            }
            final List<Item> fArabic = arabic;
            final List<Favorite> fFavs = favs;
            final List<History> fFollow = follow;
            final List<Item> fRecent = recent;
            final List<Item> fBein = bein;
            beinList = bein;

            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                bind(p, fFavs, fFollow, fRecent, fArabic);
            });

            if (p != null) {
                refreshFollow(app, p, fFollow, token);
                loadMatches(p, fBein, token);
            } else {
                Async.main(() -> {
                    if (isAdded() && token == loadToken) stripMatches.set(new ArrayList<CardStrip.Card>());
                });
            }
        });
    }

    /** Newest series from Arabic packages; filled up with Arabic-titled ones if there are few. */
    private static List<Item> arabicRecent(AppDatabase db, long pid) {
        List<Item> out = new ArrayList<>(db.dao().recentArabicSeries(pid, 20));
        if (out.size() < 12) {
            Set<Long> seen = new java.util.HashSet<>();
            for (Item it : out) seen.add(it.id);
            for (Item it : db.dao().recentSeries(pid, 600)) {
                if (out.size() >= 20) break;
                if (!seen.contains(it.id) && hasArabic(it.name)) {
                    out.add(it);
                    seen.add(it.id);
                }
            }
        }
        return out;
    }

    private static boolean hasArabic(String s) {
        if (s == null) return false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x0600 && ch <= 0x06FF) return true;
        }
        return false;
    }

    private void bind(@Nullable Playlist p, List<Favorite> favs, List<History> follow,
                      List<Item> recent, List<Item> arabic) {
        final long pid = p == null ? -1 : p.id;
        activeId = pid;
        if (p == null) {
            status.setText("لا توجد قائمة مضافة بعد.\nأضف اشتراكك (Xtream أو M3U) لعرض القنوات والأفلام والمسلسلات.");
            status.setVisibility(View.VISIBLE);
        } else if (!status.getText().toString().startsWith("تعذر")) {
            status.setText("");
            status.setVisibility(View.GONE);
        }
        footer.setVisibility(pid < 0 ? View.VISIBLE : View.GONE);
        action.setOnClickListener(v -> ((MainActivity) requireActivity()).openAddPlaylist());
        stripFav.setForceHidden(pid < 0);

        // Series I follow (with the latest episode the provider has, and "completed" option)
        followList = follow;
        bindFollow();

        // Favorites
        bindFavs(pid, favs);

        // Recently added series (all, and Arabic ones)
        stripArabic.set(seriesCards(arabic));
        List<CardStrip.Card> recentCards = seriesCards(recent);
        stripRecent.set(recentCards);
    }

    private final java.util.Set<String> liveFavIds = new java.util.HashSet<>();
    private final List<CardStrip.Card> beinCards = new ArrayList<>();
    private final List<Item> beinCardItems = new ArrayList<>();

    private void bindFavs(long pid, List<Favorite> favs) {
        liveFavIds.clear();
        List<CardStrip.Card> favCards = new ArrayList<>();
        for (final Favorite f : favs) {
            if ("live".equals(f.type)) liveFavIds.add(f.remoteId);
            CardStrip.Card c = new CardStrip.Card();
            c.kind = "live".equals(f.type) ? CardStrip.CHANNEL : CardStrip.POSTER;
            c.title = nz(f.name);
            c.image = nz(f.icon);
            c.fallback = iconFor(f.type);
            c.click = () -> openFavorite(f);
            if ("live".equals(f.type)) {
                c.starred = true;
                final Item asItem = new Item();
                asItem.remoteId = f.remoteId;
                asItem.name = f.name;
                asItem.icon = f.icon;
                asItem.streamUrl = f.streamUrl;
                c.onStar = () -> toggleLiveFavorite(asItem);
            }
            favCards.add(c);
        }
        stripFav.set(pid < 0 ? new ArrayList<CardStrip.Card>() : favCards);
        // keep the stars on the channel row in step
        for (int i = 0; i < beinCards.size(); i++) {
            beinCards.get(i).starred = liveFavIds.contains(beinCardItems.get(i).remoteId);
        }
        stripMatches.refresh();
    }

    /** Star on a channel tile: adds / removes it from the favorites, which are shown first. */
    private void toggleLiveFavorite(final Item it) {
        if (!isAdded() || activeId < 0 || it.remoteId == null) return;
        final long pid = activeId;
        final boolean was = liveFavIds.contains(it.remoteId);
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (was) {
                ud.removeFavorite(pid, "live", it.remoteId);
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = "live";
                f.remoteId = it.remoteId;
                f.name = nz(it.name);
                f.icon = nz(it.icon);
                f.streamUrl = nz(it.streamUrl);
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
            }
            final List<Favorite> all = ud.favorites(pid, 40);
            Async.main(() -> {
                if (!isAdded()) return;
                Toast.makeText(app, was ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
                bindFavs(pid, all);
            });
        });
    }

    private List<CardStrip.Card> seriesCards(List<Item> items) {
        List<CardStrip.Card> cards = new ArrayList<>();
        for (final Item it : items) {
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(it.name);
            c.image = nz(it.icon);
            c.rating = nz(it.rating);
            c.fallback = R.drawable.ic_series;
            c.click = () -> {
                if (!isAdded()) return;
                if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                    PlayerActivity.start(requireContext(), it.streamUrl, it.name);
                } else {
                    SeriesPicker.show(requireActivity(), activeId, it.name, it.remoteId, it.icon);
                }
            };
            cards.add(c);
        }
        return cards;
    }

    // ------------------------------------------------------- series I follow

    private static String latestKey(long pid, String seriesId) {
        return "latest_" + pid + "_" + seriesId;
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ');
    }

    @Nullable
    private static Latest readLatest(Context app, long pid, String seriesId) {
        String raw = Prefs.getString(app, latestKey(pid, seriesId));
        if (raw.isEmpty()) return null;
        String[] parts = raw.split("\t", -1);
        if (parts.length < 4) return null;
        Latest l = new Latest();
        try {
            l.time = Long.parseLong(parts[0]);
        } catch (NumberFormatException e) {
            return null;
        }
        l.label = parts[1];
        l.url = parts[2];
        l.title = parts[3];
        return l;
    }

    private static void writeLatest(Context app, long pid, String seriesId, String label,
                                    String url, String title) {
        Prefs.putString(app, latestKey(pid, seriesId), System.currentTimeMillis() + "\t"
                + clean(label) + "\t" + clean(url) + "\t" + clean(title));
    }

    // ---- daily download of the newest episode (Wi-Fi only, once per new episode)

    private static final class Dl {
        String url = "";
        long id = -1;
        String path = "";
    }

    private static String dlKey(long pid, String seriesId) {
        return "dl_" + pid + "_" + seriesId;
    }

    private static boolean autoDownloadOn(Context app) {
        return !"off".equals(Prefs.getString(app, "auto_dl"));
    }

    @Nullable
    private static Dl readDl(Context app, long pid, String seriesId) {
        String[] p = Prefs.getString(app, dlKey(pid, seriesId)).split("\t", -1);
        if (p.length < 3) return null;
        Dl d = new Dl();
        d.url = p[0];
        d.path = p[2];
        try {
            d.id = Long.parseLong(p[1]);
        } catch (NumberFormatException e) {
            return null;
        }
        return d;
    }

    private static boolean dlFinished(Context app, Dl d) {
        try {
            DownloadManager dm = (DownloadManager) app.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return false;
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(d.id));
            if (c == null) return false;
            try {
                if (!c.moveToFirst()) return false;
                int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                return st == DownloadManager.STATUS_SUCCESSFUL && new File(d.path).length() > 0;
            } finally {
                c.close();
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** Queues a download of the episode (unless it was already queued). Returns true if queued. */
    private static boolean enqueueEpisode(Context app, long pid, String seriesId, String seriesName,
                                          SeriesRepository.Episode ep) {
        try {
            Dl old = readDl(app, pid, seriesId);
            if (old != null && old.url.equals(ep.url)) return false;
            DownloadManager dm = (DownloadManager) app.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return false;
            String fileName = (seriesName + " " + ep.shortLabel()).replaceAll("[\\\\/:*?\"<>|]", "_")
                    + "." + (ep.ext == null || ep.ext.isEmpty() ? "mp4" : ep.ext);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(ep.url));
            r.setTitle(seriesName + " - " + ep.shortLabel());
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            r.setDestinationInExternalFilesDir(app, Environment.DIRECTORY_MOVIES, fileName);
            long id = dm.enqueue(r);
            File dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            String path = new File(dir, fileName).getAbsolutePath();
            Prefs.putString(app, dlKey(pid, seriesId), clean(ep.url) + "\t" + id + "\t" + clean(path));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean watched(History h, Latest lt, @Nullable Dl dl) {
        if (lt.url.equals(h.streamUrl) || lt.label.equals(h.episodeTitle)) return true;
        return dl != null && h.streamUrl != null && h.streamUrl.equals(Uri.fromFile(new File(dl.path)).toString());
    }

    /** Builds the "series I follow" cards from the cached latest-episode data. */
    private void bindFollow() {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final long pid = activeId;
        Set<String> done = Prefs.getCompleted(app, pid);
        List<CardStrip.Card> cards = new ArrayList<>();
        for (final History h : followList) {
            if (done.contains(h.remoteId)) continue;
            final Latest lt = readLatest(app, pid, h.remoteId);
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(h.name);
            c.image = nz(h.icon);
            c.fallback = R.drawable.ic_series;
            if (lt != null && !lt.label.isEmpty()) {
                Dl dl = readDl(app, pid, h.remoteId);
                boolean isDl = dl != null && dl.url.equals(lt.url) && dlFinished(app, dl);
                boolean hasNew = !lt.url.isEmpty() && !watched(h, lt, dl);
                c.note = (isDl ? "⬇ " : "") + (hasNew ? "جديد · " : "") + lt.label;
            }
            final boolean noHistory = h.streamUrl == null || h.streamUrl.isEmpty();
            c.click = () -> {
                if (noHistory && lt != null && !lt.url.isEmpty()) playLatest(h, lt);
                else resume(h);
            };
            c.longClick = () -> followOptions(h, lt);
            cards.add(c);
        }
        stripFollow.set(cards);
    }

    /** Once every few hours asks the provider for the newest episode of each followed series. */
    private void refreshFollow(final Context app, final Playlist p, final List<History> follow,
                               final int token) {
        if (!"xtream".equals(p.type) || follow.isEmpty()) return;
        new Thread(() -> {
            boolean changed = false;
            Set<String> done = Prefs.getCompleted(app, p.id);
            final int[] dlCount = {0};
            for (History h : follow) {
                if (token != loadToken) return;
                if (done.contains(h.remoteId)) continue;
                Latest old = readLatest(app, p.id, h.remoteId);
                long age = old == null ? Long.MAX_VALUE : System.currentTimeMillis() - old.time;
                if (age < 6L * 3600L * 1000L) continue;
                try {
                    SeriesRepository.Info inf = SeriesRepository.load(p, h.remoteId);
                    if (inf.episodes.isEmpty()) {
                        writeLatest(app, p.id, h.remoteId, "", "", "");
                    } else {
                        SeriesRepository.Episode last = inf.episodes.get(inf.episodes.size() - 1);
                        writeLatest(app, p.id, h.remoteId, last.shortLabel(), last.url, last.title);
                        Latest nl = new Latest();
                        nl.url = nz(last.url);
                        nl.label = last.shortLabel();
                        if (autoDownloadOn(app) && dlCount[0] < 3 && !nl.url.isEmpty()
                                && !watched(h, nl, readDl(app, p.id, h.remoteId))
                                && enqueueEpisode(app, p.id, h.remoteId, nz(h.name), last)) {
                            dlCount[0]++;
                            changed = true;
                        }
                    }
                    changed = true;
                } catch (Exception ex) {
                    // keep what we had and try again later
                    writeLatest(app, p.id, h.remoteId,
                            old == null ? "" : old.label,
                            old == null ? "" : old.url,
                            old == null ? "" : old.title);
                }
            }
            if (changed) {
                Async.main(() -> {
                    if (!isAdded() || token != loadToken) return;
                    bindFollow();
                });
            }
        }).start();
    }

    private void followOptions(final History h, @Nullable final Latest lt) {
        if (!isAdded()) return;
        final List<String> labels = new ArrayList<>();
        final List<Integer> actions = new ArrayList<>();
        if (lt != null && !lt.url.isEmpty()) {
            labels.add("▶ تشغيل آخر حلقة (" + lt.label + ")");
            actions.add(0);
        }
        if (lt != null && !lt.url.isEmpty()) {
            labels.add("⬇ تنزيل آخر حلقة الآن");
            actions.add(3);
        }
        labels.add(autoDownloadOn(requireContext())
                ? "التنزيل التلقائي اليومي: مفعّل (اضغط للإيقاف)"
                : "التنزيل التلقائي اليومي: متوقف (اضغط للتفعيل)");
        actions.add(4);
        labels.add("الحلقات والمواسم");
        actions.add(1);
        labels.add("✓ اكتمل المسلسل (إزالة من القائمة)");
        actions.add(2);
        new AlertDialog.Builder(requireContext())
                .setTitle(nz(h.name))
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    int a = actions.get(which);
                    if (a == 0 && lt != null) {
                        playLatest(h, lt);
                    } else if (a == 1) {
                        if (isAdded()) {
                            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
                        }
                    } else if (a == 2) {
                        markCompleted(h);
                    } else if (a == 3 && lt != null) {
                        downloadNow(h);
                    } else if (a == 4) {
                        Context app = requireContext().getApplicationContext();
                        boolean on = autoDownloadOn(app);
                        Prefs.putString(app, "auto_dl", on ? "off" : "on");
                        Toast.makeText(app, on ? "تم إيقاف التنزيل التلقائي"
                                : "تم تفعيل التنزيل التلقائي (واي فاي فقط)", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void playLatest(History h, Latest lt) {
        if (!isAdded()) return;
        Context app = requireContext().getApplicationContext();
        Dl dl = readDl(app, activeId, h.remoteId);
        String url = lt.url;
        if (dl != null && dl.url.equals(lt.url) && dlFinished(app, dl)) {
            url = Uri.fromFile(new File(dl.path)).toString(); // play the downloaded copy
        }
        long pos = watched(h, lt, dl) && h.streamUrl != null && h.streamUrl.equals(url) ? h.positionMs : 0L;
        PlayerActivity.startTracked(requireContext(), url, nz(h.name) + " - " + lt.label,
                h.playlistId, "series", h.remoteId, h.name, h.icon, lt.label, pos);
    }

    private void downloadNow(final History h) {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final Playlist[] holder = new Playlist[1];
        Toast.makeText(app, "جارٍ التحضير للتنزيل…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                holder[0] = AppDatabase.get(app).dao().getPlaylist(activeId);
                SeriesRepository.Info inf = SeriesRepository.load(holder[0], h.remoteId);
                if (inf.episodes.isEmpty()) {
                    msg = "لا توجد حلقات";
                } else {
                    SeriesRepository.Episode last = inf.episodes.get(inf.episodes.size() - 1);
                    msg = enqueueEpisode(app, activeId, h.remoteId, nz(h.name), last)
                            ? "بدأ التنزيل: " + last.shortLabel() : "هذه الحلقة قيد التنزيل أو منزّلة";
                }
            } catch (Exception ex) {
                msg = "تعذر بدء التنزيل";
            }
            final String m = msg;
            Async.main(() -> Toast.makeText(app, m, Toast.LENGTH_SHORT).show());
        }).start();
    }

    private void markCompleted(History h) {
        if (!isAdded()) return;
        Prefs.setCompleted(requireContext().getApplicationContext(), activeId, h.remoteId, true);
        Toast.makeText(requireContext(), "اكتمل المسلسل وأُزيل من القائمة", Toast.LENGTH_SHORT).show();
        bindFollow();
    }

    // ---------------------------------------------------------------- matches

    private void loadMatches(final Playlist p, final List<Item> bein, final int token) {
        new Thread(() -> {
            // 1) matches with logos, scores and minute
            List<SportsRepository.Match> sports = new ArrayList<>();
            try {
                sports = SportsRepository.today();
            } catch (Exception ignored) {
                // fall back below
            }
            if (!sports.isEmpty()) {
                final List<CardStrip.Card> cards = new ArrayList<>();
                for (final SportsRepository.Match m : sports) cards.add(matchCard(m));
                Async.main(() -> {
                    if (!isAdded() || token != loadToken) return;
                    stripMatches.setTitle("مباريات اليوم");
                    stripMatches.set(cards);
                });
            }

            // 2) provider guide: lets a tapped match open the right channel
            List<EpgRepository.Match> epg = new ArrayList<>();
            if ("xtream".equals(p.type) && !bein.isEmpty()) {
                try {
                    epg = EpgRepository.load(p, bein);
                } catch (Exception ignored) {
                    // the channel picker is used instead
                }
            }
            epgMatches = epg;
            if (!sports.isEmpty()) return;

            // 3) no match data: show the guide entries, or the beIN channels
            final List<CardStrip.Card> cards = new ArrayList<>();
            long now = System.currentTimeMillis() / 1000L;
            boolean fallbackChannels = epg.isEmpty();
            if (!fallbackChannels) {
                for (final EpgRepository.Match m : epg) {
                    CardStrip.Card c = new CardStrip.Card();
                    c.kind = CardStrip.TEXT;
                    c.title = m.title;
                    c.subtitle = timeLabel(m.start) + " · " + m.channel;
                    c.badge = (m.start <= now && now < m.stop) ? "● الآن" : "";
                    c.click = () -> play(m.streamUrl, m.title);
                    cards.add(c);
                }
            } else {
                int n = 0;
                final List<CardStrip.Card> bc = new ArrayList<>();
                final List<Item> bi = new ArrayList<>();
                for (final Item it : bein) {
                    final int num = ++n;
                    CardStrip.Card c = new CardStrip.Card();
                    c.kind = CardStrip.CHANNEL;
                    c.title = nz(it.name);
                    c.image = nz(it.icon);
                    c.fallback = R.drawable.ic_live;
                    c.click = () -> playLive(it, num);
                    c.starred = liveFavIds.contains(it.remoteId);
                    c.onStar = () -> toggleLiveFavorite(it);
                    cards.add(c);
                    bc.add(c);
                    bi.add(it);
                }
                Async.main(() -> {
                    beinCards.clear();
                    beinCards.addAll(bc);
                    beinCardItems.clear();
                    beinCardItems.addAll(bi);
                });
            }
            final boolean ch = fallbackChannels;
            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                stripMatches.setTitle(ch ? "قنوات بي إن سبورت" : "أهم المباريات");
                stripMatches.set(cards);
            });
        }).start();
    }

    private CardStrip.Card matchCard(final SportsRepository.Match m) {
        CardStrip.Card c = new CardStrip.Card();
        c.kind = CardStrip.MATCH;
        c.league = m.league;
        c.home = m.home;
        c.away = m.away;
        c.homeLogo = m.homeLogo;
        c.awayLogo = m.awayLogo;
        c.live = "in".equals(m.state);
        if ("pre".equals(m.state)) {
            c.score = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date(m.start));
            c.badge = isTomorrow(m.start) ? "غداً" : "";
        } else {
            // left-to-right on screen: away team on the left, home team on the right
            c.score = m.awayScore + " - " + m.homeScore;
            if (c.live) c.badge = ("مباشر " + nz(m.clock)).trim();
            else c.badge = "انتهت";
        }
        c.click = () -> onMatchClick(m);
        return c;
    }

    private static boolean isTomorrow(long ms) {
        Calendar now = Calendar.getInstance();
        Calendar t = Calendar.getInstance();
        t.setTimeInMillis(ms);
        return t.get(Calendar.DAY_OF_YEAR) != now.get(Calendar.DAY_OF_YEAR)
                || t.get(Calendar.YEAR) != now.get(Calendar.YEAR);
    }

    private void onMatchClick(SportsRepository.Match m) {
        if (!isAdded()) return;
        EpgRepository.Match hit = findGuideEntry(m);
        if (hit != null) {
            Item ch = findChannel(hit.streamUrl);
            if (ch != null) playLive(ch, indexOf(ch));
            else play(hit.streamUrl, hit.channel);
            return;
        }
        chooseChannel();
    }

    private EpgRepository.Match findGuideEntry(SportsRepository.Match m) {
        List<EpgRepository.Match> list = epgMatches;
        EpgRepository.Match either = null;
        for (EpgRepository.Match e : list) {
            String t = e.title == null ? "" : e.title.toLowerCase(Locale.ROOT);
            boolean h = containsAny(t, m.homeNames);
            boolean a = containsAny(t, m.awayNames);
            if (h && a) return e;
            if ((h || a) && either == null) either = e;
        }
        return either;
    }

    private static boolean containsAny(String text, List<String> names) {
        for (String n : names) {
            if (text.contains(n.toLowerCase(Locale.ROOT))) return true;
        }
        return false;
    }

    private Item findChannel(String url) {
        if (url == null) return null;
        for (Item it : beinList) {
            if (url.equals(it.streamUrl)) return it;
        }
        return null;
    }

    private int indexOf(Item ch) {
        int i = beinList.indexOf(ch);
        return i < 0 ? 0 : i + 1;
    }

    private void chooseChannel() {
        final List<Item> list = beinList;
        if (list.isEmpty()) {
            Toast.makeText(requireContext(), "لا توجد قناة متاحة لهذه المباراة", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] names = new String[list.size()];
        for (int i = 0; i < names.length; i++) names[i] = nz(list.get(i).name);
        new AlertDialog.Builder(requireContext())
                .setTitle("اختر القناة")
                .setItems(names, (d, which) -> playLive(list.get(which), which + 1))
                .show();
    }

    // ---------------------------------------------------------------- actions

    private void play(String url, String title) {
        if (!isAdded() || url == null || url.isEmpty()) return;
        PlayerActivity.start(requireContext(), url, title);
    }

    private void playLive(Item it, int number) {
        if (!isAdded() || it.streamUrl == null || it.streamUrl.isEmpty()) return;
        LiveQueue.set(beinList, null);
        PlayerActivity.startLive(requireContext(), it.streamUrl, it.name, it.icon, number, "بث مباشر");
    }

    private void openFavorite(Favorite f) {
        if (!isAdded()) return;
        if ("series".equals(f.type) && (f.streamUrl == null || f.streamUrl.isEmpty())) {
            SeriesPicker.show(requireActivity(), activeId, f.name, f.remoteId, f.icon);
        } else if ("live".equals(f.type) && f.streamUrl != null && !f.streamUrl.isEmpty()) {
            LiveQueue.clear();
            PlayerActivity.startLive(requireContext(), f.streamUrl, f.name, f.icon, 0, "بث مباشر");
        } else {
            play(f.streamUrl, f.name);
        }
    }

    private void resume(History h) {
        if (!isAdded()) return;
        if (h.streamUrl == null || h.streamUrl.isEmpty()) {
            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
            return;
        }
        PlayerActivity.startTracked(requireContext(), h.streamUrl, h.name + " - " + nz(h.episodeTitle),
                h.playlistId, "series", h.remoteId, h.name, h.icon, h.episodeTitle, h.positionMs);
    }

    private static String timeLabel(long startSec) {
        Calendar now = Calendar.getInstance();
        Calendar start = Calendar.getInstance();
        start.setTimeInMillis(startSec * 1000L);
        String hm = new SimpleDateFormat("HH:mm", Locale.getDefault()).format(start.getTime());
        if (start.getTimeInMillis() <= System.currentTimeMillis()) return "بدأت " + hm;
        int dayDiff = start.get(Calendar.DAY_OF_YEAR) - now.get(Calendar.DAY_OF_YEAR);
        if (start.get(Calendar.YEAR) != now.get(Calendar.YEAR)) dayDiff = 2;
        if (dayDiff == 0) return "اليوم " + hm;
        if (dayDiff == 1) return "غداً " + hm;
        return new SimpleDateFormat("d/M HH:mm", Locale.getDefault()).format(start.getTime());
    }

    private static int iconFor(String type) {
        if ("movie".equals(type)) return R.drawable.ic_movie;
        if ("series".equals(type)) return R.drawable.ic_series;
        return R.drawable.ic_live;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
