package com.myiptv.app.ui;

import android.app.DownloadManager;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Environment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.myiptv.app.R;
import com.myiptv.app.data.AppDatabase;
import com.myiptv.app.data.Favorite;
import com.myiptv.app.data.History;
import com.myiptv.app.data.Item;
import com.myiptv.app.data.Playlist;
import com.myiptv.app.data.SeriesRepository;
import com.myiptv.app.data.UserDao;
import com.myiptv.app.data.UserDatabase;
import com.myiptv.app.util.Async;
import com.myiptv.app.util.LiveQueue;
import com.myiptv.app.util.Prefs;
import com.myiptv.app.util.Ui;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class HomeFragment extends Fragment {
    private TextView status;
    private TextView action;
    private LinearLayout footer;
    private CardStrip stripFav;
    private CardStrip stripFavSeries;
    private CardStrip stripRecent;
    private long activeId = -1;
    private int loadToken;

    /** Favorite series (with their watch history when there is one), used for "new episodes". */
    private List<History> followList = new ArrayList<>();
    /** The favorite series, in the same order as {@link #followList}. */
    private List<Favorite> favSeriesList = new ArrayList<>();

    /** Latest episode the provider has for a followed series (cached for 6 hours). */
    private static final class Latest {
        long time;
        String label = "";
        String url = "";
        String title = "";
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        Context c = requireContext();
        ScrollView scroll = new ScrollView(c);
        scroll.setFillViewport(true);
        scroll.setSmoothScrollingEnabled(true);

        LinearLayout root = new LinearLayout(c);
        root.setOrientation(LinearLayout.VERTICAL);
        int pad = Ui.dp(c, 8);
        root.setPadding(pad, pad, pad, pad);
        root.setClipChildren(false);
        scroll.setClipChildren(false);
        scroll.addView(root, new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        status = new TextView(c);
        status.setTextColor(ContextCompat.getColor(c, R.color.muted));
        status.setTextSize(13);
        status.setLineSpacing(0, 1.3f);
        status.setVisibility(View.GONE);
        root.addView(status, lp(c, 0));

        stripFav = new CardStrip(c, "القنوات المفضلة",
                "اضغط على النجمة ☆ بجانب أي قناة لتظهر هنا.");
        stripFavSeries = new CardStrip(c, "مسلسلات مفضلة",
                "أضف مسلسلاً إلى المفضلة ليظهر هنا مع آخر حلقة له.");
        stripRecent = new CardStrip(c, "مسلسلات أضيفت حديثاً", null);
        // the two series rows use bigger cards than the channels row
        stripFavSeries.setPosterSize(88, 122);
        stripRecent.setPosterSize(88, 122);

        // three horizontal sections on one page
        root.addView(stripFav.view, lp(c, 0));
        root.addView(stripFavSeries.view, lp(c, 6));
        root.addView(stripRecent.view, lp(c, 6));

        // only shown when no list has been added yet (lists are managed from "الإعدادات")
        footer = new LinearLayout(c);
        footer.setOrientation(LinearLayout.VERTICAL);
        action = Ui.button(c, "إضافة قائمة", true);
        footer.addView(action, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        footer.setVisibility(View.GONE);
        root.addView(footer, lp(c, 24));

        // snowballs live under the scrolling content, so the cards and texts stay on top of them
        FrameLayout page = new FrameLayout(c);
        page.setClipChildren(false);
        page.addView(new SnowView(c, 34, 11L), new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        page.addView(scroll, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        return page;
    }

    private static LinearLayout.LayoutParams lp(Context c, int topDp) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.topMargin = Ui.dp(c, topDp);
        return p;
    }

    @Override
    public void onResume() {
        super.onResume();
        load();
    }

    private void load() {
        final Context app = requireContext().getApplicationContext();
        final int token = ++loadToken;
        Async.io(() -> {
            AppDatabase db = AppDatabase.get(app);
            UserDao ud = UserDatabase.get(app).dao();
            long id = Prefs.getActive(app);
            final Playlist p = id < 0 ? null : db.dao().getPlaylist(id);

            List<Favorite> favs = new ArrayList<>();
            List<Favorite> favSeries = new ArrayList<>();
            List<History> follow = new ArrayList<>();
            List<Item> recent = new ArrayList<>();
            if (p != null) {
                favs = ud.favoritesOfType(p.id, "live", 200);
                favSeries = ud.favoritesOfType(p.id, "series", 200);
                // the newest episode is looked up for every favorite series
                for (Favorite f : favSeries) {
                    History h = ud.getHistory(p.id, "series", f.remoteId);
                    if (h == null) {
                        h = new History();
                        h.playlistId = p.id;
                        h.type = "series";
                        h.remoteId = f.remoteId;
                        h.name = nz(f.name);
                        h.icon = nz(f.icon);
                        h.episodeTitle = "";
                        h.streamUrl = "";
                        h.positionMs = 0;
                        h.updatedAt = f.addedAt;
                    }
                    follow.add(h);
                }
                recent = recentMix(db, p.id);
            }
            final List<Favorite> fFavs = favs;
            final List<Favorite> fFavSeries = favSeries;
            final List<History> fFollow = follow;
            final List<Item> fRecent = recent;

            Async.main(() -> {
                if (!isAdded() || token != loadToken) return;
                bind(p, fFavs, fFavSeries, fFollow, fRecent);
            });

            if (p != null) {
                refreshFollow(app, p, fFollow, token);
            }
        });
    }

    /** Newest Arabic series first, then the other recently added series. */
    private static List<Item> recentMix(AppDatabase db, long pid) {
        List<Item> out = new ArrayList<>(db.dao().recentArabicSeries(pid, 20));
        Set<Long> seen = new java.util.HashSet<>();
        for (Item it : out) seen.add(it.id);
        if (out.size() < 12) {
            for (Item it : db.dao().recentSeries(pid, 600)) {
                if (out.size() >= 20) break;
                if (!seen.contains(it.id) && hasArabic(it.name)) {
                    out.add(it);
                    seen.add(it.id);
                }
            }
        }
        for (Item it : db.dao().recentSeries(pid, 40)) {
            if (out.size() >= 40) break;
            if (seen.add(it.id)) out.add(it);
        }
        return out;
    }

    private static boolean hasArabic(String s) {
        if (s == null) return false;
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch >= 0x0600 && ch <= 0x06FF) return true;
        }
        return false;
    }

    private void bind(@Nullable Playlist p, List<Favorite> favs, List<Favorite> favSeries,
                      List<History> follow, List<Item> recent) {
        final long pid = p == null ? -1 : p.id;
        activeId = pid;
        if (p == null) {
            status.setText("لا توجد قائمة مضافة بعد.\nأضف اشتراكك (Xtream أو M3U) لعرض القنوات والأفلام والمسلسلات.");
            status.setVisibility(View.VISIBLE);
        } else if (!status.getText().toString().startsWith("تعذر")) {
            status.setText("");
            status.setVisibility(View.GONE);
        }
        footer.setVisibility(pid < 0 ? View.VISIBLE : View.GONE);
        action.setOnClickListener(v -> ((MainActivity) requireActivity()).openAddPlaylist());
        stripFav.setForceHidden(pid < 0);
        stripFavSeries.setForceHidden(pid < 0);
        stripRecent.setForceHidden(pid < 0);

        // Favorite channels
        bindFavs(pid, favs);

        // Favorite series, each followed by a card with its latest episode
        favSeriesList = favSeries;
        followList = follow;
        bindFollow();

        // Recently added series
        stripRecent.set(pid < 0 ? new ArrayList<CardStrip.Card>() : seriesCards(recent));
    }

    private final java.util.Set<String> liveFavIds = new java.util.HashSet<>();

    /** Favorite channels row: each channel as a tile with its logo and name. */
    private void bindFavs(long pid, List<Favorite> favs) {
        liveFavIds.clear();
        List<CardStrip.Card> favCards = new ArrayList<>();
        for (final Favorite f : favs) {
            liveFavIds.add(f.remoteId);
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.CHANNEL;
            c.title = nz(f.name);
            c.image = nz(f.icon);
            c.fallback = R.drawable.ic_live;
            c.click = () -> openFavorite(f);
            c.starred = true;
            final Item asItem = new Item();
            asItem.remoteId = f.remoteId;
            asItem.name = f.name;
            asItem.icon = f.icon;
            asItem.streamUrl = f.streamUrl;
            c.onStar = () -> toggleLiveFavorite(asItem);
            favCards.add(c);
        }
        stripFav.set(pid < 0 ? new ArrayList<CardStrip.Card>() : favCards);
    }

    /** Star on a channel tile: adds / removes it from the favorites, which are shown first. */
    private void toggleLiveFavorite(final Item it) {
        if (!isAdded() || activeId < 0 || it.remoteId == null) return;
        final long pid = activeId;
        final boolean was = liveFavIds.contains(it.remoteId);
        final Context app = requireContext().getApplicationContext();
        Async.io(() -> {
            UserDao ud = UserDatabase.get(app).dao();
            if (was) {
                ud.removeFavorite(pid, "live", it.remoteId);
            } else {
                Favorite f = new Favorite();
                f.playlistId = pid;
                f.type = "live";
                f.remoteId = it.remoteId;
                f.name = nz(it.name);
                f.icon = nz(it.icon);
                f.streamUrl = nz(it.streamUrl);
                f.addedAt = System.currentTimeMillis();
                ud.putFavorite(f);
            }
            final List<Favorite> all = ud.favoritesOfType(pid, "live", 200);
            Async.main(() -> {
                if (!isAdded()) return;
                Toast.makeText(app, was ? "أُزيل من المفضلة" : "أُضيف إلى المفضلة", Toast.LENGTH_SHORT).show();
                bindFavs(pid, all);
            });
        });
    }

    private List<CardStrip.Card> seriesCards(List<Item> items) {
        List<CardStrip.Card> cards = new ArrayList<>();
        for (final Item it : items) {
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(it.name);
            c.image = nz(it.icon);
            c.rating = nz(it.rating);
            c.fallback = R.drawable.ic_series;
            c.click = () -> {
                if (!isAdded()) return;
                if (it.streamUrl != null && !it.streamUrl.isEmpty()) {
                    PlayerActivity.start(requireContext(), it.streamUrl, it.name);
                } else {
                    SeriesPicker.show(requireActivity(), activeId, it.name, it.remoteId, it.icon);
                }
            };
            cards.add(c);
        }
        return cards;
    }

    // ------------------------------------------------------- series I follow

    private static String latestKey(long pid, String seriesId) {
        return "latest_" + pid + "_" + seriesId;
    }

    private static String clean(String s) {
        return s == null ? "" : s.replace('\t', ' ').replace('\n', ' ');
    }

    @Nullable
    private static Latest readLatest(Context app, long pid, String seriesId) {
        String raw = Prefs.getString(app, latestKey(pid, seriesId));
        if (raw.isEmpty()) return null;
        String[] parts = raw.split("\t", -1);
        if (parts.length < 4) return null;
        Latest l = new Latest();
        try {
            l.time = Long.parseLong(parts[0]);
        } catch (NumberFormatException e) {
            return null;
        }
        l.label = parts[1];
        l.url = parts[2];
        l.title = parts[3];
        return l;
    }

    private static void writeLatest(Context app, long pid, String seriesId, String label,
                                    String url, String title) {
        Prefs.putString(app, latestKey(pid, seriesId), System.currentTimeMillis() + "\t"
                + clean(label) + "\t" + clean(url) + "\t" + clean(title));
    }

    // ---- daily download of the newest episode (Wi-Fi only, once per new episode)

    private static final class Dl {
        String url = "";
        long id = -1;
        String path = "";
    }

    private static String dlKey(long pid, String seriesId) {
        return "dl_" + pid + "_" + seriesId;
    }

    private static boolean autoDownloadOn(Context app) {
        return !"off".equals(Prefs.getString(app, "auto_dl"));
    }

    @Nullable
    private static Dl readDl(Context app, long pid, String seriesId) {
        String[] p = Prefs.getString(app, dlKey(pid, seriesId)).split("\t", -1);
        if (p.length < 3) return null;
        Dl d = new Dl();
        d.url = p[0];
        d.path = p[2];
        try {
            d.id = Long.parseLong(p[1]);
        } catch (NumberFormatException e) {
            return null;
        }
        return d;
    }

    private static boolean dlFinished(Context app, Dl d) {
        try {
            DownloadManager dm = (DownloadManager) app.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return false;
            Cursor c = dm.query(new DownloadManager.Query().setFilterById(d.id));
            if (c == null) return false;
            try {
                if (!c.moveToFirst()) return false;
                int st = c.getInt(c.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS));
                return st == DownloadManager.STATUS_SUCCESSFUL && new File(d.path).length() > 0;
            } finally {
                c.close();
            }
        } catch (Exception e) {
            return false;
        }
    }

    /** Queues a download of the episode (unless it was already queued). Returns true if queued. */
    private static boolean enqueueEpisode(Context app, long pid, String seriesId, String seriesName,
                                          SeriesRepository.Episode ep) {
        try {
            Dl old = readDl(app, pid, seriesId);
            if (old != null && old.url.equals(ep.url)) return false;
            DownloadManager dm = (DownloadManager) app.getSystemService(Context.DOWNLOAD_SERVICE);
            if (dm == null) return false;
            String fileName = (seriesName + " " + ep.shortLabel()).replaceAll("[\\\\/:*?\"<>|]", "_")
                    + "." + (ep.ext == null || ep.ext.isEmpty() ? "mp4" : ep.ext);
            DownloadManager.Request r = new DownloadManager.Request(Uri.parse(ep.url));
            r.setTitle(seriesName + " - " + ep.shortLabel());
            r.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            r.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI);
            r.setDestinationInExternalFilesDir(app, Environment.DIRECTORY_MOVIES, fileName);
            long id = dm.enqueue(r);
            File dir = app.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
            String path = new File(dir, fileName).getAbsolutePath();
            Prefs.putString(app, dlKey(pid, seriesId), clean(ep.url) + "\t" + id + "\t" + clean(path));
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static boolean watched(Context app, History h, Latest lt, @Nullable Dl dl) {
        if (Prefs.isSeen(app, h.playlistId, h.remoteId, lt.url, lt.label)) return true;
        if (lt.url.equals(h.streamUrl) || lt.label.equals(h.episodeTitle)) return true;
        return dl != null && h.streamUrl != null && h.streamUrl.equals(Uri.fromFile(new File(dl.path)).toString());
    }

    /**
     * Builds the favorite series row: every series is followed by a separate card with its newest
     * episode (episode number written on it); tapping that card plays the episode directly.
     */
    private void bindFollow() {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final long pid = activeId;
        if (pid < 0) {
            stripFavSeries.set(new ArrayList<CardStrip.Card>());
            return;
        }
        Set<String> done = Prefs.getCompleted(app, pid);
        List<CardStrip.Card> cards = new ArrayList<>();
        for (int i = 0; i < favSeriesList.size(); i++) {
            final Favorite f = favSeriesList.get(i);
            CardStrip.Card sc = new CardStrip.Card();
            sc.kind = CardStrip.POSTER;
            sc.title = nz(f.name);
            sc.image = nz(f.icon);
            sc.fallback = R.drawable.ic_series;
            sc.click = () -> openFavorite(f);
            cards.add(sc);

            if (i >= followList.size() || done.contains(f.remoteId)) continue;
            final History h = followList.get(i);
            final Latest lt = readLatest(app, pid, h.remoteId);
            if (lt == null || lt.label.isEmpty() || lt.url.isEmpty()) continue;
            CardStrip.Card c = new CardStrip.Card();
            c.kind = CardStrip.POSTER;
            c.title = nz(h.name);
            c.image = nz(h.icon);
            c.fallback = R.drawable.ic_series;
            Dl dl = readDl(app, pid, h.remoteId);
            boolean isDl = dl != null && dl.url.equals(lt.url) && dlFinished(app, dl);
            boolean hasNew = !watched(app, h, lt, dl);
            c.big = (isDl ? "⬇ " : "") + lt.label;
            c.eye = hasNew;   // the eye is shown only while the episode has not been watched
            c.click = () -> playLatest(h, lt);   // opens the episode directly
            c.longClick = () -> followOptions(h, lt);
            cards.add(c);
        }
        stripFavSeries.set(cards);
    }

    /** Once every few hours asks the provider for the newest episode of each followed series. */
    private void refreshFollow(final Context app, final Playlist p, final List<History> follow,
                               final int token) {
        if (!"xtream".equals(p.type) || follow.isEmpty()) return;
        new Thread(() -> {
            boolean changed = false;
            Set<String> done = Prefs.getCompleted(app, p.id);
            final int[] dlCount = {0};
            for (History h : follow) {
                if (token != loadToken) return;
                if (done.contains(h.remoteId)) continue;
                Latest old = readLatest(app, p.id, h.remoteId);
                long age = old == null ? Long.MAX_VALUE : System.currentTimeMillis() - old.time;
                if (age < 6L * 3600L * 1000L) continue;
                try {
                    SeriesRepository.Info inf = SeriesRepository.load(p, h.remoteId);
                    if (inf.episodes.isEmpty()) {
                        writeLatest(app, p.id, h.remoteId, "", "", "");
                    } else {
                        SeriesRepository.Episode last = inf.episodes.get(inf.episodes.size() - 1);
                        writeLatest(app, p.id, h.remoteId, last.shortLabel(), last.url, last.title);
                        Latest nl = new Latest();
                        nl.url = nz(last.url);
                        nl.label = last.shortLabel();
                        if (autoDownloadOn(app) && dlCount[0] < 3 && !nl.url.isEmpty()
                                && !watched(app, h, nl, readDl(app, p.id, h.remoteId))
                                && enqueueEpisode(app, p.id, h.remoteId, nz(h.name), last)) {
                            dlCount[0]++;
                            changed = true;
                        }
                    }
                    changed = true;
                } catch (Exception ex) {
                    // keep what we had and try again later
                    writeLatest(app, p.id, h.remoteId,
                            old == null ? "" : old.label,
                            old == null ? "" : old.url,
                            old == null ? "" : old.title);
                }
            }
            if (changed) {
                Async.main(() -> {
                    if (!isAdded() || token != loadToken) return;
                    bindFollow();
                });
            }
        }).start();
    }

    private void followOptions(final History h, @Nullable final Latest lt) {
        if (!isAdded()) return;
        final List<String> labels = new ArrayList<>();
        final List<Integer> actions = new ArrayList<>();
        if (lt != null && !lt.url.isEmpty()) {
            labels.add("▶ تشغيل آخر حلقة (" + lt.label + ")");
            actions.add(0);
        }
        if (lt != null && !lt.url.isEmpty()) {
            labels.add("⬇ تنزيل آخر حلقة الآن");
            actions.add(3);
        }
        labels.add(autoDownloadOn(requireContext())
                ? "التنزيل التلقائي اليومي: مفعّل (اضغط للإيقاف)"
                : "التنزيل التلقائي اليومي: متوقف (اضغط للتفعيل)");
        actions.add(4);
        labels.add("الحلقات والمواسم");
        actions.add(1);
        labels.add("✓ اكتمل المسلسل (إزالة من القائمة)");
        actions.add(2);
        new AlertDialog.Builder(requireContext())
                .setTitle(nz(h.name))
                .setItems(labels.toArray(new String[0]), (d, which) -> {
                    int a = actions.get(which);
                    if (a == 0 && lt != null) {
                        playLatest(h, lt);
                    } else if (a == 1) {
                        if (isAdded()) {
                            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
                        }
                    } else if (a == 2) {
                        markCompleted(h);
                    } else if (a == 3 && lt != null) {
                        downloadNow(h);
                    } else if (a == 4) {
                        Context app = requireContext().getApplicationContext();
                        boolean on = autoDownloadOn(app);
                        Prefs.putString(app, "auto_dl", on ? "off" : "on");
                        Toast.makeText(app, on ? "تم إيقاف التنزيل التلقائي"
                                : "تم تفعيل التنزيل التلقائي (واي فاي فقط)", Toast.LENGTH_SHORT).show();
                    }
                })
                .show();
    }

    private void playLatest(History h, Latest lt) {
        if (!isAdded()) return;
        Context app = requireContext().getApplicationContext();
        Dl dl = readDl(app, activeId, h.remoteId);
        String url = lt.url;
        if (dl != null && dl.url.equals(lt.url) && dlFinished(app, dl)) {
            url = Uri.fromFile(new File(dl.path)).toString(); // play the downloaded copy
        }
        long pos = watched(app, h, lt, dl) && h.streamUrl != null && h.streamUrl.equals(url) ? h.positionMs : 0L;
        PlayerActivity.startTracked(requireContext(), url, nz(h.name) + " - " + lt.label,
                h.playlistId, "series", h.remoteId, h.name, h.icon, lt.label, pos);
    }

    private void downloadNow(final History h) {
        if (!isAdded()) return;
        final Context app = requireContext().getApplicationContext();
        final Playlist[] holder = new Playlist[1];
        Toast.makeText(app, "جارٍ التحضير للتنزيل…", Toast.LENGTH_SHORT).show();
        new Thread(() -> {
            String msg;
            try {
                holder[0] = AppDatabase.get(app).dao().getPlaylist(activeId);
                SeriesRepository.Info inf = SeriesRepository.load(holder[0], h.remoteId);
                if (inf.episodes.isEmpty()) {
                    msg = "لا توجد حلقات";
                } else {
                    SeriesRepository.Episode last = inf.episodes.get(inf.episodes.size() - 1);
                    msg = enqueueEpisode(app, activeId, h.remoteId, nz(h.name), last)
                            ? "بدأ التنزيل: " + last.shortLabel() : "هذه الحلقة قيد التنزيل أو منزّلة";
                }
            } catch (Exception ex) {
                msg = "تعذر بدء التنزيل";
            }
            final String m = msg;
            Async.main(() -> Toast.makeText(app, m, Toast.LENGTH_SHORT).show());
        }).start();
    }

    private void markCompleted(History h) {
        if (!isAdded()) return;
        Prefs.setCompleted(requireContext().getApplicationContext(), activeId, h.remoteId, true);
        Toast.makeText(requireContext(), "اكتمل المسلسل وأُزيل من القائمة", Toast.LENGTH_SHORT).show();
        bindFollow();
    }

    // ---------------------------------------------------------------- actions

    private void play(String url, String title) {
        if (!isAdded() || url == null || url.isEmpty()) return;
        PlayerActivity.start(requireContext(), url, title);
    }

    private void openFavorite(Favorite f) {
        if (!isAdded()) return;
        if ("series".equals(f.type) && (f.streamUrl == null || f.streamUrl.isEmpty())) {
            SeriesPicker.show(requireActivity(), activeId, f.name, f.remoteId, f.icon);
        } else if ("live".equals(f.type) && f.streamUrl != null && !f.streamUrl.isEmpty()) {
            LiveQueue.clear();
            PlayerActivity.startLive(requireContext(), f.streamUrl, f.name, f.icon, 0, "بث مباشر");
        } else {
            play(f.streamUrl, f.name);
        }
    }

    private void resume(History h) {
        if (!isAdded()) return;
        if (h.streamUrl == null || h.streamUrl.isEmpty()) {
            SeriesPicker.show(requireActivity(), activeId, h.name, h.remoteId, h.icon);
            return;
        }
        PlayerActivity.startTracked(requireContext(), h.streamUrl, h.name + " - " + nz(h.episodeTitle),
                h.playlistId, "series", h.remoteId, h.name, h.icon, h.episodeTitle, h.positionMs);
    }

    private static int iconFor(String type) {
        if ("movie".equals(type)) return R.drawable.ic_movie;
        if ("series".equals(type)) return R.drawable.ic_series;
        return R.drawable.ic_live;
    }

    private static String nz(String s) {
        return s == null ? "" : s;
    }
}
